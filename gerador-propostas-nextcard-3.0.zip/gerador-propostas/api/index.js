// Entrada única da API na Vercel (vercel.json reescreve /api/* para cá).
import { handler } from '../server/app.js';
export const config = { api: { bodyParser: false } };
export default handler;
