# Gerador de Propostas NEXTCARD 3.0 — regras permanentes do projeto

Leia primeiro: `docs/IMPLEMENTATION_PLAN.md` (estado e backlog) e `docs/COMMERCIAL_RULES.md` (regras e pendências de aprovação).

## Regras que não mudam
- Não reconstruir do zero. Motor de cálculo (`src/core.js`), catálogo, prévia e renderização (`src/render.js`) são preservados.
- Valor monetário sempre em centavos inteiros. Zero é valor válido (nunca `||` para testar preço).
- A fonte oficial de dados é o servidor (`server/`, PostgreSQL). `localStorage` só para preferência visual e cache.
- Toda permissão é verificada em `server/app.js`. Esconder botão não é controle.
- O preço oficial é recalculado no servidor em `server/policy.js` a cada emissão. Nunca confiar em `tabela`, `tiers` ou totais vindos do navegador.
- Versão emitida (`proposta_versoes`) e versão de configuração (`config_versions`) são imutáveis (gatilhos no banco). Mudança = versão nova.
- Número da proposta: `DDMMAAAA/SEQ+SUFIXO`, gerado na transação de emissão. Rascunho e falha não consomem número.
- Sem alçada vigente o limite de desconto é zero. Só o papel `aprovador` concede alçada e decide exceções.
- Não inventar preço, taxa, especificação, case ou condição. Regra não confirmada fica no comportamento seguro e entra em `docs/COMMERCIAL_RULES.md`.
- Kommo: token só no servidor; chamadas marcadas `[VALIDAR]` em `server/kommo.js` ainda não foram conferidas na documentação oficial.

## Comandos
- `npm test` — cálculo + API (API exige `TEST_DATABASE_URL`).
- `node build/build.mjs` — gera `dist/index.html` (modo servidor). `NX_MODE=local node build/build.mjs` gera `dist-local/` (sem servidor, só para harness e teste visual antigo).
- `node tests/e2e_corporativo.mjs` — fluxo completo no navegador (Playwright, banco de teste, Kommo simulado).
- `python3 tests/e2e_smoke.py` — teste visual antigo, sobre `dist-local/`.
- `node build/gen_seed.mjs` — regenera `db/seed/config.json` a partir de `src/defaults.js`.

## Estilo
- Interface e textos em português do Brasil, sem travessão.
- CSS: espaçamentos só com os tokens `--esp-*` (o teste visual reprova valores fora da escala).
