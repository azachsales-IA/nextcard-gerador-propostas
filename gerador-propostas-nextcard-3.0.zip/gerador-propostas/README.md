# Gerador de Propostas NEXTCARD + Teloos (ProntoIA)

Versão 3.0: aplicativo React de página única com API e banco central (PostgreSQL). Login individual, configuração oficial versionada, alçadas de desconto, numeração corporativa, snapshot imutável das propostas e integração Kommo.

Documentação em `docs/`: `IMPLEMENTATION_PLAN.md` (estado), `ARCHITECTURE.md`, `COMMERCIAL_RULES.md` (pendências de aprovação), `DEPLOY.md`, `KOMMO_INTEGRATION.md`, `QA_CHECKLIST.md`, `USER_MANUAL.md`, `ADMIN_MANUAL.md`. Regras permanentes em `CLAUDE.md`.

```
npm install
node build/build.mjs                                   # dist/index.html (modo servidor)
DATABASE_URL=... node scripts/setup.mjs                # migrações, configuração inicial, proprietário, numeração
DATABASE_URL=... node scripts/dev.mjs                  # http://localhost:5173
TEST_DATABASE_URL=... npm test                         # cálculo + API
TEST_DATABASE_URL=... node tests/e2e_corporativo.mjs   # fluxo no navegador
```

O texto abaixo descreve a base anterior (ainda válida para cálculo, catálogo e renderização). O modo sem servidor continua disponível só para harness e teste visual: `NX_MODE=local node build/build.mjs` gera `dist-local/`.

## Estrutura
- `src/catalog.json` — catálogo gerado das tabelas oficiais (comandas V1/2025, Tecnibra V1/2026, totens V7/2026, Planos Teloos 2026).
- `src/defaults.js` — política, condições, textos, versão da configuração e pontos a validar.
- `src/core.js` — cálculos em centavos (valor final, entrada, parcelas, totem, faixas de comanda). Testes: `node build/test_core.mjs`.
- `src/render.js` — peça 1080×1920 e páginas de detalhamento em canvas; exportação PNG/JPG/PDF.
- `src/ui/*` — telas: Início (escolha do tipo), construtor em 3 passos com prévia ao vivo (`Builder.jsx` + cartões de item em `Cards.jsx`), Proposta pronta com envio pelo WhatsApp (`Pronta.jsx`), Propostas, Catálogo, Política e Configuração.
- `build/gen_data.py` — regenera o catálogo a partir das planilhas/PDFs; `build/gen_assets.py` — logos, fotos e fontes embutidas.

## Build
```
npm install
node build/test_core.mjs
node build/build.mjs   # gera dist/index.html
node build/harness.mjs # gera harness/index.html para testar as peças fora da interface

# testes de interface e da imagem (Python + Playwright + Chromium)
pip install playwright && python3 -m playwright install chromium
python3 tests/e2e_smoke.py     # fluxo completo no computador e no celular (27 verificações)
python3 tests/pecas_fontes.py  # 7 casos-limite da imagem; texto >= 30 px, rótulos >= 22 px
```
Capturas e imagens dos testes ficam em `tests/out/`.

## Regras que não mudam
- Todo valor monetário em centavos; zero é valor válido (nunca `||`).
- Valor final = Σ(qtd × preço unitário praticado); condições partem dele.
- Sem custo, markup ou margem no arquivo: totens usam apenas valores de venda por componente.

- Imagem do WhatsApp: texto com no mínimo 30 px e preço com no mínimo 72 px (rótulos em caixa alta: 22 px). Falta de espaço manda itens para o PDF, nunca reduz a fonte.
- Validade: 2, 3 ou 5 dias úteis (seg–sex sem feriados nacionais) ou 7 dias corridos, sempre com a data.
