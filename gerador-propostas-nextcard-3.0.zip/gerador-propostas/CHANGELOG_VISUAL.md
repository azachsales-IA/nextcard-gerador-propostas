# CHANGELOG visual · rodada 2

Base: rodada 1 de UX (commit `21d9c10`). Um commit por item.
- Capturas "antes": `tests/out/antes/`. Capturas "depois": `tests/out/depois/`. Pares lado a lado: `tests/out/lado_a_lado/`.
- Peças com a grade de depuração: `tests/out/depois/grade/`.

Nenhum preço, fator, cálculo, prazo, garantia ou texto comercial mudou: `src/catalog.json` e `src/defaults.js` ficam sem diff.

---

## 1. Tipografia

**Escolha: Raleway, que é a própria fonte do site da NEXTCARD.**
- Na medição automática (`tests/fontes_comparacao.py`), a Raleway teve IoU de 0,566 dos contornos contra o print, com largura a 0,9%. A segunda colocada, Nunito, teve IoU de 0,459.
- O print confirma nos detalhes: "12" no estilo antigo, "g" de um andar, "a" de dois andares, "R" de perna reta e "$" de traço fino. Não houve empate.
- Montserrat e Poppins, sugeridas no briefing, ficaram em último: são mais largas (8,4% e 5,8%) e têm outro "a" e outro "$".

**Como a fonte entra no app: "NX Sans", uma versão derivada da Raleway 4.026 (licença SIL OFL 1.1).**
- A licença reserva o nome "Raleway" e obriga a renomear qualquer versão modificada. Por isso o nome é outro. O copyright e a licença continuam dentro do arquivo, e o texto está em `build/fontes/OFL.txt`.
- Modificações feitas:
  - algarismos alinhados passam a ser o padrão, porque a Raleway usa os de estilo antigo, ruins para preços, e o canvas não permite ligar recursos da fonte;
  - novo recurso `tnum` com algarismos tabulares, para o `font-variant-numeric: tabular-nums` funcionar no CSS;
  - subconjunto latin + latin-ext;
  - pesos 400, 600, 700 e 800, em woff2 (cerca de 36 KB cada), embutidos em base64.

**Onde foi aplicada.**
- Toda a interface, nas duas marcas.
- As propostas NEXTCARD: imagem e PDF.
- As propostas Teloos mantêm a Inter.
- Space Grotesk e JetBrains Mono saíram do build: não há mais fonte monoespaçada no que o cliente vê nem na interface.

**Detalhes de acabamento.**
- Rótulos em caixa alta: peso 700 e 0,08em de espaçamento entre letras, no CSS e no canvas.
- Valores e números de tabelas usam `tabular-nums` na interface. No canvas, os valores ficam alinhados à direita.

**Garantia de que a fonte certa aparece no canvas.**
- `ensureFonts()` espera cada peso com `document.fonts.load()`. Se algum não carregar, o desenho falha com "Fonte não carregada…" em vez de sair com a fonte de reserva.
- `tests/pecas_fontes.py` confere toda fonte usada em `fillText` na imagem e nas páginas do PDF: cada família e peso precisa ter um `FontFace` carregado.
- Teste negativo: sem a NX Sans, o desenho tem de falhar.
- `tests/e2e_smoke.py`: a interface carrega a NX Sans e nenhum elemento usa fonte monoespaçada.

**Arquivos:** `build/gen_fontes.py` (novo), `src/fontes.js` (gerado), `build/fontes/OFL.txt`, `build/build.mjs`, `build/harness.mjs`, `src/render.js`, `src/styles.css`, `tests/pecas_casos.js`, `tests/pecas_fontes.py`, `tests/e2e_smoke.py`, `tests/fontes_comparacao.py` (novo).

**Como testar:**
- `python3 tests/pecas_fontes.py`
- `python3 tests/e2e_smoke.py`
- Para regenerar a comparação: `npm i --no-save @fontsource/raleway @fontsource/montserrat @fontsource/poppins @fontsource/nunito @fontsource/quicksand @fontsource/varela-round && python3 tests/fontes_comparacao.py`
- Para regenerar a fonte: `npm pack @expo-google-fonts/raleway`, extraia e rode `RALEWAY_TTF=<pasta package> python3 build/gen_fontes.py`.

## 2. Tema claro e tema escuro da interface

**O que mudou**
- **Botão Claro/Escuro no topo** (`data-testid="tema-ui"`). No celular aparece só o ícone, em 44 × 44 px.
- **Mesma opção em Configuração → Aparência.** A escolha fica salva no navegador (`nxp.ui.tema`). O padrão continua escuro.
- **Tema claro das duas marcas** (`data-theme="light"` junto com `data-brand`). O logo usa a versão oficial de letras escuras (`logoNextcard`, `logoTeloos`), sem recolorir.
- **Cores fixas trocadas por variáveis de papel:** poço, elevação, sombra, sobreposição, campo, borda de campo, texto de destaque, laranja de texto e linha da grade. Assim os dois temas usam as mesmas regras.

**Contraste (WCAG 2.2 AA)**
- **Auditoria automática nova:** `tests/contraste.js` + `tests/contraste_ui.py`.
  - Mede texto (4,5:1, ou 3:1 se grande), bordas de campos, ícones e contorno de foco (3:1).
  - Compõe o fundo real de cada elemento, com camadas translúcidas e degradês no pior caso.
  - Cobre 12 telas: perfil, início, modal, os 3 passos, proposta pronta com aviso, Propostas, Catálogo, Política, Configuração e Aparência.
  - Roda nas 2 marcas × 2 temas. Resultado: **0 problemas** nas quatro combinações.
- **Falhas antigas do tema escuro corrigidas no caminho:**
  - texto branco sobre o início claro dos degradês dos botões: 3,29:1 na NEXTCARD e 2,03:1 na Teloos. O degradê dos botões agora começa no tom da marca; o degradê original ficou nos filetes decorativos (`--grad-marca`);
  - "Enviar pelo WhatsApp", branco sobre `#25D366` (1,98:1). O verde foi escurecido para `#0C7D55`, com cerca de 5:1;
  - bordas de campos e caixas de marcar abaixo de 3:1;
  - borda de foco translúcida, que agora usa a cor sólida de destaque.
- **Estado desativado:** continua com opacidade 0,45, isento pelo critério 1.4.3. **Foco:** contorno em `--accent-2`, com pelo menos 3:1 nos dois temas.

**Arquivos:** `src/styles.css`, `src/ui/App.jsx`, `src/ui/Config.jsx`, `src/ui/common.jsx` (ícones sol e lua), `tests/contraste.js` (novo), `tests/contraste_ui.py` (novo), `tests/e2e_smoke.py`.

**Como testar:**
- `python3 tests/contraste_ui.py todos` (0 problemas).
- No e2e: tema escuro por padrão, o botão liga o claro, a escolha continua após recarregar e o contraste é AA no início nos dois temas.

## 3. Tema da proposta (PDF e imagem)

**Onde se escolhe**
- **Na proposta:** "Tema da proposta: Escuro | Claro" no passo Condições (cartão "Aparência da proposta") e na tela Proposta pronta, que redesenha a peça na hora.
- **Padrão das novas propostas:** Configuração → Aparência.
- **Salvo na proposta** (`temaProposta`): reabrir e gerar de novo dá o mesmo resultado. Propostas antigas, sem esse campo, continuam escuras. PDF e imagem usam sempre o mesmo tema.

**Como ficam as peças**
- Todas as cores do desenho vêm de uma paleta por marca e tema (`paleta(marca, tema)` em `src/render.js`). Não há mais cor fixa espalhada pelas funções.
- **NEXTCARD claro:**
  - fundo branco, painéis cinza bem claros, texto grafite (`#1F1F23`) e vermelho da marca em rótulos e destaques;
  - cantos chanfrados mantidos;
  - no lugar do anel vermelho brilhante sob os equipamentos, um "palco" claro: disco de piso cinza e sombra de contato suave;
  - logo NEXTCARD de letras escuras, o arquivo oficial `logoNextcard`, sem recolorir PNG.
- **Teloos claro:**
  - fundo branco-azulado, texto azul-escuro (`#0B1B5B`) e azul da marca;
  - selos em laranja escurecido (`#C2570C`), para o texto branco manter o contraste;
  - logo Teloos colorido.
- **Moldura do logo do cliente no tema claro:** borda fina no lugar do fundo branco, que sumiria na página branca.

**Arquivos:** `src/render.js`, `src/ui/Builder.jsx`, `src/ui/Pronta.jsx`, `src/ui/App.jsx`, `src/ui/Config.jsx`, `src/styles.css`, `tests/e2e_smoke.py`.

**Como testar:**
- No e2e: "Claro" nas condições gera a imagem de fundo claro, "Escuro" na tela final gera de novo no escuro, e o tema fica salvo na proposta.
- `python3 tests/pecas_visual.py depois`: casos (a) a (f) nos dois temas.

## 4 e 6. Capa do PDF e imagem do WhatsApp (mesmo código: `renderPeca(..., { modo: 'pdf' | 'imagem' })`)

A capa do PDF deixou de ser a própria imagem do WhatsApp. As duas saem da mesma função, e cada modo tem suas regras. Por isso as duas mudanças foram juntas num commit só.

**Equipamentos em destaque (a maior área da peça)**
- **Área dos equipamentos:**
  - capa: de 38% a 45% da altura (736 a 864 px), com alvo de 42%;
  - imagem: no mínimo 35% (672 px), com alvo de 40%.
- **Distribuição dos modelos:**
  - 1 modelo: centralizado e grande. O rótulo vai embaixo ou ao lado, conforme o que render a foto de maior área (totem estreito: rótulo ao lado);
  - 2 modelos: lado a lado, mesma altura e mesma linha de base;
  - 3 ou 4: grade com a mesma altura para todas as fotos (4 também em 2 × 2, se render foto maior).
- **Rótulo** (ENTRADA / SAÍDA / TOTEM, modelo e quantidade) centralizado logo abaixo de cada foto. Cada célula tem largura mínima para o rótulo, e a quantidade desce para uma segunda linha quando não cabe.
- **Palco:** neon no tema escuro, piso claro no tema claro.

**Fotos antes × depois** (altura em px; entre parênteses, o ganho na altura e na área de cada foto)

| Caso | Antes | Imagem | Capa do PDF |
|---|---|---|---|
| (a) catracas, 2 modelos | 294 | 528 (1,80×; área 3,2×) | 720 (2,45×; área 6,0×) |
| (b) totem, 1 modelo | 492 | 744 (1,51×; área 2,3×) | 864 (1,76×; área 3,1×) |
| (c) 3 modelos | 328 (só o totem aparecia) | 528 (1,61×; área 2,6×) | 544 (1,66×; área 2,8×) |
| (e) totem de bancada | 450 | 631 (1,40×; área 2,0×) | 720 (1,60×; área 2,6×) |

Área dos equipamentos na capa: 45% da altura em (a), (b) e (e), 35% em (c). Na imagem: de 35% a 39%. Tabela completa: `tests/out/medidas_comparadas.md`.

[VALIDAR COM OS FUNDADORES] "1,8× maior" só é possível na altura quando a foto não esbarra em outro limite:
- (b) totem de pedestal: 1,8× seriam 886 px, ou 46% da página, acima do teto de 45%.
- (c) três modelos numa linha: a largura útil (952 px) limita a altura em 544 px. Para passar disso, seria preciso quebrar em duas linhas, o que deixa as fotos menores.
- (e) totem de bancada, que é largo: o teto de 45% e a largura limitam juntos.
- Por isso a medida adotada foi a **área** de cada foto, que fica 2,0× maior ou mais em todos os casos. Na altura, (a) passa de 1,8× na capa e fica em 1,80× na imagem.

**Preço**
- De 118 px para **90 px** (−23,7%). Só reduz até 72 px se o valor não couber.
- Continua o maior número da peça.
- `tests/pecas_fontes.py` falha se o preço sair de 72 a 94 px.

**Sem dados do consultor na capa e na imagem**
- O bloco (nome, WhatsApp, site) saiu das duas.
- Na imagem, o site fica como assinatura discreta: na linha da faixa de cases ou, sem cases, no rodapé.
- `pecas_fontes.py` falha se o telefone do consultor aparecer na imagem ou na capa.

**Textos**
- Capa: "Demais condições na página 2". Imagem: "Demais condições no PDF". Ambos verificados em `pecas_fontes.py`.
- Validade continua "Válida por X · até dd/mm/aaaa". PIX em destaque + uma condição.

**Lista de itens abaixo das fotos**
- Coluna de quantidade com largura fixa e alinhada à direita.
- Todos os nomes começam no mesmo x e os valores ficam alinhados à direita.
- Quando não cabem todos: "+ N itens no PDF" na imagem, "na página 2" na capa.

**Faixa de cases na imagem**
- Entre 12% e 15% da altura (232 a 288 px), logo acima do rodapé.
- Rótulo "CLIENTES QUE CONFIAM NA NEXTCARD" + site. Logos num painel branco.
- A imagem padrão teve as margens brancas recortadas (1620 × 348 px, `build/gen_cases.py` → `src/cases.js`), para os logos ficarem maiores.

**Prioridade quando falta espaço:** equipamentos > preço e condição > itens > cases > "Incluso".
- Os equipamentos nunca ficam abaixo do mínimo.
- Depois vem o máximo de itens.
- A faixa de cases cede altura (288 → 232) para os equipamentos chegarem aos 40%.
- O "Incluso" entra só se sobrar espaço.
- Nenhum texto fica abaixo de 30 px (rótulos: 22 px) para caber.

**Cabeçalho**
- Se "PROPOSTA COMERCIAL · …" e o número não cabem na mesma linha, o número desce para a linha de baixo.
- O título fica em 1 linha (reduz de 56 até 44 px); se ainda não couber, vai para 2 linhas.

**Capa do PDF:** rodapé com a paginação (1/N). No PDF gerado, a página 1 agora é a capa. A prévia e a tela final mostram "Imagem (WhatsApp)" e "PDF · pág. 1…N".

**Arquivos:** `src/render.js`, `src/cases.js` (gerado), `build/gen_cases.py` (novo), `src/ui/Builder.jsx`, `src/ui/Pronta.jsx`, `tests/pecas_casos.js`, `tests/pecas_fontes.py`.

## 5. PDF: última página (cases + consultor)

**O que mudou na última página**
- **Seção "Cases de sucesso":** imagem na largura útil da página, em encaixe proporcional (os logos nunca são cortados), num painel branco.
- **Fechamento com o bloco do consultor:** rótulo e nome à esquerda; WhatsApp, e-mail e site à direita. Os dados vêm do perfil do consultor; o site vem da empresa. É o **único lugar do PDF com os dados do consultor**.
- **Se não couber, cria uma página nova.** O bloco do consultor foi compactado de 288 para 160 px de altura. No caso (a) ele cabe na página 3, junto com os cases, e não sobra página quase vazia.
- **Rodapé de todas as páginas de detalhamento:** só site, validade e paginação.

**Configuração → Aparência → Cases de sucesso**
- Prévia da imagem e troca por arraste ou clique. A imagem fica com até 1620 px de largura e tem as margens brancas recortadas.
- Botão "Restaurar padrão". A imagem anexada vai embutida no build como padrão (`src/cases.js`).

**Por proposta:** "Incluir cases de sucesso", no cartão "Aparência da proposta" do passo Condições. Vale para a faixa da imagem e para a seção do PDF. Vem ligado por padrão nas propostas NEXTCARD.

[VALIDAR COM OS FUNDADORES] Os logos da imagem são clientes da NEXTCARD. Por isso, nas propostas **Teloos** a opção vem **desligada** por padrão (o consultor pode ligar). Confirmar se a Teloos deve usar outra imagem.

**Arquivos:** `src/render.js`, `src/ui/Builder.jsx`, `src/ui/Config.jsx`, `src/styles.css`, `tests/pecas_casos.js`, `tests/e2e_smoke.py`.

**Como testar:**
- `pecas_fontes.py`: "PDF: consultor só na última página".
- `e2e_smoke.py`: cases ligados por padrão; troca e restauração da imagem em Configuração.

## 7. Espaçamentos, grade de depuração e teste de alinhamento

**Escala única: 8 / 16 / 24 / 32 / 48 / 64 / 96 px**
- **`render.js`:** `ESPACOS`, `MARGEM = 64` (margem lateral única nas duas peças, largura útil de 952 px), `GAP_TITULO = 24` (título → conteúdo), `GAP_LISTA = 16` (entre itens de lista), `GAP_SECAO = 48` (entre seções) e `PAD = 32` (padding de cartão). Os deslocamentos de linha de base dentro de uma caixa vêm do tamanho da fonte. Eles não são espaço entre blocos.
- **`styles.css`:** variáveis `--esp-8` … `--esp-96`. As 290 declarações de `padding`, `margin` e `gap` usam só esses tokens (valor mais próximo; no empate, o maior).
  - Folgas de 2–3 px entre linhas de texto empilhadas viraram 0, porque a entrelinha já separa.
  - Espaço para a barra fixa do construtor: 96 + 16 no computador e 96 + 64 + 8 no celular.
  - Compensações negativas: `calc(-1 * token)`.
  - Caixa de marcar das formas de pagamento: alinhada à esquerda, em vez de usar margem de −12 px.
- **Valores monetários alinhados à direita** na lista de itens, na tabela do detalhamento e no total.
- **Tabela do detalhamento rebalanceada:** as colunas numéricas têm a largura do maior valor e a descrição fica com o resto.
- **Cabeçalho:** a etiqueta e o número da proposta não colidem mais. Quando os dois não cabem na mesma linha, o número desce.

**Modo de depuração `?grid=1`** (no app, `dist/index.html?grid=1`, e no harness)
- Mostra as margens, 12 colunas e a caixa de cada bloco, com nome, `y` e altura.
- Com a grade ligada, a imagem e o PDF baixados também saem com a grade (é só para conferência).
- Capturas em `tests/out/depois/grade/`.

**Teste automático das caixas** (`pecas_fontes.py`, linhas "layout <caso> (<tema>)")
- Roda os casos (a) a (f) nos dois temas, na imagem e em todas as páginas do PDF (50 peças). Confere:
  - Toda seção começa em x = 64 e termina em x = 1016 (±1 px).
  - O espaço entre seções consecutivas é 48 px (±1).
  - Não há sobreposição entre seções e rodapé, nem entre fotos e rótulos.
  - Nenhuma caixa sai da página.
- `e2e_smoke.py`, linha "CSS: espaçamentos só com tokens": falha se aparecer px, em ou % fora da escala em `padding`, `margin` ou `gap`.

**Arquivos:** `src/render.js`, `src/styles.css`, `build/harness.mjs`, `tests/pecas_fontes.py`, `tests/e2e_smoke.py`.

## 8. Correções do PDF

1. **Paginação.** A capa mostrava "1/3" e as páginas de detalhamento contavam só a si mesmas ("1/2", "2/2"). Agora todas usam n/N do documento inteiro, com a capa incluída: 1/3, 2/3, 3/3. O ajuste está em `renderPaginasPDF`, que informa ao detalhamento que ele começa na página 2.
2. **"Comandas personalizadas com a sua marca" repetida em "O que está incluso".**
   - **Origem:** a frase existe uma única vez em `defaults.js` (inclusos da família "comanda") e em todo o histórico só há essa grafia. A sugestão automática (`autoInclusos`) já elimina repetição exata, tanto hoje quanto na base v2. A repetição, portanto, vem da **lista salva na proposta**: o mesmo texto adicionado de novo à mão, ou uma variante com espaço, maiúscula ou ponto final diferente (por exemplo, editada em Configuração), que a comparação exata não reconhece.
   - **Correção no render:** `semRepetidos()`, em `core.js`, é aplicada em `buildModel`. Compara sem diferenciar maiúsculas, espaços extras e pontuação final, e mantém a primeira grafia. Vale para a imagem, a capa e o detalhamento. `defaults.js` não foi tocado.
3. **Página 3 com área vazia.** Os cases de sucesso e o bloco do consultor agora ocupam a última página (seção 5). No caso (a), a última página fica 91% ocupada.
   - Nos casos (b), (c), (d) e (e), a página 2 ficava cheia e a última só com cases e consultor, 34–38% ocupada (o mesmo vazio, em outro lugar).
   - **Equilíbrio automático:** quando a última página termina antes de 55% da altura, seções inteiras da penúltima descem para ela. O ponto de quebra escolhido é o que deixa a página menos cheia o mais cheia possível. A página é montada de novo, e a nova versão só vale se o número de páginas não mudar.
   - Resultado: a última página fica entre 55% e 63% ocupada em (b)–(f), e a (a) segue com 91% (tabela em `tests/out/medidas_comparadas.md`).
   - Seção que começou na página anterior (continuação) nunca é dividida de novo.

4. **Anel do palco encostando no rótulo** (achado na validação final). Com a foto larga da catraca de saída, o anel descia cerca de 40 px abaixo da base e tocava "SAÍDA". Correção:
   - Acima de 110 px de raio, o anel é achatado e não passa de ~20 px abaixo da base.
   - O rótulo fica a 24 px da foto.
   - O efeito: em (a) e (e), a foto da capa perde 8 px de altura (728 → 720), sem mudar nenhuma razão de forma relevante.

**Arquivos:** `src/render.js`, `src/core.js`, `build/test_core.mjs`, `tests/pecas_casos.js`.

**Como testar:**
- `test_core.mjs`: "inclusos sem repetidos".
- `pecas_fontes.py`:
  - "PDF: paginação n/N contando a capa", nos 7 casos.
  - "inclusos sem repetição": o caso 4 recebe de propósito a frase duplicada com outra grafia.
  - Linhas "layout …": a última página do PDF termina depois de 50% da altura.
- As duas checagens foram conferidas ao contrário: sem a correção, falham.

---

## Validação

**Como rodar** (saída completa em `tests/out/resultados_visual.txt`):
```
node build/test_core.mjs
node build/build.mjs && node build/harness.mjs
python3 tests/e2e_smoke.py
python3 tests/pecas_fontes.py
python3 tests/pecas_visual.py depois && python3 tests/medidas_tabela.py && python3 tests/lado_a_lado.py
```

**Resultado:** os quatro testes passam, com 0 falha. A auditoria de contraste (`tests/contraste_ui.py`) dá 0 problema nas 4 combinações (tema × marca). O diff de `src/catalog.json` e `src/defaults.js` contra a base v2 tem 0 linha.

| Critério de aceite | Situação | Onde conferir |
|---|---|---|
| Sem fonte monoespaçada nem Space Grotesk | ok: NX Sans na interface e na NEXTCARD; a Teloos mantém a Inter | `e2e_smoke.py`, `medidas.json` (famílias) |
| Temas claro e escuro com contraste AA | ok: 0 problema | `contraste_ui.py` |
| Capa e imagem sem dados do consultor | ok | `pecas_fontes.py` |
| Última página com cases + consultor | ok | `pecas_fontes.py`, `lado_a_lado/*_pdf.jpg` |
| Imagem com faixa de cases (12–15%) | ok: 232 px (12,1%); 286 px sem fotos | `medidas_comparadas.md` |
| Fotos ≥ 1,8× maiores | na área, sim em todos os casos; na altura, só em (a). [VALIDAR] | seção 4 e 6 |
| Preço com 72–80% do tamanho atual | ok: 118 → 90 px (76%) | `pecas_fontes.py` |
| Alinhamento e sobreposição, (a)–(f), dois temas | ok: 12 cenários, 50 peças | `pecas_fontes.py` (linhas "layout") |
| `git diff` vazio em `catalog.json` e `defaults.js` | ok | `resultados_visual.txt` |

**Entregáveis**
- `tests/out/antes/` e `tests/out/depois/`: páginas do PDF, imagem e interface em 1440 × 900 e 390 × 844. O "depois" está nos dois temas.
- `tests/out/depois/grade/`: todas as peças com a grade de depuração.
- `tests/out/lado_a_lado/`: antes × depois escuro × depois claro, para cada caso (imagem e PDF) e cada tela.
- `tests/out/fontes_comparacao.png`: comparação das fontes; justificativa na seção 1.
- `tests/out/medidas_comparadas.md` e `tests/out/resultados_visual.txt`.

## Pendências [VALIDAR COM OS FUNDADORES]

1. **"1,8× maior" na altura** conflita com o teto de 45% da capa e com a largura útil nos casos (b), (c) e (e). Adotei a área como medida (seção 4 e 6). Se a regra for mesmo a altura, é preciso escolher entre ultrapassar os 45% e usar fotos em duas linhas.
2. **Cases de sucesso na Teloos:** os logos da imagem são clientes NEXTCARD. Por isso a opção vem desligada nas propostas Teloos. A Teloos tem uma imagem própria?
3. **Nome da fonte:** a licença da Raleway (OFL) obriga a renomear a versão modificada, então ela entrou como "NX Sans". Confirmar se o nome serve ou se preferem outro.
4. **Fotos novas de totem** (`ref/foto-totem-*.webp`): ficaram guardadas, sem uso. Trocar as fotos do catálogo muda qual foto aparece em cada modelo, e as novas têm fundo cinza (precisariam de recorte). Confirmar qual foto vale para cada modelo.
5. **PDF atual** (`proposta-atual.pdf`): não chegou. As capturas "antes" foram geradas com o código da rodada 1, nos mesmos casos (a)–(f).
6. **Inclusos repetidos:** a origem não está em `defaults.js`. O mais provável é uma lista editada na proposta ou uma configuração salva no navegador com a frase repetida em outra grafia. O render já elimina a repetição, mas vale revisar a Configuração no navegador de quem gerou o PDF.
7. **Sugestão (não pedida):** quando uma lista continua na página seguinte, os itens aparecem sem o título da seção. Repetir o título "(continuação)" custa cerca de 48 px e, no caso (a), levaria o bloco do consultor para uma 4ª página. Por isso ficou como está.

---

# Rodada 3 · fotos oficiais e telas do sistema Teloos

## 9. Fotos oficiais dos equipamentos (Drive da NEXTCARD, 30/09)

**Origem e tratamento**
- As 19 fotos da pasta do Drive foram baixadas pelo conector do Google Drive e estão em `ref/drive/`.
- `build/gen_fotos.py` gera `src/fotos.js`:
  - recorta o fundo branco, e também a sombra de piso encostada nas bases escuras;
  - deixa a borda suave e sem halo branco;
  - corta as margens e limita a altura a 1100 px (WebP com transparência, 1,1 MB no total).
- As partes brancas dos totens (NX24-P, NX24-V e NX15,6-B) ficam inteiras: só sai o branco ligado às bordas da foto.

**Foto de cada modelo** (no trecho de fotos do `defaults.js`; o resto da política comercial ficou idêntico, conferido com os preços e os textos)
| Foto nova | Modelos |
|---|---|
| Totem pedestal NX24-V | NX24-V; NX32-V (mesma aparência) |
| Totem parede NX24-P | NX24-P; NX32-P |
| Totem bancada NX21-B | NX21-B; NX24-B |
| Totem bancada NX15,6-B | NX15-B; NX18,5-B |
| Totem horizontal | NX18,5-H (antes sem foto) |
| Expedidoras C120 e C150 | catraca acoplada |
| Expedidora C180 + Smart | C180 com catraca Smart (antes sem foto) |
| Receptoras R120 e R150 | catraca acoplada |
| Receptoras R100 e R200 + Smart | com catraca Smart |
| Comandas 15 × 10, 14 × 8 e 9 × 7 | todas as comandas, por tamanho (9 × 7 × 3,5 usa a 9 × 7) |

- Modelos sem foto nova (C250, variantes Tecnew, R300, RD120 e variantes sem catraca) continuam com a foto anterior ou sem foto.
- Topdata Fit (expedidora e urna), cartão comanda e a vista lateral do NX15,6-B ficam na biblioteca, para escolha manual.

**Configuração já salva no navegador:** na primeira abertura, a migração troca só as fotos que ainda estavam no padrão anterior. A foto escolhida à mão em Configuração é mantida. A migração roda uma vez só.

**Nas propostas**
- As fotos novas entram automaticamente na imagem, na capa e no PDF.
- **Proposta só de comandas:** a foto da comanda vai em destaque, uma por tamanho (antes não havia foto nenhuma).
- Em propostas com totem ou catraca, as comandas continuam na lista de itens, para não ficarem do tamanho de uma catraca ao lado dela.

**No sistema**
- Cartões do início com as fotos novas (totem, catraca e comanda).
- Catálogo de catracas e de comandas com foto. Modelo sem foto mostra "sem foto aprovada" no mesmo espaço.
- Seletor de foto também no item de comanda.
- Configuração ganhou "Foto de cada comanda".

**Medidas com as fotos novas** (`tests/out/medidas_comparadas.md`, que substitui os números da tabela das seções 4 e 6):
- Imagem: catracas 528 px (1,80×), totem de pedestal 744 px, totem de bancada NX21-B 621 px, comanda 784 px.
- Capa: catracas 720 px (2,45×), totem 864 px, NX21-B 720 px, comanda 864 px.
- Preço continua em 90 px (76% do tamanho anterior).

**Testes:** `pecas_fontes.py`, linha "fotos: migração da configuração salva". Também passam o layout (a)–(f) nos dois temas, o e2e e o contraste.

[VALIDAR COM OS FUNDADORES] Estas associações foram feitas por aparência: NX32-V, NX32-P, NX18,5-B, NX24-B e comanda 9 × 7 × 3,5. O NX15-B do catálogo usa a foto chamada "NX15,6B". Confirmar.

## 10. Teloos: telas do sistema na proposta

A proposta Teloos agora mostra o software, como o site da Teloos faz. As telas partem da referência enviada (painel "Visão de Vendas") e são desenhadas pelo próprio gerador (`src/telas.js`). Por isso ficam nítidas em qualquer tamanho, seguem os dois temas e não dependem de imagem externa.

**Imagem do WhatsApp e capa do PDF** (bloco "TELAS DO SISTEMA · IMAGENS ILUSTRATIVAS", o maior da peça)
- **Painel de gestão numa janela de navegador:**
  - barra lateral com os módulos;
  - indicadores de vendas (hoje, ontem, 7 dias, mês);
  - gráfico diário de 30 dias e gráfico mensal empilhado (salão + delivery, com legenda);
  - mais vendidos, ranking de grupos e visão geral.
- A barra do topo e o avatar levam o **nome do restaurante do cliente**.
- Selo flutuante "+23 pedidos realizados hoje" e celular com o **app de mesas** (livre, ocupada, conta; "Lançar pedido").
- **Prioridade:** as telas buscam 560 px (29% da altura) e nunca ficam abaixo de 440 px. O plano ocupa o que sobra.
- **Plano contratado mais compacto:**
  - nome do plano em cima;
  - duas colunas: "Recursos do plano" e "Adicionais contratados";
  - o que não cabe vira "e mais N recursos" ou "+ N adicionais no PDF". A lista completa, com os valores, continua no PDF.
- Preço, condição e validade não mudaram.

**PDF, detalhamento:** nova seção "Telas do sistema", depois dos recursos do plano. Mostra a frente de caixa (PDV: categorias, produtos, pedido da mesa com serviço e total) e o celular com o **cardápio digital**, com a legenda "Frente de caixa (PDV) e cardápio digital. Imagens ilustrativas."

**Detalhes**
- Números e produtos das telas são de exemplo, marcados como ilustrativos.
- Os textos pequenos dentro das telas fazem parte da ilustração, como o texto na tela de um totem numa foto. Por isso ficam fora da regra de texto mínimo, e o canvas da ilustração é marcado para o teste separar. Todo o texto da proposta continua com 30 px (rótulos, 22 px) ou mais.
- No tema escuro, um brilho azul elíptico fica atrás das telas. As sombras têm sangria, sem corte reto na borda.
- Gráficos seguem as regras de marca do guia de visualização: colunas finas com ponta arredondada, 2 px de respiro entre segmentos empilhados, grade discreta e legenda para as duas séries.

**Testes:** `pecas_fontes.py`, checagem "Teloos: telas do sistema na imagem, na capa e no detalhamento", nos casos 6 e 7. O layout (f) segue alinhado e sem sobreposição nos dois temas.

[VALIDAR COM OS FUNDADORES] Nomes dos módulos, números e produtos das telas são de exemplo. Se a Teloos tiver prints oficiais do sistema, eles podem entrar no lugar da ilustração. A imagem de dispositivos enviada (com a marca onPDV) não foi usada, para não misturar outra marca na proposta Teloos. Confirmar se pode.

### 10.1 Correção: tela do sistema "esticada"

**Causa:** com pouca altura (por exemplo, com a faixa de cases ligada), a ilustração mantinha a altura e alargava o desenho. O painel ficava largo e baixo, com colunas espaçadas demais.

**Correção**
- **Proporção fixa:** o desenho tem 952 × 560 e sempre ocupa a largura útil na mesma escala. Nunca estica.
- **Com pouca altura:** o painel é recortado embaixo com um esmaecimento suave, que começa depois dos gráficos. O celular e o selo continuam inteiros, em escala uniforme.
- **Altura mínima de 440 px:** indicadores e gráficos aparecem sempre inteiros.
- **Prioridade na imagem:** telas > preço > plano > cases. Abaixo do alvo, a faixa de cases cede altura primeiro (fica em 232 px).
- **Rótulo:** "TELAS ILUSTRATIVAS DO SISTEMA" foi para o espaço livre acima da janela do navegador, o que ganhou 48 px de tela.
- **Plano:**
  - "e mais N recursos" fica na linha do nome do plano, e as colunas mostram só recursos;
  - o total de adicionais vai no rótulo da coluna ("3 ADICIONAIS CONTRATADOS").
- **Gráficos:** títulos encurtados ("Vendas diárias · 30 dias", "Mensal · 12 meses") para não encostarem na legenda.

**Teste** (`pecas_fontes.py`, linha "Teloos: telas na proporção do desenho (sem esticar)…"): a ilustração sai na escala da largura útil (1048 px com a sangria), sem distorção e com pelo menos 440 px, com e sem cases, nos dois temas. Conferido ao contrário: com o código anterior, o teste falha.

---

# Rodada 4 · infraestrutura, frases, ícones e tema Cinza (05/10)

## 11. Infraestrutura e integração das catracas (texto novo, menos espaço)
- **Texto novo** (enviado pelo Gabriel) em `defaults.js`. A infraestrutura passou a ter 5 itens; o item 2 tem subitens para a catraca de entrada e a de saída.
- **Diagramação:**
  - itens numerados em duas colunas, com texto de 22 px;
  - o item 2 mostra "Catraca de entrada" e "Catraca de saída" como subitens com rótulo vermelho e filete;
  - o texto ocupa cerca de 40% menos altura do que a lista de antes.
- **Integração das catracas:** nova seção. O 1º parágrafo explica como funciona. O 2º ("software comunicador mediante contratação adicional") vai num quadro de destaque com ícone.
- **Editável em Configuração → Textos:**
  - na infraestrutura, linha que começa com "- " vira subitem, e "Rótulo: texto" destaca o rótulo;
  - novo editor "Integração das catracas".
- **Configuração já salva no navegador:** a infraestrutura antiga é trocada pela nova só se ainda estiver no texto padrão antigo. Texto editado à mão é mantido. A migração roda uma vez só.
- **Páginas:** se precisar, o PDF ganha uma página. O caso (a) foi de 3 para 4 páginas, com o equilíbrio entre as duas últimas.

## 12. Frases pedidas pelo Hamilton
- **Capa do PDF**, logo abaixo da identificação, com filete vermelho: "Escolher nossa solução e know-how é certeza da entrega de resultados reais para seu projeto."
- **Fim do detalhamento**, em destaque, acima da frase da marca: "Nossos objetivos vão muito além do que um simples processo de venda!"
- As duas ficam em Configuração → Textos e são exclusivas da NEXTCARD. As linhas das frases centralizadas são equilibradas, sem palavra sozinha na última linha.

## 13. "O que está incluso" com ícones
- Cada item ganha um ícone de linha conforme o assunto:
  - garantia → escudo; suporte → headset; instalação ou treinamento → chave; implantação → foguete;
  - integração → tomada; documentação → documento; fabricação → fábrica; manutenção ou robustez → engrenagem;
  - personalização ou marca → etiqueta; impressora; pinpad; usuários.
- **No PDF:** duas colunas com o ícone num quadrado da marca.
- **Na imagem e na capa:** o mesmo ícone no lugar do "check".

## 14. Tema Cinza (NEXTCARD): Preto, Branco ou Cinza
- **Outro formato, não só outra cor:**
  - faixa grafite no topo, com o logo branco e o filete vermelho (na capa, na imagem e em todas as páginas do detalhamento);
  - fundo cinza-claro, como as seções do site;
  - valor, itens e escopo em cartões brancos.
- **Contraste:** textos com 4,5:1 ou mais sobre o cinza e sobre o branco.
- **Onde escolher:** no passo Condições, na tela da proposta pronta e em Configuração (padrão das novas propostas). As opções aparecem como Preto, Branco e Cinza.
- Na Teloos continuam Escuro e Claro; uma proposta Teloos com Cinza sai como Claro.

**Testes:**
- `e2e_smoke.py`: opções Preto, Branco e Cinza; imagem com faixa grafite no topo e fundo cinza; tema salvo na proposta.
- `pecas_fontes.py`:
  - layout (a)–(f) também no tema Cinza;
  - frase de abertura na capa e de encerramento no PDF;
  - infraestrutura nova e integração nos casos com catraca;
  - migração dos textos.

[VALIDAR COM OS FUNDADORES]
- O cinza saiu do print do site (seções em ~#E0E0E0); o site em si não abre neste ambiente. Se a NEXTCARD tiver o código de cor oficial, troca-se numa linha.
- Os inclusos são sugeridos por família de produto e editáveis na proposta. Os ícones seguem o texto.
