async () => {
  const N = window.NX;
  const sizes = [];
  const orig = CanvasRenderingContext2D.prototype.fillText;
  // textos da ilustração (telas do sistema Teloos) fazem parte da imagem: ficam fora da regra de texto mínimo
  CanvasRenderingContext2D.prototype.fillText = function (t, x, y) { const m = /(\d+(?:\.\d+)?)px/.exec(this.font); if (!this.canvas.__ilustracao) sizes.push([m ? +m[1] : 0, String(t)]); return orig.apply(this, arguments); };
  const cfg = N.defaultConfig();
  cfg.responsaveis = [{ nome: 'Ana Souza', sigla: 'A', telefone: '(41) 90000-0000', email: '' }];
  const perfil = { nome: 'Ana Souza' };
  const emit = (p) => ({ ...p, numero: '30092026/1218A', emitidaEm: '2026-09-30T13:00:00', nome: p.nome || N.nomeSugerido(p, cfg) });
  const casos = {};
  // 1 catracas
  let p = N.novaProposta('nextcard', cfg, 'catraca', perfil);
  p.cliente = { ...p.cliente, empresa: 'Restaurante Modelo', contato: 'Ana Souza' };
  p.validadeOpcao = '3u'; p.pagamento.destaque = 'bol2856';
  casos.c1_catracas = emit(p);
  // 2 totem referência FOB
  p = N.novaProposta('nextcard', cfg, 'totem', perfil);
  p.cliente = { ...p.cliente, empresa: 'Restaurante Modelo', contato: 'Ana Souza' };
  casos.c2_totem = emit(p);
  // 3 totem sem pinpad/impressora, 3 un, cliente 45 chars
  p = N.novaProposta('nextcard', cfg, 'totem', perfil);
  const T = cfg.nextcard.totem;
  const sel = { ...p.itens[0].config, modelo: 'NX21-B', pinpad: T.opcoes.pinpad.find(o=>!o.curto).id, impressora: T.opcoes.impressora.find(o=>!o.curto).id };
  p.itens = [N.linhaTotem(sel, cfg, p, 3)];
  p.cliente = { ...p.cliente, empresa: 'Churrascaria e Pizzaria Sabor da Serra Gaúcha', contato: 'Maria Aparecida Fernandes' };
  p.validadeOpcao = '2u'; p.pagamento.frete = 'FOB';
  p.inclusos = N.autoInclusos(p, cfg);
  casos.c3_totem_limite = emit(p);
  // 4 sob medida, 8 itens sem foto
  p = N.novaProposta('nextcard', cfg, 'livre', perfil);
  const C = cfg.nextcard.comandas;
  p.itens = [N.linhaComanda(C[0], 100), N.linhaComanda(C[3], 50), N.linhaComanda(C[6], 300), N.linhaServico(cfg.nextcard.servicos[0]), N.linhaAvulsa('Leitor de comandas USB', 'Balcão do caixa', 45000, 2), N.linhaAvulsa('Cabo de rede', '', 0, 1), N.linhaComanda(C[9], 30), N.linhaAvulsa('Suporte de parede', '', 12000, 4)];
  p.cliente = { ...p.cliente, empresa: 'Bar Central' };
  p.pagamento.condicoes = ['pix']; p.pagamento.destaque = null;
  // lista editada à mão com o mesmo incluso repetido (outra grafia): a peça mostra uma vez só
  p.inclusos = [...N.autoInclusos(p, cfg), ' comandas  personalizadas com a sua marca.']; p.inclusosAuto = false;
  casos.c4_livre_8itens = emit(p);
  // 5 misto totem + catraca
  p = N.novaProposta('nextcard', cfg, 'catraca', perfil);
  p.itens.unshift(N.linhaTotem({ modelo: 'NX32-V', ...T.referencia }, cfg, p, 2));
  p.pagamento.destaque = 'cc6';
  p.cliente = { ...p.cliente, empresa: 'Parque Aventura' };
  p.inclusos = N.autoInclusos(p, cfg);
  casos.c5_misto = emit(p);
  // 6 Teloos: plano com mais recursos, 6 adicionais, cupom 10, anual cartão, D+1
  p = N.novaProposta('teloos', cfg, 'teloos', perfil);
  const pl = [...cfg.teloos.planos].sort((a, b) => b.recursos.length - a.recursos.length)[0];
  p.teloos = { plano: pl.id, cupom: 10, implantacao: 'd1' };
  const ads = cfg.teloos.adicionais.filter((a) => a.planos.includes(pl.id) && a.cents != null).slice(0, 6);
  p.itens = [N.linhaPlano(pl, 10), ...ads.map((a) => N.linhaAdicional(a, 10, 1)), N.linhaImplantacao(cfg.teloos.implantacao.find((i) => i.id === 'd1'))];
  p.pagamento.destaque = 'anualcartao';
  p.cliente = { ...p.cliente, empresa: 'Churrascaria e Pizzaria Sabor da Serra Gaúcha', contato: 'Ana Souza' };
  p.inclusos = N.autoInclusos(p, cfg);
  casos.c6_teloos_cheio = emit(p);
  // 7 Teloos simples
  p = N.novaProposta('teloos', cfg, 'teloos', perfil);
  const pl2 = cfg.teloos.planos[0];
  p.teloos = { plano: pl2.id, cupom: 0, implantacao: 'padrao' };
  p.itens = [N.linhaPlano(pl2, 0), N.linhaImplantacao(cfg.teloos.implantacao[0])];
  p.cliente = { ...p.cliente, empresa: 'Lanchonete Modelo' };
  p.validadeOpcao = '2u';
  p.inclusos = N.autoInclusos(p, cfg);
  casos.c7_teloos_simples = emit(p);
  // fontes usadas em cada fillText: família e peso precisam ter um FontFace carregado (nunca a fonte de reserva)
  const fontes = new Set();
  const orig2 = CanvasRenderingContext2D.prototype.fillText;
  CanvasRenderingContext2D.prototype.fillText = function () { fontes.add(this.font); return orig2.apply(this, arguments); };
  const semFace = () => [...fontes].filter((f) => {
    // o canvas serializa 700 como "bold" e omite o 400
    const m = /^(?:(bold|normal|\d{3})\s+)?[\d.]+px\s+"?([^",]+)"?/.exec(f);
    if (!m) return true;
    const w = !m[1] || m[1] === 'normal' ? '400' : m[1] === 'bold' ? '700' : m[1];
    return ![...document.fonts].some((ff) => ff.family.replace(/"/g, '') === m[2] && String(ff.weight) === w && ff.status === 'loaded');
  });
  const out = {};
  for (const [k, prop] of Object.entries(casos)) {
    sizes.length = 0;
    const m = N.buildModel(prop, cfg, {}, N.PHOTOS);
    const cv = await N.renderPeca(m, cfg, 1, { modo: 'imagem' });
    const small = sizes.filter(([s, t]) => s < 30 && t.trim().length > 1).map(([s, t]) => `${s}px:${t.slice(0, 50)}`);
    const labels = sizes.filter(([s, t]) => s < 30 && t.trim().length <= 1).map(([s]) => s);
    const precos = sizes.filter(([, t]) => /^R\$\s?[\d.]+,\d\d$/.test(t.trim())).map(([s]) => s);
    const preco = precos.length ? Math.max(...precos) : null;
    const txtImg = sizes.map(([, t]) => t).join('|');
    // capa do PDF (modo pdf) e detalhamento também entram na checagem de fontes
    sizes.length = 0;
    await N.renderPeca(m, cfg, 1, { modo: 'pdf' });
    const txtCapa = sizes.map(([, t]) => t).join('|');
    // textos por página do PDF (o hook guarda no próprio canvas)
    const origPg = CanvasRenderingContext2D.prototype.fillText;
    CanvasRenderingContext2D.prototype.fillText = function (t) { (this.canvas.__t || (this.canvas.__t = [])).push(String(t)); return origPg.apply(this, arguments); };
    const pags = N.renderPaginasPDF ? await N.renderPaginasPDF(m, cfg, 1) : [await N.renderDetalhe(m, cfg, 1)].flat();
    CanvasRenderingContext2D.prototype.fillText = origPg;
    const fone = (cfg.responsaveis[0] || {}).telefone;
    const comFone = pags.map((c) => (c.__t || []).join('|').includes(fone));
    const extras = m.condExtras > 0;
    const checks = {
      'imagem sem dados do consultor': !txtImg.includes(fone) && !/WhatsApp \(/.test(txtImg),
      'capa sem dados do consultor': !txtCapa.includes(fone) && !/WhatsApp \(/.test(txtCapa),
      'imagem: "Demais condições no PDF"': !extras || txtImg.includes('Demais condições no PDF'),
      'capa: "Demais condições na página 2"': !extras || txtCapa.includes('Demais condições na página 2'),
      'inclusos sem repetição (imagem e cada página do PDF)': [txtImg, ...pags.map((c) => (c.__t || []).join('|'))].every((t) => (t.match(/comandas\s+personalizadas com a sua marca/gi) || []).length <= 1),
      // rótulos em caixa alta saem caractere a caractere: remonta as sequências de 1 caractere antes de procurar "n/N"
      'capa: frase de abertura': m.brand !== 'nextcard' || txtCapa.includes('Escolher nossa solução'),
      'PDF: frase de encerramento': m.brand !== 'nextcard' || pags.slice(1).some((c) => (c.__t || []).join(' ').includes('Nossos objetivos')),
      'PDF catracas: infraestrutura nova e integração': !N.familias(m.calc.linhas).has('catraca') || (pags.some((c) => (c.__t || []).join(' ').includes('conector fêmea de 3 pinos')) && pags.some((c) => (c.__t || []).join(' ').includes('software comunicador'))),
      'PDF: paginação n/N contando a capa': pags.every((c, i) => (c.__t || []).reduce((a, t) => { if (t.length === 1 && a.solto) a.r[a.r.length - 1] += t; else a.r.push(t); a.solto = t.length === 1; return a; }, { r: [], solto: false }).r
        .some((t) => new RegExp(`(^|[^\\d/])${i + 1}/${pags.length}($|[^\\d/])`).test(t))),
      'Teloos: telas do sistema na imagem, na capa e no detalhamento': m.brand !== 'teloos' || ((cv.__blocos || []).some((b) => b.nome === 'telas do sistema') && (pags[0].__blocos || []).some((b) => b.nome === 'telas do sistema') && pags.slice(1).some((c) => (c.__blocos || []).some((b) => b.nome === 'Telas do sistema'))),
      'PDF: consultor só na última página': comFone.length > 1 && comFone[comFone.length - 1] && comFone.slice(0, -1).every((x) => !x),
    };
    out[k] = { img: cv.toDataURL('image/jpeg', 0.9), small, minLabel: labels.length ? Math.min(...labels) : null, minAll: Math.min(...sizes.filter(([s,t])=>t.trim()).map(([s]) => s)), preco, checks };
  }
  out.__fontes = { usadas: [...fontes], semFace: semFace() };
  return out;
}
