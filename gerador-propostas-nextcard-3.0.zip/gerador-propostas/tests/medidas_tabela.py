"""Tabela antes × depois a partir de tests/out/antes/medidas.json e tests/out/depois/medidas.json.
Uso: python3 tests/medidas_tabela.py  (grava tests/out/medidas_comparadas.md)"""
import json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = json.load(open(os.path.join(ROOT, 'tests', 'out', 'antes', 'medidas.json')))
D = json.load(open(os.path.join(ROOT, 'tests', 'out', 'depois', 'medidas.json')))
H = 1920
def fotos(m): return m['fotos'] or []
def alt(m): return max((f['h'] for f in fotos(m)), default=0)
def area(m): return sum(f['w'] * f['h'] for f in fotos(m))
def pct_bloco(blocos, nome):
    b = next((b for b in blocos or [] if b['nome'] in (nome, 'telas do sistema')), None)  # Teloos: telas do sistema no lugar dos equipamentos
    return f"{b['h'] / H:.0%}" if b else '—'
def ocupacao(blocos):
    s = [b for b in blocos or [] if b['tipo'] != 'ancora']
    return f"{max(b['y'] + b['h'] for b in s) / H:.0%}" if s else '—'
L = ['# Medidas antes × depois (base 1080 × 1920)', '',
     'Altura e área das fotos desenhadas; "equip." = altura do bloco de equipamentos (na Teloos, das telas do sistema) sobre a altura da peça; preço em px; ocupação da última página = fim do último bloco / 1920.', '']
for peca in ('imagem', 'pdf'):
    L += [f"## {'Imagem do WhatsApp' if peca == 'imagem' else 'Capa do PDF'}", '',
          '| caso | tema | foto: altura antes → depois | × altura | × área | equip. na página | preço antes → depois | % do preço |', '|---|---|---|---|---|---|---|---|']
    for k, d in D.items():
        caso, tema = k.rsplit('_', 1)
        a = A.get(f'{caso}_escuro', {}).get(peca, {}); dm = d[peca]
        blocos = d['blocos'] if peca == 'imagem' else (d['blocosPdf'] or [None])[0]
        ha, hd, aa, ad = alt(a), alt(dm), area(a), area(dm)
        L.append(f"| {caso} | {tema} | {ha or '—'} → {hd or '—'} | {f'{hd / ha:.2f}×' if ha else '—'} | {f'{ad / aa:.2f}×' if aa else '—'} | {pct_bloco(blocos, 'equipamentos')} | {a.get('preco_px')} → {dm['preco_px']} | {dm['preco_px'] / a['preco_px']:.0%} |")
    L.append('')
L += ['## Páginas do PDF', '', '| caso | tema | páginas antes → depois | ocupação da última página |', '|---|---|---|---|']
for k, d in D.items():
    caso, tema = k.rsplit('_', 1)
    L.append(f"| {caso} | {tema} | {A.get(f'{caso}_escuro', {}).get('paginas')} → {d['paginas']} | {ocupacao((d['blocosPdf'] or [None])[-1])} |")
open(os.path.join(ROOT, 'tests', 'out', 'medidas_comparadas.md'), 'w').write('\n'.join(L) + '\n')
print('\n'.join(L))
