// Auditoria de contraste WCAG 2.2 AA da tela atual (roda no navegador via page.evaluate).
// Texto: 4,5:1 (3:1 se grande: ≥ 24 px, ou ≥ 18,66 px em negrito). Bordas de campos, ícones e foco: 3:1.
// O fundo de cada elemento é composto do <html> até ele (camadas translúcidas e degradês; degradê = pior caso).
// Controles desativados ficam de fora (WCAG 1.4.3 os isenta).
() => {
  // termina animações de entrada (opacidade) para medir o estado final
  for (const a of document.getAnimations()) { try { a.finish(); } catch (e) { /* animação infinita */ } }
  const parse = (c) => {
    if (!c || c === 'transparent') return [0, 0, 0, 0];
    let m = c.match(/color\(srgb ([\d.e-]+) ([\d.e-]+) ([\d.e-]+)(?: \/ ([\d.e-]+))?\)/);
    if (m) return [m[1] * 255, m[2] * 255, m[3] * 255, m[4] === undefined ? 1 : +m[4]];
    m = c.match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    const p = m[1].split(/[\s,/]+/).filter(Boolean).map(Number);
    return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1];
  };
  const over = (t, b) => { const a = t[3] + b[3] * (1 - t[3]); return a ? [0, 1, 2].map((i) => (t[i] * t[3] + b[i] * b[3] * (1 - t[3])) / a).concat(a) : [0, 0, 0, 0]; };
  const lum = ([r, g, b]) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  const stops = (bi) => (bi.match(/rgba?\([^)]+\)|color\(srgb[^)]+\)/g) || []).map(parse).filter(Boolean);
  const cache = new Map();
  const fundos = (el) => {
    if (!el) return [[255, 255, 255, 1]];
    if (cache.has(el)) return cache.get(el);
    let c = fundos(el.parentElement);
    const cs = getComputedStyle(el);
    const bc = parse(cs.backgroundColor);
    if (bc && bc[3] > 0) c = c.map((x) => over(bc, x));
    if (cs.backgroundImage && cs.backgroundImage.includes('gradient')) {
      // camadas: se a de cima é opaca (ex.: fundo + borda em degradê), só ela conta
      const camadas = cs.backgroundImage.match(/(?:linear|radial|conic)-gradient\((?:[^()]|\([^()]*\))*\)/g) || [];
      const topo = camadas.length ? stops(camadas[0]) : [];
      const g = topo.length && topo.every((s) => s[3] === 1) ? topo : stops(cs.backgroundImage);
      if (g.length) { const n = []; for (const x of c) for (const s of g) n.push(over(s, x)); c = n.slice(0, 32); }
    }
    cache.set(el, c);
    return c;
  };
  const opac = (el) => { let o = 1; for (let e = el; e && e.nodeType === 1; e = e.parentElement) o *= Number(getComputedStyle(e).opacity); return o; };
  const visivel = (el) => { const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false; const cs = getComputedStyle(el); return cs.visibility !== 'hidden' && cs.display !== 'none'; };
  const desativado = (el) => !!el.closest('[disabled],[aria-disabled="true"],[aria-hidden="true"],.sr-only,canvas');
  const desc = (el) => `${el.tagName.toLowerCase()}${el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).slice(0, 2).join('.') : ''}`;
  const falhas = [];
  const pior = (fg, el) => { let r = 99; for (const b of fundos(el)) { const f = over(fg, b); r = Math.min(r, ratio(f, b)); } return r; };
  // 1. textos
  for (const el of document.querySelectorAll('body *')) {
    if (!visivel(el) || desativado(el)) continue;
    const temTexto = [...el.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim().length > 0) || (el.matches('input:not([type=checkbox]):not([type=file]),select,textarea') && el.value);
    if (!temTexto) continue;
    const cs = getComputedStyle(el);
    const fg = parse(cs.color); if (!fg) continue;
    fg[3] *= opac(el);
    const px = parseFloat(cs.fontSize), grande = px >= 24 || (px >= 18.66 && Number(cs.fontWeight) >= 700);
    // seletor de marca: o texto ativo fica sobre o indicador (elemento irmão posicionado atrás)
    const alvoFundo = el.closest('.brand-switch') && el.classList.contains('on') ? document.querySelector('.brand-switch-ind') : el;
    const r = pior(fg, alvoFundo), min = grande ? 3 : 4.5;
    if (r < min - 0.02) falhas.push({ tipo: 'texto', el: desc(el), txt: (el.value || el.textContent).trim().slice(0, 40), r: +r.toFixed(2), min });
  }
  // 2. bordas de campos (3:1 com o fundo em volta)
  for (const el of document.querySelectorAll('input.inp:not(.inp-flat), select.inp, textarea.inp, .qty, .chk-box, .search-mini, .top-search, .toggle-track')) {
    if (!visivel(el) || desativado(el)) continue;
    const cs = getComputedStyle(el);
    if (parseFloat(cs.borderTopWidth) === 0) continue;
    const bc = parse(cs.borderTopColor); if (!bc) continue;
    // borda transparente (ex.: caixa marcada, preenchida): o limite é o próprio preenchimento
    let r;
    if (bc[3] < 0.1) { const dentro = fundos(el), fora = fundos(el.parentElement); r = 99; for (const a of dentro) for (const f of fora) r = Math.min(r, ratio(a, f)); }
    else r = pior(bc, el.parentElement);
    if (r < 2.98) falhas.push({ tipo: 'borda', el: desc(el), r: +r.toFixed(2), min: 3 });
  }
  // 3. ícones (traço na cor do texto)
  for (const svg of document.querySelectorAll('body svg')) {
    const el = svg.parentElement;
    if (!el || !visivel(svg) || desativado(svg)) continue;
    const fg = parse(getComputedStyle(svg).color); if (!fg || fg[3] === 0) continue;
    fg[3] *= opac(svg);
    const r = pior(fg, el);
    if (r < 2.98) falhas.push({ tipo: 'ícone', el: desc(el), r: +r.toFixed(2), min: 3 });
  }
  // 4. contorno de foco (--accent-2) sobre o fundo da página e dos cartões
  const cs = getComputedStyle(document.documentElement);
  const foco = parse(getComputedStyle(document.body).getPropertyValue('--accent-2') ? (() => { const d = document.createElement('i'); d.style.color = cs.getPropertyValue('--accent-2'); document.body.appendChild(d); const c = getComputedStyle(d).color; d.remove(); return c; })() : null);
  const card = document.querySelector('.card') || document.body;
  if (foco) { const r = Math.min(pior(foco, document.body), pior(foco, card)); if (r < 2.98) falhas.push({ tipo: 'foco', el: '--accent-2', r: +r.toFixed(2), min: 3 }); }
  // agrupa repetições
  const vistos = new Map();
  for (const f of falhas) { const k = `${f.tipo}|${f.el}|${f.r}`; if (!vistos.has(k)) vistos.set(k, { ...f, n: 0 }); vistos.get(k).n++; }
  return [...vistos.values()];
}
