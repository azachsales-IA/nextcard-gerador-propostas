"""Capturas visuais das propostas e da interface, para comparar antes e depois.
Uso: node build/build.mjs && node build/harness.mjs && python3 tests/pecas_visual.py antes|depois
Grava em tests/out/<fase>/:
  pecas/<caso>_<tema>_imagem.jpg, <caso>_<tema>_pdf_p<n>.jpg e <caso>_<tema>.pdf (casos a–f)
  grade/… as mesmas peças com ?grid=1 (só quando o harness tem o modo de depuração)
  interface/<tela>_<pc|cel>_<tema>.png
  medidas.json (tamanho do preço, fotos desenhadas, famílias de fonte, caixas dos blocos)"""
import base64, json, os, sys
from playwright.sync_api import sync_playwright

FASE = sys.argv[1] if len(sys.argv) > 1 else 'depois'
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HARNESS = 'file://' + os.path.join(ROOT, 'harness', 'index.html')
APP = 'file://' + os.path.join(ROOT, 'dist', 'index.html')
OUT = os.path.join(ROOT, 'tests', 'out', FASE)
JS = open(os.path.join(ROOT, 'tests', 'pecas_casos_visuais.js'), encoding='utf-8').read()
for d in ('pecas', 'grade', 'interface'): os.makedirs(os.path.join(OUT, d), exist_ok=True)

def grava(path, data_url):
    open(path, 'wb').write(base64.b64decode(data_url.split(',', 1)[1]))

medidas = {}
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(HARNESS); pg.wait_for_timeout(500)
    tem_temas = pg.evaluate('!!(window.NX && window.NX.renderPaginasPDF)')
    temas = ['escuro', 'claro', 'cinza'] if tem_temas else ['escuro']
    for tema in temas:
        for grid in ([False, True] if tem_temas else [False]):
            res = pg.evaluate(JS, {'tema': tema, 'grid': grid})
            pasta = os.path.join(OUT, 'grade' if grid else 'pecas')
            for caso, r in res.items():
                base = os.path.join(pasta, f'{caso}_{tema}')
                grava(base + '_imagem.jpg', r['img'])
                for i, pag in enumerate(r['pags']): grava(f'{base}_pdf_p{i + 1}.jpg', pag)
                if not grid:
                    grava(base + '.pdf', r['pdf'])
                    medidas[f'{caso}_{tema}'] = {**r['medidas'], 'paginas': len(r['pags'])}
            print('peças', tema, 'grade' if grid else '', 'ok', flush=True)
    if errs: print('ERROS no harness:', errs)

    # Interface: início, solução, condições e proposta pronta (computador e celular)
    for tema_ui in (['escuro', 'claro'] if tem_temas else ['escuro']):
        for nome, vp, mob in (('pc', {'width': 1440, 'height': 900}, False), ('cel', {'width': 390, 'height': 844}, True)):
            ctx = b.new_context(viewport=vp, device_scale_factor=2 if mob else 1, is_mobile=mob, has_touch=mob)
            ctx.add_init_script(f"try {{ localStorage.setItem('nxp.ui', JSON.stringify({{ brand: 'nextcard', tema: '{tema_ui}' }})); }} catch (e) {{}}")
            q = ctx.new_page()
            q.goto(APP); q.wait_for_timeout(900)
            q.get_by_test_id('perfil-nome').fill('Ana Souza'); q.get_by_role('button', name='Salvar').click(); q.wait_for_timeout(3800)
            s = lambda t: q.screenshot(path=os.path.join(OUT, 'interface', f'{t}_{nome}_{tema_ui}.png'))
            s('1_inicio')
            q.get_by_test_id('sol-catraca').click(); q.wait_for_timeout(500)
            q.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
            q.locator('.stepper2 .st').nth(1).click(); q.wait_for_timeout(1200); s('2_solucao')
            q.locator('.stepper2 .st').nth(2).click(); q.wait_for_timeout(1200); s('3_condicoes')
            (q.locator('.m-bar').get_by_role('button', name='Gerar') if mob else q.locator('.b-side').get_by_role('button', name='Gerar proposta')).click()
            q.wait_for_selector('[data-testid=preview-img]', timeout=30000); q.wait_for_timeout(800); s('4_pronta')
            ctx.close()
            print('interface', tema_ui, nome, 'ok', flush=True)
    b.close()
json.dump(medidas, open(os.path.join(OUT, 'medidas.json'), 'w'), ensure_ascii=False, indent=1)
print(json.dumps({k: {'preco_img': v['imagem']['preco_px'], 'preco_pdf': v['pdf']['preco_px'], 'fotos_img': v['imagem']['fotos'], 'paginas': v['paginas']} for k, v in medidas.items()}, ensure_ascii=False))
