"""Composições lado a lado: antes (escuro) × depois (escuro) × depois (claro) × depois (cinza, NEXTCARD).
Uso: python3 tests/lado_a_lado.py  (depois de pecas_visual.py antes e depois)
Grava em tests/out/lado_a_lado/: <caso>_imagem.jpg, <caso>_pdf.jpg (uma linha por versão) e interface_<tela>_<pc|cel>.jpg"""
import glob, os, re
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'tests', 'out')
DEST = os.path.join(OUT, 'lado_a_lado'); os.makedirs(DEST, exist_ok=True)
try: FONTE = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 30)
except OSError: FONTE = ImageFont.load_default()
FAIXA, ESP = 56, 24

def abre(p, escala):
    im = Image.open(p).convert('RGB')
    return im.resize((round(im.width * escala), round(im.height * escala)), Image.LANCZOS)

def linha(imgs):
    w = sum(i.width for i in imgs) + ESP * (len(imgs) - 1); h = max(i.height for i in imgs)
    out = Image.new('RGB', (w, h), 'white'); x = 0
    for i in imgs: out.paste(i, (x, 0)); x += i.width + ESP
    return out

def compoe(colunas, destino, empilhar=False):
    """colunas: [(rótulo, imagem)]; lado a lado (ou empilhadas), com rótulo em cima de cada uma"""
    partes = []
    for rot, im in colunas:
        c = Image.new('RGB', (im.width, im.height + FAIXA), 'white'); c.paste(im, (0, FAIXA))
        ImageDraw.Draw(c).text((8, 12), rot, fill=(24, 24, 27), font=FONTE); partes.append(c)
    if empilhar:
        w = max(p.width for p in partes); h = sum(p.height for p in partes) + ESP * (len(partes) - 1)
        out = Image.new('RGB', (w, h), 'white'); y = 0
        for p in partes: out.paste(p, (0, y)); y += p.height + ESP
    else: out = linha(partes)
    out.save(destino, quality=88)

casos = sorted({re.sub(r'_(escuro|claro|cinza)_imagem\.jpg$', '', os.path.basename(p)) for p in glob.glob(os.path.join(OUT, 'depois', 'pecas', '*_imagem.jpg'))})
for caso in casos:
    ant = os.path.join(OUT, 'antes', 'pecas', f'{caso}_escuro')
    dep = lambda t: os.path.join(OUT, 'depois', 'pecas', f'{caso}_{t}')
    extra = [('depois · cinza', abre(dep('cinza') + '_imagem.jpg', .5))] if os.path.exists(dep('cinza') + '_imagem.jpg') else []
    compoe([('antes', abre(ant + '_imagem.jpg', .5)), ('depois · escuro', abre(dep('escuro') + '_imagem.jpg', .5)), ('depois · claro', abre(dep('claro') + '_imagem.jpg', .5))] + extra,
           os.path.join(DEST, f'{caso}_imagem.jpg'))
    pags = lambda base: [abre(p, .3) for p in sorted(glob.glob(base + '_pdf_p*.jpg'))]
    extra = [('depois · cinza', linha(pags(dep('cinza'))))] if pags(dep('cinza')) else []
    compoe([(f'antes ({len(pags(ant))} págs.)', linha(pags(ant))), ('depois · escuro', linha(pags(dep('escuro')))), ('depois · claro', linha(pags(dep('claro'))))] + extra,
           os.path.join(DEST, f'{caso}_pdf.jpg'), empilhar=True)
for p in sorted(glob.glob(os.path.join(OUT, 'antes', 'interface', '*_escuro.png'))):
    nome = os.path.basename(p).replace('_escuro.png', '')
    esc = .5 if '_pc' in nome else .6
    compoe([('antes', abre(p, esc)), ('depois · escuro', abre(os.path.join(OUT, 'depois', 'interface', f'{nome}_escuro.png'), esc)),
            ('depois · claro', abre(os.path.join(OUT, 'depois', 'interface', f'{nome}_claro.png'), esc))], os.path.join(DEST, f'interface_{nome}.jpg'))
print('lado a lado:', len(os.listdir(DEST)), 'arquivos em', DEST)
