// Fluxo corporativo de ponta a ponta no navegador (Playwright + PostgreSQL de teste + Kommo simulado).
// Uso: node build/build.mjs && TEST_DATABASE_URL=postgres://... node tests/e2e_corporativo.mjs
// Cobre os cenários de homologação 1 a 5 e 8 (persistência, periférico, alçada, numeração, Kommo, atualização).
import http from 'node:http';
import fs from 'node:fs';
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)(process.env.PLAYWRIGHT_PATH || 'playwright'); // Playwright global do ambiente ou do projeto

const DB = process.env.TEST_DATABASE_URL;
if (!DB) { console.log('TEST_DATABASE_URL não definida'); process.exit(1); }
process.env.DATABASE_URL = DB;
const OUT = new URL('./out/corp/', import.meta.url);
fs.mkdirSync(OUT, { recursive: true });
let falhas = 0, n = 0;
const ok = (c, m) => { n++; if (c) console.log('ok  ', m); else { falhas++; console.log('FAIL', m); } };

// Kommo simulado
const kommo = { anexos: {}, uploads: 0, bytes: 0, esperado: 0, falhar: 1 };
const ks = http.createServer(async (req, res) => {
  const ch = []; for await (const c of req) ch.push(c); const body = Buffer.concat(ch);
  const j = (o, s = 200) => { res.statusCode = s; res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(o)); };
  const u = new URL(req.url, 'http://x'); const base = `http://127.0.0.1:${ks.address().port}`;
  if (u.pathname === '/api/v4/account') return j({ drive_url: base + '/drive' });
  if (u.pathname === '/api/v4/leads/pipelines') return j({ _embedded: { pipelines: [{ id: 1, name: 'Funil Nextcard', _embedded: { statuses: [{ id: 2, name: 'Envio de proposta' }] } }] } });
  if (u.pathname === '/api/v4/users') return j({ _embedded: { users: [{ id: 3, name: 'Ana' }] } });
  const lead = (id, name) => ({ id, name, pipeline_id: 1, status_id: 2, responsible_user_id: 3, created_at: 1794000000, _embedded: { contacts: [{ id: 9, is_main: true }], companies: [{ id: 5 }] } });
  if (u.pathname === '/api/v4/leads') return j({ _embedded: { leads: [lead(22728655, 'Comandas Eletrônicas | Maria'), lead(22728700, 'Totem | Maria')] } });
  if (u.pathname === '/api/v4/leads/22728655') return j(lead(22728655, 'Comandas Eletrônicas | Maria'));
  if (u.pathname === '/api/v4/contacts/9') return j({ id: 9, name: 'Maria Souza', custom_fields_values: [{ field_code: 'PHONE', values: [{ value: '+55 41 99999-0000' }] }, { field_code: 'EMAIL', values: [{ value: 'maria@nabrasa.com.br' }] }] });
  if (u.pathname === '/api/v4/companies/5') return j({ id: 5, name: 'Na Brasa Restaurante' });
  if (u.pathname === '/drive/v1.0/sessions') { const b = JSON.parse(body); kommo.esperado = b.file_size; kommo.bytes = 0; return j({ upload_url: base + '/drive/up', max_part_size: 512 * 1024 }); }
  if (u.pathname === '/drive/up') { kommo.bytes += body.length; if (kommo.bytes >= kommo.esperado) { kommo.uploads++; return j({ uuid: 'f' + kommo.uploads }); } return j({ next_url: base + '/drive/up' }); }
  const m = u.pathname.match(/^\/api\/v4\/leads\/(\d+)\/files$/);
  if (m && req.method === 'PUT') { if (kommo.falhar > 0) { kommo.falhar--; return j({ title: 'Erro temporário' }, 500); } (kommo.anexos[m[1]] ||= []).push(...JSON.parse(body).map((x) => x.file_uuid)); return j({}); }
  if (m) return j({ _embedded: { files: (kommo.anexos[m[1]] || []).map((f) => ({ file_uuid: f })) } });
  j({ title: 'nf' }, 404);
});
await new Promise((r) => ks.listen(0, '127.0.0.1', r));
process.env.KOMMO_BASE_URL = `http://127.0.0.1:${ks.address().port}`; process.env.KOMMO_TOKEN = 't';

const dbm = await import('../server/db.js');
await dbm.q('drop schema public cascade; create schema public;');
await dbm.migrate();
const { hashSenha } = await import('../server/auth.js');
const CFG = JSON.parse(fs.readFileSync(new URL('../db/seed/config.json', import.meta.url), 'utf8'));
await dbm.q('insert into config_versions (version, data) values (1, $1)', [CFG]);
await dbm.q('insert into sequencia (id, proximo) values (1, 1276)');
const SENHA = 'senha-forte-123';
for (const [e, nome, sg, roles] of [['admin@nx.com', 'Admin Nextcard', 'AD', ['owner']], ['hamilton@nx.com', 'Hamilton Flores', 'HF', ['aprovador', 'gestor']], ['ana@nx.com', 'Ana Lima', 'AL', ['consultor']]])
  await dbm.q('insert into users (email, nome, sigla, telefone, roles, pass_hash) values ($1, $2, $3, $4, $5, $6)', [e, nome, sg, '(41) 98888-0000', roles, hashSenha(SENHA)]);

const { handler } = await import('../server/app.js');
const html = fs.readFileSync(new URL('../dist/index.html', import.meta.url));
const srv = http.createServer((req, res) => (req.url.startsWith('/api/') ? handler(req, res) : (res.setHeader('Content-Type', 'text/html; charset=utf-8'), res.end(html))));
await new Promise((r) => srv.listen(0, '127.0.0.1', r));
const URL_ = `http://127.0.0.1:${srv.address().port}/`;

const browser = await chromium.launch();
const shot = (pg, nome) => pg.screenshot({ path: new URL(nome + '.png', OUT).pathname });
async function entrar(email, viewport = { width: 1440, height: 900 }) {
  const ctx = await browser.newContext({ viewport, acceptDownloads: true });
  const pg = await ctx.newPage();
  pg.on('pageerror', (e) => { falhas++; console.log('FAIL erro de página:', e.message); });
  pg.on('dialog', (d) => d.accept());
  await pg.goto(URL_);
  await pg.fill('[data-testid=login-email]', email);
  await pg.fill('[data-testid=login-senha]', SENHA);
  await pg.click('button[type=submit]');
  await pg.waitForSelector('.side-nav');
  return pg;
}
const nav = (pg, t) => pg.click(`.side-nav button:has-text("${t}")`);
const tem = async (pg, sel) => (await pg.locator(sel).count()) > 0;

try {
  // ── Login ──
  {
    const ctx = await browser.newContext(); const pg = await ctx.newPage();
    await pg.goto(URL_);
    await pg.waitForSelector('[data-testid=login-email]');
    await shot(pg, '01-login');
    await pg.fill('[data-testid=login-email]', 'ana@nx.com'); await pg.fill('[data-testid=login-senha]', 'errada'); await pg.click('button[type=submit]');
    await pg.waitForSelector('[data-testid=login-erro]');
    ok(true, 'senha errada mostra erro e não entra');
    await ctx.close();
  }

  // ── Cenários 1 e 2: administrador altera taxa e preço de serviço; salva; persiste ──
  const admin = await entrar('admin@nx.com');
  await nav(admin, 'Configuração');
  await admin.click('.seg button:has-text("Condições")');
  await shot(admin, '02-config-condicoes');
  const antesBar = await tem(admin, '[data-testid=savebar]');
  ok(!antesBar, 'sem alteração não há barra de salvamento');
  const inputs = admin.locator('.content input.inp');
  let alvo = null;
  for (let i = 0; i < await inputs.count(); i++) { const v = await inputs.nth(i).inputValue(); if (v.replace(',', '.') === '1.077') { alvo = inputs.nth(i); break; } }
  ok(!!alvo, 'campo do fator 1,077 encontrado');
  await alvo.fill('1,0825'); await alvo.blur();
  await admin.waitForSelector('[data-testid=savebar][data-estado=sujo]');
  ok(true, 'alteração mostra "Alterações não salvas"');
  await shot(admin, '03-config-nao-salvo');
  await admin.click('[data-testid=savebar-salvar]');
  await admin.waitForSelector('[data-testid=savebar][data-estado=salvo]');
  ok(true, 'barra confirma "Salvo com sucesso" só depois do servidor');
  const v2 = (await dbm.q('select version, data from config_versions order by version desc limit 1')).rows[0];
  ok(v2.version === 2 && v2.data.nextcard.condicoes.find((c) => c.id === 'cc6').fator === 1.0825, 'taxa gravada no banco como versão 2');
  await admin.reload(); await admin.waitForSelector('.side-nav');
  await nav(admin, 'Configuração'); await admin.click('.seg button:has-text("Condições")');
  let achou = false;
  for (let i = 0; i < await inputs.count(); i++) if ((await inputs.nth(i).inputValue()).replace(',', '.') === '1.0825') achou = true;
  ok(achou, 'depois de recarregar a página a taxa continua 1,0825');

  // ── Consultor: vê a taxa nova, não tem telas de administração ──
  const ana = await entrar('ana@nx.com');
  ok(!(await tem(ana, '.side-nav button:has-text("Administração")')), 'consultor não vê Administração');
  await nav(ana, 'Configuração');
  ok(!(await tem(ana, '.seg button:has-text("Catálogo e preços")')) && !(await tem(ana, '.seg button:has-text("Condições")')), 'consultor não vê catálogo, preços nem condições em Configuração');
  await shot(ana, '04-consultor-config');

  // ── Cenários 4 e 5: proposta de catracas, negócio do Kommo, emissão, número, anexo ──
  await ana.click('.side-new');
  await ana.click('.modal >> text=Catracas');
  await ana.waitForSelector('[data-testid=kommo-busca]');
  await ana.fill('[data-testid=kommo-busca]', 'maria'); await ana.keyboard.press('Enter');
  await ana.waitForSelector('[data-testid=kommo-lead]');
  ok(await ana.locator('[data-testid=kommo-lead]').count() === 2, 'cliente com dois negócios: o consultor escolhe');
  await shot(ana, '05-kommo-busca');
  await ana.locator('[data-testid=kommo-lead]').first().click();
  await ana.waitForSelector('[data-testid=kommo-vinculado]');
  ok(await ana.inputValue('[data-testid=cliente-empresa]') === 'Na Brasa Restaurante', 'dados do cliente importados do Kommo');
  await ana.click('.step-nav .btn-primary'); // passo 2
  await ana.waitForSelector('[data-testid=card-catraca]');
  await shot(ana, '06-solucao');
  await ana.click('.step-nav .btn-primary'); // passo 3
  await ana.waitForTimeout(400);
  await ana.click('.step-nav .btn-gerar');
  await ana.waitForSelector('.ready-head h2', { timeout: 30000 });
  const num1 = (await ana.textContent('.ready-head h2')).trim();
  ok(/^Nº \d{8}\/1276AL$/.test(num1), `número no padrão DDMMAAAA/SEQ+SUFIXO (${num1})`);
  await ana.waitForSelector('[data-testid=kommo-status][data-estado=falha]', { timeout: 60000 });
  ok(true, 'falha do Kommo aparece na tela, com a proposta preservada');
  await shot(ana, '07-kommo-falha');
  ok(kommo.uploads === 1, 'PDF enviado uma vez ao Kommo');
  await ana.click('[data-testid=kommo-repetir]');
  await ana.waitForSelector('[data-testid=kommo-status][data-estado=anexado]', { timeout: 30000 });
  ok(kommo.uploads === 1 && (kommo.anexos['22728655'] || []).length === 1, 'nova tentativa anexa sem reenviar o arquivo e sem duplicar');
  await shot(ana, '08-kommo-anexado');
  const ver = (await dbm.q("select v.valor_final, v.config_version, length(v.pdf) as tam, substring(v.pdf from 1 for 5) as ini from proposta_versoes v where v.numero like '%/1276AL'")).rows[0];
  ok(ver && ver.tam > 20000 && ver.ini.toString() === '%PDF-', `PDF emitido guardado no servidor (${Math.round(ver.tam / 1024)} KB)`);
  ok(ver.config_version === 2, 'snapshot aponta para a versão 2 da configuração');
  const etapa = (await dbm.q("select etapa, compartilhamento from propostas where numero like '%/1276AL'")).rows[0];
  ok(etapa.etapa === 'rascunho' && etapa.compartilhamento === 'nao_compartilhada', 'emitir e anexar não marca a proposta como enviada');
  const [dl] = await Promise.all([ana.waitForEvent('download'), ana.click('[data-testid=baixar-pdf]')]);
  ok(/^Proposta_\d{8}_1276AL\.pdf$/.test(dl.suggestedFilename()), `nome seguro do arquivo (${dl.suggestedFilename()})`);
  const valor1 = ver.valor_final;

  // ── Cenário 2: administrador muda o preço do serviço; proposta antiga não muda ──
  await nav(admin, 'Configuração'); await admin.click('.seg button:has-text("Catálogo e preços")');
  await admin.click('.card-head .seg button:has-text("Serviços")');
  await admin.waitForTimeout(300);
  const money = admin.locator('.content .inp-money');
  let srvInput = null;
  for (let i = 0; i < await money.count(); i++) if ((await money.nth(i).inputValue()) === '2.450,00') { srvInput = money.nth(i); break; }
  ok(!!srvInput, 'preço do serviço de instalação encontrado no catálogo');
  await srvInput.fill('2.600,00'); await srvInput.blur();
  await admin.click('[data-testid=savebar-salvar]');
  await admin.waitForSelector('[data-testid=savebar][data-estado=salvo]');
  const depois = (await dbm.q("select v.valor_final from proposta_versoes v where v.numero like '%/1276AL'")).rows[0];
  ok(depois.valor_final === valor1, 'proposta já emitida mantém o valor original');

  // consultor volta à aba: recebe a tabela nova sem recarregar
  await ana.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  await ana.waitForTimeout(1200);
  await ana.click('.side-new'); await ana.click('.modal >> text=Catracas');
  await ana.fill('[data-testid=cliente-empresa]', 'Posto Teste');
  await ana.click('.step-nav .btn-primary'); await ana.click('.step-nav .btn-primary'); await ana.waitForTimeout(300);
  const totalTxt = await ana.textContent('[data-testid=valor-final-side]');
  await ana.click('.step-nav .btn-gerar');
  await ana.waitForSelector('.ready-head h2');
  const num2 = (await ana.textContent('.ready-head h2')).trim();
  ok(/\/1277AL$/.test(num2), `segunda proposta recebe o número seguinte (${num2})`);
  const v2b = (await dbm.q("select valor_final, config_version from proposta_versoes where numero like '%/1277AL'")).rows[0];
  ok(v2b.valor_final === valor1 + 15000 && v2b.config_version === 3, `nova proposta usa o preço novo do serviço (${totalTxt.trim()})`);

  // ── Cenário 3: alçada ──
  await ana.click('.ready-foot button:has-text("Editar")');
  await ana.waitForSelector('[data-testid=card-catraca]');
  const preco = ana.locator('[data-testid=card-catraca] .inp-money').first();
  const tabela = await preco.inputValue();
  const cents = Number(tabela.replace(/\./g, '').replace(',', '.')) * 100;
  const com4 = (Math.round(cents * 0.96) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2 });
  await preco.fill(com4); await preco.blur();
  await ana.waitForSelector('[data-testid=resumo-desconto]');
  ok((await ana.textContent('[data-testid=resumo-desconto]')).includes('Sua alçada: 0%'), 'resumo mostra desconto e alçada zero');
  await shot(ana, '09-desconto-acima');
  await ana.click('.b-side .btn-gerar');
  await ana.waitForSelector('[data-testid=pedir-aprovacao]');
  ok(true, 'emissão acima da alçada é bloqueada com explicação');
  ok((await dbm.q("select versao from propostas where numero like '%/1277AL'")).rows[0].versao === 1, 'bloqueio não gera nova versão nem consome número');
  await ana.fill('[data-testid=justificativa]', 'Cliente fecha hoje à vista');
  await shot(ana, '10-pedido-aprovacao');
  await ana.click('[data-testid=pedir-aprovacao]');
  await ana.waitForSelector('[data-testid=aprovacao]');

  const ham = await entrar('hamilton@nx.com');
  ok(!(await tem(ham, '.seg button:has-text("Catálogo e preços")')), 'aprovador não edita catálogo');
  await nav(ham, 'Aprovações');
  await ham.waitForSelector('[data-testid=aprovacao]');
  await shot(ham, '11-aprovacoes');
  await ham.click('[data-testid=aprovacao] button:has-text("Aprovar")');
  await ham.click('.modal .btn-primary');
  await ham.waitForSelector('text=Aprovada');
  // alçada de 5% para a Ana
  await nav(ham, 'Administração');
  await ham.waitForSelector('[data-testid=alcada-user]');
  await ham.selectOption('[data-testid=alcada-user]', { label: 'Ana Lima' });
  await ham.fill('[data-testid=alcada-pct]', '5');
  await ham.click('[data-testid=alcada-conceder]');
  await ham.waitForSelector('text=Vigente');
  await shot(ham, '12-alcadas');

  // Ana emite a revisão aprovada: mesmo número, versão 2
  await nav(ana, 'Propostas');
  await ana.click('text=Posto Teste');
  await ana.waitForSelector('.ready-foot');
  await ana.click('.ready-foot button:has-text("Editar")');
  await ana.waitForSelector('[data-testid=card-catraca]');
  await ana.click('.b-side .btn-gerar');
  await ana.waitForSelector('.ready-head h2 small');
  ok((await ana.textContent('.ready-head h2')).includes('1277AL') && (await ana.textContent('.ready-head h2')).includes('versão 2'), 'revisão aprovada mantém o número e vira versão 2');
  const snap = (await dbm.q("select snapshot from proposta_versoes where numero like '%/1277AL' and versao = 2")).rows[0].snapshot;
  ok(snap.desconto.via === 'alcada' && snap.desconto.alcada.pct === 5 && snap.desconto.pct > 0 && snap.desconto.pct <= 5, 'snapshot registra o desconto e a alçada que o cobriu (a aprovação por exceção é coberta nos testes de API)');
  const v1 = (await dbm.q("select valor_final from proposta_versoes where numero like '%/1277AL' and versao = 1")).rows[0];
  ok(v1.valor_final === valor1 + 15000, 'versão 1 continua com o valor original');

  // ── Celular ──
  const cel = await entrar('ana@nx.com', { width: 390, height: 844 });
  await cel.waitForTimeout(500);
  const largura = await cel.evaluate(() => document.documentElement.scrollWidth);
  ok(largura <= 392, `sem rolagem horizontal no celular (${largura}px)`);
  await shot(cel, '13-celular-inicio');

  // ── Painel e histórico do administrador ──
  await nav(admin, 'Administração');
  await admin.click('.seg button:has-text("Histórico de alterações")');
  await admin.waitForSelector('text=Configuração publicada');
  ok((await admin.textContent('.tbl')).includes('nextcard.condicoes[cc6].fator'), 'histórico mostra o que mudou em cada publicação');
  await shot(admin, '14-historico');
  await admin.click('.seg button:has-text("Usuários")');
  await shot(admin, '15-usuarios');
} catch (e) { falhas++; console.log('FAIL exceção:', e.message.split('\n')[0]); try { for (const c of browser.contexts()) for (const p of c.pages()) await p.screenshot({ path: new URL(`erro-${Date.now()}.png`, OUT).pathname }); } catch (_) { /* sem captura */ } }

await browser.close(); srv.close(); ks.close(); await dbm.closePool();
console.log(falhas ? `\n${falhas} FALHA(S) em ${n} verificações` : `\nTODAS AS ${n} VERIFICAÇÕES PASSARAM`);
process.exit(falhas ? 1 : 0);
