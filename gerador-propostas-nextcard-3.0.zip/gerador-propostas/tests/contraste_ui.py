"""Auditoria de contraste (WCAG AA) de todas as telas, nas duas marcas e nos dois temas da interface.
Uso: node build/build.mjs && python3 tests/contraste_ui.py [claro|escuro|todos]
Telas: início, modal "Nova proposta", passos Cliente/Solução (cartão aberto)/Condições, proposta pronta com aviso,
Propostas, Catálogo, Política e Configuração. Falha (código 1) se houver problema no tema pedido."""
import json, os, sys
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = 'file://' + os.path.join(ROOT, 'dist', 'index.html')
JS = open(os.path.join(ROOT, 'tests', 'contraste.js'), encoding='utf-8').read()
alvo = sys.argv[1] if len(sys.argv) > 1 else 'todos'
temas = ['escuro', 'claro'] if alvo == 'todos' else [alvo]
total = {}
with sync_playwright() as p:
    b = p.chromium.launch()
    for tema in temas:
        for marca in ('nextcard', 'teloos'):
            ctx = b.new_context(viewport={'width': 1440, 'height': 900})
            ctx.add_init_script(f"try {{ localStorage.setItem('nxp.ui', JSON.stringify({{ brand: '{marca}', tema: '{tema}' }})); }} catch (e) {{}}")
            pg = ctx.new_page(); pg.goto(URL); pg.wait_for_timeout(800)
            res = {}
            aud = lambda nome: res.__setitem__(nome, pg.evaluate(JS))
            aud('perfil (modal)')
            pg.get_by_test_id('perfil-nome').fill('Ana Souza'); pg.get_by_role('button', name='Salvar').click(); pg.wait_for_timeout(400)
            aud('início + aviso')
            pg.locator('.side-new').click(); pg.wait_for_timeout(300); aud('modal nova proposta'); pg.keyboard.press('Escape')
            sol = 'sol-teloos' if marca == 'teloos' else 'sol-catraca'
            pg.get_by_test_id(sol).click(); pg.wait_for_timeout(500); aud('passo cliente')
            pg.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
            pg.locator('.stepper2 .st').nth(1).click(); pg.wait_for_timeout(600)
            if marca == 'nextcard':
                pg.locator('[data-testid=card-comanda] .icard-thumb').click(); pg.wait_for_timeout(300)
            else:
                pg.locator('.plan').nth(1).click(); pg.locator('.addon .add-btn').first.click(); pg.wait_for_timeout(300)
            aud('passo solução')
            pg.locator('.stepper2 .st').nth(2).click(); pg.wait_for_timeout(600)
            if marca == 'nextcard': pg.get_by_test_id('cond-cc12').locator('.pay-main').click(); pg.wait_for_timeout(300)
            aud('passo condições')
            pg.locator('.b-side').get_by_role('button', name='Gerar proposta').click()
            pg.wait_for_selector('[data-testid=preview-img]', timeout=30000); pg.wait_for_timeout(600); aud('proposta pronta')
            for nav in ('Propostas', 'Catálogo', 'Política comercial', 'Configuração'):
                pg.locator('.side-nav .nav', has_text=nav).click(); pg.wait_for_timeout(400); aud(nav.lower())
            pg.locator('.seg button', has_text='Aparência').click(); pg.wait_for_timeout(300); aud('configuração · aparência')
            ctx.close()
            n = sum(len(v) for v in res.values())
            total[f'{tema}/{marca}'] = n
            print(f'\n== {tema} · {marca}: {n} problema(s)')
            for tela, fs in res.items():
                for f in fs: print(f'  [{tela}] {f["tipo"]} {f["el"]} "{f.get("txt", "")}" {f["r"]}:1 (mín. {f["min"]}) ×{f["n"]}')
    b.close()
print('\nResumo:', json.dumps(total, ensure_ascii=False))
sys.exit(1 if any(v for v in total.values()) else 0)
