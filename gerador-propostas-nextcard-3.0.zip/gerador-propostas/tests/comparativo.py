"""Monta as capturas antes/depois lado a lado em tests/out/comparativo/ (usa o Chromium do Playwright).
Uso: python3 tests/ux_auditoria.py depois && python3 tests/comparativo.py"""
import base64, os
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(ROOT, 'tests', 'out', 'rodada1', 'auditoria', 'antes'); D = os.path.join(ROOT, 'tests', 'out', 'rodada1', 'auditoria', 'depois')
O = os.path.join(ROOT, 'tests', 'out', 'rodada1', 'comparativo'); os.makedirs(O, exist_ok=True)
PARES = [('cel_c1_teloos', 'P1 · Teloos no celular: adicionais'), ('cel_a2_solucao', 'P2 · Cartão de item no celular'),
         ('pc_a5_cc12_sem_valor', 'P3 · Condição sem valor do simulador (computador)'), ('cel_a5_cc12_sem_valor', 'P3 · Condição sem valor do simulador (celular)'),
         ('cel_e1_busca', 'P4 · Busca em Propostas (celular)'), ('pc_e1_busca', 'P4 · Busca em Propostas (computador)'),
         ('cel_a3_toast', 'P5 · Aviso com botão de fechar (celular)'), ('pc_a7_envio_sem_permissao', 'P6 · Envio sem permissão de copiar a imagem'),
         ('pc_b1_totem', 'P7 e P9 · Totem: chips e contraste'), ('cel_a4_condicoes', 'P10 · Condições no celular (alvos de 44 px)')]
uri = lambda p: 'data:image/png;base64,' + base64.b64encode(open(p, 'rb').read()).decode()
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1600, 'height': 900})
    for nome, tit in PARES:
        cel = nome.startswith('cel')
        w = 380 if cel else 760
        html = f"""<html><body style="margin:0;padding:20px;background:#f4f4f5;font:600 20px system-ui;color:#111">
        <div style="margin-bottom:12px">{tit}</div><div style="display:flex;gap:24px;align-items:flex-start">
        <figure style="margin:0"><figcaption style="color:#b91c1c;margin-bottom:6px">ANTES</figcaption><img src="{uri(os.path.join(A, nome + '.png'))}" style="width:{w}px;display:block"></figure>
        <figure style="margin:0"><figcaption style="color:#15803d;margin-bottom:6px">DEPOIS</figcaption><img src="{uri(os.path.join(D, nome + '.png'))}" style="width:{w}px;display:block"></figure>
        </div></body></html>"""
        pg.set_content(html); pg.wait_for_timeout(200)
        pg.set_viewport_size({'width': 2 * w + 64, 'height': 600})
        pg.screenshot(path=os.path.join(O, nome + '.png'), full_page=True)
        print('ok', nome)
    b.close()
