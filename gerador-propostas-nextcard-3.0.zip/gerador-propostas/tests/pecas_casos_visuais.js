// Casos (a)–(f) das capturas visuais. Recebe { tema, grid } e devolve imagem, páginas do PDF, o PDF e medidas.
// Roda no harness (window.NX). Funciona com a versão antiga (sem temas nem modo) e com a nova.
async ({ tema, grid }) => {
  const N = window.NX;
  const cfg = N.defaultConfig();
  cfg.responsaveis = [{ nome: 'Ana Souza', sigla: 'A', telefone: '(41) 90000-0000', email: 'ana.souza@exemplo.com.br' }];
  const perfil = { nome: 'Ana Souza' };
  const emit = (p) => ({ ...p, numero: '30092026/1218A', emitidaEm: '2026-09-30T13:00:00', nome: p.nome || N.nomeSugerido(p, cfg), temaProposta: tema });
  // logo fictício do cliente (fundo transparente, letras escuras)
  const lc = document.createElement('canvas'); lc.width = 520; lc.height = 200;
  const lx = lc.getContext('2d'); lx.fillStyle = '#B4262C'; lx.beginPath(); lx.arc(100, 100, 80, 0, Math.PI * 2); lx.fill();
  lx.fillStyle = '#FFFFFF'; lx.font = '700 90px sans-serif'; lx.textAlign = 'center'; lx.fillText('R', 100, 132);
  lx.fillStyle = '#222222'; lx.textAlign = 'left'; lx.font = '700 64px sans-serif'; lx.fillText('Modelo', 200, 96); lx.font = '400 40px sans-serif'; lx.fillText('restaurante', 202, 150);
  const logoCliente = lc.toDataURL('image/png');
  const T = cfg.nextcard.totem;
  const casos = {};
  // (a) catracas: 2 modelos + comandas + serviço (como o exemplo)
  let p = N.novaProposta('nextcard', cfg, 'catraca', perfil);
  p.cliente = { ...p.cliente, empresa: 'Restaurante Modelo', contato: 'Ana Souza', logo: logoCliente };
  p.validadeOpcao = '3u'; p.pagamento.destaque = 'bol2856';
  casos.a_catracas = emit(p);
  // (b) totem com 1 modelo
  p = N.novaProposta('nextcard', cfg, 'totem', perfil);
  p.cliente = { ...p.cliente, empresa: 'Restaurante Modelo', contato: 'Ana Souza' };
  casos.b_totem = emit(p);
  // (c) 3 modelos de equipamento: totem + expedidora + receptora
  p = N.novaProposta('nextcard', cfg, 'catraca', perfil);
  p.itens.unshift(N.linhaTotem({ modelo: 'NX32-V', ...T.referencia }, cfg, p, 2));
  p.pagamento.destaque = 'cc6';
  p.cliente = { ...p.cliente, empresa: 'Restaurante Modelo' };
  p.inclusos = N.autoInclusos(p, cfg);
  casos.c_tres_modelos = emit(p);
  // (d) só comandas, sem foto de equipamento
  p = N.novaProposta('nextcard', cfg, 'comanda', perfil);
  p.cliente = { ...p.cliente, empresa: 'Restaurante Modelo', contato: 'Ana Souza' };
  casos.d_comandas = emit(p);
  // (e) cliente com nome longo (45 caracteres), sem logo
  p = N.novaProposta('nextcard', cfg, 'totem', perfil);
  const sel = { ...p.itens[0].config, modelo: 'NX21-B' };
  p.itens = [N.linhaTotem(sel, cfg, p, 3)];
  p.cliente = { ...p.cliente, empresa: 'Churrascaria e Pizzaria Sabor da Serra Gaúcha', contato: 'Maria Aparecida Fernandes' };
  p.validadeOpcao = '2u';
  p.inclusos = N.autoInclusos(p, cfg);
  casos.e_nome_longo = emit(p);
  // (f) Teloos
  p = N.novaProposta('teloos', cfg, 'teloos', perfil);
  const pl = cfg.teloos.planos[1] || cfg.teloos.planos[0];
  p.teloos = { plano: pl.id, cupom: 10, implantacao: 'd1' };
  const ads = cfg.teloos.adicionais.filter((a) => a.planos.includes(pl.id) && a.cents != null).slice(0, 3);
  p.itens = [N.linhaPlano(pl, 10), ...ads.map((a) => N.linhaAdicional(a, 10, 1)), N.linhaImplantacao(cfg.teloos.implantacao.find((i) => i.id === 'd1'))];
  p.pagamento.destaque = 'anualcartao';
  p.cliente = { ...p.cliente, empresa: 'Restaurante Modelo', contato: 'Ana Souza' };
  p.inclusos = N.autoInclusos(p, cfg);
  casos.f_teloos = emit(p);

  // medidas: maior fonte (preço) e fotos de equipamento desenhadas
  const fotos = new Set(Object.values(N.PHOTOS));
  let sizes = [], draws = [];
  const oFill = CanvasRenderingContext2D.prototype.fillText, oDraw = CanvasRenderingContext2D.prototype.drawImage;
  CanvasRenderingContext2D.prototype.fillText = function (t, x, y) { const m = /(\d+(?:\.\d+)?)px/.exec(this.font); sizes.push([m ? +m[1] : 0, String(t), this.font]); return oFill.apply(this, arguments); };
  CanvasRenderingContext2D.prototype.drawImage = function (im) { if (arguments.length >= 5 && im && fotos.has(im.src)) { const t = this.getTransform(); draws.push({ w: arguments[3] * t.a, h: arguments[4] * t.d }); } return oDraw.apply(this, arguments); };
  const medir = () => {
    const precos = sizes.filter(([, t]) => /^R\$\s?[\d.]+,\d\d$/.test(t.trim()));
    const r = { preco_px: precos.length ? Math.max(...precos.map(([s]) => s)) : null, fotos: draws.map((d) => ({ w: Math.round(d.w), h: Math.round(d.h) })), familias: [...new Set(sizes.map(([, , f]) => (f.match(/px\s+"?([^",]+)/) || [])[1]))] };
    sizes = []; draws = [];
    return r;
  };
  const out = {};
  for (const [k, prop] of Object.entries(casos)) {
    const m = N.buildModel(prop, cfg, {}, N.PHOTOS);
    const opts = { grid };
    sizes = []; draws = [];
    const img = await N.renderPeca(m, cfg, 1, { ...opts, modo: 'imagem' });
    const mImg = medir();
    let pags;
    if (N.renderPaginasPDF) pags = await N.renderPaginasPDF(m, cfg, 1, opts);
    else pags = [await N.renderPeca(m, cfg, 1), ...(await N.renderDetalhe(m, cfg, 1))];
    const mPdf = medir();
    const pdf = await N.pdfBlob(pags);
    const pdfB64 = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.readAsDataURL(pdf); });
    out[k] = {
      img: img.toDataURL('image/jpeg', 0.9),
      pags: pags.map((c) => c.toDataURL('image/jpeg', 0.88)),
      pdf: pdfB64,
      medidas: { imagem: mImg, pdf: mPdf, blocos: img.__blocos || null, blocosPdf: pags.map((c) => c.__blocos || null) },
    };
  }
  CanvasRenderingContext2D.prototype.fillText = oFill; CanvasRenderingContext2D.prototype.drawImage = oDraw;
  return out;
}
