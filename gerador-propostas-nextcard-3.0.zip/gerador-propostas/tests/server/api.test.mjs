// Testes de integração da API contra um PostgreSQL real.
// Uso: TEST_DATABASE_URL=postgres://... node --test tests/server/
// O Kommo é simulado por um servidor local (a API real não foi exercitada; ver docs/KOMMO_INTEGRATION.md).
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import crypto from 'node:crypto';

const DB = process.env.TEST_DATABASE_URL;
if (!DB) { console.log('TEST_DATABASE_URL não definida: testes de API ignorados'); process.exit(0); }
process.env.DATABASE_URL = DB;
process.env.PG_POOL_MAX = '10';

// ── Kommo simulado ──
const kommo = { anexos: {}, uploads: 0, falharAnexo: 0, falharUpload: 0 };
const kommoSrv = http.createServer(async (req, res) => {
  const chunks = []; for await (const c of req) chunks.push(c);
  const body = Buffer.concat(chunks);
  const j = (o, s = 200) => { res.statusCode = s; res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(o)); };
  if (req.headers.authorization !== 'Bearer tok') return j({ title: 'Unauthorized' }, 401);
  const u = new URL(req.url, 'http://x');
  const base = `http://127.0.0.1:${kommoSrv.address().port}`;
  if (u.pathname === '/api/v4/account') return j({ id: 1, drive_url: base + '/drive' });
  if (u.pathname === '/api/v4/leads/pipelines') return j({ _embedded: { pipelines: [{ id: 10, name: 'Funil Nextcard', _embedded: { statuses: [{ id: 5, name: 'Envio de proposta' }] } }] } });
  if (u.pathname === '/api/v4/users') return j({ _embedded: { users: [{ id: 7, name: 'Maria' }] } });
  if (u.pathname === '/api/v4/leads' && req.method === 'GET') {
    if (u.searchParams.get('query') === 'nada') { res.statusCode = 204; return res.end(); }
    return j({ _embedded: { leads: [{ id: 22728655, name: 'Comandas Eletrônicas | Maria', pipeline_id: 10, status_id: 5, responsible_user_id: 7, created_at: 1794000000, _embedded: { contacts: [{ id: 99, is_main: true }] } }, { id: 22728656, name: 'Totem | Maria', pipeline_id: 10, status_id: 5, responsible_user_id: 7, created_at: 1794000001, _embedded: { contacts: [{ id: 99 }] } }] } });
  }
  if (u.pathname === '/drive/v1.0/sessions') { if (kommo.falharUpload > 0) { kommo.falharUpload--; return j({ title: 'boom' }, 500); } return j({ session_id: 1, upload_url: base + '/drive/up/1', max_part_size: 1024 }); }
  if (u.pathname.startsWith('/drive/up/')) {
    const n = Number(u.pathname.split('/').pop());
    kommo.partes = (kommo.partes || 0) + body.length;
    if (kommo.partes >= kommo.esperado) { kommo.uploads++; kommo.partes = 0; return j({ uuid: 'file-' + kommo.uploads }); }
    return j({ next_url: base + '/drive/up/' + (n + 1) });
  }
  const m = u.pathname.match(/^\/api\/v4\/leads\/(\d+)\/files$/);
  if (m && req.method === 'PUT') {
    if (kommo.falharAnexo > 0) { kommo.falharAnexo--; return j({ title: 'erro' }, 500); }
    (kommo.anexos[m[1]] ||= []).push(...JSON.parse(body.toString()).map((x) => x.file_uuid));
    return j({ _embedded: { files: [] } });
  }
  if (m && req.method === 'GET') return j({ _embedded: { files: (kommo.anexos[m[1]] || []).map((f) => ({ file_uuid: f })) } });
  j({ title: 'not found' }, 404);
});

let api, base, srv, dbm, CFG;
before(async () => {
  await new Promise((r) => kommoSrv.listen(0, '127.0.0.1', r));
  process.env.KOMMO_BASE_URL = `http://127.0.0.1:${kommoSrv.address().port}`;
  process.env.KOMMO_TOKEN = 'tok';
  dbm = await import('../../server/db.js');
  await dbm.q('drop schema public cascade; create schema public;');
  await dbm.migrate();
  CFG = JSON.parse(fs.readFileSync(new URL('../../db/seed/config.json', import.meta.url), 'utf8'));
  const { hashSenha } = await import('../../server/auth.js');
  await dbm.q("insert into config_versions (version, data) values (1, $1)", [CFG]);
  await dbm.q('insert into sequencia (id, proximo) values (1, 1276)');
  const u = (email, nome, sigla, roles) => dbm.q('insert into users (email, nome, sigla, roles, pass_hash) values ($1, $2, $3, $4, $5)', [email, nome, sigla, roles, hashSenha('senha-forte-123')]);
  await u('admin@x.com', 'Admin', 'AD', ['owner']);
  await u('hamilton@x.com', 'Hamilton Flores', 'HF', ['aprovador', 'gestor']);
  await u('ana@x.com', 'Ana', 'A', ['consultor']);
  await u('bia@x.com', 'Bia', 'B', ['consultor']);
  const { handler } = await import('../../server/app.js');
  srv = http.createServer(handler);
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${srv.address().port}`;
});
after(async () => { srv?.close(); kommoSrv.close(); await dbm?.closePool(); });

// cliente de teste com cookie por usuário
function cliente() {
  let cookie = '';
  const call = async (method, path, body, { raw, semCsrf } = {}) => {
    const headers = { ...(cookie ? { cookie } : {}), ...(semCsrf ? {} : { 'x-nx': '1' }) };
    if (body !== undefined) headers['content-type'] = raw ? 'application/pdf' : 'application/json';
    const r = await fetch(base + path, { method, headers, body: body === undefined ? undefined : raw ? body : JSON.stringify(body) });
    const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
    const ct = r.headers.get('content-type') || '';
    return { status: r.status, body: ct.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer()) };
  };
  return { get: (p) => call('GET', p), post: (p, b, o) => call('POST', p, b ?? {}, o), put: (p, b, o) => call('PUT', p, b, o), patch: (p, b) => call('PATCH', p, b), del: (p) => call('DELETE', p), login: (email) => call('POST', '/api/login', { email, senha: 'senha-forte-123' }) };
}
const como = async (email) => { const c = cliente(); const r = await c.login(email); assert.equal(r.status, 200); return c; };
const clone = (o) => JSON.parse(JSON.stringify(o));

function propCatraca(extra = {}) {
  const N = CFG.nextcard;
  const cat = N.catracas[0], cmd = N.comandas.find((c) => c.id === 'CMD14x8-RFI'), srvc = N.servicos[0];
  return {
    empresa: 'nextcard', modalidade: 'direta', cliente: { empresa: 'Na Brasa', contato: 'Maria', telefone: '41999990000' }, validadeOpcao: '7c', responsavel: '',
    itens: [
      { uid: 'a', kind: 'catraca', refId: cat.id, qtd: 2, nome: cat.nome, tabela: cat.cents, preco: null, piso: 'tabela' },
      { uid: 'b', kind: 'comanda', refId: cmd.id, qtd: 400, nome: 'Comanda', tiers: cmd.tiers, preco: null, piso: 'tabela' },
      { uid: 'c', kind: 'servico', refId: srvc.id, qtd: 1, nome: srvc.nome, tabela: srvc.cents, preco: null, piso: 'zero' },
    ],
    pagamento: { condicoes: ['pix', 'cc6'], overrides: {}, entradas: {}, frete: 'CIF' }, ...extra,
  };
}
const totalTabela = () => { const N = CFG.nextcard; return N.catracas[0].cents * 2 + 1280 * 400 + N.servicos[0].cents; };

test('sessão: rotas exigem login; senha errada não entra; escrita exige cabeçalho anti-CSRF', async () => {
  const anon = cliente();
  assert.equal((await anon.get('/api/config')).status, 401);
  assert.equal((await anon.get('/api/propostas')).status, 401);
  const r = await cliente().post('/api/login', { email: 'ana@x.com', senha: 'errada' });
  assert.equal(r.status, 401);
  const ana = await como('ana@x.com');
  assert.equal((await ana.post('/api/analise', { data: propCatraca() }, { semCsrf: true })).status, 403);
  const me = await ana.get('/api/me');
  assert.deepEqual(me.body.user.roles, ['consultor']);
  assert.equal(me.body.alcadaPct, 0);
  assert.equal(JSON.stringify(me.body).includes('pass_hash'), false);
});

test('persistência: taxa alterada pelo proprietário fica salva, vale para outro usuário e outra sessão', async () => {
  const admin = await como('admin@x.com');
  const c0 = (await admin.get('/api/config')).body;
  const data = clone(c0.data);
  data.nextcard.condicoes.find((c) => c.id === 'cc6').fator = 1.0825;
  data.nextcard.servicos[0].cents = 260000; // periférico/serviço com preço novo
  const s = await admin.put('/api/config', { baseVersion: c0.version, data, nota: 'Taxa cartão 6x' });
  assert.equal(s.status, 200); assert.equal(s.body.version, c0.version + 1);
  const ana = await como('ana@x.com'); // outra sessão, outro usuário
  const c1 = (await ana.get('/api/config')).body;
  assert.equal(c1.version, c0.version + 1);
  assert.equal(c1.data.nextcard.condicoes.find((c) => c.id === 'cc6').fator, 1.0825);
  assert.equal(c1.data.nextcard.servicos[0].cents, 260000);
  CFG = c1.data;
  // versão anterior continua disponível e intacta
  const antiga = (await ana.get('/api/config/versions/' + c0.version)).body;
  assert.equal(antiga.data.nextcard.condicoes.find((c) => c.id === 'cc6').fator, 1.077);
  await assert.rejects(dbm.q('update config_versions set nota = $1 where version = $2', ['x', c0.version]), /imutável/);
});

test('persistência: conflito de edição simultânea é detectado; configuração inválida é recusada', async () => {
  const admin = await como('admin@x.com');
  const c = (await admin.get('/api/config')).body;
  const d = clone(c.data); d.nextcard.arredondamento = '10';
  assert.equal((await admin.put('/api/config', { baseVersion: c.version - 1, data: d })).status, 409);
  const ruim = clone(c.data); ruim.nextcard.condicoes[1].fator = 0.9;
  const r = await admin.put('/api/config', { baseVersion: c.version, data: ruim });
  assert.equal(r.status, 422);
  const nan = clone(c.data); nan.nextcard.catracas[0].cents = -5;
  assert.equal((await admin.put('/api/config', { baseVersion: c.version, data: nan })).status, 422);
  assert.equal((await admin.get('/api/config')).body.version, c.version);
});

test('permissões: consultor, gestor e aprovador não alteram catálogo, taxas, usuários, numeração nem fotos', async () => {
  const c = (await (await como('admin@x.com')).get('/api/config')).body;
  for (const email of ['ana@x.com', 'hamilton@x.com']) {
    const u = await como(email);
    assert.equal((await u.put('/api/config', { baseVersion: c.version, data: c.data })).status, 403, email + ' config');
    assert.equal((await u.post('/api/users', { email: 'x@x.com', nome: 'X', senha: 'senha-forte-123', roles: ['owner'] })).status, 403);
    assert.equal((await u.put('/api/sequencia', { proximo: 1 })).status, 403);
    assert.equal((await u.put('/api/fotos/abc', { data: 'data:image/png;base64,AAAA' })).status, 403);
  }
  const ana = await como('ana@x.com');
  const bia = (await (await como('admin@x.com')).get('/api/users')).body.users.find((x) => x.email === 'bia@x.com');
  assert.equal((await ana.post('/api/alcadas', { userId: bia.id, pct: 50 })).status, 403, 'consultor não concede alçada');
  assert.equal((await ana.patch('/api/users/' + bia.id, { roles: ['owner'] })).status, 403);
  assert.equal((await ana.get('/api/users')).status, 403);
  assert.equal((await ana.get('/api/audit')).status, 403);
  // proprietário sem papel de aprovador não concede desconto
  assert.equal((await (await como('admin@x.com')).post('/api/alcadas', { userId: bia.id, pct: 5 })).status, 403);
});

test('emissão no preço de tabela: número no padrão DDMMAAAA/SEQ+SUFIXO e snapshot imutável', async () => {
  const ana = await como('ana@x.com');
  const id = crypto.randomUUID();
  const r = await ana.post(`/api/propostas/${id}/emitir`, { data: propCatraca() });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  const p = r.body.proposta;
  assert.match(p.numero, /^\d{8}\/1276A$/);
  assert.equal(p.versao, 1);
  const v = (await ana.get(`/api/propostas/${id}/versoes/1`)).body;
  assert.equal(v.snapshot.valorFinal, totalTabela());
  assert.equal(v.snapshot.desconto.pct, 0);
  await assert.rejects(dbm.q("update proposta_versoes set valor_final = 1 where proposta_id = $1", [id]), /imutável/);
  await assert.rejects(dbm.q('delete from proposta_versoes where proposta_id = $1', [id]), /não pode ser excluída/);
  // revisão: mesmo número, versão 2, data do código preservada
  const d2 = propCatraca(); d2.itens[0].qtd = 3;
  const r2 = await ana.post(`/api/propostas/${id}/emitir`, { data: d2 });
  assert.equal(r2.body.proposta.numero, p.numero);
  assert.equal(r2.body.proposta.versao, 2);
  assert.equal((await ana.get(`/api/propostas/${id}/versoes/1`)).body.snapshot.prop.itens[0].qtd, 2, 'versão 1 não mudou');
});

test('proposta antiga mantém o preço original depois de mudança de tabela', async () => {
  const ana = await como('ana@x.com'), admin = await como('admin@x.com');
  const id = crypto.randomUUID();
  await ana.post(`/api/propostas/${id}/emitir`, { data: propCatraca() });
  const antes = (await ana.get(`/api/propostas/${id}/versoes/1`)).body;
  const c = (await admin.get('/api/config')).body;
  const d = clone(c.data); d.nextcard.servicos[0].cents += 50000;
  assert.equal((await admin.put('/api/config', { baseVersion: c.version, data: d })).status, 200);
  const depois = (await ana.get(`/api/propostas/${id}/versoes/1`)).body;
  assert.deepEqual(depois.snapshot, antes.snapshot);
  assert.equal(depois.configVersion, c.version);
  // nova proposta usa o preço novo
  const id2 = crypto.randomUUID();
  const n = await ana.post(`/api/propostas/${id2}/emitir`, { data: propCatraca() });
  assert.equal(n.body.proposta._srv.configVersion, c.version + 1);
  const v2 = (await ana.get(`/api/propostas/${id2}/versoes/1`)).body;
  assert.equal(v2.snapshot.valorFinal, antes.snapshot.valorFinal + 50000);
  CFG = d;
});

test('numeração: emissões simultâneas recebem números únicos e consecutivos; rascunho e falha não consomem número', async () => {
  const ana = await como('ana@x.com'), bia = await como('bia@x.com');
  const antes = (await dbm.q('select proximo from sequencia')).rows[0].proximo;
  // falha de validação não consome número
  const ruim = propCatraca(); ruim.itens[0].refId = 'NAO-EXISTE';
  assert.equal((await ana.post(`/api/propostas/${crypto.randomUUID()}/emitir`, { data: ruim })).status, 422);
  // salvar rascunho várias vezes não consome número
  const rid = crypto.randomUUID();
  for (let i = 0; i < 3; i++) assert.equal((await ana.put(`/api/propostas/${rid}`, { data: propCatraca() })).status, 200);
  assert.equal((await dbm.q('select proximo from sequencia')).rows[0].proximo, antes);
  const rs = await Promise.all(Array.from({ length: 12 }, (_, i) => (i % 2 ? ana : bia).post(`/api/propostas/${crypto.randomUUID()}/emitir`, { data: propCatraca() })));
  assert.ok(rs.every((r) => r.status === 200), JSON.stringify(rs.find((r) => r.status !== 200)?.body));
  const seqs = rs.map((r) => Number(r.body.proposta.numero.split('/')[1].replace(/\D/g, ''))).sort((a, b) => a - b);
  assert.equal(new Set(seqs).size, 12);
  assert.deepEqual(seqs, Array.from({ length: 12 }, (_, i) => antes + i));
  assert.ok(rs.some((r) => r.body.proposta.numero.endsWith('B')) && rs.some((r) => r.body.proposta.numero.endsWith('A')));
  // administrador não pode voltar a sequência para número já usado
  const admin = await como('admin@x.com');
  assert.equal((await admin.put('/api/sequencia', { proximo: antes })).status, 422);
});

test('alçada: sem alçada o limite é zero; dentro e igual ao limite passa; acima bloqueia', async () => {
  const ana = await como('ana@x.com'), ham = await como('hamilton@x.com');
  const cat = CFG.nextcard.catracas[0];
  const comDesc = (pct) => { const d = propCatraca(); d.itens = [d.itens[0]]; d.itens[0].qtd = 1; d.itens[0].preco = Math.round(cat.cents * (1 - pct / 100)); return d; };
  let r = await ana.post(`/api/propostas/${crypto.randomUUID()}/emitir`, { data: comDesc(1) });
  assert.equal(r.status, 403); assert.equal(r.body.erro, 'aprovacao_necessaria'); assert.equal(r.body.limite, 0);
  const users = (await ham.get('/api/users')).body.users;
  const anaId = users.find((u) => u.email === 'ana@x.com').id;
  assert.equal((await ham.post('/api/alcadas', { userId: anaId, pct: 5, condicoes: 'Aprovado por Hamilton' })).status, 200);
  assert.equal((await ana.get('/api/me')).body.alcadaPct, 5);
  const an = await ana.post('/api/analise', { data: comDesc(3) });
  assert.equal(an.body.ok, true); assert.equal(an.body.limite, 5); assert.equal(an.body.pct, 3);
  assert.equal((await ana.post(`/api/propostas/${crypto.randomUUID()}/emitir`, { data: comDesc(3) })).status, 200);
  const igual = await ana.post(`/api/propostas/${crypto.randomUUID()}/emitir`, { data: comDesc(5) });
  assert.equal(igual.status, 200);
  assert.equal((await ana.get(`/api/propostas/${igual.body.proposta.id}/versoes/1`)).body.snapshot.desconto.via, 'alcada');
  assert.equal((await ana.post(`/api/propostas/${crypto.randomUUID()}/emitir`, { data: comDesc(5.5) })).status, 403);
  // alçada de outro consultor não vale; bia continua em zero
  assert.equal((await (await como('bia@x.com')).post(`/api/propostas/${crypto.randomUUID()}/emitir`, { data: comDesc(1) })).status, 403);
});

test('alçada: tentativas de contornar pelo payload são neutralizadas', async () => {
  const bia = await como('bia@x.com');
  const cat = CFG.nextcard.catracas[0];
  const emite = (d) => bia.post(`/api/propostas/${crypto.randomUUID()}/emitir`, { data: d });
  // 1) adulterar o preço de tabela enviado pelo navegador
  let d = propCatraca(); d.itens[0].tabela = 100; d.itens[0].tabelaCheia = 100;
  let r = await emite(d);
  assert.equal(r.status, 200);
  assert.equal((await bia.get(`/api/propostas/${r.body.proposta.id}/versoes/1`)).body.snapshot.valorFinal, totalTabela(), 'servidor regrava o preço oficial');
  // 2) adulterar faixas de comanda
  d = propCatraca(); d.itens[1].tiers = [{ ate: 999999, cents: 1 }];
  r = await emite(d);
  assert.equal((await bia.get(`/api/propostas/${r.body.proposta.id}/versoes/1`)).body.snapshot.valorFinal, totalTabela());
  // 3) preço negativo, quantidade negativa, item negativo
  d = propCatraca(); d.itens[0].preco = -100; assert.equal((await emite(d)).status, 422);
  d = propCatraca(); d.itens[0].qtd = -1; assert.equal((await emite(d)).status, 422);
  d = propCatraca(); d.itens.push({ uid: 'x', kind: 'avulso', nome: 'Abatimento', qtd: 1, tabela: -50000, preco: null }); assert.equal((await emite(d)).status, 422);
  // 4) cortesia (serviço a zero) é desconto
  d = propCatraca(); d.itens[2].preco = 0; r = await emite(d); assert.equal(r.status, 403);
  // 5) descontos pequenos somados em várias linhas contam juntos
  d = propCatraca(); d.itens[0].preco = cat.cents - 1; d.itens[1].preco = 1279; r = await emite(d); assert.equal(r.status, 403);
  assert.ok(r.body.pendencias.some((p) => p.tipo === 'desconto'));
  // 6) condição de pagamento com total abaixo do à vista (desconto disfarçado de "simulador")
  d = propCatraca(); d.pagamento.overrides = { cc6: totalTabela() - 100000 }; r = await emite(d); assert.equal(r.status, 403);
  assert.ok(r.body.pendencias.some((p) => p.tipo === 'condicao_abaixo_avista'));
  // 7) item livre substituindo produto do catálogo pede aprovação
  d = propCatraca(); d.itens = [{ uid: 'x', kind: 'avulso', nome: 'Catraca C150', qtd: 1, tabela: 100000, preco: null }]; r = await emite(d); assert.equal(r.status, 403);
  // 8) cupom Teloos inexistente e modalidade inexistente
  d = propCatraca(); d.modalidade = 'amigo'; assert.equal((await emite(d)).status, 422);
  // 9) opção de totem inventada
  const T = CFG.nextcard.totem;
  d = propCatraca(); d.itens = [{ uid: 't', kind: 'totem', refId: 'NX24-V', qtd: 1, config: { modelo: 'NX24-V', ...T.referencia, pinpad: 'gratis' }, preco: null }];
  assert.equal((await emite(d)).status, 422);
});

test('aprovação excepcional: pedido, decisão do aprovador e emissão; mudar a proposta invalida a aprovação', async () => {
  const bia = await como('bia@x.com'), ham = await como('hamilton@x.com'), ana = await como('ana@x.com');
  const cat = CFG.nextcard.catracas[0];
  const d = propCatraca(); d.itens[0].preco = Math.round(cat.cents * 0.9);
  const id = crypto.randomUUID();
  assert.equal((await bia.put(`/api/propostas/${id}`, { data: d })).status, 200);
  assert.equal((await bia.post(`/api/propostas/${id}/emitir`, { data: d })).status, 403);
  const ped = await bia.post(`/api/propostas/${id}/aprovacao`, { data: d, justificativa: 'Cliente fecha hoje' });
  assert.equal(ped.status, 200);
  assert.equal((await bia.get('/api/propostas')).body.propostas.find((p) => p.id === id)._srv.status, 'aguardando_aprovacao');
  // consultor não aprova (nem o próprio pedido); proprietário sem papel de aprovador também não
  assert.equal((await bia.post(`/api/aprovacoes/${ped.body.id}/decidir`, { aprovar: true })).status, 403);
  assert.equal((await (await como('admin@x.com')).post(`/api/aprovacoes/${ped.body.id}/decidir`, { aprovar: true })).status, 403);
  assert.equal((await ana.get('/api/aprovacoes')).body.aprovacoes.some((a) => a.id === ped.body.id), false, 'outro consultor não vê');
  assert.equal((await bia.post(`/api/propostas/${id}/emitir`, { data: d })).status, 403, 'pendente não emite');
  assert.equal((await ham.post(`/api/aprovacoes/${ped.body.id}/decidir`, { aprovar: true, resposta: 'Ok, excepcional' })).status, 200);
  assert.equal((await ham.post(`/api/aprovacoes/${ped.body.id}/decidir`, { aprovar: false, resposta: 'x' })).status, 409);
  // mudou o desconto depois de aprovado → aprovação não vale
  const d2 = clone(d); d2.itens[0].preco = Math.round(cat.cents * 0.8);
  assert.equal((await bia.post(`/api/propostas/${id}/emitir`, { data: d2 })).status, 403);
  const ok = await bia.post(`/api/propostas/${id}/emitir`, { data: d });
  assert.equal(ok.status, 200);
  const snap = (await bia.get(`/api/propostas/${id}/versoes/1`)).body.snapshot;
  assert.equal(snap.desconto.via, 'aprovacao'); assert.equal(snap.desconto.aprovacao.por, 'Hamilton Flores');
  // recusa exige motivo
  const id2 = crypto.randomUUID(); await bia.put(`/api/propostas/${id2}`, { data: d });
  const p2 = await bia.post(`/api/propostas/${id2}/aprovacao`, { data: d });
  assert.equal((await ham.post(`/api/aprovacoes/${p2.body.id}/decidir`, { aprovar: false })).status, 422);
  assert.equal((await ham.post(`/api/aprovacoes/${p2.body.id}/decidir`, { aprovar: false, resposta: 'Fora da política' })).status, 200);
  assert.equal((await bia.post(`/api/propostas/${id2}/emitir`, { data: d })).status, 403);
  // aprovador emite com desconto direto (autoridade própria, registrada no snapshot)
  const hid = crypto.randomUUID();
  const hr = await ham.post(`/api/propostas/${hid}/emitir`, { data: d });
  assert.equal(hr.status, 200); assert.match(hr.body.proposta.numero, /HF$/);
  assert.equal((await ham.get(`/api/propostas/${hid}/versoes/1`)).body.snapshot.desconto.via, 'aprovador');
});

test('isolamento: consultor não lê, altera, emite nem baixa proposta de outro consultor', async () => {
  const ana = await como('ana@x.com'), bia = await como('bia@x.com'), ham = await como('hamilton@x.com');
  const id = crypto.randomUUID();
  await ana.post(`/api/propostas/${id}/emitir`, { data: propCatraca() });
  assert.equal((await bia.get('/api/propostas')).body.propostas.some((p) => p.id === id), false);
  assert.equal((await bia.get(`/api/propostas/${id}/versoes/1`)).status, 404);
  assert.equal((await bia.get(`/api/propostas/${id}/versoes/1/pdf`)).status, 404);
  assert.equal((await bia.put(`/api/propostas/${id}`, { data: propCatraca() })).status, 404);
  assert.equal((await bia.post(`/api/propostas/${id}/emitir`, { data: propCatraca() })).status, 404);
  assert.equal((await bia.del(`/api/propostas/${id}`)).status, 404);
  assert.equal((await ham.get('/api/propostas')).body.propostas.some((p) => p.id === id), true, 'gestor acompanha a equipe');
  // emitida não é apagada: é cancelada e o número fica preservado
  assert.equal((await ana.del(`/api/propostas/${id}`)).body.cancelada, true);
  assert.equal((await dbm.q('select count(*)::int as n from proposta_versoes where proposta_id = $1', [id])).rows[0].n, 1);
});

const PDF = Buffer.concat([Buffer.from('%PDF-1.4\n'), crypto.randomBytes(3000)]);
test('PDF emitido: armazenado uma vez, não é substituído, baixa idêntico com nome seguro', async () => {
  const ana = await como('ana@x.com');
  const id = crypto.randomUUID();
  const e = await ana.post(`/api/propostas/${id}/emitir`, { data: propCatraca() });
  assert.equal((await ana.put(`/api/propostas/${id}/versoes/1/pdf`, Buffer.from('<html>'), { raw: true })).status, 422);
  assert.equal((await ana.put(`/api/propostas/${id}/versoes/1/pdf`, PDF, { raw: true })).status, 200);
  const de_novo = await ana.put(`/api/propostas/${id}/versoes/1/pdf`, Buffer.concat([PDF, Buffer.from('x')]), { raw: true });
  assert.equal(de_novo.body.jaExistia, true);
  const r = await fetch(base + `/api/propostas/${id}/versoes/1/pdf`, { headers: { cookie: (await (async () => { const c = cliente(); const l = await fetch(base + '/api/login', { method: 'POST', headers: { 'x-nx': '1', 'content-type': 'application/json' }, body: JSON.stringify({ email: 'ana@x.com', senha: 'senha-forte-123' }) }); return l.headers.get('set-cookie').split(';')[0]; })()) } });
  assert.equal(r.status, 200);
  assert.ok(Buffer.from(await r.arrayBuffer()).equals(PDF));
  const num = e.body.proposta.numero.replace('/', '_');
  assert.equal(r.headers.get('content-disposition'), `attachment; filename="Proposta_${num}.pdf"`);
});

test('Kommo (simulado): busca, anexo confirmado, repetição sem duplicar, falha com nova tentativa sem novo upload', async () => {
  const ana = await como('ana@x.com');
  const leads = (await ana.get('/api/kommo/leads?q=maria')).body.leads;
  assert.equal(leads.length, 2, 'mesmo cliente com dois negócios: o consultor escolhe');
  assert.equal(leads[0].etapa, 'Envio de proposta'); assert.equal(leads[0].pipeline, 'Funil Nextcard');
  assert.deepEqual((await ana.get('/api/kommo/leads?q=nada')).body.leads, []);
  const id = crypto.randomUUID();
  await ana.post(`/api/propostas/${id}/emitir`, { data: propCatraca({ kommo: { leadId: 22728655, nome: leads[0].nome } }) });
  assert.equal((await ana.post(`/api/propostas/${id}/versoes/1/kommo`, {})).status, 409, 'sem PDF não anexa');
  await ana.put(`/api/propostas/${id}/versoes/1/pdf`, PDF, { raw: true });
  kommo.esperado = PDF.length; kommo.uploads = 0;
  // falha na associação depois do upload
  kommo.falharAnexo = 1;
  const f = await ana.post(`/api/propostas/${id}/versoes/1/kommo`, {});
  assert.equal(f.status, 502); assert.equal(f.body.podeRepetir, true);
  assert.equal((await ana.get('/api/propostas')).body.propostas.find((p) => p.id === id)._srv.kommo.status, 'falha');
  assert.equal(kommo.uploads, 1);
  // nova tentativa reaproveita o arquivo já enviado
  const ok = await ana.post(`/api/propostas/${id}/versoes/1/kommo`, {});
  assert.equal(ok.status, 200); assert.equal(ok.body.status, 'anexado');
  assert.equal(kommo.uploads, 1, 'sem novo upload');
  assert.deepEqual(kommo.anexos['22728655'], ['file-1']);
  // repetir depois de anexado não duplica
  const rep = await ana.post(`/api/propostas/${id}/versoes/1/kommo`, {});
  assert.equal(rep.body.repetida, true);
  assert.equal(kommo.uploads, 1); assert.equal(kommo.anexos['22728655'].length, 1);
  assert.equal((await ana.post(`/api/propostas/${id}/versoes/1/kommo`, { leadId: 22728656 })).status, 409, 'não reanexa a outro negócio em silêncio');
  // número e versão preservados mesmo com falha de integração
  const p = (await ana.get('/api/propostas')).body.propostas.find((x) => x.id === id);
  assert.equal(p.versao, 1); assert.equal(p._srv.kommo.status, 'anexado');
  // outro consultor não anexa a proposta alheia
  assert.equal((await (await como('bia@x.com')).post(`/api/propostas/${id}/versoes/1/kommo`, {})).status, 404);
  // token inválido vira erro claro, sem vazar o token
  const tok = process.env.KOMMO_TOKEN; process.env.KOMMO_TOKEN = 'errado';
  const { limpaCacheKommo } = await import('../../server/kommo.js'); limpaCacheKommo();
  const bad = await ana.get('/api/kommo/leads?q=maria');
  assert.equal(bad.status, 502); assert.equal(JSON.stringify(bad.body).includes('errado'), false);
  process.env.KOMMO_TOKEN = tok; limpaCacheKommo();
});

test('usuários: proprietário cria e desativa; último proprietário não pode ser removido; login bloqueia após falhas', async () => {
  const admin = await como('admin@x.com');
  assert.equal((await admin.post('/api/users', { email: 'novo@x.com', nome: 'Novo', senha: 'curta' })).status, 422);
  const n = await admin.post('/api/users', { email: 'novo@x.com', nome: 'Novo', sigla: 'nv1', senha: 'senha-forte-123', roles: ['consultor', 'root'] });
  assert.equal(n.status, 200); assert.deepEqual(n.body.user.roles, ['consultor']); assert.equal(n.body.user.sigla, 'NV');
  assert.equal((await admin.post('/api/users', { email: 'NOVO@x.com', nome: 'Novo', senha: 'senha-forte-123' })).status, 409);
  const novo = await como('novo@x.com');
  assert.equal((await admin.patch('/api/users/' + n.body.user.id, { ativo: false })).status, 200);
  assert.equal((await novo.get('/api/me')).status, 401, 'sessão encerrada ao desativar');
  const eu = (await admin.get('/api/me')).body.user;
  assert.equal((await admin.patch('/api/users/' + eu.id, { roles: ['consultor'] })).status, 422);
  for (let i = 0; i < 8; i++) await cliente().post('/api/login', { email: 'bia@x.com', senha: 'x' });
  assert.equal((await cliente().login('bia@x.com')).status, 429);
  await dbm.q("update users set bloqueado_ate = null where email = 'bia@x.com'");
});

test('auditoria registra publicação de configuração com o que mudou', async () => {
  const ev = (await (await como('admin@x.com')).get('/api/audit')).body.eventos;
  const pub = ev.find((e) => e.acao === 'config.publicada' && e.detalhe.nota === 'Taxa cartão 6x');
  assert.ok(pub);
  assert.ok(pub.detalhe.alteracoes.some((a) => a.campo === 'nextcard.condicoes[cc6].fator' && a.antes === '1.077' && a.depois === '1.0825'));
  assert.ok(ev.some((e) => e.acao === 'acesso.negado'));
  assert.ok(ev.some((e) => e.acao === 'proposta.emitida'));
});
