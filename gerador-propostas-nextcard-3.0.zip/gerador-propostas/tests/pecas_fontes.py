"""Renderiza 7 casos-limite da imagem do WhatsApp e mede o tamanho de cada texto desenhado.
Regra: texto >= 30 px; rótulos em caixa alta com espaçamento (desenhados letra a letra) >= 22 px.
Uso: node build/harness.mjs && python3 tests/pecas_fontes.py"""
import base64, os, sys
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = 'file://' + os.path.join(ROOT, 'harness', 'index.html')
OUT = os.path.join(ROOT, 'tests', 'out'); os.makedirs(OUT, exist_ok=True)
JS = open(os.path.join(ROOT, 'tests', 'pecas_casos.js'), encoding='utf-8').read()
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(URL); pg.wait_for_timeout(500)
    res = pg.evaluate(JS)
    # teste negativo: sem a NX Sans, o desenho precisa falhar (e não sair com a fonte de reserva)
    pg2 = b.new_page(); pg2.goto(URL); pg2.wait_for_timeout(300)
    negativo = pg2.evaluate("""async () => {
      // tira as @font-face da NX Sans (faces declaradas no CSS só saem removendo a folha de estilo)
      for (const st of document.querySelectorAll('style')) st.textContent = st.textContent.replace(/@font-face\{font-family:"NX Sans"[^}]*\}/g, '');
      const N = window.NX, cfg = N.defaultConfig();
      const p = N.novaProposta('nextcard', cfg, 'catraca', { nome: 'Ana Souza' });
      try { await N.renderPeca(N.buildModel(p, cfg, {}, N.PHOTOS), cfg, 1); return 'desenhou com a fonte de reserva'; }
      catch (e) { return 'ok: ' + e.message; } }""")
    # fotos novas: configuração salva no padrão antigo migra; escolha feita à mão em Configuração fica
    mig = pg.evaluate('''() => {
      const N = window.NX, v1 = N.FOTOS_V1, s = N.defaultConfig();
      delete s.fotosVersao;
      s.nextcard.totem.modelos.forEach((m) => { m.foto = v1.totem[m.id] || null; });
      s.nextcard.catracas.forEach((c) => { c.foto = v1.catraca(c); });
      s.nextcard.comandas.forEach((c) => { delete c.foto; });
      s.nextcard.totem.modelos.find((m) => m.id === 'NX21-B').foto = 'totem-parede'; // escolha manual
      const mudou = N.migraFotos(s, N.defaultConfig());
      const f = (id) => s.nextcard.totem.modelos.find((m) => m.id === id).foto;
      const c = (id) => s.nextcard.catracas.find((k) => k.id === id).foto;
      return { mudou, nx24v: f('NX24-V'), nx21b: f('NX21-B'), c120: c('TEC-C120-AC'), c250: c('TEC-C250-AC'), comanda: s.nextcard.comandas[0].foto, de_novo: N.migraFotos(s, N.defaultConfig()),
        todas: [...s.nextcard.totem.modelos, ...s.nextcard.catracas, ...s.nextcard.comandas].every((x) => !x.foto || N.PHOTOS[x.foto]) };
    }''')
    ok_mig = mig['mudou'] and mig['nx24v'] == 'totem-nx24v' and mig['nx21b'] == 'totem-parede' and mig['c120'] == 'catraca-c120' and mig['c250'] == 'catraca-expedidora-acoplada' and mig['comanda'] and not mig['de_novo'] and mig['todas']
    print(('OK   ' if ok_mig else 'FALHA ') + f'fotos: migração da configuração salva (troca as antigas, mantém a escolha manual, roda uma vez) | {mig}')
    falhas_mig = 0 if ok_mig else 1
    # Teloos: telas do sistema sem distorção (mesma escala na largura e na altura) e com os gráficos inteiros,
    # também com a faixa de cases ligada (menos altura), nos dois temas
    tel = pg.evaluate('''async () => {
      const N = window.NX, cfg = N.defaultConfig(), out = [];
      const oDraw = CanvasRenderingContext2D.prototype.drawImage;
      let draws = [];
      CanvasRenderingContext2D.prototype.drawImage = function (im) { if (im && im.__ilustracao && arguments.length >= 5) { const t = this.getTransform(); draws.push({ sx: arguments[3] * t.a / im.width, sy: arguments[4] * t.d / im.height, w: arguments[3] }); } return oDraw.apply(this, arguments); };
      for (const tema of ['escuro', 'claro']) for (const cases of [false, true]) {
        let p = N.novaProposta('teloos', cfg, 'teloos', { nome: 'Ana Souza' });
        p.cliente = { ...p.cliente, empresa: 'Restaurante Modelo' }; p.temaProposta = tema; p.incluirCases = cases;
        const m = N.buildModel({ ...p, numero: '30092026/1221H', emitidaEm: '2026-09-30T13:00:00' }, cfg, {}, N.PHOTOS);
        draws = [];
        const cv = await N.renderPeca(m, cfg, 1, { modo: 'imagem' });
        const b = (cv.__blocos || []).find((x) => x.nome === 'telas do sistema');
        out.push({ tema, cases, h: b ? b.h : 0, distorcao: Math.max(0, ...draws.map((d) => Math.abs(d.sx - d.sy))), largura: draws.length ? Math.round(draws[0].w) : 0 });
      }
      CanvasRenderingContext2D.prototype.drawImage = oDraw;
      return out;
    }''')
    ok_tel = all(t['h'] >= 440 and t['distorcao'] < 0.01 and abs(t['largura'] - 1048) <= 1 for t in tel)  # 952 de desenho + 2 × 48 de sangria, escala 1: nunca alarga
    print(('OK   ' if ok_tel else 'FALHA ') + f'Teloos: telas na proporção do desenho (sem esticar) e com os gráficos inteiros (≥ 440 px), com e sem cases | {tel}')
    falhas_mig += 0 if ok_tel else 1
    # textos novos (05/10): infraestrutura padrão antiga troca; editada à mão fica; campos novos entram; roda uma vez
    mt = pg.evaluate('''() => {
      const N = window.NX, f = N.defaultConfig();
      const a = N.defaultConfig(); delete a.textosVersao; a.nextcard.infraCatraca = [...N.INFRA_V1]; delete a.nextcard.integracaoCatraca; delete a.nextcard.fraseAbertura; delete a.nextcard.fraseEncerramento;
      const b = N.defaultConfig(); delete b.textosVersao; b.nextcard.infraCatraca = ['Texto do cliente'];
      const ma = N.migraTextos(a, f), mb = N.migraTextos(b, f);
      return { ma, mb, infraNova: JSON.stringify(a.nextcard.infraCatraca) === JSON.stringify(f.nextcard.infraCatraca), manual: b.nextcard.infraCatraca[0], campos: !!(a.nextcard.integracaoCatraca && a.nextcard.fraseAbertura && a.nextcard.fraseEncerramento), de_novo: N.migraTextos(a, f) };
    }''')
    ok_mt = mt['ma'] and mt['mb'] and mt['infraNova'] and mt['manual'] == 'Texto do cliente' and mt['campos'] and not mt['de_novo']
    print(('OK   ' if ok_mt else 'FALHA ') + f'textos: migração da infraestrutura e das frases novas | {mt}')
    falhas_mig += 0 if ok_mt else 1
    # alinhamento e sobreposição a partir das caixas dos blocos: casos (a)–(f) nos dois temas
    VIS = open(os.path.join(ROOT, 'tests', 'pecas_casos_visuais.js'), encoding='utf-8').read()
    layout = {tema: pg.evaluate(VIS, {'tema': tema, 'grid': False}) for tema in ('escuro', 'claro', 'cinza')}
    b.close()

M, W_ = 64, 1080  # margem única e largura (base 1080)
def confere(blocos):
    erros = []
    sec = sorted([b for b in blocos if b['tipo'] == 'secao'], key=lambda b: b['y'])
    for b in sec:
        if abs(b['x'] - M) > 1 or abs(b['x'] + b['w'] - (W_ - M)) > 1: erros.append(f"{b['nome']}: x {b['x']}–{b['x'] + b['w']} fora da margem")
    gaps = [(a['nome'], c['nome'], c['y'] - (a['y'] + a['h'])) for a, c in zip(sec, sec[1:])]
    for a, c, g in gaps:
        if abs(g - 48) > 1: erros.append(f'espaço {a} → {c} = {g} (esperado 48)')
    for grupo in (sec + [b for b in blocos if b['tipo'] == 'ancora'], [b for b in blocos if b['tipo'] in ('foto', 'rotulo')]):
        for i, a in enumerate(grupo):
            for c in grupo[i + 1:]:
                if a['x'] < c['x'] + c['w'] - 1 and c['x'] < a['x'] + a['w'] - 1 and a['y'] < c['y'] + c['h'] - 1 and c['y'] < a['y'] + a['h'] - 1:
                    erros.append(f"sobreposição {a['nome']} × {c['nome']}")
    for b in blocos:
        if b['y'] < 0 or b['y'] + b['h'] > 1920: erros.append(f"{b['nome']} fora da página")
    return erros
falhas_layout = 0
for tema, casos in layout.items():
    for caso, r in casos.items():
        pags = [('imagem', r['medidas']['blocos'])] + [(f'pdf p{i + 1}', bl) for i, bl in enumerate(r['medidas']['blocosPdf'])]
        erros = [f'{nome}: {e}' for nome, bl in pags for e in confere(bl or [])]
        # equilíbrio: a última página do PDF termina depois de 50% da altura (sem grande área vazia)
        ult = [b for b in (r['medidas']['blocosPdf'] or [[]])[-1] or [] if b['tipo'] == 'secao' and b['nome'] != 'cabeçalho']
        ocup = max((b['y'] + b['h'] for b in ult), default=0) / 1920
        if len(pags) > 2 and ocup < 0.5: erros.append(f'última página do PDF com {ocup:.0%} de ocupação')
        vazios = [nome for nome, bl in pags if not bl]
        if vazios: erros.append(f'sem caixas registradas: {vazios}')
        falhas_layout += bool(erros)
        print(('FALHA ' if erros else 'OK   ') + f'layout {caso} ({tema}) | {len(pags)} peças' + ('' if not erros else ' | ' + '; '.join(erros[:4])))
fontes = res.pop('__fontes')
falhas = 0
print('fontes usadas:', len(fontes['usadas']), '| sem FontFace carregado:', fontes['semFace'][:5])
if fontes['semFace']: falhas += 1; print('FALHA fonte de reserva no canvas')
fam = {f.split('px', 1)[1].strip().split(',')[0].strip('" ') for f in fontes['usadas']}
if fam - {'NX Sans', 'Inter'}: falhas += 1; print('FALHA famílias inesperadas:', fam)
print(('OK   ' if negativo.startswith('ok') else 'FALHA ') + 'sem a fonte embutida o desenho falha em vez de usar a de reserva | ' + negativo)
falhas += not negativo.startswith('ok')
for k, v in res.items():
    open(os.path.join(OUT, f'peca_{k}.jpg'), 'wb').write(base64.b64decode(v['img'].split(',')[1]))
    # preço: 20–25% menor que os 118 px de antes (≤ 80% = 94 px), nunca abaixo de 72 px
    preco_ok = v.get('preco') is not None and 72 <= v['preco'] <= 94
    falhos = [n for n, okc in (v.get('checks') or {}).items() if not okc]
    if not preco_ok: print('FALHA preço fora de 72–94 px:', k, v.get('preco'))
    for n in falhos: print('FALHA', k, n)
    ruim = v['small'] or (v['minLabel'] is not None and v['minLabel'] < 22) or not preco_ok or falhos
    falhas += bool(ruim)
    print(('FALHA ' if ruim else 'OK   ') + k, '| rótulo mín.', v['minLabel'], '| preço', v.get('preco'), 'px | textos < 30 px:', v['small'][:5])
if errs: print('Erros:', errs); falhas += 1
falhas += falhas_layout + falhas_mig
print(f'\n{falhas} falha(s). Imagens em tests/out/')
sys.exit(1 if falhas else 0)
