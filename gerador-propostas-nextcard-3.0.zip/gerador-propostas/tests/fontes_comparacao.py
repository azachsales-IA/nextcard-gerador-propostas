"""Compara a tipografia do site da NEXTCARD (ref/site-nextcard.png) com famílias livres (OFL).
1) Medida objetiva: frases brancas da faixa preta do site × a mesma frase desenhada em cada família
   (mesma altura), com sobreposição dos contornos (IoU) e diferença de largura.
2) Quadro visual: recortes do site + a frase de teste e os glifos a, g, R, $ em cada família.
Uso: python3 tests/fontes_comparacao.py   (gera tests/out/fontes_comparacao.png e fontes_comparacao.json)"""
import base64, io, json, os
from PIL import Image, ImageOps
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'tests', 'out'); os.makedirs(OUT, exist_ok=True)
FS = os.path.join(ROOT, 'node_modules', '@fontsource')
FAMILIAS = [('Raleway', 'raleway'), ('Montserrat', 'montserrat'), ('Poppins', 'poppins'), ('Nunito', 'nunito'), ('Quicksand', 'quicksand'), ('Varela Round', 'varela-round')]
PESOS = [400, 500, 600, 700]
site = Image.open(os.path.join(ROOT, 'ref', 'site-nextcard.png')).convert('RGB')
# frases brancas sobre a faixa preta do site (coordenadas do print)
FRASES = [('Entrega em Todo o Brasil', (60, 600, 330, 640)), ('Compra Segura', (440, 600, 620, 640)), ('Em até 12x no cartão', (755, 600, 980, 640))]

def mascara(im):
    g = ImageOps.grayscale(im)
    m = g.point(lambda v: 255 if v > 110 else 0)
    bb = m.getbbox()
    return m.crop(bb) if bb else m

def iou(a, b):
    # a e b com a mesma altura; compara na largura da menor e penaliza a diferença de largura
    w = min(a.width, b.width); h = a.height
    pa, pb = a.crop((0, 0, w, h)).load(), b.crop((0, 0, w, h)).load()
    inter = uni = 0
    for y in range(h):
        for x in range(w):
            A, B = pa[x, y] > 127, pb[x, y] > 127
            inter += A and B; uni += A or B
    return inter / uni if uni else 0

def woff(slug, w):
    for sub in ('latin', 'latin-ext'):
        pass
    f = os.path.join(FS, slug, 'files', f'{slug}-latin-{w}-normal.woff2')
    return f if os.path.exists(f) else None

css = ''
for fam, slug in FAMILIAS:
    for w in PESOS:
        f = woff(slug, w)
        if f: css += f"@font-face{{font-family:'{fam}';font-weight:{w};src:url(data:font/woff2;base64,{base64.b64encode(open(f,'rb').read()).decode()}) format('woff2')}}\n"

res = {}
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    pg.set_content(f'<html><head><style>{css}</style></head><body></body></html>')
    pg.evaluate("document.fonts.ready")
    render = """async ([fam, w, txt]) => {
      await document.fonts.load(`${w} 120px "${fam}"`, txt);
      const c = document.createElement('canvas'); c.width = 2600; c.height = 260; const x = c.getContext('2d');
      x.fillStyle = '#000'; x.fillRect(0, 0, c.width, c.height); x.fillStyle = '#fff'; x.font = `${w} 120px "${fam}"`; x.fillText(txt, 20, 170);
      return c.toDataURL('image/png'); }"""
    for fam, slug in FAMILIAS:
        melhor = None
        for w in PESOS:
            if not woff(slug, w): continue
            ious, larg = [], []
            for txt, box in FRASES:
                ref = mascara(site.crop(box))
                cand = mascara(Image.open(io.BytesIO(base64.b64decode(pg.evaluate(render, [fam, w, txt]).split(',')[1]))))
                cand = cand.resize((max(1, round(cand.width * ref.height / cand.height)), ref.height))
                ious.append(iou(ref, cand)); larg.append(cand.width / ref.width - 1)
            r = {'peso': w, 'iou': round(sum(ious) / len(ious), 3), 'dif_largura_%': round(100 * sum(abs(v) for v in larg) / len(larg), 1)}
            if not melhor or r['iou'] > melhor['iou']: melhor = r
        res[fam] = melhor
        print(fam, melhor, flush=True)

    # Quadro visual
    def uri(im):
        bio = io.BytesIO(); im.save(bio, 'PNG'); return 'data:image/png;base64,' + base64.b64encode(bio.getvalue()).decode()
    rec_titulo = uri(site.crop((0, 70, 760, 150)))
    rec_faixa = uri(site.crop((40, 590, 1000, 650)))
    rec_texto = uri(site.crop((160, 700, 760, 845)))
    ordem = sorted(FAMILIAS, key=lambda f: -res[f[0]]['iou'])
    linhas = ''
    for fam, slug in ordem:
        r = res[fam]
        linhas += f"""<div class="row"><div class="nome"><b>{fam}</b><small>IoU {r['iou']:.3f} · largura {r['dif_largura_%']}% · peso {r['peso']}</small></div>
        <div class="amostra" style="font-family:'{fam}'"><div class="t1" style="font-weight:700">Projeto de automação NEXTCARD · R$ 29.804,00 · Catraca expedidora</div>
        <div class="t2" style="font-weight:{r['peso']}">Entrega em Todo o Brasil · Compra Segura · Em até 12x no cartão</div>
        <div class="t3" style="font-weight:700">Automação Comercial</div></div>
        <div class="gl" style="font-family:'{fam}';font-weight:700">a g R $<span style="font-weight:400"> a g R $ 12</span></div></div>"""
    html = f"""<html><head><style>{css}
    body{{margin:0;padding:28px;background:#fff;font:14px sans-serif;color:#111;width:1600px}}
    h1{{font:700 22px sans-serif;margin:0 0 12px}} .ref{{display:flex;gap:16px;align-items:flex-start;margin-bottom:18px;background:#111;padding:12px}}
    .ref img{{display:block;max-height:120px}} .row{{display:grid;grid-template-columns:230px 1fr 330px;gap:18px;align-items:center;padding:12px 0;border-top:1px solid #ddd}}
    .nome b{{display:block;font-size:18px}} .nome small{{color:#555}} .t1{{font-size:26px}} .t2{{font-size:22px;color:#333;margin-top:4px}} .t3{{font-size:30px;margin-top:4px}}
    .gl{{font-size:54px;letter-spacing:.04em}}</style></head><body>
    <h1>Site da NEXTCARD (print) × famílias livres (OFL) — ordenadas pela semelhança medida</h1>
    <div class="ref"><img src="{rec_titulo}"><img src="{rec_texto}"></div><div class="ref"><img src="{rec_faixa}"></div>{linhas}</body></html>"""
    pg.set_viewport_size({'width': 1660, 'height': 900})
    pg.set_content(html); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(600)
    pg.screenshot(path=os.path.join(OUT, 'fontes_comparacao.png'), full_page=True)
    b.close()
json.dump(res, open(os.path.join(OUT, 'fontes_comparacao.json'), 'w'), ensure_ascii=False, indent=1)
