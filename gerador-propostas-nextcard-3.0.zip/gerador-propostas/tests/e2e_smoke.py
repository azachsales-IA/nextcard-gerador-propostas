"""Teste de ponta a ponta do gerador (Playwright + Chromium).
Uso: node build/build.mjs && python3 tests/e2e_smoke.py
Falha com código 1 se qualquer verificação não passar."""
import os, re, sys
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = 'file://' + os.path.join(ROOT, 'dist-local', 'index.html')  # variante sem servidor (NX_MODE=local node build/build.mjs)
OUT = os.path.join(ROOT, 'tests', 'out'); os.makedirs(OUT, exist_ok=True)
falhas, errs, reqs = [], [], []

def contraste_dim(pg):
    # contraste WCAG de --dim sobre --bg-3 (a superfície mais clara usada atrás de texto)
    return pg.evaluate("""() => {
      const cs = getComputedStyle(document.documentElement);
      const rgb = (h) => { h = cs.getPropertyValue(h).trim().replace('#', ''); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255); };
      const L = (c) => { const f = (v) => (v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4)); return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2]); };
      const a = L(rgb('--dim')), b = L(rgb('--bg-3'));
      return (Math.max(a, b) + .05) / (Math.min(a, b) + .05);
    }""")

def alvos_pequenos(pg):
    # controles do construtor (fora links de texto) com área de toque abaixo de 44 × 44 px
    return pg.evaluate("""() => [...document.querySelectorAll('.b-main button, .b-main input, .b-main select, .b-main label.chk, .m-bar button')]
      .filter((el) => !el.matches('.link, input[type=checkbox], input[type=file]') && el.getClientRects().length)
      .map((el) => { const r = el.getBoundingClientRect(); return { t: (el.getAttribute('aria-label') || el.textContent || el.className).trim().slice(0, 24), w: Math.round(r.width), h: Math.round(r.height) }; })
      .filter((x) => x.w < 44 || x.h < 44)""")

def png_teste(w=600, h=200):
    # PNG simples gerado sem dependências: fundo branco com uma faixa escura no meio (para o recorte de margens)
    import struct, zlib
    linhas = b''.join(b'\x00' + b''.join((b'\x20\x20\x20' if 60 <= y < 140 and 100 <= x < 500 else b'\xff\xff\xff') for x in range(w)) for y in range(h))
    ch = lambda t, d: struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + ch(b'IDAT', zlib.compress(linhas)) + ch(b'IEND', b'')

def ok(cond, msg):
    print(('OK   ' if cond else 'FALHA ') + msg, flush=True)
    if not cond: falhas.append(msg)

# espaçamento: padding, margin e gap do CSS só usam os tokens 8/16/24/32/48/64/96 (ou 0 / auto / somas e negativos deles)
CSS = open(os.path.join(ROOT, 'src', 'styles.css'), encoding='utf-8').read()
TOKENS = set(map(int, re.findall(r'--esp-(\d+):\s*\1px', CSS)))
fora = []
for m in re.finditer(r'(?<![\w-])((?:padding|margin)(?:-[a-z]+)*|(?:row-|column-)?gap)\s*:\s*([^;}]+)', CSS):
    v = re.sub(r'env\([^)]*\)', '', m.group(2))
    if re.search(r'\d(px|em|rem|%)', v) or any(int(t) not in TOKENS for t in re.findall(r'--esp-(\d+)', v)): fora.append(f'{m.group(1)}: {m.group(2).strip()}')
ok(TOKENS == {8, 16, 24, 32, 48, 64, 96} and not fora, f'CSS: espaçamentos só com tokens {sorted(TOKENS)}' + (f' | fora da escala: {fora[:5]}' if fora else ''))

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or None)
    ctx = b.new_context(viewport={'width': 1440, 'height': 900}, accept_downloads=True)
    ctx.grant_permissions(['clipboard-read', 'clipboard-write'])
    pg = ctx.new_page()
    pg.on('console', lambda m: errs.append(f'{m.type}: {m.text}') if m.type == 'error' else None)
    pg.on('pageerror', lambda e: errs.append('PAGEERROR ' + str(e)))
    pg.on('request', lambda r: reqs.append(r.url) if not r.url.startswith(('file:', 'data:', 'blob:')) else None)
    pg.add_init_script("window.__opened=[]; window.open=(u)=>{window.__opened.push(u); return null};")
    pg.goto(URL); pg.wait_for_timeout(1200)

    # 1. Perfil no primeiro uso
    ok(pg.get_by_test_id('perfil-nome').count() == 1, 'perfil do consultor aparece no primeiro uso')
    pg.get_by_test_id('perfil-nome').fill('Ana Souza')
    pg.get_by_role('button', name='Salvar').click(); pg.wait_for_timeout(400)
    pg.screenshot(path=os.path.join(OUT, '01_inicio.png'))
    ok(pg.locator('[data-testid^=sol-]').count() == 5, '5 tipos de proposta na tela inicial')
    fam = pg.evaluate("""() => ({ nx: [...document.fonts].some((f) => f.family.replace(/"/g, '') === 'NX Sans' && f.status === 'loaded'),
      proibidas: [...new Set([...document.querySelectorAll('body *')].map((e) => getComputedStyle(e).fontFamily).filter((f) => /mono|Space Grotesk|JetBrains/i.test(f)))] })""")
    ok(fam['nx'] and not fam['proibidas'], 'interface na NX Sans, sem fonte monoespaçada' + ('' if not fam['proibidas'] else f": {fam['proibidas']}"))
    # tema da interface: botão no topo, salvo no navegador, contraste AA no tema claro
    CONTRASTE = open(os.path.join(ROOT, 'tests', 'contraste.js'), encoding='utf-8').read()
    ok(pg.evaluate('document.documentElement.dataset.theme') == 'dark', 'tema escuro é o padrão')
    pg.get_by_test_id('tema-ui').click(); pg.wait_for_timeout(300)
    ok(pg.evaluate('document.documentElement.dataset.theme') == 'light', 'botão do topo liga o tema claro')
    pg.reload(); pg.wait_for_timeout(900)
    ok(pg.evaluate('document.documentElement.dataset.theme') == 'light', 'tema claro continua após recarregar')
    prob = pg.evaluate(CONTRASTE)
    ok(not prob, 'tema claro: contraste AA no início' + ('' if not prob else f': {prob[:3]}'))
    pg.get_by_test_id('tema-ui').click(); pg.wait_for_timeout(300)
    prob = pg.evaluate(CONTRASTE)
    ok(pg.evaluate('document.documentElement.dataset.theme') == 'dark' and not prob, 'volta ao tema escuro, com contraste AA' + ('' if not prob else f': {prob[:3]}'))

    # 2. Catracas + comandas
    pg.get_by_test_id('sol-catraca').click(); pg.wait_for_timeout(600)
    pg.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
    pg.get_by_placeholder('Quem decide').fill('Ana Souza')
    pg.get_by_placeholder('(41) 90000-0000').fill('(41) 90000-0000')
    pg.get_by_role('button', name='Continuar').first.click(); pg.wait_for_timeout(600)
    ok(pg.locator('[data-testid^=card-]').count() == 4, 'preset de catracas com 4 itens')
    pg.locator('[data-testid=card-comanda] .icard-title').click(); pg.wait_for_timeout(300)
    pg.locator('.tier', has_text='até 300').click(); pg.wait_for_timeout(400)
    ok(pg.locator('[data-testid=card-comanda] .qty input').input_value() == '300', 'faixa de comanda ajusta a quantidade')
    pg.locator('[data-testid=card-servico] .toggle').click(); pg.wait_for_timeout(300)
    ok(pg.locator('[data-testid=card-servico] .icard-total b').inner_text().strip().lower() == 'incluso', 'valor zero aparece como incluso')
    pg.screenshot(path=os.path.join(OUT, '02_solucao.png'), full_page=True)

    # piso: preço abaixo da tabela volta ao valor de tabela
    m = pg.locator('[data-testid=card-catraca] .inp-money').first
    tab = m.input_value(); m.fill('100'); m.press('Enter'); pg.wait_for_timeout(300)
    ok(m.input_value() == tab, 'preço abaixo da tabela volta ao piso')
    n_toasts = pg.locator('.toast').count()
    pg.locator('.toast', has_text='mínimo').get_by_role('button', name='Fechar aviso').click(); pg.wait_for_timeout(200)
    ok(n_toasts >= 1 and pg.locator('.toast').count() == n_toasts - 1, 'aviso pode ser fechado')

    pg.get_by_role('button', name='Continuar').first.click(); pg.wait_for_timeout(600)
    pg.get_by_role('radio', name=re.compile('3 dias úteis')).click(); pg.wait_for_timeout(200)
    pg.locator('[data-testid=cond-bol2856] .star').click(); pg.wait_for_timeout(600)
    ok(pg.get_by_role('radio', name=re.compile('CIF')).get_attribute('aria-checked') == 'true', 'frete CIF sugerido para catracas')
    # condição sem fator: avisa na linha e no resumo até receber o total do simulador
    cc12 = pg.get_by_test_id('cond-cc12')
    cc12.locator('.pay-main').click(); pg.wait_for_timeout(400)
    ok(cc12.get_by_test_id('aviso-sem-valor').count() == 1 and pg.get_by_test_id('pend-sem-valor').count() == 1, 'condição sem valor do simulador avisada na linha e no resumo')
    t12 = pg.get_by_label('total Cartão de crédito até 12x'); t12.fill('999999'); t12.press('Enter'); pg.wait_for_timeout(400)
    ok(cc12.get_by_test_id('aviso-sem-valor').count() == 0 and pg.get_by_test_id('pend-sem-valor').count() == 0, 'aviso some ao informar o total do simulador')
    cc12.locator('.pay-main').click(); pg.wait_for_timeout(300)
    ok([r.inner_text().strip() for r in pg.get_by_test_id('tema-proposta').get_by_role('radio').all()] == ['Preto', 'Branco', 'Cinza'], 'NEXTCARD: tema da proposta em Preto, Branco ou Cinza')
    pg.get_by_test_id('tema-proposta').get_by_role('radio', name='Branco').click(); pg.wait_for_timeout(300)
    ok(pg.get_by_test_id('incluir-cases').locator('input').is_checked(), 'cases de sucesso ligados por padrão na NEXTCARD')
    pg.screenshot(path=os.path.join(OUT, '03_condicoes.png'), full_page=True)

    pg.get_by_role('button', name='Gerar proposta').first.click()
    pg.wait_for_selector('[data-testid=preview-img]', timeout=20000)
    pg.wait_for_function("!document.querySelector('.ready-grid button:nth-child(2)').disabled", timeout=40000)
    LUZ = """() => new Promise((r) => { const im = document.querySelector('[data-testid=preview-img]'); const c = document.createElement('canvas'); c.width = 40; c.height = 40; const x = c.getContext('2d');
      const f = () => { x.drawImage(im, 0, 0, 40, 40, 0, 0, 40, 40); const d = x.getImageData(0, 0, 40, 40).data; let s = 0; for (let i = 0; i < d.length; i += 4) s += (d[i] + d[i + 1] + d[i + 2]) / 3; r(s / (d.length / 4)); };
      im.complete ? f() : (im.onload = f); })"""
    ok(pg.evaluate(LUZ) > 200, 'tema claro escolhido nas condições: imagem com fundo claro')
    pg.get_by_test_id('tema-proposta-pronta').get_by_role('radio', name='Cinza').click()
    pg.wait_for_function("!document.querySelector('.ready-grid button:nth-child(2)').disabled", timeout=40000); pg.wait_for_timeout(400)
    # brilho médio de um quadrado de 40 px na altura fy da imagem (0 = topo): faixa grafite no topo, fundo cinza no meio
    LUZ_EM = """(fy) => new Promise((r) => { const im = document.querySelector('[data-testid=preview-img]'); const c = document.createElement('canvas'); c.width = 40; c.height = 40; const x = c.getContext('2d');
      const f = () => { x.drawImage(im, 2, Math.round(im.naturalHeight * fy), 40, 40, 0, 0, 40, 40); const d = x.getImageData(0, 0, 40, 40).data; let s = 0; for (let i = 0; i < d.length; i += 4) s += (d[i] + d[i + 1] + d[i + 2]) / 3; r(s / (d.length / 4)); };
      im.complete ? f() : (im.onload = f); })"""
    topo, meio = pg.evaluate(LUZ_EM, 0.0), pg.evaluate(LUZ_EM, 0.55)
    ok(topo < 80 and 190 < meio < 240, f'tema Cinza na proposta pronta: faixa grafite no topo e fundo cinza ({topo:.0f} / {meio:.0f})')
    ok(pg.evaluate("JSON.parse(localStorage.getItem('nxp.propostas'))[0].temaProposta") == 'cinza', 'tema Cinza fica salvo na proposta')
    pg.get_by_test_id('tema-proposta-pronta').get_by_role('radio', name='Preto').click()
    pg.wait_for_function("!document.querySelector('.ready-grid button:nth-child(2)').disabled", timeout=40000); pg.wait_for_timeout(400)
    ok(pg.evaluate(LUZ) < 60, 'tema escuro escolhido na proposta pronta: imagem refeita no escuro')
    ok(pg.evaluate("JSON.parse(localStorage.getItem('nxp.propostas'))[0].temaProposta") == 'escuro', 'tema fica salvo na proposta')
    pg.screenshot(path=os.path.join(OUT, '04_pronta.png'))
    msg = pg.get_by_label('Mensagem para o cliente').input_value()
    ok('Válida por 3 dias úteis' in msg, 'mensagem traz validade com prazo e data')
    with pg.expect_download(timeout=30000) as dl: pg.get_by_role('button', name='PDF completo').click()
    ok(dl.value.suggested_filename.endswith('.pdf'), 'download do PDF')
    with pg.expect_download() as dl: pg.get_by_role('button', name='Imagem JPG').click()
    ok(dl.value.suggested_filename.endswith('.jpg'), 'download do JPG')
    pg.get_by_role('button', name='Enviar pelo WhatsApp').click(); pg.wait_for_timeout(800)
    abertos = pg.evaluate('window.__opened')
    ok(bool(abertos) and abertos[0].startswith('https://wa.me/5541900000000?text='), 'WhatsApp abre com número internacional e mensagem')
    ok(pg.locator('.ready-etapa .chip.on').inner_text().strip() == 'Enviada', 'proposta marcada como enviada')
    ok(pg.get_by_test_id('envio-passos').count() == 1, 'computador: passos do envio ficam na tela')

    # 3. Teloos
    pg.locator('.nav', has_text='Início').click(); pg.wait_for_timeout(400)
    ok(pg.locator('.follow').count() >= 1, 'proposta enviada aparece em Aguardando resposta')
    pg.get_by_test_id('sol-teloos').click(); pg.wait_for_timeout(600)
    ok(pg.evaluate('document.documentElement.dataset.brand') == 'teloos', 'tema Teloos ao escolher Sistema Teloos')
    ok(min(contraste_dim(pg), 99) >= 4.5, 'contraste do texto secundário (--dim) ≥ 4,5:1 na Teloos')
    pg.get_by_test_id('cliente-empresa').fill('Lanchonete Modelo')
    pg.get_by_role('button', name='Continuar').first.click(); pg.wait_for_timeout(500)
    pg.locator('.plan').nth(1).click(); pg.wait_for_timeout(300)
    pg.locator('.addon').first.get_by_role('button', name='Adicionar').click(); pg.wait_for_timeout(300)
    pg.get_by_role('button', name='Continuar').first.click(); pg.wait_for_timeout(500)
    pg.get_by_role('button', name='Gerar proposta').first.click()
    pg.wait_for_selector('[data-testid=preview-img]', timeout=20000); pg.wait_for_timeout(400)
    ok(True, 'proposta Teloos gerada')

    # 4. Totem: remover e desfazer
    pg.locator('.side-new').click(); pg.wait_for_timeout(400)
    dentro = []
    for _ in range(10):
        pg.keyboard.press('Tab'); dentro.append(pg.evaluate("!!document.activeElement.closest('.modal')"))
    ok(all(dentro), 'modal: foco entra e fica preso na janela')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    ok(pg.evaluate("document.activeElement.classList.contains('side-new')"), 'modal: foco volta ao botão de origem ao fechar')
    pg.locator('.side-new').click(); pg.wait_for_timeout(400)
    pg.locator('.modal').get_by_test_id('sol-totem').click(); pg.wait_for_timeout(600)
    ok(pg.evaluate('document.documentElement.dataset.brand') == 'nextcard', 'tema NEXTCARD ao escolher Totem')
    ok(contraste_dim(pg) >= 4.5, 'contraste do texto secundário (--dim) ≥ 4,5:1 na NEXTCARD')
    pg.get_by_role('button', name='Continuar').first.click(); pg.wait_for_timeout(500)
    antes = pg.locator('[data-testid=card-totem] .icard-title b').inner_text()
    pg.locator('.field-label', has_text='Pinpad').click(); pg.wait_for_timeout(200)
    ok(pg.locator('[data-testid=card-totem] .icard-title b').inner_text() == antes, 'clicar no rótulo não altera a escolha')
    pin = pg.locator('[data-testid=card-totem] .chips[aria-label=Pinpad]')
    pin.locator('.chip.on').focus(); escolha = pin.locator('.chip.on').inner_text()
    pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(300)
    ok(pin.locator('.chip.on').inner_text() != escolha and pin.locator('[tabindex="0"]').count() == 1 and pg.evaluate("document.activeElement.getAttribute('aria-checked') === 'true'"), 'chips: setas mudam a escolha e o grupo tem um só ponto de Tab')
    pg.locator('[data-testid=card-totem] .menu .icon-btn').click(); pg.wait_for_timeout(200)
    pg.get_by_role('menuitem', name='Remover item').click(); pg.wait_for_timeout(300)
    ok(pg.locator('[data-testid^=card-]').count() == 0, 'remover item')
    pg.locator('.toast-act').first.click(); pg.wait_for_timeout(300)
    ok(pg.locator('[data-testid^=card-]').count() == 1, 'desfazer remoção')

    # 5. Persistência
    pg.reload(); pg.wait_for_timeout(1200)
    ok(pg.locator('.modal').count() == 0, 'perfil não reaparece após recarregar')
    pg.locator('.nav', has_text='Propostas').click(); pg.wait_for_timeout(500)
    ok(pg.locator('[data-testid=prop-card]').count() >= 2, 'propostas persistem após recarregar')
    # a proposta Teloos não aparece com NEXTCARD selecionada, mas a tela avisa e troca num clique
    pg.get_by_label('Buscar propostas').fill('Lanchonete'); pg.wait_for_timeout(300)
    ok(pg.locator('[data-testid=prop-card]').count() == 0 and pg.get_by_test_id('outra-marca').count() == 1, 'busca avisa que há proposta na outra marca')
    pg.get_by_test_id('outra-marca').get_by_role('button', name='Ver Teloos').click(); pg.wait_for_timeout(500)
    ok(pg.evaluate('document.documentElement.dataset.brand') == 'teloos' and pg.locator('[data-testid=prop-card]').count() == 1, 'troca para Teloos mantendo a busca')

    # 5a. Configuração → Aparência: troca e restauração da imagem dos cases
    pg.locator('.nav', has_text='Configuração').click(); pg.wait_for_timeout(300)
    pg.locator('.seg button', has_text='Aparência').click(); pg.wait_for_timeout(300)
    pg.get_by_test_id('cases-config').locator('input[type=file]').set_input_files({'name': 'cases.png', 'mimeType': 'image/png', 'buffer': png_teste()})
    pg.wait_for_timeout(800)
    salvo = pg.evaluate("(JSON.parse(localStorage.getItem('nxp.fotos') || '{}')['cases-sucesso'] || '').slice(0, 15)")
    ok(salvo.startswith('data:image/'), 'imagem dos cases trocada em Configuração')
    pg.get_by_test_id('cases-config').get_by_role('button', name='Restaurar padrão').click(); pg.wait_for_timeout(400)
    ok(not pg.evaluate("!!(JSON.parse(localStorage.getItem('nxp.fotos') || '{}')['cases-sucesso'])"), 'imagem padrão dos cases restaurada')

    # 5b. Computador sem permissão para copiar imagem: baixa a imagem e mostra o caminho alternativo
    nctx = b.new_context(viewport={'width': 1440, 'height': 900}, accept_downloads=True)
    np_ = nctx.new_page()
    np_.on('pageerror', lambda e: errs.append('SEM-CLIPBOARD ' + str(e)))
    np_.add_init_script("window.__opened=[]; window.open=(u)=>{window.__opened.push(u); return null}; navigator.clipboard && (navigator.clipboard.write = () => Promise.reject(new Error('negado')));")
    np_.goto(URL); np_.wait_for_timeout(1000)
    np_.get_by_test_id('perfil-nome').fill('Ana Souza'); np_.get_by_role('button', name='Salvar').click(); np_.wait_for_timeout(300)
    np_.get_by_test_id('sol-comanda').click(); np_.wait_for_timeout(500)
    np_.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
    np_.locator('.b-side').get_by_role('button', name='Gerar proposta').click()
    np_.wait_for_function("!document.querySelector('.ready-grid button').disabled", timeout=40000)
    with np_.expect_download() as dl: np_.get_by_role('button', name='Enviar pelo WhatsApp').click()
    np_.wait_for_timeout(400)
    ok(dl.value.suggested_filename.endswith('.jpg') and np_.get_by_test_id('envio-alternativo').count() == 1, 'computador sem permissão de copiar: imagem baixada e passos na tela')
    nctx.close()

    # 6. Celular
    mctx = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
    mp = mctx.new_page()
    mp.on('pageerror', lambda e: errs.append('CELULAR ' + str(e)))
    mp.goto(URL); mp.wait_for_timeout(1000)
    mp.get_by_test_id('perfil-nome').fill('Ana Souza'); mp.get_by_role('button', name='Salvar').click(); mp.wait_for_timeout(300)
    ok(mp.evaluate('document.documentElement.scrollWidth') <= 390, 'celular: início sem rolagem horizontal')
    mp.screenshot(path=os.path.join(OUT, 'm01_inicio.png'), full_page=True)
    mp.get_by_test_id('sol-catraca').click(); mp.wait_for_timeout(500)
    mp.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
    mp.locator('.m-bar').get_by_role('button', name='Continuar').click(); mp.wait_for_timeout(500)
    ok(mp.evaluate('document.documentElement.scrollWidth') <= 390, 'celular: construtor sem rolagem horizontal')
    linhas = mp.evaluate("[...document.querySelectorAll('.icard-title b')].map(b => Math.round(b.getBoundingClientRect().height / parseFloat(getComputedStyle(b).lineHeight)))")
    ok(linhas and max(linhas) <= 2, 'celular: título do cartão de item em até 2 linhas')
    peq = alvos_pequenos(mp)
    ok(not peq, 'celular: controles da solução com pelo menos 44 px' + ('' if not peq else f': {peq[:4]}'))
    mp.screenshot(path=os.path.join(OUT, 'm02_solucao.png'), full_page=True)
    mp.locator('.m-bar').get_by_role('button', name='Prévia').click(); mp.wait_for_timeout(1200)
    ok(mp.locator('.sheet canvas').count() == 1, 'celular: prévia abre em folha')
    mp.locator('.sheet .icon-btn[aria-label=Fechar]').click(); mp.wait_for_timeout(200)
    mp.locator('.m-bar').get_by_role('button', name='Continuar').click(); mp.wait_for_timeout(400)
    peq = alvos_pequenos(mp)
    ok(not peq, 'celular: controles das condições com pelo menos 44 px' + ('' if not peq else f': {peq[:4]}'))
    mp.locator('.m-bar').get_by_role('button', name='Gerar').click()
    mp.wait_for_selector('[data-testid=preview-img]', timeout=20000); mp.wait_for_timeout(400)
    ok(mp.evaluate('document.documentElement.scrollWidth') <= 390, 'celular: proposta pronta sem rolagem horizontal')
    mp.screenshot(path=os.path.join(OUT, 'm03_pronta.png'), full_page=True)
    # Teloos no celular: adicionais cabem na tela e o botão "Adicionar" recebe o toque
    mp.locator('.bottom-nav .bn-new').click(); mp.wait_for_timeout(400)
    mp.locator('.modal').get_by_test_id('sol-teloos').click(); mp.wait_for_timeout(500)
    mp.get_by_test_id('cliente-empresa').fill('Lanchonete Modelo')
    mp.locator('.m-bar').get_by_role('button', name='Continuar').click(); mp.wait_for_timeout(500)
    ok(mp.evaluate('document.documentElement.scrollWidth') <= 390, 'celular: solução Teloos sem rolagem horizontal')
    mp.locator('.plan').nth(1).click(); mp.wait_for_timeout(300)
    mp.locator('.addon').first.get_by_role('button', name='Adicionar').click(timeout=5000); mp.wait_for_timeout(300)
    ok(mp.locator('.addon.on').count() == 1, 'celular: adicional Teloos entra com um toque')
    b.close()

ok(not [r for r in reqs if 'wa.me' not in r], 'nenhuma requisição externa')
ok(not errs, 'nenhum erro de console' + ('' if not errs else ': ' + ' | '.join(errs[:5])))
print(f'\n{len(falhas)} falha(s). Capturas em tests/out/')
sys.exit(1 if falhas else 0)
