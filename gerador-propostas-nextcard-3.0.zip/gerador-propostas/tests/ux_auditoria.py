"""Auditoria de UX: percorre as 5 jornadas no computador (1440 × 900) e no celular (390 × 844),
salva capturas e mede os pontos das hipóteses (alvos de toque, contraste, toasts, cartões, prévia).
Uso: node build/build.mjs && python3 tests/ux_auditoria.py antes|depois
Não é um teste de aceite: grava tests/out/auditoria/<fase>/medidas.json para comparar antes e depois."""
import json, os, sys, time
from playwright.sync_api import sync_playwright

FASE = sys.argv[1] if len(sys.argv) > 1 else 'antes'
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = 'file://' + os.path.join(ROOT, 'dist', 'index.html')
OUT = os.path.join(ROOT, 'tests', 'out', 'rodada1', 'auditoria', FASE); os.makedirs(OUT, exist_ok=True)
M = {}

ALVOS_JS = """() => {
  const out = [];
  for (const el of document.querySelectorAll('button, a, input, select, textarea, [role=button], [role=radio], label.chk, label.toggle')) {
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) continue;
    const st = getComputedStyle(el); if (st.visibility === 'hidden' || st.display === 'none') continue;
    if (el.closest('[hidden]')) continue;
    if (el.matches('input[type=checkbox], input[type=file]')) continue;
    if (r.width < 44 || r.height < 44) out.push({ tag: el.tagName.toLowerCase(), cls: (el.className && el.className.baseVal === undefined ? el.className : '').toString().slice(0, 40), txt: (el.getAttribute('aria-label') || el.textContent || '').trim().slice(0, 30), w: Math.round(r.width), h: Math.round(r.height) });
  }
  return out;
}"""

CONTRASTE_JS = """() => {
  const lum = (c) => { const m = c.match(/[\\d.]+/g).map(Number); const f = (v) => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(m[0]) + .7152 * f(m[1]) + .0722 * f(m[2]); };
  const cs = getComputedStyle(document.documentElement);
  const hex = (h) => { h = h.trim().replace('#', ''); return `rgb(${parseInt(h.slice(0,2),16)},${parseInt(h.slice(2,4),16)},${parseInt(h.slice(4,6),16)})`; };
  const bg = hex(cs.getPropertyValue('--bg'));
  const r = {};
  for (const k of ['--text', '--muted', '--dim']) { const a = lum(hex(cs.getPropertyValue(k))), b = lum(bg); r[k] = +(((Math.max(a, b) + .05) / (Math.min(a, b) + .05)).toFixed(2)); }
  return r;
}"""

def shot(pg, nome):
    pg.screenshot(path=os.path.join(OUT, nome + '.png'), full_page=False)

def novo_contexto(b, mobile):
    vp = {'width': 390, 'height': 844} if mobile else {'width': 1440, 'height': 900}
    ctx = b.new_context(viewport=vp, device_scale_factor=2 if mobile else 1, has_touch=mobile, is_mobile=mobile, accept_downloads=True)
    pg = ctx.new_page()
    pg.add_init_script("window.__opened=[]; window.open=(u)=>{window.__opened.push(u); return null};")
    errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(URL); pg.wait_for_timeout(900)
    if pg.get_by_test_id('perfil-nome').count():
        pg.get_by_test_id('perfil-nome').fill('Ana Souza')
        pg.get_by_role('button', name='Salvar').click(); pg.wait_for_timeout(300)
    return ctx, pg, errs

def continuar(pg, mobile):
    if mobile: pg.locator('.m-bar').get_by_role('button', name='Continuar').dispatch_event('click')
    else: pg.locator('.step-nav').get_by_role('button', name='Continuar').click()
    pg.wait_for_timeout(500)

def gerar(pg, mobile):
    if mobile: pg.locator('.m-bar').get_by_role('button', name='Gerar').dispatch_event('click')
    else: pg.locator('.step-nav').get_by_role('button', name='Gerar proposta').click()
    pg.wait_for_timeout(2500)

def jornadas(b, mobile):
    tag = 'cel' if mobile else 'pc'
    ctx, pg, errs = novo_contexto(b, mobile)
    R = {}
    shot(pg, f'{tag}_a0_inicio')
    R['dica_primeiro_uso'] = pg.locator('[data-testid=dica]').count()
    # (a) primeira proposta de catracas
    pg.get_by_test_id('sol-catraca').click(); pg.wait_for_timeout(600)
    R['dica_passo1'] = pg.locator('[data-testid=dica]').count()
    pg.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
    pg.get_by_placeholder('(41) 90000-0000').fill('(41) 90000-0000')
    shot(pg, f'{tag}_a1_cliente')
    continuar(pg, mobile)
    shot(pg, f'{tag}_a2_solucao')
    R['solucao_altura_px'] = pg.evaluate('document.documentElement.scrollHeight')
    R['cartoes'] = pg.locator('[data-testid^=card-]').count()
    R['titulo_cartao_linhas'] = pg.evaluate("""() => [...document.querySelectorAll('.icard-title b')].map(b => Math.round(b.getBoundingClientRect().height / parseFloat(getComputedStyle(b).lineHeight)))""")
    R['cabecalho_cartao_px'] = pg.evaluate("""() => [...document.querySelectorAll('.icard-head')].map(h => Math.round(h.getBoundingClientRect().height))""")
    R['alvos_pequenos_solucao'] = pg.evaluate(ALVOS_JS) if mobile else None
    # toast x conteúdo: remove um item e mede a sobreposição do toast com a barra fixa e o conteúdo
    pg.locator('[data-testid^=card-] .menu .icon-btn').last.click(); pg.wait_for_timeout(200)
    pg.get_by_role('menuitem', name='Remover item').click(); pg.wait_for_timeout(350)
    R['toast'] = pg.evaluate("""() => { const t = document.querySelector('.toast'); if (!t) return null; const r = t.getBoundingClientRect();
      const bar = document.querySelector('.m-bar'); const br = bar && getComputedStyle(bar).display !== 'none' ? bar.getBoundingClientRect() : null;
      const hit = [...document.querySelectorAll('.icard, .card, button')].filter(e => !t.contains(e) && !(bar && bar.contains(e))).filter(e => { const q = e.getBoundingClientRect(); return q.bottom > r.top && q.top < r.bottom && q.right > r.left && q.left < r.right; }).length;
      return { top: Math.round(r.top), bottom: Math.round(r.bottom), altura: Math.round(r.height), sobre_barra: br ? (r.bottom > br.top) : false, elementos_cobertos: hit, fechar: !!t.querySelector('[aria-label="Fechar aviso"]') }; }""")
    shot(pg, f'{tag}_a3_toast')
    pg.get_by_role('button', name='Desfazer').click(); pg.wait_for_timeout(300)
    continuar(pg, mobile)
    shot(pg, f'{tag}_a4_condicoes')
    R['condicoes_altura_px'] = pg.evaluate('document.documentElement.scrollHeight')
    R['condicoes_linhas_pagamento'] = pg.locator('.pay').count()
    R['alvos_pequenos_condicoes'] = pg.evaluate(ALVOS_JS) if mobile else None
    # hipótese 3: condição sem fator marcada e destacada sem valor
    pg.get_by_test_id('cond-cc12').locator('.pay-main').click(); pg.wait_for_timeout(400)
    cc = pg.get_by_test_id('cond-cc12')
    R['cc12_aviso_visivel'] = cc.locator('.disc.open').count() > 0
    R['cc12_texto'] = cc.inner_text()[:160]
    cc.locator('.star').click(); pg.wait_for_timeout(500)
    R['cc12_alerta_resumo'] = pg.locator('[data-testid=aviso-sem-valor]').count()
    shot(pg, f'{tag}_a5_cc12_sem_valor')
    cc.locator('.pay-main').click(); pg.wait_for_timeout(300)
    gerar(pg, mobile)
    shot(pg, f'{tag}_a6_pronta')
    # hipótese 9: envio no computador sem permissão de copiar imagem
    if not mobile:
        pg.get_by_role('button', name='Enviar pelo WhatsApp').click(); pg.wait_for_timeout(700)
        R['envio_sem_clipboard_toast'] = [t.inner_text() for t in pg.locator('.toast').all()]
        R['envio_sem_clipboard_baixou'] = pg.locator('[data-testid=envio-alternativo]').count()
        shot(pg, f'{tag}_a7_envio_sem_permissao')
    R['erros'] = errs
    ctx.close()

    # (b) totem trocando modelo e opcionais
    ctx, pg, errs = novo_contexto(b, mobile)
    pg.get_by_test_id('sol-totem').click(); pg.wait_for_timeout(600)
    pg.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
    continuar(pg, mobile)
    card = pg.get_by_test_id('card-totem')
    if card.locator('.icard-body').count() == 0: card.locator('.icard-thumb').click(); pg.wait_for_timeout(300)
    chips = card.locator('.model-group .chip')
    R['totem_modelos'] = chips.count()
    if chips.count() > 2: chips.nth(2).click(); pg.wait_for_timeout(400)
    R['totem_altura_config_px'] = pg.evaluate("document.querySelector('[data-testid=card-totem]').getBoundingClientRect().height")
    shot(pg, f'{tag}_b1_totem')
    # teclado nos chips: Tab até um chip do grupo e seta para a direita
    card.locator('.chips[aria-label=Pinpad] .chip.on').focus()
    antes = card.locator('.chips[aria-label=Pinpad] .chip.on').inner_text()
    pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(300)
    depois = card.locator('.chips[aria-label=Pinpad] .chip.on').inner_text()
    R['chips_setas'] = antes != depois
    R['chips_tabstops_pinpad'] = pg.evaluate("[...document.querySelectorAll('.chips[aria-label=Pinpad] .chip')].filter(c => c.tabIndex >= 0).length")
    ctx.close()

    # (c) Teloos: plano, 3 adicionais, cupom e implantação D+1
    ctx, pg, errs = novo_contexto(b, mobile)
    R['troca_marca_visivel_inicio'] = pg.locator('.brand-switch').is_visible()
    pg.get_by_test_id('sol-teloos').click(); pg.wait_for_timeout(600)
    pg.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
    continuar(pg, mobile)
    R['teloos_largura_sem_plano_px'] = pg.evaluate('document.documentElement.scrollWidth')
    pg.locator('[data-testid^=plano-]').nth(1).click(); pg.wait_for_timeout(300)
    R['teloos_largura_com_plano_px'] = pg.evaluate('document.documentElement.scrollWidth')
    R['teloos_botao_adicionar_clicavel'] = pg.evaluate("""() => { const b = document.querySelector('.addon .add-btn'); b.scrollIntoView({ block: 'center' }); const r = b.getBoundingClientRect(); const e = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return !!e && b.contains(e); }""")
    for i in range(3): pg.locator('.addon .add-btn').first.dispatch_event('click'); pg.wait_for_timeout(200)
    pg.locator('.chips').first.locator('.chip').nth(2).click(); pg.wait_for_timeout(200)
    impl = pg.locator('.card', has_text='Implantação e treinamento').locator('.chip')
    impl.nth(min(2, impl.count() - 1)).click(); pg.wait_for_timeout(400)
    shot(pg, f'{tag}_c1_teloos')
    R['teloos_continuar_visivel'] = pg.evaluate("""() => { const b = [...document.querySelectorAll('.m-bar button, .step-nav button')].find(x => /Continuar/.test(x.textContent) && x.offsetParent); if (!b) return null; const r = b.getBoundingClientRect(); return r.right <= window.innerWidth && r.left >= 0; }""")
    R['teloos_altura_px'] = pg.evaluate('document.documentElement.scrollHeight')
    continuar(pg, mobile); gerar(pg, mobile)
    shot(pg, f'{tag}_c2_teloos_pronta')
    ctx.close()

    # (d) reabrir uma proposta enviada, ajustar e reenviar + (e) busca e marcar como ganha
    ctx, pg, errs = novo_contexto(b, mobile)
    pg.get_by_test_id('sol-comanda').click(); pg.wait_for_timeout(600)
    pg.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
    continuar(pg, mobile); continuar(pg, mobile); gerar(pg, mobile)
    pg.get_by_role('button', name='Enviar pelo WhatsApp').click(); pg.wait_for_timeout(600)
    pg.get_by_role('button', name='Editar', exact=True).click(); pg.wait_for_timeout(600)
    R['reabrir_passo'] = pg.locator('.st.on b').inner_text()
    shot(pg, f'{tag}_d1_reabrir')
    gerar_btn = pg.locator('.m-bar' if mobile else '.step-nav').get_by_role('button', name='Gerar' if mobile else 'Gerar proposta')
    R['reabrir_gerar_direto'] = gerar_btn.count() > 0
    ctx.close()

    ctx, pg, errs = novo_contexto(b, mobile)
    # cria uma proposta Teloos enviada e procura com a marca NEXTCARD selecionada
    pg.get_by_test_id('sol-teloos').click(); pg.wait_for_timeout(500)
    pg.get_by_test_id('cliente-empresa').fill('Restaurante Modelo')
    continuar(pg, mobile); continuar(pg, mobile); gerar(pg, mobile)
    pg.get_by_role('button', name='Enviar pelo WhatsApp').click(); pg.wait_for_timeout(500)
    pg.evaluate("document.querySelector('.back') && document.querySelector('.back').click()"); pg.wait_for_timeout(400)
    pg.locator('.brand-switch button', has_text='NEXTCARD').click(); pg.wait_for_timeout(400)
    if mobile: pg.locator('.bottom-nav button', has_text='Propostas').click()
    else: pg.locator('.side-nav .nav', has_text='Propostas').click()
    pg.wait_for_timeout(400)
    if mobile: pg.locator('.seg button', has_text='Lista').click(); pg.wait_for_timeout(200)
    pg.get_by_label('Buscar propostas').fill('Modelo'); pg.wait_for_timeout(300)
    R['busca_propostas_outra_marca'] = pg.locator('[data-testid=prop-row], [data-testid=prop-card]').count()
    R['busca_aviso_outra_marca'] = pg.locator('[data-testid=outra-marca]').count()
    shot(pg, f'{tag}_e1_busca')
    ctx.close()
    return R

def contraste(b):
    ctx, pg, _ = novo_contexto(b, False)
    r = {'nextcard': pg.evaluate(CONTRASTE_JS)}
    pg.locator('.brand-switch button', has_text='Teloos').click(); pg.wait_for_timeout(400)
    r['teloos'] = pg.evaluate(CONTRASTE_JS)
    # foco preso no modal: abre "Nova proposta" e dá 12 Tabs
    pg.locator('.side-new').click(); pg.wait_for_timeout(300)
    fora = 0
    for _ in range(12):
        pg.keyboard.press('Tab')
        fora += pg.evaluate("!document.activeElement.closest('.modal')")
    r['modal_foco_fora_em_12_tabs'] = fora
    ctx.close()
    return r

def desempenho(b):
    ctx = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=3, is_mobile=True, has_touch=True)
    pg = ctx.new_page()
    cdp = ctx.new_cdp_session(pg); cdp.send('Emulation.setCPUThrottlingRate', {'rate': 4})
    pg.goto(URL); pg.wait_for_timeout(1500)
    if pg.get_by_test_id('perfil-nome').count():
        pg.get_by_test_id('perfil-nome').fill('Ana Souza'); pg.get_by_role('button', name='Salvar').click(); pg.wait_for_timeout(300)
    pg.get_by_test_id('sol-catraca').click(); pg.wait_for_timeout(1500)
    pg.evaluate("""() => { window.__lt = []; new PerformanceObserver(l => l.getEntries().forEach(e => window.__lt.push(Math.round(e.duration)))).observe({ type: 'longtask', buffered: false }); }""")
    t0 = time.time()
    pg.get_by_test_id('cliente-empresa').press_sequentially('Restaurante Modelo', delay=60)
    digitar = time.time() - t0
    pg.wait_for_timeout(2500)
    lt = pg.evaluate('window.__lt')
    # sobre o celular a prévia só aparece na folha: há desenho mesmo com a folha fechada?
    canv = pg.evaluate("document.querySelectorAll('.b-side canvas').length")
    ctx.close()
    return {'cpu_4x_digitar_18_letras_s': round(digitar, 2), 'tarefas_longas_ms': lt, 'soma_tarefas_longas_ms': sum(lt), 'canvas_na_prévia_oculta': canv}

with sync_playwright() as p:
    b = p.chromium.launch()
    M['computador'] = jornadas(b, False)
    M['celular'] = jornadas(b, True)
    M['contraste_e_modal'] = contraste(b)
    M['desempenho_celular_cpu4x'] = desempenho(b)
    b.close()
json.dump(M, open(os.path.join(OUT, 'medidas.json'), 'w'), ensure_ascii=False, indent=1)
print(json.dumps(M, ensure_ascii=False, indent=1))
