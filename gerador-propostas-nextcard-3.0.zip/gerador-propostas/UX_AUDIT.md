# Auditoria de UX · Gerador de Propostas NEXTCARD + Teloos

Base: código-fonte v2 (configuração NX-2026.09-v2) · Data: 30/09/2026 · Método: heurísticas de Nielsen + WCAG 2.2 AA

## Como a auditoria foi feita

- As 5 jornadas pedidas foram percorridas de forma automática no computador (1440 × 900) e no celular (390 × 844, toque, DPR 2) com `tests/ux_auditoria.py`:
  (a) consultor novo fazendo a primeira proposta de catracas; (b) totem trocando modelo e opcionais; (c) Teloos com plano, 3 adicionais, cupom e implantação D+1; (d) reabrir uma proposta enviada, ajustar e reenviar; (e) achar uma proposta antiga pela busca e marcar como ganha.
- O script salva as capturas e as medidas em `tests/out/rodada1/auditoria/antes/` (e `depois/`, após as mudanças). As medidas ficam em `medidas.json`.
- Medidas coletadas: altura das telas, linhas do título dos cartões, altura do cabeçalho dos cartões, alvos de toque abaixo de 44 px, sobreposição dos avisos (toasts), contraste das cores de texto, foco nos modais, navegação por setas nos chips, rolagem horizontal, tempo de digitação e tarefas longas com CPU 4× mais lenta.
- Dados de teste: "Restaurante Modelo", "Ana Souza" e "(41) 90000-0000". Este relatório não reproduz preços nem textos comerciais.

## Resumo

| # | Hipótese do briefing | Resultado |
|---|---|---|
| 1 | Passo "Solução" longo, talvez caiba um modo compacto | **Confirmada no celular.** Com 4 itens, a tela tem 1.894 px no celular e 1.191 px no computador. A maior parte vem do cabeçalho do cartão (237 a 337 px no celular, contra 150 a 156 px no computador). O modo compacto separado não é necessário: basta enxugar o cabeçalho (P2). |
| 2 | As 8 formas de pagamento aparecem todas | **Confirmada, severidade média.** São 8 linhas e o passo "Condições" tem 2.601 px no celular. Ficou para a próxima rodada (P10). |
| 3 | Condição sem fator depende do simulador e o consultor não percebe | **Confirmada, severidade alta.** O campo abre sozinho ao marcar a condição. Mas, se o consultor deixa em branco e marca a estrela, a imagem e o resumo passam a mostrar **outra** condição sem avisar. Captura `pc_a5_cc12_sem_valor.png`. |
| 4 | No celular o cabeçalho do cartão fica apertado | **Confirmada.** O título ocupa 2 a 3 linhas porque sobra só cerca de 140 px para ele. A especificação chega a 5 linhas. Captura `cel_a2_solucao.png`. |
| 5 | Os toasts cobrem conteúdo | **Confirmada.** No celular, o toast cobre 5 elementos (cartões e botões) e 2 toasts empilhados ocupam cerca de 250 px. Não há botão de fechar. O aviso importante do envio some em 4,2 s. |
| 6 | Falta orientação no primeiro uso | **Parcial, severidade baixa.** O Início já orienta ("O que vamos propor hoje?"), os tipos vêm preenchidos e cada passo tem subtítulo explicativo. A falta que se nota está nas condições sem valor (P3) e no envio no computador (P6). |
| 7 | Chips sem setas, modais sem foco preso, contraste do texto secundário | **Confirmada nos três pontos.** Setas não mudam a escolha. Nos modais, 12 de 12 Tabs deixaram o foco fora da janela. A cor `--dim` da NEXTCARD tem contraste de 3,81:1 (mínimo 4,5:1) e é usada nos rótulos de 10 px dos cartões e nas dicas dos campos. |
| 8 | Prévia redesenha a cada mudança; travamento em celular fraco | **Descartada como problema de travamento.** Com CPU 4× mais lenta, digitar 18 letras gerou 1 tarefa longa de 92 ms. A espera de 220 ms funciona. Achado lateral: no celular, a prévia lateral (oculta) também é desenhada a cada mudança. É desperdício, com severidade baixa (P11). |
| 9 | No computador, o envio depende da permissão de copiar imagem | **Confirmada, severidade média.** Sem a permissão, o app abre o WhatsApp e mostra "Baixe a imagem e anexe…", mas **não baixa nada**, e o aviso some em 4,2 s. Captura `pc_a7_envio_sem_permissao.png`. |
| 10 | A troca NEXTCARD/Teloos confunde | **Confirmada em Propostas.** A lista e o quadro filtram pela marca do topo sem avisar. Uma proposta Teloos buscada com a NEXTCARD selecionada resulta em "Nenhuma proposta encontrada". No construtor, a troca fica oculta e não confunde. Captura `cel_e1_busca.png`. |

**Achado novo, fora das hipóteses (severidade alta):** no celular, o passo "Solução" da Teloos tem **rolagem horizontal** (493 px de largura numa tela de 390 px). O botão "Adicionar" dos adicionais fica cortado fora do cartão e não recebe o toque. O botão "Continuar" da barra fixa fica parcialmente fora da tela. O teste e2e só verificava a rolagem na proposta de catracas, por isso não detectou. Captura `cel_c1_teloos.png`.

## Tabela de problemas

Severidade: alta (impede ou induz a erro na proposta), média (atrasa ou confunde), baixa (acabamento). Esforço: P (horas), M (1 dia), G (vários dias). Risco para as regras da seção 5 do briefing (preço, imagem, validade, offline, testes).

| ID | Problema | Onde (tela · arquivo) | Evidência | Sev. | Proposta de solução | Esf. | Risco | Decisão |
|---|---|---|---|---|---|---|---|---|
| P1 | Adicionais Teloos estouram a largura no celular: rolagem horizontal, "Adicionar" inalcançável, "Continuar" cortado | Solução Teloos · `styles.css` (`.addons` com `1fr` = `minmax(auto, 1fr)` e nome em `nowrap`) | `cel_c1_teloos.png`; largura 493 px; `teloos_botao_adicionar_clicavel: false` | Alta | Trilha da grade com `minmax(0, 1fr)`, para o nome truncar dentro do cartão | P | Nenhum | **Implementar** |
| P2 | Cabeçalho do cartão de item apertado no celular: título em 3 linhas, especificação em até 5 linhas | Solução · `styles.css` (`.icard-*` ≤ 600 px) | `cel_a2_solucao.png`; cabeçalho de 237 a 337 px; título com 2 a 3 linhas | Média | Ações em coluna estreita, miniatura menor, especificação limitada a 2 linhas quando o cartão está fechado (texto completo ao abrir) | P | Nenhum (só a interface) | **Implementar** |
| P3 | Condição sem fator marcada, ou com estrela, sem valor do simulador: some da imagem e a estrela vai para outra condição sem aviso | Condições · `Builder.jsx` (`PagamentoCard`, `Resumo`) | `pc_a5_cc12_sem_valor.png`; nenhum alerta (`cc12_alerta_resumo: 0`) | Alta | Aviso na própria linha ("não aparece na imagem nem no PDF até você informar o total") e pendência no resumo e na barra do celular, com atalho para o campo. "Gerar" continua liberado | P | Baixo: não mexe em cálculo nem bloqueia "Gerar" | **Implementar** |
| P4 | Propostas: lista, quadro e busca filtram pela marca do topo sem avisar; a busca não acha a proposta da outra marca | Propostas · `Screens.jsx` (`Propostas`), `App.jsx` | `cel_e1_busca.png`; 0 resultados com a proposta existente | Alta | Faixa "N propostas Teloos também correspondem · Ver em Teloos" (troca a marca num toque) e rótulo da marca no título da lista | P | Nenhum | **Implementar** |
| P5 | Toasts cobrem conteúdo, sem botão de fechar; os de alerta somem rápido demais | Global · `App.jsx`, `styles.css` | `cel_a3_toast.png`; 5 elementos cobertos; sem "Fechar" | Média | Botão "Fechar aviso", tempo por tipo (confirmação 3,5 s; alerta 6,5 s; com ação 7 s) e toast mais baixo no celular | P | Nenhum | **Implementar** |
| P6 | Envio no computador sem permissão de copiar imagem: pede para baixar, mas não baixa, e o aviso some | Proposta pronta · `Pronta.jsx` | `pc_a7_envio_sem_permissao.png` | Média | Se a cópia falhar, baixar o JPG na hora. Mostrar um bloco fixo "Como enviar" com os passos e os botões "Baixar imagem de novo" e "Baixar PDF" | P | Nenhum | **Implementar** |
| P7 | Chips (grupo de opção única) sem setas: com teclado é preciso passar por cada chip com Tab | Global · `common.jsx` (`Chips`) | `chips_setas: false` | Média | Padrão WAI-ARIA de rádio: um único ponto de Tab por grupo, setas e Home/End mudam a escolha | P | Baixo: a escolha continua passando pelo mesmo `onChange` | **Implementar** |
| P8 | Modais e folha sem foco inicial e sem foco preso; o foco não volta ao fechar | Global · `common.jsx` (`Modal`, `Sheet`) | `modal_foco_fora_em_12_tabs: 12` | Média | Foco no primeiro campo ao abrir, Tab e Shift+Tab presos, foco devolvido ao botão de origem | P | Nenhum | **Implementar** |
| P9 | Contraste da cor `--dim` da NEXTCARD de 3,81:1 (texto de 10 a 12 px) | Global · `styles.css` | `contraste_e_modal.nextcard.--dim: 3.81` | Média | Clarear `--dim` para ≥ 4,5:1 sobre fundo e superfícies, mantendo a hierarquia (continua mais apagado que `--muted`). Conferir o mesmo na Teloos | P | Nenhum: a imagem e o PDF usam cores próprias em `render.js` | **Implementar** |
| P10 | Alvos de toque abaixo de 44 px no celular: botões de ícone de 32 px, quantidade de 30 × 34 px, estrela de 34 px, "Ajustar" de 36 px, "Incluir" de 32 px, itens inclusos de 32 px | Solução e Condições · `styles.css` | `alvos_pequenos_*`: 40 e 43 ocorrências | Média | Tamanho mínimo de 44 px abaixo de 900 px de largura, sem mudar o computador | P | Nenhum | **Implementar** |
| P11 | 8 formas de pagamento sempre visíveis (passo longo) | Condições · `Builder.jsx` | `cel_a4_condicoes.png`; 2.601 px | Média | Mostrar as marcadas + "Adicionar condição" | M | Médio: esconder condições reduz a descoberta. Melhor validar com os consultores antes | Próxima rodada |
| P12 | Prévia lateral oculta no celular é desenhada a cada mudança | Construtor · `Builder.jsx` (`LivePreview`) | `canvas_na_prévia_oculta: 1`; 1 tarefa de 92 ms com CPU 4× | Baixa | Não desenhar quando o quadro está oculto | P | Baixo | Próxima rodada (sem travamento medido) |
| P13 | Reabrir uma proposta enviada no celular: a barra mostra "Continuar" no passo 2; para gerar de novo são 2 toques a mais | Construtor · `Builder.jsx` (`m-bar`) | `reabrir_gerar_direto: false` (celular) | Baixa | Na edição de proposta já emitida, oferecer "Gerar" em qualquer passo | P | Baixo | Próxima rodada |
| P14 | Tela de Propostas no celular com 2 campos de busca (global e da lista) | Propostas · `App.jsx`, `styles.css` | `cel_e1_busca.png` | Baixa | Esconder a busca global na rota Propostas do celular | P | Nenhum | Próxima rodada |
| P15 | Dicas de primeiro uso | Construtor | Hipótese 6 | Baixa | Subtítulos já cumprem o papel; P3 e P6 cobrem os pontos de dúvida reais | P | Nenhum | Não fazer agora |
| P16 | `build/harness.mjs` falha se a pasta `harness/` não existe (zip sem a pasta) | Build · `build/harness.mjs` | `ENOENT` ao rodar `node build/harness.mjs` | Média (bloqueia o teste da imagem) | Criar a pasta antes de gravar | P | Nenhum | **Corrigido** (pré-requisito para rodar os testes) |

## Resultado depois da rodada 1 (medidas de `tests/ux_auditoria.py`)

| Medida | Antes | Depois |
|---|---|---|
| Largura da página na Solução Teloos, celular 390 px | 493 px | 390 px |
| Botão "Adicionar" dos adicionais Teloos recebe o toque no celular | não | sim |
| Condição sem valor com estrela: alerta no resumo ou na barra | 0 | 1 |
| Busca em Propostas por cliente da outra marca: aviso com atalho | não | sim |
| Linhas do título dos 4 cartões (catracas, celular) | 3, 2, 3, 3 | 2, 2, 2, 2 |
| Cabeçalho dos cartões (celular) | 237 a 337 px | 226 a 266 px |
| Altura do passo Solução com 4 itens (celular) | 1.894 px | 1.697 px |
| Toast com botão de fechar | não | sim |
| Envio no computador sem permissão de copiar | nenhum arquivo baixado, aviso de 4 s | JPG baixado e passos fixos na tela |
| Setas nos chips / pontos de Tab no grupo Pinpad | não / 2 | sim / 1 |
| Tabs fora do modal (em 12) | 12 | 0 |
| Contraste `--dim` NEXTCARD / Teloos (sobre o fundo) | 3,81 / 5,19 | 5,89 / 6,43 |
| Alvos < 44 px no construtor, celular (Solução / Condições) | 40 / 43 | 2 / 2 (*) |

(*) Os que restam são o link de texto "descartar rascunho", que está isento pelo critério 2.5.8 por ser texto em linha, e interruptores medidos em 43,x px, arredondados para 44 na captura.

**Efeitos colaterais medidos, sem impacto relevante:**
- O passo Condições no celular ficou 93 px mais alto (2.601 → 2.694 px), por causa dos alvos maiores e do aviso de condição sem valor.
- A Solução Teloos no celular ficou 31 px mais alta (2.552 → 2.583 px).
- O toast no celular ainda cobre elementos enquanto está visível. Ficou mais baixo, pode ser fechado e a confirmação some em 3,5 s.
- As tarefas longas com CPU 4× variaram de 92 para 167 ms somados (2 tarefas), mas o código da prévia não mudou. O tempo de digitação seguiu estável (1,59 s → 1,63 s para 18 letras). Fica o registro para a P12.

## Pontos fortes (manter)

- Cada tipo de proposta já começa preenchido; o passo "Cliente" pede só o nome da empresa.
- Salvamento automático com indicação "salvo hh:mm", desfazer ao remover item e ao mover etapa.
- O piso de preço é aplicado com aviso claro ("voltou para …"); "incluso" em valor zero.
- A prévia ao vivo com o resumo lateral no computador responde bem mesmo com CPU lenta.
- No celular, a barra fixa com o total e o botão principal está sempre à mão.

## Não implementado e por quê

- **P11 (condições recolhidas):** muda o jeito de ver as opções. Recolher sem conversar com os consultores pode esconder condições que eles oferecem de cabeça. Recomendado testar com 2 ou 3 consultores antes.
- **P12, P13, P14:** baixa severidade e sem impacto medido. Ficam para a próxima rodada para caber no limite de 10 itens.
- **P15:** não houve evidência de dúvida que justificasse dicas extras. Os pontos de dúvida reais foram tratados em P3 e P6.
- Fora do escopo do briefing: opção A/B para catracas, PDF A4, integrações, backend, login, preços e política.

## Pendências para os fundadores

- [VALIDAR COM OS FUNDADORES] Condições sem fator (cartão 1x, 3x, 12x e boleto 21/42/63) ainda dependem do valor do simulador oficial. A interface agora avisa quando falta o valor, mas o ideal é confirmar os fatores para eliminar a digitação. O ponto já consta na lista de pendências da configuração.
- [VALIDAR COM OS FUNDADORES] Os dados de configuração (política, preços, fotos) seguem sem alteração nesta rodada. Nenhum item comercial foi mudado.
