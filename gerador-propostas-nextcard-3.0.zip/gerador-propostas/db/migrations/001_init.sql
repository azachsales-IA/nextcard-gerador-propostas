-- Gerador de Propostas NEXTCARD 3.0 — núcleo corporativo
-- Persistência central, usuários, alçadas, numeração, snapshots imutáveis, Kommo e auditoria.

create extension if not exists pgcrypto;

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  nome text not null,
  sigla text not null default '',          -- sufixo comercial do número da proposta (ex.: HF)
  telefone text not null default '',
  roles text[] not null default '{consultor}', -- owner | aprovador | gestor | consultor
  pass_hash text not null,
  ativo boolean not null default true,
  falhas_login int not null default 0,
  bloqueado_ate timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists sessions (
  token_hash text primary key,
  user_id uuid not null references users(id) on delete cascade,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists sessions_user on sessions(user_id);

-- Configuração oficial (catálogo, preços, taxas, textos). Cada salvamento cria uma versão nova e imutável.
create table if not exists config_versions (
  version int primary key,
  data jsonb not null,
  nota text not null default '',
  created_by uuid references users(id),
  created_at timestamptz not null default now()
);

-- Fotos enviadas pelo administrador (biblioteca de mídia)
create table if not exists fotos (
  id text primary key,
  data text not null,           -- data URL
  meta jsonb not null default '{}',
  created_by uuid references users(id),
  updated_at timestamptz not null default now()
);

-- Alçadas de desconto: autorização formal registrada. Sem linha vigente, o limite é zero.
create table if not exists alcadas (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id),
  pct numeric(5,2) not null check (pct >= 0 and pct <= 100),
  kinds text[],                 -- null = todas as categorias; senão lista de tipos de item (totem, catraca, comanda, servico, plano, adicional, implantacao)
  inicio date not null default current_date,
  fim date,
  condicoes text not null default '',
  aprovado_por uuid not null references users(id),
  aprovado_em timestamptz not null default now(),
  revogada_em timestamptz,
  revogada_por uuid references users(id)
);
create index if not exists alcadas_user on alcadas(user_id);

create table if not exists sequencia (
  id int primary key check (id = 1),
  proximo int not null check (proximo > 0)
);

create table if not exists propostas (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references users(id),
  empresa text not null default 'nextcard',
  status text not null default 'rascunho',   -- rascunho | aguardando_aprovacao | emitida | cancelada
  etapa text not null default 'rascunho',    -- funil comercial (rascunho/enviada/negociacao/ganho/perdido)
  compartilhamento text not null default 'nao_compartilhada', -- nao_compartilhada | iniciado | registrado
  data jsonb not null,                       -- rascunho de trabalho (editável)
  rev int not null default 1,                -- controle de concorrência do rascunho
  seq int unique,
  sufixo text,
  numero text unique,                        -- código comercial DDMMAAAA/SEQ+SUFIXO, fixo após a 1ª emissão
  versao int not null default 0,
  emitida_em timestamptz,
  cliente_nome text not null default '',
  valor_final bigint,
  kommo_lead_id bigint,
  kommo_lead_nome text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists propostas_owner on propostas(owner_id, updated_at desc);

create table if not exists aprovacoes (
  id uuid primary key default gen_random_uuid(),
  proposta_id uuid not null references propostas(id) on delete cascade,
  solicitante uuid not null references users(id),
  pct numeric(7,4) not null,
  motivos jsonb not null default '[]',
  fingerprint text not null,                 -- hash dos itens/preços/condições aprovados
  justificativa text not null default '',
  status text not null default 'pendente',   -- pendente | aprovada | rejeitada
  decidido_por uuid references users(id),
  decidido_em timestamptz,
  resposta text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists aprovacoes_status on aprovacoes(status, created_at desc);

-- Versão emitida: snapshot imutável (dados, itens, preços, política usada, alçada, aprovação) + PDF final.
create table if not exists proposta_versoes (
  id uuid primary key default gen_random_uuid(),
  proposta_id uuid not null references propostas(id),
  versao int not null,
  numero text not null,
  snapshot jsonb not null,
  config_version int not null references config_versions(version),
  valor_final bigint not null,
  desconto_pct numeric(7,4) not null default 0,
  aprovacao_id uuid references aprovacoes(id),
  emitida_por uuid not null references users(id),
  emitida_em timestamptz not null default now(),
  pdf bytea,
  pdf_sha256 text,
  cancelada_em timestamptz,
  unique (proposta_id, versao)
);

create or replace function proposta_versoes_imutavel() returns trigger language plpgsql as $$
begin
  if tg_op = 'DELETE' then raise exception 'versão emitida não pode ser excluída'; end if;
  if new.snapshot is distinct from old.snapshot or new.numero is distinct from old.numero
     or new.versao is distinct from old.versao or new.valor_final is distinct from old.valor_final
     or new.config_version is distinct from old.config_version or new.emitida_em is distinct from old.emitida_em
     or new.desconto_pct is distinct from old.desconto_pct then
    raise exception 'versão emitida é imutável';
  end if;
  if old.pdf is not null and new.pdf is distinct from old.pdf then
    raise exception 'o PDF emitido não pode ser substituído';
  end if;
  return new;
end $$;
drop trigger if exists trg_versoes_imutavel on proposta_versoes;
create trigger trg_versoes_imutavel before update or delete on proposta_versoes
  for each row execute function proposta_versoes_imutavel();

create or replace function config_versions_imutavel() returns trigger language plpgsql as $$
begin raise exception 'versão de configuração publicada é imutável'; end $$;
drop trigger if exists trg_config_imutavel on config_versions;
create trigger trg_config_imutavel before update or delete on config_versions
  for each row execute function config_versions_imutavel();

-- Vínculo do PDF emitido com o negócio no Kommo (fila persistente de sincronização)
create table if not exists kommo_links (
  versao_id uuid primary key references proposta_versoes(id),
  lead_id bigint not null,
  status text not null default 'pendente',   -- pendente | enviado | anexado | falha
  file_uuid text,                            -- reaproveitado em novas tentativas (sem novo upload)
  tentativas int not null default 0,
  erro text,
  anexado_em timestamptz,
  verificado_em timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists settings (
  key text primary key,
  value jsonb not null,
  updated_by uuid references users(id),
  updated_at timestamptz not null default now()
);

-- Importações de dados que estavam no navegador (localStorage) para conferência do administrador
create table if not exists importacoes (
  id uuid primary key default gen_random_uuid(),
  enviado_por uuid not null references users(id),
  origem text not null default '',
  payload jsonb not null,
  status text not null default 'pendente',   -- pendente | aplicada | descartada
  created_at timestamptz not null default now()
);

create table if not exists audit_log (
  id bigserial primary key,
  user_id uuid references users(id),
  acao text not null,
  alvo text not null default '',
  detalhe jsonb not null default '{}',
  at timestamptz not null default now()
);
create index if not exists audit_at on audit_log(at desc);
