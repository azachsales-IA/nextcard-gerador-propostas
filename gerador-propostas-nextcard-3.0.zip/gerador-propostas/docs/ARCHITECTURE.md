# Arquitetura

## Antes (versão recebida)
Aplicativo React de página única em um `index.html`, sem servidor. Configuração, propostas, fotos e numeração ficavam no `localStorage` de cada navegador.

Problemas confirmados na auditoria do código:

| Arquivo | Problema | Efeito |
|---|---|---|
| `src/store.js` (`loadConfig`) | Ao mudar `CONFIG_VERSION`, a configuração salva era trocada pela do código, preservando só consultores e numeração | Taxas e preços alterados sumiam a cada atualização |
| `src/store.js` | `localStorage` por navegador | Alteração de um computador não chegava aos outros |
| `src/model.js` (`emitir`) | Sequência lida de `cfg.proximoNumero` local | Dois computadores geravam o mesmo número |
| `src/ui/Pronta.jsx` | Proposta emitida redesenhada com a configuração atual | Documento antigo mudava quando a tabela mudava |
| `src/ui/Pronta.jsx` (`enviar`) | Marcava "enviada" ao abrir o WhatsApp | Status sem confirmação |
| `src/ui/Config.jsx` | Qualquer pessoa editava catálogo, taxas e numeração | Sem controle de acesso |
| `src/ui/Cards.jsx` | Serviço em "cortesia", item livre e total do "simulador" sem conferência | Desconto sem autorização |

## Agora
```
Navegador (dist/index.html, React)
   │  fetch /api/*  (cookie de sessão HttpOnly + cabeçalho x-nx)
   ▼
api/index.js  →  server/app.js   rotas, permissões, transações
                 server/policy.js preço oficial, desconto, alçada, numeração (funções puras)
                 server/auth.js   senha (scrypt), sessão, bloqueio por tentativas
                 server/kommo.js  cliente Kommo (token só aqui)
                 server/db.js     PostgreSQL (pg), migrações
   ▼
PostgreSQL (Supabase, Neon ou equivalente)   db/migrations/001_init.sql
```
Hospedagem: Vercel. O front continua um único HTML estático; a API é uma função serverless (`vercel.json` reescreve `/api/*`).

### Decisões
1. **PostgreSQL acessado por `DATABASE_URL`**, sem SDK de fornecedor. Funciona em Supabase, Neon ou Vercel Postgres e é testável localmente. Uma dependência nova (`pg`).
2. **Autenticação própria** (e-mail e senha, scrypt, sessão em tabela, cookie HttpOnly). Equipe pequena, sem necessidade de provedor externo. Trocar por SSO depois não muda o restante.
3. **Configuração como documento JSON versionado** (`config_versions`), não em dezenas de tabelas. Preserva o formato que o motor de cálculo e a renderização já usam, dá histórico e snapshot de graça. Custo: relatórios por produto exigem ler JSON. Normalizar é possível depois, sem quebrar propostas emitidas.
4. **PDF emitido guardado no banco** (`bytea`, até 4,3 MB por causa do limite de corpo da Vercel). Volume esperado baixo. Se crescer, mover para armazenamento de objetos mantendo o hash.
5. **Modo local** (`NX_MODE=local`) só para harness e teste visual antigo. Não é publicado.

### Tabelas
`users`, `sessions`, `config_versions` (imutável), `fotos`, `alcadas`, `sequencia`, `propostas` (rascunho de trabalho), `proposta_versoes` (snapshot imutável + PDF), `aprovacoes`, `kommo_links` (fila de sincronização), `importacoes`, `settings`, `audit_log`.

### Papéis
| Papel | Pode |
|---|---|
| `owner` | Catálogo, preços, taxas, textos, fotos, usuários, numeração, importações |
| `aprovador` | Conceder e revogar alçadas, decidir exceções, emitir com desconto próprio, ver todas as propostas |
| `gestor` | Ver propostas da equipe e painel |
| `consultor` | Criar, emitir, anexar e consultar as próprias propostas |

Uma pessoa pode acumular papéis. O proprietário sem papel de aprovador não concede desconto; o aprovador sem papel de proprietário não edita catálogo nem taxa.

### Emissão (uma transação)
1. Trava a proposta. 2. Lê a configuração vigente. 3. Recalcula cada linha contra o catálogo oficial. 4. Calcula desconto efetivo e confere alçada ou aprovação (pela impressão digital dos itens, preços e condições). 5. Reserva o número (`update sequencia ... returning`). 6. Grava o snapshot. Qualquer falha desfaz tudo, inclusive o número.

### Segurança
- Sessão em cookie `HttpOnly`, `SameSite=Lax`, `Secure` em produção. Escrita exige cabeçalho `x-nx` (bloqueia formulário de outro site).
- Consultor não lê proposta de outro (resposta 404, sem revelar existência).
- 8 senhas erradas bloqueiam a conta por 15 minutos.
- Segredos só em variáveis de ambiente. Nenhum `.env` no repositório.
- Trilha de auditoria: publicações de configuração (com o que mudou), alçadas, aprovações, emissões, falhas do Kommo, acessos negados.
