# Integração Kommo

## Situação
Implementada no servidor e testada contra um Kommo simulado. **Não foi validada na documentação oficial nem em conta real**: o ambiente de desenvolvimento não tinha acesso a `developers.kommo.com`. Não ativar em produção antes do roteiro de homologação abaixo.

## O que o sistema faz
1. No passo Cliente, o consultor busca o negócio (nome, empresa, telefone, e-mail ou número). Com mais de um resultado, ele escolhe. Nada é escolhido sozinho.
2. Os dados do contato completam só os campos vazios da proposta. Nada é gravado no CRM.
3. Na emissão, o PDF é guardado no servidor. Em seguida o servidor envia o arquivo ao Kommo, associa ao negócio e consulta os arquivos do negócio para confirmar.
4. A tela só mostra "Proposta emitida e anexada ao Kommo" depois dessa confirmação, com código, negócio, data, responsável e link.
5. O cliente não recebe nada automaticamente. O negócio não muda de etapa.

## Garantias testadas (com o simulador)
- Repetir a chamada depois de anexado não envia nem anexa de novo.
- Falha na associação depois do upload: a nova tentativa reaproveita o arquivo já enviado.
- Falha de integração não altera número, versão nem PDF.
- Uma versão já anexada a um negócio não é anexada a outro em silêncio.
- Token inválido vira mensagem clara, sem expor o token.
- Consultor não anexa proposta de outro consultor.

## Chamadas a validar (`server/kommo.js`, marcadas `[VALIDAR]`)
| Passo | Chamada assumida |
|---|---|
| Domínio de arquivos | `GET /api/v4/account?with=drive_url` → `drive_url` |
| Sessão de upload | `POST {drive_url}/v1.0/sessions` com `file_name`, `file_size`, `content_type` → `upload_url`, `max_part_size` |
| Envio | `POST upload_url` com o binário em partes → `next_url` ou `uuid` final |
| Associação | `PUT /api/v4/leads/{id}/files` com `[{ "file_uuid": "..." }]` |
| Confirmação | `GET /api/v4/leads/{id}/files` → `_embedded.files[].file_uuid` |
| Busca | `GET /api/v4/leads?query=...&with=contacts` (204 quando vazio) |
| Apoio | `GET /api/v4/leads/pipelines`, `/api/v4/users`, `/api/v4/contacts/{id}`, `/api/v4/companies/{id}` |

Pontos a confirmar na documentação: nomes exatos dos campos, se o upload exige cabeçalhos próprios, escopo de arquivos na integração, limites de requisição, busca por CNPJ (depende de campo personalizado).

## Configuração
Variáveis no servidor (nunca no navegador):
- `KOMMO_SUBDOMAIN` — subdomínio da conta (`https://SUBDOMINIO.kommo.com`).
- `KOMMO_TOKEN` — token de longa duração de uma integração privada com acesso a negócios, contatos e arquivos.

Sem essas variáveis o sistema funciona normalmente e mostra "Kommo não configurado".

## Roteiro de homologação (negócio de teste, nunca um real)
1. Criar no Kommo um negócio "TESTE GERADOR" com um contato.
2. Configurar as variáveis no ambiente de homologação.
3. Buscar o negócio pelo nome e pelo número. Conferir pipeline, etapa e responsável.
4. Emitir uma proposta. Conferir o PDF na aba Mídia do negócio (onde hoje ficam os orçamentos enviados à mão).
5. Clicar de novo em anexar: não pode duplicar.
6. Trocar o token por um inválido: a tela deve mostrar a falha e permitir nova tentativa depois de corrigir.
7. Registrar o resultado e remover as marcas `[VALIDAR]` conferidas.
