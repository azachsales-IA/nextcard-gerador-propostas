# Implantação, migração e rollback

## Pré-requisitos (decisões e acessos que só a NEXTCARD tem)
1. Banco PostgreSQL (Supabase, Neon ou Vercel Postgres) e a `DATABASE_URL`.
2. Acesso ao projeto na Vercel.
3. E-mail e nome do proprietário administrativo; se Hamilton acumula o papel de aprovador.
4. Próximo número de proposta (conferir o último realmente usado).
5. Credenciais Kommo (opcional nesta etapa).

## Passo a passo
A produção atual não é tocada até o passo 6.

1. **Cópia de segurança do que existe hoje.** Em cada computador que usa a versão atual: Configuração → Backup JSON → exportar configuração e propostas. Guardar os arquivos. Os dados antigos continuam no navegador; nada é apagado.
2. **Banco.** Criar o banco e rodar:
```bash
DATABASE_URL="postgres://..." OWNER_EMAIL="..." OWNER_NOME="..." OWNER_SENHA="..." OWNER_SIGLA="HF" OWNER_APROVADOR=1 SEQ_INICIAL=1276 node scripts/setup.mjs
```
   O script aplica as migrações, publica a configuração inicial como versão 1, cria o proprietário e define a numeração. Rodar de novo não sobrescreve nada. `OWNER_APROVADOR=1` só se a mesma pessoa for a autoridade comercial. `SEQ_INICIAL` é o próximo número, nunca um já usado.
3. **Ambiente de homologação na Vercel** (deploy de prévia, não o de produção). Variáveis: `DATABASE_URL`, `NODE_ENV=production`, e depois `KOMMO_SUBDOMAIN` e `KOMMO_TOKEN`.
4. **Validar a configuração inicial.** O proprietário confere preços e taxas contra as tabelas vigentes e corrige o que for preciso em Configuração. A configuração inicial vem do código recebido, não de uma política aprovada.
5. **Importar o que estava nos navegadores.** Cada pessoa entra na versão nova no seu computador e clica em "Enviar ao servidor" no aviso da tela inicial. Propostas viram rascunhos da própria pessoa (com o número antigo anotado). A configuração local vai para Administração → Importar dados antigos, onde o proprietário compara com a oficial e decide. Configurações diferentes entre computadores não são mescladas automaticamente.
   Observação: o aviso só aparece no mesmo endereço em que a versão antiga era usada, porque o navegador separa os dados por endereço. Se a versão nova ficar em outro endereço, usar os arquivos exportados no passo 1: propostas em Configuração → Minha conta → Importar arquivo de propostas; configuração em Configuração → Exportar e pendências → Importar configuração (só o proprietário; entra no editor e vale depois de salvar).
6. **Homologação** (cenários de `docs/QA_CHECKLIST.md`) e só então promover para produção.
7. **Usuários e alçadas.** Criar as contas, definir sufixos e registrar as alçadas aprovadas.

## Rollback
- **Aplicação:** na Vercel, promover o deploy anterior (Deployments → Promote). A versão antiga volta a funcionar com os dados que continuam no navegador de cada pessoa.
- **Banco:** nenhuma migração apaga dados. Para voltar a configuração, o proprietário abre a versão anterior (o histórico guarda todas) e publica de novo como versão nova. Versões emitidas nunca são alteradas.
- **Cópia do banco:** ativar backup diário do provedor. Cópia manual: `pg_dump "$DATABASE_URL" > backup.sql`.
- Propostas emitidas na versão nova não existem na antiga. Em caso de rollback, baixar os PDFs antes.

## Variáveis de ambiente
| Variável | Obrigatória | Uso |
|---|---|---|
| `DATABASE_URL` | Sim | Conexão PostgreSQL |
| `NODE_ENV=production` | Sim | Cookie de sessão só em HTTPS |
| `KOMMO_SUBDOMAIN`, `KOMMO_TOKEN` | Não | Integração Kommo |
| `PG_POOL_MAX` | Não | Conexões por função (padrão 3) |

## Limitações conhecidas
- PDF emitido acima de 4,3 MB não é aceito pela função da Vercel. O sistema gera de novo em resolução menor quando passa de 4,2 MB.
- Sem recuperação de senha por e-mail: o proprietário redefine a senha do usuário.
- Fotos enviadas pelo administrador não são versionadas. O PDF guardado garante o documento emitido; a prévia redesenhada de uma proposta antiga pode mostrar a foto atual.
