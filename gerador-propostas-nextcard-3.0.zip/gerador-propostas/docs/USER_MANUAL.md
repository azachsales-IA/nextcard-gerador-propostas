# Manual do consultor

Versão 3.0, estado de 12/11/2026. As telas abaixo são capturas reais do sistema em ambiente de teste.

## 1. Entrar
Abra o endereço do sistema e entre com seu e-mail e senha. A conta é criada pelo administrador. Depois de 8 senhas erradas a conta fica bloqueada por 15 minutos.

![Tela de entrada](img/01-login.png)

No canto inferior do menu aparecem seu nome, o sufixo do seu número de proposta e a sua alçada de desconto. Para trocar a senha ou sair: Configuração → Minha conta.

## 2. Criar a proposta
1. Clique em **Nova proposta** e escolha o tipo (totem, catracas e comandas, comandas, projeto sob medida ou Teloos).
2. **Cliente.** Se a integração com o Kommo estiver ativa, busque o negócio por nome, empresa, telefone, e-mail ou número. Se o cliente tiver mais de um negócio, escolha o certo. Os dados do contato preenchem os campos vazios; você pode completar à mão. Nada é alterado no Kommo.

![Busca do negócio no Kommo](img/05-kommo-busca.png)

3. **Solução.** Adicione, remova e ajuste quantidades. Para totens, escolha os opcionais. O preço vem da tabela oficial.
4. **Condições.** Escolha as formas de pagamento, a validade, o frete e as observações.

O rascunho é salvo no servidor enquanto você edita. O indicador "salvo hh:mm" só aparece depois que o servidor confirma.

## 3. Desconto e alçada
Você pode reduzir o valor unitário de um item. O resumo lateral mostra o total de tabela, o desconto em percentual e em reais, a sua alçada e o saldo.
- Dentro da alçada: a proposta é emitida normalmente e o desconto fica registrado.
- Acima da alçada (ou sem alçada, que equivale a zero): a emissão é bloqueada. Nenhum número é usado e o rascunho fica salvo.
- Também pedem aprovação: item livre (fora do catálogo), serviço em cortesia e condição de pagamento com total abaixo do valor à vista.

## 4. Pedir aprovação
Na tela de bloqueio, escreva a justificativa e clique em **Solicitar aprovação**. Acompanhe em **Aprovações**. Depois de aprovada, abra a proposta e clique em **Gerar proposta**. A aprovação vale só para aquela proposta, exatamente como foi enviada: se mudar item, preço ou condição, é preciso pedir de novo.

![Pedido de aprovação](img/10-pedido-aprovacao.png)

## 5. Emitir
Clique em **Gerar proposta**. O servidor confere tudo de novo e atribui o número no padrão `DDMMAAAA/sequência+sufixo` (exemplo: `11112026/1276AL`). O número não muda mais. Se você editar e gerar de novo, a proposta vira versão 2 com o mesmo número; a versão anterior continua guardada.

## 6. Kommo
Com um negócio vinculado, o PDF é anexado sozinho logo depois da emissão. A tela mostra **Proposta emitida e anexada ao Kommo** só depois que o Kommo confirma. Se falhar, aparece o motivo e o botão **Tentar novamente**; a proposta, o número e o PDF ficam preservados e o arquivo não é duplicado.

![Proposta anexada](img/08-kommo-anexado.png)

Anexar ao Kommo não envia nada ao cliente e não muda a etapa do negócio.

## 7. Compartilhar
- **Enviar pelo WhatsApp** abre a conversa com a mensagem pronta (editável). No computador, a imagem é copiada para colar; no celular, abre o compartilhamento com imagem e PDF.
- **PDF completo** baixa o arquivo oficial guardado na emissão.
- Abrir o WhatsApp não marca a proposta como enviada. Quando confirmar que o cliente recebeu, marque a situação como **Enviada**.

## 8. Propostas antigas
Em **Propostas**, busque por cliente ou número. Uma proposta emitida abre exatamente com os preços e condições da data da emissão, mesmo que a tabela tenha mudado. Com mais de uma versão, use "ver as versões emitidas" para baixar cada PDF.

Excluir um rascunho apaga o rascunho. Excluir uma proposta emitida apenas cancela: o número e os documentos ficam no histórico.

## 9. Problemas comuns
| Situação | O que fazer |
|---|---|
| "Rascunho ainda não salvo no servidor" | Verifique a internet. A próxima alteração tenta de novo. Não feche a aba enquanto o aviso aparecer |
| "Esta condição precisa de aprovação" | Ajuste os valores ou solicite aprovação |
| "A numeração ainda não foi configurada" | Avise o administrador |
| "Falha ao anexar ao Kommo" | Clique em Tentar novamente. Persistindo, avise o administrador (token ou permissão) |
| "Tabela e condições atualizadas pela administração" | A tabela mudou enquanto você trabalhava. Confira os valores antes de emitir |
| Sessão terminou | Entre de novo. O rascunho salvo continua na lista |
