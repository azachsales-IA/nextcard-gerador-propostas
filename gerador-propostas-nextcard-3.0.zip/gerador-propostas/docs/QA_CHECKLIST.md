# Testes e homologação

## Automatizados
| Suíte | Comando | Cobertura | Resultado em 12/11/2026 |
|---|---|---|---|
| Núcleo de cálculo | `node build/test_core.mjs` | Parcelas, arredondamento, totens, comandas, validade | Todos passaram |
| API | `TEST_DATABASE_URL=... node --test tests/server/*.test.mjs` | Sessão, persistência, conflito, permissões, numeração simultânea, alçada, tentativas de burla, aprovação, isolamento, PDF, Kommo simulado, usuários, auditoria | 15 de 15 |
| Navegador | `TEST_DATABASE_URL=... node tests/e2e_corporativo.mjs` | Login, taxa e preço persistidos, emissão, número, Kommo (falha e nova tentativa), alçada, aprovação, celular, histórico | 32 de 32 |
| Visual antigo | `NX_MODE=local node build/build.mjs && python3 tests/e2e_smoke.py` | Fluxo e layout no modo sem servidor | 0 falhas |

Não testado: Kommo real, deploy na Vercel, banco gerenciado (Supabase ou Neon), navegadores além do Chromium.

## Homologação com Hamilton
| # | Cenário | Coberto por teste automático | Falta validar com a NEXTCARD |
|---|---|---|---|
| 1 | Taxa de cartão persiste, vale para outro consultor | Sim | Em produção |
| 2 | Preço de periférico novo nas próximas, antigo preservado | Sim (serviço de instalação) | Com um opcional de totem |
| 3 | Alçada dentro e acima do limite | Sim | Valores reais de alçada |
| 4 | Duas emissões simultâneas, números únicos | Sim (12 simultâneas) | Sufixo e número inicial |
| 5 | PDF anexado ao negócio no Kommo | Só com simulador | Conta real, negócio de teste |
| 6 | Proposta visualmente premium | Não (fase visual não iniciada) | — |
| 7 | Consultor usa só o manual | Não | Com um consultor |
| 8 | Atualização preserva preços, taxas, alçadas, propostas | Sim (dados no banco, não no navegador) | Após o primeiro deploy seguinte |
