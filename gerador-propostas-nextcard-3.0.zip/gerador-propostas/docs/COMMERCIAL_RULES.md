# Regras comerciais: fontes, o que o sistema aplica e o que aguarda aprovação

## Matriz de fontes (pasta Vendas.IA, lida em 12/11/2026)
| Fonte | Uso | Situação |
|---|---|---|
| Política Comercial de Pagamento V2_2026 (PDF) | Regra de pagamento, desconto e validade | Lida na íntegra. A cópia do Drive está sem data no campo de aprovação |
| Tabela Totem V7_2026 (xlsm) | Preço de totens | Já embutida no catálogo do sistema; não reconferida nesta etapa |
| Tabela Produtos Tecnibra V1_2026 (PDF) | Preço de catracas | Já embutida; não reconferida |
| Tabelas de comandas V1 2025 (cliente final e parceiros) | Preço por faixa | Já embutida; confirmar vigência (é de 2025) |
| Planos 2026 Teloos (xlsx) | Planos e adicionais | Já embutida; duas abas com preços diferentes |
| Propostas 1208H (totem) e 1217H (catracas) | Referência de apresentação | Não são política |
| Manual da marca Nextbe, playbook, apresentações, fotos em fundo branco, banners | Identidade e mídia | Não processados nesta etapa (fase visual) |

Não reconferido linha a linha contra as planilhas nesta etapa: o catálogo do sistema veio do código recebido. A configuração inicial precisa ser validada pelo administrador antes do uso (ver `docs/DEPLOY.md`).

## O que o sistema aplica hoje
- Preço de tabela recalculado no servidor a cada emissão.
- Desconto efetivo = soma das diferenças abaixo da tabela ÷ total de tabela dos itens de catálogo. Frete e itens livres ficam fora da base. Cortesia de serviço e cupom Teloos contam como desconto.
- Sem alçada vigente, limite zero. Acima do limite, a emissão é bloqueada e o consultor pode pedir aprovação.
- Item livre (fora do catálogo) sempre pede aprovação.
- Nenhuma condição de pagamento pode ter total abaixo do valor à vista.
- Fator de condição abaixo de 1 é recusado na configuração (seria desconto).
- Validade contada da emissão, com as opções já existentes (2, 3 ou 5 dias úteis, ou 7 corridos).

## Conflitos e lacunas que exigem decisão (nada foi corrigido em silêncio)
| # | Tema | O que diz a política | O que existe hoje | Decisão necessária | Dono |
|---|---|---|---|---|---|
| 1 | Faixas de boleto | Até 2.000,00 / de 2.001,00 a 3.999,00 / a partir de 4.000,00 | Não aplicado por faixa | Como tratar 2.000,01 a 2.000,99 e 3.999,01 a 3.999,99 | Financeiro |
| 2 | Faixas de cartão | Até 3.000,00 / de 3.001,00 a 4.999,00 / a partir de 5.000,00 | Não aplicado por faixa | Como tratar 3.000,01 a 3.000,99 e 4.999,01 a 4.999,99 | Financeiro |
| 3 | Prazos de boleto | 7/21, 7/21/42, 21/42/63 dias. Exemplo da seção 6 usa "saldo em 21 dias" e "21/42" | Condições 28 e 28/56 dias, tiradas das propostas 1208H e 1217H | Quais prazos valem | Financeiro |
| 4 | Simulador de pagamentos | Uso obrigatório | Fatores 1,025 / 1,051 / 1,077 foram deduzidos de propostas antigas. Cartão 1x, 3x, 12x e boleto 21/42/63 estão sem fator | Enviar o simulador oficial (fórmula ou tabela de fatores) | Financeiro |
| 5 | Desconto | Proibido sem autorização prévia da Diretoria Comercial | Alçada registrada no sistema com aprovador, data e vigência | Confirmar que a alçada registrada vale como autorização formal | Hamilton |
| 6 | Quem concede desconto | Diretoria Comercial | Só o papel Aprovador | Confirmar se Hamilton acumula Proprietário e Aprovador | Hamilton |
| 7 | 3x sem juros | "Dica comercial", fora da proposta formal | Consultor pode informar o total do cartão igual ao à vista (nunca abaixo) | Manter livre, limitar a 3x ou exigir aprovação | Hamilton |
| 8 | Primeira compra, recorrente (180 dias), inadimplência | Regras diferentes por perfil | Não aplicado: o sistema não tem o histórico financeiro do cliente | Fonte do dado (Omie ou campo informado) e regra de fronteira dos 180 dias | Financeiro |
| 9 | Validade | 7 dias corridos a partir do envio | Conta da emissão; oferece também dias úteis (decisão de 29/09) | Qual regra vale e a partir de qual data | Hamilton |
| 10 | Numeração | Padrão 10112026/1275HF | Sequência central, sufixo por usuário | Próximo número real e regra do sufixo (HF ou H; propostas antigas usam "H") | Hamilton |
| 11 | Revenda | 6% sobre totens na tabela de parceiros | Consultor escolhe a modalidade | Quem pode usar a modalidade Revenda e se vale para catracas e comandas | Hamilton |
| 12 | Teloos | Fora da política V2 | Cupom 5% e 10% e descontos por periodicidade na configuração | Confirmar se cupom Teloos também exige alçada (hoje exige) | Hamilton |
| 13 | Preços divergentes | Tabelas oficiais | Proposta 1217H usa preços diferentes da Tecnibra V1/2026; 1208H não bate com a V7 | Confirmar tabela vigente | Hamilton |

As pendências que já estavam no código (frete, feriados, serviços por região, TEF Teloos) continuam listadas em Configuração → Exportar e pendências.

## Fora do escopo entregue (regras ainda não implementadas)
Campanhas e Black Friday, alçada por campanha ou condição de pagamento, política em fluxo rascunho → revisão → aprovação, perfil de cliente, comparação de soluções.
