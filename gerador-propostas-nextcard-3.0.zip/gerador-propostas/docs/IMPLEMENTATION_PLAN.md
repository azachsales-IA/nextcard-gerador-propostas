# Plano de implementação e estado

Atualizado em 12/11/2026. Regras: `COMMERCIAL_RULES.md`. Arquitetura: `ARCHITECTURE.md`.

## Entregue e testado (P0)
| Item | Onde |
|---|---|
| Persistência central (configuração, fotos, propostas, usuários, alçadas) | `server/`, `db/migrations/001_init.sql` |
| Fim da restauração de preços e taxas em atualização | Configuração no banco, versionada; `CONFIG_VERSION` não apaga mais nada no modo servidor |
| Estados de salvamento (não salvo, salvando, salvo, falha, conflito) e proteção ao fechar a aba | `src/ui/App.jsx`, `BarraSalvar` |
| Autenticação individual e permissões no servidor | `server/auth.js`, `server/app.js` |
| Acesso administrativo exclusivo ao catálogo, taxas, usuários e numeração | Papel `owner` |
| Alçadas por consultor, categoria e vigência; limite padrão zero | `alcadas`, Administração → Alçadas |
| Bloqueio acima da alçada, pedido e decisão de exceção | `aprovacoes`, tela Aprovações |
| Proteção contra burla (preço de tabela adulterado, item negativo, cortesia, soma de descontos, condição abaixo do à vista, item livre) | `server/policy.js` |
| Numeração `DDMMAAAA/SEQ+SUFIXO` atômica e central | `sequencia`, rota de emissão |
| Snapshot imutável por versão e PDF guardado | `proposta_versoes` (gatilho no banco) |
| Proposta antiga desenhada com a configuração da época | `src/ui/Pronta.jsx` |
| "Enviada" não é mais marcada ao abrir o WhatsApp | `src/ui/Pronta.jsx` |
| Kommo: busca, escolha do negócio, upload, associação, confirmação, nova tentativa sem duplicar | `server/kommo.js` (pendente de validação real) |
| Importação dos dados que estavam nos navegadores, com comparação | Administração → Importar dados antigos |
| Auditoria com o que mudou em cada publicação | `audit_log` |
| Painel gerencial básico | Administração → Painel |
| Manuais e guia de implantação | `docs/` |

## Não entregue
| Prioridade | Item | Observação |
|---|---|---|
| P0 | Validação do Kommo em conta real | Depende de acesso à documentação e de um negócio de teste |
| P0 | Deploy (banco gerenciado + Vercel) | Depende de credenciais |
| P0 | Regras de pagamento por perfil de cliente e por faixa de valor | Depende das decisões 1 a 4 e 8 de `COMMERCIAL_RULES.md` |
| P0 | Manual em PDF | Conteúdo pronto em Markdown; gerar o PDF depois da homologação, com as telas finais |
| P1 | Redesign Liquid Glass e Design System | Não iniciado. Só as telas novas seguem o visual atual |
| P1 | Novo PDF (Express e Consultiva), capa, card de investimento | Não iniciado. A renderização atual foi preservada |
| P1 | Biblioteca de mídia e fotos 4K do Drive | Não iniciado. Fotos atuais são as embutidas no código |
| P1 | Exportação vetorial do PDF e novos formatos de imagem | Hoje o PDF é composto por páginas em imagem |
| P1 | Cadastro completo de produto (SKU, código Omie, especificações, desativação) | Hoje edita preços, nomes e fotos dos produtos existentes |
| P2 | Campanhas e Black Friday, templates oficiais, comparação de soluções | Não iniciado |
| P2 | Fluxo de política rascunho → revisão → aprovação | Hoje: publicação direta pelo proprietário, com histórico |
| P2 | Recuperação de senha por e-mail, SSO | Não iniciado |

## Próxima etapa sugerida
1. Decisões pendentes e credenciais (lista em `COMMERCIAL_RULES.md` e `DEPLOY.md`).
2. Homologação em ambiente de prévia e validação real do Kommo.
3. Fase visual: Design System, depois os dois modelos de proposta, depois a biblioteca de mídia.
