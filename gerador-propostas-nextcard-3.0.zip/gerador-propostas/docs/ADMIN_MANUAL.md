# Manual do administrador

Versão 3.0, estado de 12/11/2026. Capturas reais em ambiente de teste. Implantação e rollback: `DEPLOY.md`.

## Papéis
- **Proprietário**: catálogo, preços, taxas, textos, fotos, usuários, numeração, importações.
- **Aprovador** (autoridade comercial): alçadas e exceções.
- **Gestor**: acompanha propostas da equipe e o painel.
- **Consultor**: cria e emite as próprias propostas.

## 1. Usuários
Administração → Usuários → Novo usuário. Informe nome, e-mail, senha inicial (10 caracteres ou mais, com letras e números), sufixo do número (até 3 letras) e papéis. Para redefinir a senha, edite o usuário e preencha "Nova senha". Desativar um usuário encerra as sessões dele na hora. O sistema não deixa ficar sem proprietário ativo.

![Usuários](img/15-usuarios.png)

## 2. Preços, produtos e taxas
Configuração (só o proprietário vê as abas de edição):
- **Condições**: fator de cada forma de pagamento, parcelas, entrada padrão. Fator 1,0825 significa 8,25% de acréscimo sobre o valor à vista. Fator abaixo de 1 é recusado.
- **Catálogo e preços**: base dos totens e valor de cada opcional (sistema, pinpad, leitor, impressora, adesivagem), catracas, faixas de comandas, serviços.
- **Fotos dos produtos**, **Textos**, **Empresa**.

Ao alterar qualquer campo aparece a barra **Alterações não salvas**. Nada vale para a equipe até clicar em **Salvar alterações** e a barra mostrar **Salvo com sucesso**. Cada salvamento cria uma versão nova da configuração; as anteriores ficam guardadas e as propostas já emitidas não mudam.

![Alteração não salva](img/03-config-nao-salvo.png)

Se duas pessoas editarem ao mesmo tempo, quem salvar depois recebe o aviso de conflito e precisa recarregar. Fechar a aba com alteração pendente pede confirmação.

Criar produto novo de totem ou catraca, desativar produto e categorias novas ainda não têm tela própria (ver plano de implementação).

## 3. Alçadas de desconto
Administração → Alçadas de desconto (papel Aprovador). Escolha o consultor, o limite em percentual, a vigência, as categorias (nenhuma marcada vale para todas) e as condições. Cada registro guarda quem aprovou e quando. Sem alçada vigente o limite é zero. Para encerrar antes do prazo, clique em Revogar.

![Alçadas](img/12-alcadas.png)

O limite é comparado ao desconto efetivo total da proposta sobre a tabela dos itens de catálogo. Frete e itens livres não entram na base.

## 4. Aprovações
Em **Aprovações** aparecem os pedidos com cliente, consultor, motivo, percentual e justificativa. Abra a proposta para conferir, depois aprove ou recuse (a recusa exige motivo). A aprovação vale só para aquela proposta, com exatamente aqueles itens, preços e condições.

![Aprovações](img/11-aprovacoes.png)

## 5. Numeração
Administração → Numeração. Informe o próximo número antes do primeiro uso; sem isso a emissão fica bloqueada. O sistema não aceita voltar para um número já usado. O sufixo vem do cadastro de cada usuário.

## 6. Kommo
Depende das variáveis `KOMMO_SUBDOMAIN` e `KOMMO_TOKEN` no servidor (ver `KOMMO_INTEGRATION.md`). Falhas aparecem no painel (contagem) e no histórico (motivo).

## 7. Dados da versão anterior
Administração → Importar dados antigos lista as configurações enviadas pelos navegadores da equipe. **Comparar** mostra, item a item, o que difere da configuração oficial. **Carregar no editor** traz os valores para a tela de Configuração como alteração não salva: revise e salve para publicar. Nada é aplicado automaticamente.

## 8. Histórico e auditoria
Administração → Histórico de alterações mostra quem publicou cada versão da configuração e o que mudou (campo, antes, depois), além de alçadas, aprovações, emissões, falhas do Kommo e acessos negados.

![Histórico](img/14-historico.png)

## 9. Backup e recuperação
- Ative o backup automático do provedor do banco.
- Configuração → Exportar e pendências → Exportar configuração gera uma cópia em arquivo.
- Para voltar a uma configuração anterior: importe o arquivo exportado (ou use Importar dados antigos), revise e salve. Isso cria uma versão nova; o histórico é preservado.

## 10. Erros
| Mensagem | Causa provável | Ação |
|---|---|---|
| Falha ao salvar: fator abaixo de 1 | Fator digitado como desconto | Corrigir o fator |
| Conflito de atualização | Outra sessão salvou antes | Recarregar e refazer a alteração |
| Configuração oficial ainda não publicada | Banco sem a versão inicial | Rodar `scripts/setup.mjs` |
| Kommo recusou o token (401) | Token vencido ou revogado | Gerar novo token e atualizar a variável |
