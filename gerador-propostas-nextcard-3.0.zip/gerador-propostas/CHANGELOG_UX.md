# CHANGELOG de UX · rodada 1

Base: código-fonte v2 (NX-2026.09-v2). Diagnóstico completo em `UX_AUDIT.md`.
Um commit por item. As capturas "antes" e "depois" estão em `tests/out/rodada1/auditoria/` e os pares lado a lado em `tests/out/rodada1/comparativo/`.

Nenhum preço, fator, texto comercial, prazo, garantia, compatibilidade nem mapeamento de fotos foi alterado: `src/catalog.json` e `src/defaults.js` estão idênticos à base (`git diff` vazio, mesmo SHA-256). Nenhum cálculo em `src/core.js` ou `src/model.js` mudou, e `src/render.js` (imagem e PDF) não foi tocado.

---

## 0. Build: `harness.mjs` cria a pasta `harness/`
- **Problema:** o zip veio sem a pasta `harness/`, e `node build/harness.mjs` falhava com `ENOENT`. Sem isso não dava para rodar `tests/pecas_fontes.py`.
- **Arquivos:** `build/harness.mjs`.
- **Como testar:** apague `harness/` e rode `node build/harness.mjs`.

## 1. Celular: adicionais Teloos cabem na tela (P1, severidade alta)
- **Problema:** no passo "Solução" da Teloos, a grade de adicionais usava `1fr` (que não encolhe abaixo do conteúdo) com o nome em uma linha só. A página ficava com 493 px de largura numa tela de 390 px, o botão "Adicionar" ficava cortado fora do cartão e o "Continuar" da barra fixa saía da tela. A busca de adicionais também tinha o ícone quebrado para cima do campo.
- **Arquivos:** `src/styles.css`, `tests/e2e_smoke.py`.
- **Como testar:** no celular (390 px), escolha Sistema Teloos → Continuar. A página não rola para o lado e "Adicionar" funciona com um toque.
- **Novas verificações no e2e:** "celular: solução Teloos sem rolagem horizontal" e "celular: adicional Teloos entra com um toque".

## 2. Condições: aviso quando falta o total do simulador (P3, severidade alta)
- **Problema:** uma condição sem fator (cartão 1x, 3x, 12x, boleto 21/42/63) marcada, ou com estrela, e sem o total do simulador saía da imagem e do PDF sem aviso. A estrela passava para outra condição sem o consultor perceber.
- **O que mudou:**
  - a linha da condição mostra "Falta o total do simulador. Sem ele, esta condição não aparece na imagem nem no PDF (e a imagem vai destacar outra condição)";
  - o resumo lateral lista a pendência com atalho para o campo;
  - no celular, a barra fixa mostra "1 condição sem valor", que leva ao campo.
- **O que não mudou:** "Gerar proposta" continua sempre liberado e nenhum cálculo foi alterado.
- **Arquivos:** `src/ui/Builder.jsx`, `src/styles.css`, `tests/e2e_smoke.py`.
- **Como testar:** Catracas → Condições → marque "Cartão de crédito até 12x" e a estrela. O aviso aparece. Informe um total e o aviso some.
- **Novas verificações no e2e:** "condição sem valor do simulador avisada na linha e no resumo" e "aviso some ao informar o total do simulador".

## 3. Propostas: aviso e troca de marca quando a busca acha proposta da outra marca (P4, severidade alta)
- **Problema:** a lista e o quadro mostram só a marca do topo. Buscar um cliente Teloos com NEXTCARD selecionada resultava em "Nenhuma proposta encontrada".
- **O que mudou:** uma faixa informa "1 proposta Teloos também corresponde a 'Modelo'". O botão "Ver Teloos" (ou "Ver NEXTCARD") troca a marca mantendo a busca. Sem busca, a faixa indica quantas propostas existem na outra marca.
- **Arquivos:** `src/ui/Screens.jsx`, `src/ui/App.jsx`, `src/styles.css`, `tests/e2e_smoke.py`.
- **Como testar:** crie uma proposta Teloos, volte para NEXTCARD → Propostas → busque o cliente.
- **Novas verificações no e2e:** "busca avisa que há proposta na outra marca" e "troca para Teloos mantendo a busca".

## 4. Celular: cartão de item mais compacto (P2, severidade média)
- **Problema:** o título do item quebrava em 3 linhas e a especificação em até 5, porque os botões de ação tomavam a largura do título. O cabeçalho do cartão tinha de 237 a 337 px.
- **O que mudou:**
  - ações empilhadas numa coluna estreita e miniatura menor;
  - especificação limitada a 2 linhas com o cartão fechado (completa ao abrir);
  - total numa linha só;
  - margem interna menor nos cartões de passo.
- **Arquivos:** `src/styles.css`, `tests/e2e_smoke.py`.
- **Como testar:** Catracas → Solução, no celular. Os títulos ficam em até 2 linhas.
- **Nova verificação no e2e:** "celular: título do cartão de item em até 2 linhas".

## 5. Avisos (toasts): fechar, tempo por tipo e versão compacta no celular (P5, severidade média)
- **Problema:** os avisos cobriam cartões e botões, não tinham botão de fechar, e os alertas sumiam em 4,2 s.
- **O que mudou:**
  - botão "Fechar aviso" (44 px no celular);
  - duração por tipo: confirmação 3,5 s, alerta 6,5 s, aviso com "Desfazer" 7 s;
  - no celular, avisos mais baixos e no máximo 2 empilhados.
- **Arquivos:** `src/ui/App.jsx`, `src/styles.css`, `tests/e2e_smoke.py`.
- **Como testar:** digite um preço abaixo da tabela. Aparece o aviso de mínimo, que pode ser fechado no ×.
- **Nova verificação no e2e:** "aviso pode ser fechado".

## 6. Envio no computador: passos na tela e imagem baixada quando não dá para copiar (P6, severidade média)
- **Problema:** sem permissão para copiar imagem, o app abria o WhatsApp e dizia "Baixe a imagem e anexe…", mas não baixava nada, e o aviso sumia.
- **O que mudou:** se a cópia falhar, a imagem é baixada na hora. Um bloco fixo "Na conversa do WhatsApp" lista os passos (colar ou anexar a imagem, anexar o PDF) com os botões "Baixar imagem de novo" e "Baixar PDF". Quando a cópia funciona, o bloco mostra "cole com Ctrl+V (⌘V no Mac)". No celular, o compartilhamento nativo segue igual.
- **Arquivos:** `src/ui/Pronta.jsx`, `src/styles.css`, `tests/e2e_smoke.py`.
- **Como testar:** no computador, gere uma proposta e clique em "Enviar pelo WhatsApp" (num navegador que bloqueie a cópia, a imagem é baixada).
- **Novas verificações no e2e:** "computador: passos do envio ficam na tela" e "computador sem permissão de copiar: imagem baixada e passos na tela".

## 7. Teclado: chips navegáveis por setas (P7, severidade média)
- **Problema:** cada chip era um ponto de Tab e as setas não faziam nada. Nos opcionais do totem eram dezenas de Tabs.
- **O que mudou:** padrão de grupo de rádio. O grupo tem um só ponto de Tab (a opção escolhida) e setas, Home e End mudam a escolha pelo mesmo `onChange` de antes.
- **Arquivos:** `src/ui/common.jsx`, `tests/e2e_smoke.py`.
- **Como testar:** Totem → Solução. Dê Tab até "Pinpad" e use as setas.
- **Nova verificação no e2e:** "chips: setas mudam a escolha e o grupo tem um só ponto de Tab".

## 8. Acessibilidade: foco preso nos diálogos e contorno de foco visível (P8, severidade média)
- **Problema:** ao abrir "Nova proposta", o perfil ou a prévia em folha, o foco ficava na página de trás (12 de 12 Tabs fora da janela). O contorno de foco dos botões chanfrados era cortado pelo `clip-path`.
- **O que mudou:**
  - ao abrir um diálogo, o foco vai para o primeiro campo ou opção;
  - Tab e Shift+Tab ficam presos no diálogo;
  - ao fechar, o foco volta ao botão de origem, sem roubar o foco automático do campo "Empresa" no construtor;
  - o contorno de foco dos botões fica por dentro do botão.
- **Arquivos:** `src/ui/common.jsx`, `src/styles.css`, `tests/e2e_smoke.py`.
- **Como testar:** "Nova proposta" → Tab várias vezes → Esc.
- **Novas verificações no e2e:** "modal: foco entra e fica preso na janela" e "modal: foco volta ao botão de origem ao fechar".

## 9. Contraste do texto secundário (P9, severidade média)
- **Problema:** `--dim` da NEXTCARD tinha 3,81:1 sobre o fundo e 3,45:1 sobre `--bg-3`. É a cor de rótulos de 10 px, dicas e "preço de tabela".
- **O que mudou:** NEXTCARD `#8A8A94` (5,9:1 sobre o fundo) e Teloos `#8193C6` (≥ 4,5:1 também sobre `--bg-3`). A cor continua mais apagada que `--muted`. A imagem e o PDF usam cores próprias e não mudaram.
- **Arquivos:** `src/styles.css`, `tests/e2e_smoke.py`.
- **Novas verificações no e2e:** "contraste do texto secundário (--dim) ≥ 4,5:1" na NEXTCARD e na Teloos.

## 10. Celular: alvos de toque com pelo menos 44 px (P10, severidade média)
- **Problema:** no celular havia 40 alvos abaixo de 44 px no passo "Solução" e 43 no passo "Condições": botões de ícone de 32 px, quantidade de 30 × 34 px, estrela de 34 px, "Ajustar" de 36 px, "Incluir" e itens inclusos de 32 px, caixa de marcar de 30 × 20 px.
- **O que mudou:** abaixo de 900 px de largura, esses controles passam a ter no mínimo 44 × 44 px (as áreas de toque crescem; o visual muda pouco). O controle de quantidade tem 46 px de altura: 44 px úteis mais a borda. O computador não muda.
- **Arquivos:** `src/styles.css`, `tests/e2e_smoke.py`.
- **Como testar:** Catracas → Solução e Condições no celular.
- **Nova verificação no e2e:** "celular: controles do construtor com pelo menos 44 px".

---

## Validação final

- `node build/test_core.mjs`: todos os testes passaram.
- `python3 tests/e2e_smoke.py`: 44 de 44 verificações (eram 27). Inclui "nenhuma requisição externa", "nenhum erro de console" e rolagem horizontal em 390 px no início, no construtor, na proposta pronta e na Solução Teloos.
- `python3 tests/pecas_fontes.py`: 7 de 7 casos. A imagem do WhatsApp não mudou (`src/render.js` intacto).
- A saída completa do terminal está em `tests/out/rodada1/resultados/testes_depois.txt`.
- `sha256sum` de `src/catalog.json` e `src/defaults.js` igual ao do zip recebido.

### Arquivos novos de apoio
- `tests/ux_auditoria.py`: percorre as 5 jornadas e grava capturas e medidas (`antes`/`depois`).
- `tests/comparativo.py`: monta os pares antes/depois em `tests/out/rodada1/comparativo/`.
