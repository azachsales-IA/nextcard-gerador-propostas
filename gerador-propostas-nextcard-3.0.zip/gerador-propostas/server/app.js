// API do Gerador de Propostas (Node puro; funciona em função serverless da Vercel e no servidor local).
// Toda permissão é verificada aqui. O navegador só exibe o que o servidor autorizou.
import crypto from 'node:crypto';
import { q, tx } from './db.js';
import * as A from './auth.js';
import * as P from './policy.js';
import * as K from './kommo.js';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ROLES = ['owner', 'aprovador', 'gestor', 'consultor'];
const ETAPAS = ['rascunho', 'enviada', 'negociacao', 'ganho', 'perdido'];
const MAX_JSON = 3.5 * 1024 * 1024;
const MAX_PDF = 4.3 * 1024 * 1024; // limite de corpo das funções da Vercel é 4,5 MB

class Http extends Error { constructor(status, code, msg, extra) { super(msg || code); this.status = status; this.code = code; this.extra = extra; } }
const nao = (cond, status, code, msg, extra) => { if (cond) throw new Http(status, code, msg, extra); };

async function corpo(req, limite) {
  if (req.body !== undefined && req.body !== null) {
    if (Buffer.isBuffer(req.body)) return req.body;
    if (typeof req.body === 'string') return Buffer.from(req.body);
    return req.body; // já interpretado pela plataforma
  }
  const partes = []; let n = 0;
  for await (const c of req) { n += c.length; if (n > limite) throw new Http(413, 'grande', 'Conteúdo acima do limite'); partes.push(c); }
  return Buffer.concat(partes);
}
async function json(req) {
  const b = await corpo(req, MAX_JSON);
  if (!Buffer.isBuffer(b)) return b || {};
  if (!b.length) return {};
  try { return JSON.parse(b.toString('utf8')); } catch (_) { throw new Http(400, 'json', 'JSON inválido'); }
}
const audit = (c, user, acao, alvo, detalhe = {}) => (c || { query: q }).query('insert into audit_log (user_id, acao, alvo, detalhe) values ($1, $2, $3, $4)', [user?.id || null, acao, String(alvo || ''), detalhe]);
const seguro = (req) => (req.headers['x-forwarded-proto'] || '').split(',')[0] === 'https' || process.env.NODE_ENV === 'production';

async function configAtual(c) {
  const r = await (c || { query: q }).query('select version, data, created_at, nota from config_versions order by version desc limit 1');
  nao(!r.rows[0], 503, 'sem_config', 'Configuração oficial ainda não publicada');
  return r.rows[0];
}
const alcadasDe = async (c, userId) => (await (c || { query: q }).query('select * from alcadas where user_id = $1', [userId])).rows;
const exigeAvulso = async (c) => { const r = await (c || { query: q }).query("select value from settings where key = 'avulsoExigeAprovacao'"); return r.rows[0] ? r.rows[0].value !== false : true; };

function linhaProposta(r) {
  return {
    ...r.data, id: r.id, empresa: r.empresa, numero: r.numero, versao: r.versao, etapa: r.etapa,
    emitidaEm: r.emitida_em ? new Date(r.emitida_em).toISOString() : null,
    criadaEm: new Date(r.created_at).toISOString(), atualizadaEm: new Date(r.updated_at).toISOString(),
    _srv: {
      rev: r.rev, status: r.status, ownerId: r.owner_id, ownerNome: r.owner_nome, compartilhamento: r.compartilhamento,
      kommo: r.kommo_lead_id ? { leadId: r.kommo_lead_id, nome: r.kommo_lead_nome, url: K.kommoLeadUrl(r.kommo_lead_id), status: r.kommo_status || 'negocio_selecionado', erro: r.kommo_erro || null } : null,
      configVersion: r.config_version || null, temPdf: !!r.tem_pdf, aprovacao: r.aprov_status || null,
    },
  };
}
const SEL_PROP = `select p.*, u.nome as owner_nome, v.config_version, (v.pdf is not null) as tem_pdf, k.status as kommo_status, k.erro as kommo_erro,
  (select a.status from aprovacoes a where a.proposta_id = p.id order by a.created_at desc limit 1) as aprov_status
  from propostas p join users u on u.id = p.owner_id
  left join proposta_versoes v on v.proposta_id = p.id and v.versao = p.versao
  left join kommo_links k on k.versao_id = v.id`;

async function carregaProposta(c, id, user, { paraEscrita = false } = {}) {
  nao(!UUID.test(id), 400, 'id', 'Identificador inválido');
  const r = await c.query(`select * from propostas where id = $1${paraEscrita ? ' for update' : ''}`, [id]);
  const p = r.rows[0];
  if (!p) return null;
  const dono = p.owner_id === user.id;
  const ve = dono || A.tem(user, 'owner', 'aprovador', 'gestor');
  nao(!ve, 404, 'nao_encontrada', 'Proposta não encontrada'); // 404 para não revelar existência
  nao(paraEscrita && !dono && !A.tem(user, 'aprovador'), 403, 'proibido', 'Somente o responsável pode alterar esta proposta');
  return p;
}

// ───────────────────────── Rotas ─────────────────────────
const rotas = [];
const rota = (method, path, opts, fn) => { if (typeof opts === 'function') { fn = opts; opts = {}; } rotas.push({ method, re: new RegExp('^' + path.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), opts, fn }); };

rota('POST', '/api/login', { publico: true }, async ({ req, res }) => {
  const b = await json(req);
  const r = await A.login(b.email, b.senha);
  nao(r.erro === 'bloqueado', 429, 'bloqueado', 'Muitas tentativas. Aguarde 15 minutos.');
  nao(r.erro, 401, 'credenciais', 'E-mail ou senha incorretos');
  res.setHeader('Set-Cookie', A.cookieSessao(r.token, r.exp, seguro(req)));
  await audit(null, r.user, 'login', r.user.email);
  return { user: r.user };
});
rota('POST', '/api/logout', { publico: true }, async ({ req, res }) => { await A.logout(A.lerCookie(req)); res.setHeader('Set-Cookie', A.cookieLimpo(seguro(req))); return { ok: true }; });

rota('GET', '/api/me', async ({ user }) => {
  const [al, cv, pend] = await Promise.all([
    alcadasDe(null, user.id), q('select max(version) as v from config_versions'),
    A.tem(user, 'aprovador') ? q("select count(*)::int as n from aprovacoes where status = 'pendente'") : { rows: [{ n: 0 }] },
  ]);
  return { user: A.publico(user), alcadaPct: P.limiteVigente(al), configVersion: cv.rows[0].v, kommo: K.kommoAtivo(), aprovacoesPendentes: pend.rows[0].n };
});
rota('POST', '/api/me/senha', async ({ req, user }) => {
  const b = await json(req);
  nao(!A.confereSenha(b.atual, user.pass_hash), 403, 'senha', 'Senha atual incorreta');
  nao(!A.senhaForte(b.nova), 422, 'senha_fraca', 'A senha precisa de 10 caracteres ou mais, com letras e números');
  await q('update users set pass_hash = $2, updated_at = now() where id = $1', [user.id, A.hashSenha(b.nova)]);
  await audit(null, user, 'senha.alterada', user.email);
  return { ok: true };
});

// ── Configuração oficial (somente o proprietário administrativo altera) ──
rota('GET', '/api/config', async () => configAtual());
rota('GET', '/api/config/versions', { roles: ['owner', 'aprovador', 'gestor'] }, async () =>
  ({ versions: (await q('select c.version, c.nota, c.created_at, u.nome as autor from config_versions c left join users u on u.id = c.created_by order by c.version desc limit 200')).rows }));
rota('GET', '/api/config/versions/:v', async ({ params }) => {
  const r = await q('select version, data, created_at, nota from config_versions where version = $1', [Number(params.v) || 0]);
  nao(!r.rows[0], 404, 'nao_encontrada', 'Versão não encontrada');
  return r.rows[0];
});
rota('PUT', '/api/config', { roles: ['owner'] }, async ({ req, user }) => {
  const b = await json(req);
  const erros = P.validarConfig(b.data);
  nao(erros.length, 422, 'config_invalida', 'Configuração inválida', { erros: erros.slice(0, 20) });
  return tx(async (c) => {
    await c.query('lock table config_versions in exclusive mode');
    const atual = (await c.query('select version, data from config_versions order by version desc limit 1')).rows[0];
    const v = atual ? atual.version : 0;
    nao(Number(b.baseVersion) !== v, 409, 'conflito', 'A configuração foi alterada por outra sessão. Recarregue antes de salvar.', { version: v });
    if (atual && JSON.stringify(atual.data) === JSON.stringify(b.data)) return { version: v, inalterada: true };
    const r = await c.query('insert into config_versions (version, data, nota, created_by) values ($1, $2, $3, $4) returning version, created_at', [v + 1, b.data, String(b.nota || '').slice(0, 500), user.id]);
    await audit(c, user, 'config.publicada', `v${v + 1}`, { nota: b.nota || '', alteracoes: diffResumo(atual?.data, b.data) });
    return r.rows[0];
  });
});
// Resumo das diferenças (caminho, antes, depois) para o histórico de alterações; limitado a 60 entradas
function diffResumo(a, b, path = '', out = []) {
  if (out.length >= 60) return out;
  if (JSON.stringify(a) === JSON.stringify(b)) return out;
  const obj = (x) => x && typeof x === 'object';
  if (!obj(a) || !obj(b)) { const s = (x) => { const t = JSON.stringify(x); return t && t.length > 120 ? t.slice(0, 117) + '…' : t; }; out.push({ campo: path, antes: s(a), depois: s(b) }); return out; }
  const chave = (x, i) => (obj(x) && x.id ? `[${x.id}]` : `[${i}]`);
  if (Array.isArray(a) && Array.isArray(b)) {
    const porId = a.every((x) => obj(x) && x.id) && b.every((x) => obj(x) && x.id);
    if (porId) {
      const ma = new Map(a.map((x) => [x.id, x])), mb = new Map(b.map((x) => [x.id, x]));
      for (const id of new Set([...ma.keys(), ...mb.keys()])) diffResumo(ma.get(id), mb.get(id), `${path}[${id}]`, out);
    } else for (let i = 0; i < Math.max(a.length, b.length); i++) diffResumo(a[i], b[i], path + chave(null, i), out);
    return out;
  }
  for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) diffResumo(a[k], b[k], path ? `${path}.${k}` : k, out);
  return out;
}

rota('GET', '/api/fotos', async () => { const o = {}; for (const r of (await q('select id, data from fotos')).rows) o[r.id] = r.data; return { fotos: o }; });
rota('PUT', '/api/fotos/:id', { roles: ['owner'] }, async ({ req, params, user }) => {
  const b = await json(req);
  nao(!/^[\w.:-]{1,80}$/.test(params.id), 400, 'id', 'Identificador inválido');
  nao(typeof b.data !== 'string' || !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(b.data), 422, 'imagem', 'Envie PNG, JPG ou WebP');
  await q('insert into fotos (id, data, meta, created_by) values ($1, $2, $3, $4) on conflict (id) do update set data = excluded.data, meta = excluded.meta, updated_at = now()', [params.id, b.data, b.meta || {}, user.id]);
  await audit(null, user, 'foto.salva', params.id);
  return { ok: true };
});
rota('DELETE', '/api/fotos/:id', { roles: ['owner'] }, async ({ params, user }) => { await q('delete from fotos where id = $1', [params.id]); await audit(null, user, 'foto.removida', params.id); return { ok: true }; });

// ── Usuários (proprietário) ──
rota('GET', '/api/users', { roles: ['owner', 'aprovador', 'gestor'] }, async () => ({ users: (await q('select * from users order by nome')).rows.map(A.publico) }));
const limpaRoles = (r) => [...new Set((Array.isArray(r) ? r : []).filter((x) => ROLES.includes(x)))];
rota('POST', '/api/users', { roles: ['owner'] }, async ({ req, user }) => {
  const b = await json(req);
  const email = String(b.email || '').trim().toLowerCase();
  nao(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email), 422, 'email', 'E-mail inválido');
  nao(String(b.nome || '').trim().length < 2, 422, 'nome', 'Informe o nome');
  nao(!A.senhaForte(b.senha), 422, 'senha_fraca', 'A senha precisa de 10 caracteres ou mais, com letras e números');
  const roles = limpaRoles(b.roles); if (!roles.length) roles.push('consultor');
  try {
    const r = await q('insert into users (email, nome, sigla, telefone, roles, pass_hash) values ($1, $2, $3, $4, $5, $6) returning *',
      [email, b.nome.trim(), siglaOk(b.sigla), String(b.telefone || '').slice(0, 30), roles, A.hashSenha(b.senha)]);
    await audit(null, user, 'usuario.criado', email, { roles });
    return { user: A.publico(r.rows[0]) };
  } catch (e) { if (e.code === '23505') throw new Http(409, 'duplicado', 'Já existe usuário com este e-mail'); throw e; }
});
const siglaOk = (s) => String(s || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3);
rota('PATCH', '/api/users/:id', { roles: ['owner'] }, async ({ req, params, user }) => {
  const b = await json(req);
  return tx(async (c) => {
    const alvo = (await c.query('select * from users where id = $1 for update', [params.id])).rows[0];
    nao(!alvo, 404, 'nao_encontrado', 'Usuário não encontrado');
    const roles = b.roles === undefined ? alvo.roles : limpaRoles(b.roles);
    const ativo = b.ativo === undefined ? alvo.ativo : !!b.ativo;
    if (alvo.roles.includes('owner') && (!roles.includes('owner') || !ativo)) {
      const n = (await c.query("select count(*)::int as n from users where 'owner' = any(roles) and ativo and id <> $1", [alvo.id])).rows[0].n;
      nao(n === 0, 422, 'ultimo_owner', 'O sistema precisa de pelo menos um proprietário administrativo ativo');
    }
    const r = await c.query('update users set nome = $2, sigla = $3, telefone = $4, roles = $5, ativo = $6, updated_at = now() where id = $1 returning *',
      [alvo.id, b.nome === undefined ? alvo.nome : String(b.nome).trim() || alvo.nome, b.sigla === undefined ? alvo.sigla : siglaOk(b.sigla), b.telefone === undefined ? alvo.telefone : String(b.telefone).slice(0, 30), roles, ativo]);
    if (b.senha !== undefined) {
      nao(!A.senhaForte(b.senha), 422, 'senha_fraca', 'A senha precisa de 10 caracteres ou mais, com letras e números');
      await c.query('update users set pass_hash = $2, falhas_login = 0, bloqueado_ate = null where id = $1', [alvo.id, A.hashSenha(b.senha)]);
    }
    if (!ativo || b.senha !== undefined) await c.query('delete from sessions where user_id = $1', [alvo.id]);
    await audit(c, user, 'usuario.alterado', alvo.email, { roles, ativo, senha: b.senha !== undefined });
    return { user: A.publico(r.rows[0]) };
  });
});
// O próprio usuário ajusta nome e telefone; sigla e papéis são do proprietário
rota('PATCH', '/api/me', async ({ req, user }) => {
  const b = await json(req);
  const r = await q('update users set nome = $2, telefone = $3, updated_at = now() where id = $1 returning *', [user.id, String(b.nome || user.nome).trim().slice(0, 120) || user.nome, String(b.telefone ?? user.telefone).slice(0, 30)]);
  return { user: A.publico(r.rows[0]) };
});

// ── Alçadas de desconto (autoridade comercial) ──
rota('GET', '/api/alcadas', async ({ user }) => {
  const todos = A.tem(user, 'owner', 'aprovador', 'gestor');
  const r = await q(`select a.*, u.nome as usuario, ap.nome as aprovador from alcadas a join users u on u.id = a.user_id join users ap on ap.id = a.aprovado_por ${todos ? '' : 'where a.user_id = $1'} order by a.aprovado_em desc`, todos ? [] : [user.id]);
  return { alcadas: r.rows.map((a) => ({ ...a, pct: Number(a.pct) })) };
});
rota('POST', '/api/alcadas', { roles: ['aprovador'] }, async ({ req, user }) => {
  const b = await json(req);
  const pct = Number(b.pct);
  nao(!Number.isFinite(pct) || pct < 0 || pct > 100, 422, 'pct', 'Percentual inválido');
  nao(!UUID.test(String(b.userId)), 422, 'usuario', 'Selecione o consultor');
  const kinds = Array.isArray(b.kinds) && b.kinds.length ? b.kinds.filter((k) => ['totem', 'catraca', 'comanda', 'servico', 'plano', 'adicional', 'implantacao'].includes(k)) : null;
  const dt = (s) => (/^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) ? s : null);
  nao(dt(b.inicio) && dt(b.fim) && b.fim < b.inicio, 422, 'vigencia', 'O fim da vigência é anterior ao início');
  const r = await q('insert into alcadas (user_id, pct, kinds, inicio, fim, condicoes, aprovado_por) values ($1, $2, $3, $4::date, $5, $6, $7) returning *',
    [b.userId, pct, kinds, dt(b.inicio) || P.diaBR(), dt(b.fim), String(b.condicoes || '').slice(0, 1000), user.id]);
  await audit(null, user, 'alcada.concedida', b.userId, { pct, kinds, inicio: b.inicio || null, fim: b.fim || null });
  return { alcada: { ...r.rows[0], pct: Number(r.rows[0].pct) } };
});
rota('POST', '/api/alcadas/:id/revogar', { roles: ['aprovador'] }, async ({ params, user }) => {
  const r = await q('update alcadas set revogada_em = now(), revogada_por = $2 where id = $1 and revogada_em is null returning user_id', [params.id, user.id]);
  nao(!r.rows[0], 404, 'nao_encontrada', 'Alçada não encontrada ou já revogada');
  await audit(null, user, 'alcada.revogada', r.rows[0].user_id, { id: params.id });
  return { ok: true };
});

// ── Numeração ──
rota('GET', '/api/sequencia', { roles: ['owner', 'aprovador'] }, async () => {
  const [s, m] = await Promise.all([q('select proximo from sequencia where id = 1'), q('select coalesce(max(seq), 0) as m from propostas')]);
  return { proximo: s.rows[0]?.proximo ?? null, ultimoUsado: m.rows[0].m };
});
rota('PUT', '/api/sequencia', { roles: ['owner'] }, async ({ req, user }) => {
  const n = Number((await json(req)).proximo);
  nao(!Number.isInteger(n) || n < 1, 422, 'numero', 'Número inválido');
  return tx(async (c) => {
    await c.query('lock table sequencia in exclusive mode');
    const m = (await c.query('select coalesce(max(seq), 0) as m from propostas')).rows[0].m;
    nao(n <= m, 422, 'ja_usado', `O número ${m} já foi usado. O próximo precisa ser maior.`);
    await c.query('insert into sequencia (id, proximo) values (1, $1) on conflict (id) do update set proximo = excluded.proximo', [n]);
    await audit(c, user, 'sequencia.definida', String(n));
    return { proximo: n };
  });
});

// ── Propostas ──
rota('GET', '/api/propostas', async ({ user }) => {
  const todos = A.tem(user, 'owner', 'aprovador', 'gestor');
  const r = await q(`${SEL_PROP} where p.status <> 'cancelada' ${todos ? '' : 'and p.owner_id = $1'} order by p.updated_at desc limit 1000`, todos ? [] : [user.id]);
  return { propostas: r.rows.map(linhaProposta) };
});
const resumoCliente = (d) => String(d?.cliente?.empresa || '').slice(0, 200);
rota('PUT', '/api/propostas/:id', async ({ req, params, user }) => {
  const b = await json(req);
  const d = b.data;
  nao(!d || typeof d !== 'object' || !['nextcard', 'teloos'].includes(d.empresa), 422, 'dados', 'Proposta inválida');
  return tx(async (c) => {
    const p = await carregaProposta(c, params.id, user, { paraEscrita: true });
    const lead = d.kommo?.leadId ? Number(d.kommo.leadId) : null;
    if (!p) {
      await c.query('insert into propostas (id, owner_id, empresa, data, cliente_nome, etapa, kommo_lead_id, kommo_lead_nome) values ($1, $2, $3, $4, $5, $6, $7, $8)',
        [params.id, user.id, d.empresa, d, resumoCliente(d), 'rascunho', lead, d.kommo?.nome || null]);
      return { rev: 1 };
    }
    nao(p.status === 'cancelada', 409, 'cancelada', 'Proposta cancelada');
    nao(b.rev !== undefined && Number(b.rev) !== p.rev, 409, 'conflito', 'Esta proposta foi alterada em outra sessão', { rev: p.rev });
    const r = await c.query('update propostas set data = $2, cliente_nome = $3, kommo_lead_id = $4, kommo_lead_nome = $5, rev = rev + 1, updated_at = now() where id = $1 returning rev',
      [p.id, d, resumoCliente(d), lead, d.kommo?.nome || null]);
    return { rev: r.rows[0].rev };
  });
});
rota('DELETE', '/api/propostas/:id', async ({ params, user }) => tx(async (c) => {
  const p = await carregaProposta(c, params.id, user, { paraEscrita: true });
  nao(!p, 404, 'nao_encontrada', 'Proposta não encontrada');
  if (p.numero) { // emitida: nunca apaga, só cancela (o número e os documentos ficam preservados)
    await c.query("update propostas set status = 'cancelada', updated_at = now() where id = $1", [p.id]);
    await audit(c, user, 'proposta.cancelada', p.numero);
    return { cancelada: true };
  }
  await c.query('delete from propostas where id = $1', [p.id]);
  return { excluida: true };
}));
rota('PATCH', '/api/propostas/:id/situacao', async ({ req, params, user }) => {
  const b = await json(req);
  return tx(async (c) => {
    const p = await carregaProposta(c, params.id, user, { paraEscrita: true });
    nao(!p, 404, 'nao_encontrada', 'Proposta não encontrada');
    const etapa = ETAPAS.includes(b.etapa) ? b.etapa : p.etapa;
    const comp = ['nao_compartilhada', 'iniciado', 'registrado'].includes(b.compartilhamento) ? b.compartilhamento : p.compartilhamento;
    await c.query('update propostas set etapa = $2, compartilhamento = $3, updated_at = now() where id = $1', [p.id, etapa, comp]);
    return { etapa, compartilhamento: comp };
  });
});

// Análise ao vivo: informa limite, desconto efetivo e o que bloquearia a emissão (sem gravar nada)
rota('POST', '/api/analise', async ({ req, user }) => {
  const b = await json(req);
  const cfg = await configAtual();
  const an = P.analisar(b.data, cfg.data);
  const al = await alcadasDe(null, user.id);
  const dec = P.decidir(an, { alcadas: al, aprovador: A.tem(user, 'aprovador'), exigeAprovacaoAvulso: await exigeAvulso() });
  return { configVersion: cfg.version, erros: an.erros, pct: Number(an.pct.toFixed(4)), desconto: an.desconto, base: an.base, valorFinal: an.valorFinal, limite: P.limiteVigente(al), ok: dec.ok, bloqueio: dec.bloqueio || null, pendencias: dec.pendencias || [], via: dec.via || null };
});

rota('POST', '/api/propostas/:id/aprovacao', async ({ req, params, user }) => {
  const b = await json(req);
  return tx(async (c) => {
    let p = await carregaProposta(c, params.id, user, { paraEscrita: true });
    if (!p) { // rascunho ainda não sincronizado: cria agora, para o pedido nunca se perder
      nao(!b.data || !['nextcard', 'teloos'].includes(b.data.empresa), 422, 'dados', 'Proposta inválida');
      await c.query('insert into propostas (id, owner_id, empresa, data, cliente_nome) values ($1, $2, $3, $4, $5)', [params.id, user.id, b.data.empresa, b.data, resumoCliente(b.data)]);
      p = (await c.query('select * from propostas where id = $1 for update', [params.id])).rows[0];
    }
    const cfg = await configAtual(c);
    const an = P.analisar(b.data || p.data, cfg.data);
    nao(an.erros.length, 422, 'invalida', 'A proposta tem erros', { erros: an.erros });
    const dec = P.decidir(an, { alcadas: await alcadasDe(c, user.id), aprovador: false, exigeAprovacaoAvulso: await exigeAvulso(c) });
    nao(dec.ok, 422, 'desnecessaria', 'Esta proposta não precisa de aprovação');
    await c.query("update aprovacoes set status = 'rejeitada', resposta = 'Substituída por novo pedido', decidido_em = now() where proposta_id = $1 and status = 'pendente'", [p.id]);
    const r = await c.query('insert into aprovacoes (proposta_id, solicitante, pct, motivos, fingerprint, justificativa) values ($1, $2, $3, $4, $5, $6) returning id',
      [p.id, user.id, an.pct, JSON.stringify(dec.pendencias), P.fingerprint(an.prop, an), String(b.justificativa || '').slice(0, 2000)]);
    await c.query("update propostas set status = case when numero is null then 'aguardando_aprovacao' else status end, data = $2, rev = rev + 1, updated_at = now() where id = $1", [p.id, b.data || p.data]);
    await audit(c, user, 'aprovacao.solicitada', p.id, { pct: Number(an.pct.toFixed(2)) });
    return { id: r.rows[0].id };
  });
});
rota('GET', '/api/aprovacoes', async ({ user }) => {
  const todos = A.tem(user, 'owner', 'aprovador', 'gestor');
  const r = await q(`select a.*, s.nome as solicitante_nome, d.nome as decisor_nome, p.cliente_nome, p.numero, p.data as proposta
    from aprovacoes a join users s on s.id = a.solicitante left join users d on d.id = a.decidido_por join propostas p on p.id = a.proposta_id
    ${todos ? '' : 'where a.solicitante = $1'} order by (a.status = 'pendente') desc, a.created_at desc limit 200`, todos ? [] : [user.id]);
  return { aprovacoes: r.rows.map((a) => ({ ...a, pct: Number(a.pct) })) };
});
rota('POST', '/api/aprovacoes/:id/decidir', { roles: ['aprovador'] }, async ({ req, params, user }) => {
  const b = await json(req);
  return tx(async (c) => {
    const a = (await c.query('select * from aprovacoes where id = $1 for update', [params.id])).rows[0];
    nao(!a, 404, 'nao_encontrada', 'Pedido não encontrado');
    nao(a.status !== 'pendente', 409, 'decidido', 'Este pedido já foi decidido');
    const st = b.aprovar ? 'aprovada' : 'rejeitada';
    nao(!b.aprovar && !String(b.resposta || '').trim(), 422, 'justificativa', 'Informe o motivo da recusa');
    await c.query('update aprovacoes set status = $2, decidido_por = $3, decidido_em = now(), resposta = $4 where id = $1', [a.id, st, user.id, String(b.resposta || '').slice(0, 2000)]);
    await c.query("update propostas set status = 'rascunho', updated_at = now() where id = $1 and status = 'aguardando_aprovacao'", [a.proposta_id]);
    await audit(c, user, `aprovacao.${st}`, a.proposta_id, { pct: Number(a.pct) });
    return { status: st };
  });
});

// Emissão: valida tudo de novo, reserva o número de forma atômica e grava o snapshot imutável.
rota('POST', '/api/propostas/:id/emitir', async ({ req, params, user }) => {
  const b = await json(req);
  return tx(async (c) => {
    let p = await carregaProposta(c, params.id, user, { paraEscrita: true });
    const d = b.data || p?.data;
    nao(!d || typeof d !== 'object', 422, 'dados', 'Proposta inválida');
    if (!p) {
      await c.query('insert into propostas (id, owner_id, empresa, data, cliente_nome) values ($1, $2, $3, $4, $5)', [params.id, user.id, d.empresa, d, resumoCliente(d)]);
      p = (await c.query('select * from propostas where id = $1 for update', [params.id])).rows[0];
    }
    nao(p.status === 'cancelada', 409, 'cancelada', 'Proposta cancelada');
    nao(!String(d.cliente?.empresa || '').trim(), 422, 'cliente', 'Informe o cliente antes de emitir');
    const cfg = await configAtual(c);
    const an = P.analisar(d, cfg.data);
    nao(an.erros.length, 422, 'invalida', 'A proposta tem erros', { erros: an.erros });
    const alc = await alcadasDe(c, user.id);
    let dec = P.decidir(an, { alcadas: alc, aprovador: A.tem(user, 'aprovador'), exigeAprovacaoAvulso: await exigeAvulso(c) });
    let aprovacao = null;
    const fp = P.fingerprint(an.prop, an);
    if (!dec.ok && dec.bloqueio === 'aprovacao') {
      aprovacao = (await c.query("select a.*, u.nome as decisor from aprovacoes a join users u on u.id = a.decidido_por where a.proposta_id = $1 and a.status = 'aprovada' and a.fingerprint = $2 order by a.decidido_em desc limit 1", [p.id, fp])).rows[0];
      nao(!aprovacao, 403, 'aprovacao_necessaria', 'Esta condição precisa de aprovação antes da emissão', { pendencias: dec.pendencias, limite: dec.limite, pct: Number(an.pct.toFixed(4)) });
      dec = { ok: true, via: 'aprovacao' };
    }
    const dono = (await c.query('select * from users where id = $1', [p.owner_id])).rows[0];
    const agora = new Date();
    let { seq, sufixo, numero } = p;
    if (!numero) {
      const s = await c.query('update sequencia set proximo = proximo + 1 where id = 1 returning proximo - 1 as n');
      nao(!s.rows[0], 503, 'sem_sequencia', 'A numeração ainda não foi configurada pelo administrador');
      seq = s.rows[0].n; sufixo = dono.sigla || '';
      numero = P.codigoComercial(agora, seq, sufixo);
    }
    const versao = p.versao + 1;
    const emitidaEm = agora.toISOString();
    const prop = { ...an.prop, id: p.id, numero, versao, emitidaEm, primeiraEmissao: an.prop.primeiraEmissao || (p.emitida_em ? new Date(p.emitida_em).toISOString() : emitidaEm), responsavel: an.prop.responsavel || dono.nome };
    prop.responsavelContato = { nome: prop.responsavel, sigla: dono.sigla, telefone: dono.telefone, email: dono.email };
    delete prop._srv; delete prop.tocada;
    prop.historico = [...(Array.isArray(prop.historico) ? prop.historico : []).filter((h) => h.versao < versao), { versao, data: emitidaEm, valorFinal: an.valorFinal }];
    const snapshot = {
      prop, configVersion: cfg.version, valorFinal: an.valorFinal,
      desconto: { pct: Number(an.pct.toFixed(4)), valor: an.desconto, base: an.base, via: dec.via, motivos: an.motivos,
        alcada: dec.alcada ? { id: dec.alcada.id, pct: Number(dec.alcada.pct), aprovadoPor: dec.alcada.aprovado_por, aprovadoEm: dec.alcada.aprovado_em } : null,
        aprovacao: aprovacao ? { id: aprovacao.id, por: aprovacao.decisor, em: aprovacao.decidido_em, resposta: aprovacao.resposta } : null },
      emissor: { id: user.id, nome: user.nome }, responsavel: { id: dono.id, nome: dono.nome, sigla: dono.sigla, telefone: dono.telefone, email: dono.email },
      fingerprint: fp,
    };
    await c.query('insert into proposta_versoes (proposta_id, versao, numero, snapshot, config_version, valor_final, desconto_pct, aprovacao_id, emitida_por, emitida_em) values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)',
      [p.id, versao, numero, snapshot, cfg.version, an.valorFinal, an.pct, aprovacao?.id || null, user.id, agora]);
    await c.query("update propostas set status = 'emitida', data = $2, seq = $3, sufixo = $4, numero = $5, versao = $6, emitida_em = $7, valor_final = $8, cliente_nome = $9, rev = rev + 1, updated_at = now(), kommo_lead_id = $10, kommo_lead_nome = $11 where id = $1",
      [p.id, prop, seq, sufixo, numero, versao, agora, an.valorFinal, resumoCliente(prop), prop.kommo?.leadId ? Number(prop.kommo.leadId) : p.kommo_lead_id, prop.kommo?.nome || p.kommo_lead_nome]);
    await audit(c, user, 'proposta.emitida', numero, { versao, valorFinal: an.valorFinal, descontoPct: Number(an.pct.toFixed(2)), via: dec.via, configVersion: cfg.version });
    const r = await c.query(`${SEL_PROP} where p.id = $1`, [p.id]);
    return { proposta: linhaProposta(r.rows[0]) };
  });
});

async function carregaVersao(params, user) {
  const p = await carregaProposta({ query: q }, params.id, user);
  nao(!p, 404, 'nao_encontrada', 'Proposta não encontrada');
  const v = (await q('select id, versao, numero, snapshot, config_version, valor_final, desconto_pct, emitida_em, emitida_por, pdf_sha256, (pdf is not null) as tem_pdf from proposta_versoes where proposta_id = $1 and versao = $2', [p.id, Number(params.v) || 0])).rows[0];
  nao(!v, 404, 'nao_encontrada', 'Versão não encontrada');
  return { p, v };
}
rota('GET', '/api/propostas/:id/versoes', async ({ params, user }) => {
  const p = await carregaProposta({ query: q }, params.id, user);
  nao(!p, 404, 'nao_encontrada', 'Proposta não encontrada');
  const r = await q(`select v.versao, v.numero, v.valor_final, v.desconto_pct, v.config_version, v.emitida_em, (v.pdf is not null) as tem_pdf, u.nome as emissor, k.status as kommo_status, k.erro as kommo_erro
    from proposta_versoes v join users u on u.id = v.emitida_por left join kommo_links k on k.versao_id = v.id where v.proposta_id = $1 order by v.versao desc`, [p.id]);
  return { versoes: r.rows.map((x) => ({ ...x, desconto_pct: Number(x.desconto_pct) })) };
});
rota('GET', '/api/propostas/:id/versoes/:v', async ({ params, user }) => { const { v } = await carregaVersao(params, user); return { versao: v.versao, numero: v.numero, snapshot: v.snapshot, configVersion: v.config_version, emitidaEm: v.emitida_em, temPdf: v.tem_pdf }; });
rota('PUT', '/api/propostas/:id/versoes/:v/pdf', async ({ req, params, user }) => {
  const { p, v } = await carregaVersao(params, user);
  nao(p.owner_id !== user.id && !A.tem(user, 'aprovador') && v.emitida_por !== user.id, 403, 'proibido', 'Sem permissão');
  if (v.tem_pdf) return { ok: true, jaExistia: true, sha256: v.pdf_sha256 }; // documento emitido não é substituído
  const buf = await corpo(req, MAX_PDF);
  nao(!Buffer.isBuffer(buf) || buf.length < 100 || buf.subarray(0, 5).toString() !== '%PDF-', 422, 'pdf', 'Arquivo PDF inválido');
  nao(buf.length > MAX_PDF, 413, 'grande', 'PDF acima de 4,3 MB');
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  await q('update proposta_versoes set pdf = $2, pdf_sha256 = $3 where id = $1 and pdf is null', [v.id, buf, sha]);
  return { ok: true, sha256: sha };
});
rota('GET', '/api/propostas/:id/versoes/:v/pdf', async ({ params, user, res }) => {
  const { v } = await carregaVersao(params, user);
  const r = await q('select pdf from proposta_versoes where id = $1', [v.id]);
  nao(!r.rows[0]?.pdf, 404, 'sem_pdf', 'O PDF desta versão ainda não foi armazenado');
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${P.nomeArquivoSeguro(v.numero)}"`);
  res.setHeader('Cache-Control', 'private, no-store');
  return { __raw: r.rows[0].pdf };
});

// ── Kommo ──
rota('GET', '/api/kommo/leads', async ({ query }) => { nao(!K.kommoAtivo(), 503, 'kommo_off', 'Integração Kommo não configurada'); return { leads: await K.buscarLeads(query.get('q')) }; });
rota('GET', '/api/kommo/leads/:id', async ({ params }) => { nao(!K.kommoAtivo(), 503, 'kommo_off', 'Integração Kommo não configurada'); return { lead: await K.detalheLead(params.id) }; });

// Anexa o PDF emitido ao negócio. Idempotente: repetir a chamada não duplica arquivo nem vínculo.
rota('POST', '/api/propostas/:id/versoes/:v/kommo', async ({ req, params, user }) => {
  nao(!K.kommoAtivo(), 503, 'kommo_off', 'Integração Kommo não configurada');
  const b = await json(req);
  const { p, v } = await carregaVersao(params, user);
  nao(p.owner_id !== user.id && !A.tem(user, 'aprovador'), 403, 'proibido', 'Sem permissão');
  const leadId = Number(b.leadId || p.kommo_lead_id);
  nao(!Number.isInteger(leadId) || leadId <= 0, 422, 'lead', 'Selecione o negócio do Kommo');
  nao(!v.tem_pdf, 409, 'sem_pdf', 'O PDF ainda não foi armazenado. Tente de novo em instantes.');
  const ex = (await q('select * from kommo_links where versao_id = $1', [v.id])).rows[0];
  if (ex?.status === 'anexado') { nao(ex.lead_id !== leadId, 409, 'outro_lead', 'Esta versão já está anexada a outro negócio'); return { status: 'anexado', leadId, url: K.kommoLeadUrl(leadId), anexadoEm: ex.anexado_em, repetida: true }; }
  // reserva a vez: só uma chamada por versão trabalha de cada vez
  const vez = await q(`insert into kommo_links (versao_id, lead_id, status, tentativas) values ($1, $2, 'processando', 1)
    on conflict (versao_id) do update set status = 'processando', tentativas = kommo_links.tentativas + 1, updated_at = now(),
      lead_id = excluded.lead_id
    where kommo_links.status <> 'anexado' and (kommo_links.status <> 'processando' or kommo_links.updated_at < now() - interval '2 minutes') returning *`, [v.id, leadId]);
  nao(!vez.rows[0], 409, 'em_andamento', 'O envio ao Kommo já está em andamento');
  let uuid = vez.rows[0].file_uuid;
  try {
    if (!uuid) {
      const pdf = (await q('select pdf from proposta_versoes where id = $1', [v.id])).rows[0].pdf;
      uuid = await K.enviarArquivo(P.nomeArquivoSeguro(v.numero), pdf);
      await q("update kommo_links set file_uuid = $2, updated_at = now() where versao_id = $1", [v.id, uuid]); // guarda já: nova tentativa não reenvia
    }
    await K.anexarAoLead(leadId, uuid);
    const ok = await K.arquivoNoLead(leadId, uuid);
    nao(!ok, 502, 'nao_confirmado', 'O Kommo não confirmou o arquivo no negócio');
    const r = await q("update kommo_links set status = 'anexado', erro = null, anexado_em = now(), verificado_em = now(), updated_at = now() where versao_id = $1 returning anexado_em", [v.id]);
    await q('update propostas set kommo_lead_id = $2, kommo_lead_nome = coalesce($3, kommo_lead_nome) where id = $1', [p.id, leadId, b.leadNome || null]);
    await audit(null, user, 'kommo.anexado', v.numero, { leadId, versao: v.versao });
    return { status: 'anexado', leadId, url: K.kommoLeadUrl(leadId), anexadoEm: r.rows[0].anexado_em };
  } catch (e) {
    const msg = e instanceof K.KommoError || e instanceof Http ? e.message : 'Falha inesperada no envio ao Kommo';
    await q("update kommo_links set status = 'falha', erro = $2, updated_at = now() where versao_id = $1", [v.id, msg]);
    await audit(null, user, 'kommo.falha', v.numero, { leadId, erro: msg, etapa: e.etapa || null });
    throw new Http(502, 'kommo_falha', msg, { podeRepetir: true });
  }
});

// ── Importação de dados que estavam no navegador ──
rota('POST', '/api/importacoes', async ({ req, user }) => {
  const b = await json(req);
  nao(!b.payload || typeof b.payload !== 'object', 422, 'dados', 'Nada para importar');
  const r = await q('insert into importacoes (enviado_por, origem, payload) values ($1, $2, $3) returning id', [user.id, String(b.origem || '').slice(0, 200), b.payload]);
  await audit(null, user, 'importacao.enviada', r.rows[0].id);
  return { id: r.rows[0].id };
});
rota('GET', '/api/importacoes', { roles: ['owner'] }, async () => ({ importacoes: (await q('select i.id, i.origem, i.status, i.created_at, u.nome as autor, i.payload from importacoes i join users u on u.id = i.enviado_por order by i.created_at desc limit 50')).rows }));
rota('POST', '/api/importacoes/:id/status', { roles: ['owner'] }, async ({ req, params, user }) => {
  const st = (await json(req)).status;
  nao(!['aplicada', 'descartada'].includes(st), 422, 'status', 'Status inválido');
  await q('update importacoes set status = $2 where id = $1', [params.id, st]);
  await audit(null, user, `importacao.${st}`, params.id);
  return { ok: true };
});
// Importa propostas antigas do navegador como rascunhos/históricos do próprio usuário (sem número novo; o número antigo fica só como referência)
rota('POST', '/api/propostas-importar', async ({ req, user }) => {
  const lista = (await json(req)).propostas;
  nao(!Array.isArray(lista) || lista.length > 500, 422, 'dados', 'Lista inválida');
  let n = 0;
  for (const d of lista) {
    if (!d || !['nextcard', 'teloos'].includes(d.empresa)) continue;
    const legado = d.numero ? { numeroLegado: d.numero, emitidaEmLegado: d.emitidaEm || null } : {};
    const data = { ...d, ...legado, numero: null, versao: 0, emitidaEm: null, idLegado: d.id };
    const dup = await q("select 1 from propostas where owner_id = $1 and data->>'idLegado' = $2", [user.id, String(d.id)]);
    if (dup.rows[0]) continue;
    await q('insert into propostas (owner_id, empresa, data, cliente_nome, etapa) values ($1, $2, $3, $4, $5)', [user.id, d.empresa, data, resumoCliente(d), ETAPAS.includes(d.etapa) ? d.etapa : 'rascunho']);
    n++;
  }
  await audit(null, user, 'propostas.importadas', String(n));
  return { importadas: n };
});

rota('GET', '/api/audit', { roles: ['owner', 'aprovador'] }, async () => ({ eventos: (await q('select a.id, a.acao, a.alvo, a.detalhe, a.at, u.nome as usuario from audit_log a left join users u on u.id = a.user_id order by a.id desc limit 300')).rows }));

rota('GET', '/api/dashboard', { roles: ['owner', 'aprovador', 'gestor'] }, async () => {
  const [st, cons, k, ap] = await Promise.all([
    q("select status, count(*)::int as n, coalesce(sum(valor_final), 0) as valor from propostas where status <> 'cancelada' group by status"),
    q("select u.nome, count(*)::int as n, coalesce(sum(p.valor_final), 0) as valor from propostas p join users u on u.id = p.owner_id where p.status = 'emitida' group by u.nome order by valor desc"),
    q('select status, count(*)::int as n from kommo_links group by status'),
    q("select count(*)::int as n from aprovacoes where status = 'pendente'"),
  ]);
  // valor proposto considera só a versão vigente de cada proposta (revisões não somam) e não representa vendas
  return { porStatus: st.rows, porConsultor: cons.rows, kommo: k.rows, aprovacoesPendentes: ap.rows[0].n };
});

// ───────────────────────── Despacho ─────────────────────────
export async function handler(req, res) {
  const url = new URL(req.url, 'http://x');
  const path = url.pathname.replace(/\/+$/, '') || '/';
  const envia = (status, obj) => { if (res.headersSent) return; res.statusCode = status; res.setHeader('Content-Type', 'application/json; charset=utf-8'); res.setHeader('Cache-Control', 'no-store'); res.end(JSON.stringify(obj)); };
  try {
    const cand = rotas.filter((r) => r.re.test(path));
    if (!cand.length) return envia(404, { erro: 'nao_encontrada', mensagem: 'Rota inexistente' });
    const r = cand.find((x) => x.method === req.method);
    if (!r) return envia(405, { erro: 'metodo', mensagem: 'Método não permitido' });
    // Proteção CSRF: toda escrita exige cabeçalho próprio (formulários de outros sites não conseguem enviá-lo)
    if (req.method !== 'GET' && req.headers['x-nx'] !== '1') return envia(403, { erro: 'csrf', mensagem: 'Requisição recusada' });
    let user = null;
    if (!r.opts.publico) {
      user = await A.usuarioDaSessao(A.lerCookie(req));
      if (!user) return envia(401, { erro: 'sessao', mensagem: 'Entre para continuar' });
      if (r.opts.roles && !A.tem(user, ...r.opts.roles)) { await audit(null, user, 'acesso.negado', `${req.method} ${path}`); return envia(403, { erro: 'proibido', mensagem: 'Você não tem permissão para esta ação' }); }
    }
    const out = await r.fn({ req, res, user, params: r.re.exec(path).groups || {}, query: url.searchParams });
    if (out && out.__raw) { res.statusCode = 200; return res.end(out.__raw); }
    return envia(200, out ?? { ok: true });
  } catch (e) {
    if (e instanceof Http) return envia(e.status, { erro: e.code, mensagem: e.message, ...(e.extra || {}) });
    if (e instanceof K.KommoError) return envia(502, { erro: 'kommo', mensagem: e.message });
    console.error('[api]', req.method, path, e);
    return envia(500, { erro: 'interno', mensagem: 'Erro interno. Tente novamente.' });
  }
}
