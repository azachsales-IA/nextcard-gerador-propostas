import pg from 'pg';
import fs from 'node:fs';

// bigint → number (valores em centavos cabem com folga); numeric continua string e é convertido onde usado
pg.types.setTypeParser(20, (v) => Number(v));
pg.types.setTypeParser(1082, (v) => v); // date como 'AAAA-MM-DD' (sem fuso)

let pool;
export function getPool() {
  if (!pool) {
    const url = process.env.DATABASE_URL;
    if (!url) throw new Error('DATABASE_URL não configurada');
    const local = /localhost|127\.0\.0\.1|host=\//.test(url);
    pool = new pg.Pool({ connectionString: url, max: Number(process.env.PG_POOL_MAX || 3), ssl: local || process.env.PGSSL === 'off' ? false : { rejectUnauthorized: false } });
  }
  return pool;
}
export const q = (text, params) => getPool().query(text, params);

export async function tx(fn) {
  const c = await getPool().connect();
  try {
    await c.query('begin');
    const r = await fn(c);
    await c.query('commit');
    return r;
  } catch (e) {
    try { await c.query('rollback'); } catch (_) { /* conexão já caiu */ }
    throw e;
  } finally { c.release(); }
}

export async function migrate() {
  const dir = new URL('../db/migrations/', import.meta.url);
  await q('create table if not exists _migrations (nome text primary key, at timestamptz not null default now())');
  const feitas = new Set((await q('select nome from _migrations')).rows.map((r) => r.nome));
  for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.sql')).sort()) {
    if (feitas.has(f)) continue;
    await tx(async (c) => {
      await c.query(fs.readFileSync(new URL(f, dir), 'utf8'));
      await c.query('insert into _migrations (nome) values ($1)', [f]);
    });
  }
}

export async function closePool() { if (pool) { await pool.end(); pool = null; } }
