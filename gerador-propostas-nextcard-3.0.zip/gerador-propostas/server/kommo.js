// Cliente Kommo (somente servidor). O token nunca vai ao navegador.
//
// ATENÇÃO — PENDENTE DE VALIDAÇÃO: os caminhos e formatos abaixo seguem a Files API da Kommo como
// conhecida na data do desenvolvimento, mas NÃO foram conferidos contra developers.kommo.com
// (o ambiente de desenvolvimento não tinha acesso ao domínio) nem testados em uma conta real.
// Antes de ativar em produção: conferir cada chamada marcada com [VALIDAR] e rodar o roteiro de
// homologação de docs/KOMMO_INTEGRATION.md em um negócio de teste.
//
// Variáveis: KOMMO_SUBDOMAIN (ex.: nextcard), KOMMO_TOKEN (token de longa duração da integração privada),
// KOMMO_BASE_URL (opcional, para testes).

const cfg = () => {
  const base = process.env.KOMMO_BASE_URL || (process.env.KOMMO_SUBDOMAIN ? `https://${process.env.KOMMO_SUBDOMAIN}.kommo.com` : null);
  return { base, token: process.env.KOMMO_TOKEN || null };
};
export const kommoAtivo = () => { const c = cfg(); return !!(c.base && c.token); };
export const kommoLeadUrl = (id) => { const c = cfg(); return c.base ? `${c.base}/leads/detail/${id}` : null; };

export class KommoError extends Error {
  constructor(msg, status, etapa) { super(msg); this.status = status; this.etapa = etapa; }
}

async function chamada(url, { method = 'GET', body, headers = {}, etapa = 'api', raw = false } = {}) {
  const c = cfg();
  if (!c.base || !c.token) throw new KommoError('Integração Kommo não configurada', 0, 'config');
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 25000);
  let res;
  try {
    res = await fetch(url, {
      method, signal: ctrl.signal,
      headers: { Authorization: `Bearer ${c.token}`, ...(body && !raw ? { 'Content-Type': 'application/json' } : {}), ...headers },
      body: body ? (raw ? body : JSON.stringify(body)) : undefined,
    });
  } catch (e) {
    throw new KommoError(e.name === 'AbortError' ? 'Kommo não respondeu a tempo' : 'Falha de rede ao falar com o Kommo', 0, etapa);
  } finally { clearTimeout(t); }
  if (res.status === 204) return null;
  const txt = await res.text();
  let json = null;
  try { json = txt ? JSON.parse(txt) : null; } catch (_) { /* resposta não JSON */ }
  if (!res.ok) {
    const det = json?.detail || json?.title || json?.message || '';
    const msg = res.status === 401 ? 'Kommo recusou o token (401)' : res.status === 403 ? 'Sem permissão no Kommo (403)' : res.status === 429 ? 'Limite de requisições do Kommo atingido' : `Kommo respondeu ${res.status}`;
    throw new KommoError(det ? `${msg}: ${String(det).slice(0, 200)}` : msg, res.status, etapa);
  }
  return json;
}
const api = (path, o) => chamada(cfg().base + path, o);

let cache = { at: 0, pipelines: null, users: null, drive: null };
async function referencias() {
  if (cache.pipelines && Date.now() - cache.at < 10 * 60000) return cache;
  const [p, u] = await Promise.all([api('/api/v4/leads/pipelines'), api('/api/v4/users?limit=250')]);
  const pipelines = {}, etapas = {}, users = {};
  for (const pl of p?._embedded?.pipelines || []) { pipelines[pl.id] = pl.name; for (const s of pl._embedded?.statuses || []) etapas[`${pl.id}:${s.id}`] = s.name; }
  for (const x of u?._embedded?.users || []) users[x.id] = x.name;
  cache = { ...cache, at: Date.now(), pipelines, etapas, users };
  return cache;
}
export const limpaCacheKommo = () => { cache = { at: 0, pipelines: null, users: null, drive: null }; };

function resumoLead(l, ref) {
  return {
    id: l.id, nome: l.name, valor: l.price ?? null,
    pipeline: ref.pipelines[l.pipeline_id] || String(l.pipeline_id || ''),
    etapa: ref.etapas[`${l.pipeline_id}:${l.status_id}`] || String(l.status_id || ''),
    responsavel: ref.users[l.responsible_user_id] || '',
    criadoEm: l.created_at ? new Date(l.created_at * 1000).toISOString() : null,
    contatos: (l._embedded?.contacts || []).map((c) => c.id),
    empresaId: l._embedded?.companies?.[0]?.id || null,
    url: kommoLeadUrl(l.id),
  };
}

// [VALIDAR] GET /api/v4/leads?query=&with=contacts — busca livre (nome, telefone, e-mail, empresa)
export async function buscarLeads(termo) {
  const s = String(termo || '').trim();
  if (s.length < 2) return [];
  const ref = await referencias();
  if (/^\d{5,}$/.test(s)) {
    try { const l = await api(`/api/v4/leads/${s}?with=contacts`); if (l) return [resumoLead(l, ref)]; } catch (e) { if (e.status !== 404 && e.status !== 400) throw e; }
  }
  const r = await api(`/api/v4/leads?limit=25&with=contacts&query=${encodeURIComponent(s)}`);
  return (r?._embedded?.leads || []).map((l) => resumoLead(l, ref));
}

const campo = (ent, code) => (ent?.custom_fields_values || []).find((f) => f.field_code === code)?.values?.[0]?.value || '';
// [VALIDAR] detalhes do negócio + contato principal + empresa (somente leitura; nada é sobrescrito no CRM)
export async function detalheLead(id) {
  const ref = await referencias();
  const l = await api(`/api/v4/leads/${Number(id)}?with=contacts`);
  if (!l) throw new KommoError('Negócio não encontrado no Kommo', 404, 'lead');
  const out = { ...resumoLead(l, ref), contato: null, empresa: null };
  const principal = (l._embedded?.contacts || []).find((c) => c.is_main) || l._embedded?.contacts?.[0];
  if (principal) { const c = await api(`/api/v4/contacts/${principal.id}`); if (c) out.contato = { id: c.id, nome: c.name || '', telefone: campo(c, 'PHONE'), email: campo(c, 'EMAIL') }; }
  if (out.empresaId) { const e = await api(`/api/v4/companies/${out.empresaId}`); if (e) out.empresa = { id: e.id, nome: e.name || '' }; }
  return out;
}

// [VALIDAR] GET /api/v4/account?with=drive_url → drive_url
async function driveUrl() {
  if (cache.drive) return cache.drive;
  const a = await api('/api/v4/account?with=drive_url', { etapa: 'drive' });
  if (!a?.drive_url) throw new KommoError('Conta Kommo sem drive_url (verifique o escopo de arquivos)', 0, 'drive');
  cache.drive = String(a.drive_url).replace(/\/$/, '');
  return cache.drive;
}

// [VALIDAR] POST {drive}/v1.0/sessions → { upload_url, max_part_size }; POST upload_url (binário) → { next_url } ou { uuid }
export async function enviarArquivo(nome, buffer, contentType = 'application/pdf') {
  const drive = await driveUrl();
  const s = await chamada(`${drive}/v1.0/sessions`, { method: 'POST', etapa: 'upload', body: { file_name: nome, file_size: buffer.length, content_type: contentType } });
  if (!s?.upload_url) throw new KommoError('Kommo não abriu a sessão de upload', 0, 'upload');
  const parte = Math.max(1, Number(s.max_part_size) || buffer.length);
  let url = s.upload_url, pos = 0, fim = null;
  while (pos < buffer.length) {
    const r = await chamada(url, { method: 'POST', etapa: 'upload', raw: true, body: buffer.subarray(pos, pos + parte), headers: { 'Content-Type': 'application/octet-stream' } });
    pos += parte;
    if (r?.uuid) { fim = r; break; }
    if (!r?.next_url) throw new KommoError('Upload interrompido pelo Kommo', 0, 'upload');
    url = r.next_url;
  }
  if (!fim?.uuid) throw new KommoError('Kommo não confirmou o arquivo enviado', 0, 'upload');
  return fim.uuid;
}

// [VALIDAR] PUT /api/v4/leads/{id}/files  corpo: [{ file_uuid }]
export const anexarAoLead = (leadId, fileUuid) => api(`/api/v4/leads/${Number(leadId)}/files`, { method: 'PUT', etapa: 'anexo', body: [{ file_uuid: fileUuid }] });

// [VALIDAR] GET /api/v4/leads/{id}/files → _embedded.files[].file_uuid
export async function arquivoNoLead(leadId, fileUuid) {
  const r = await api(`/api/v4/leads/${Number(leadId)}/files?limit=250`, { etapa: 'verificacao' });
  return (r?._embedded?.files || []).some((f) => f.file_uuid === fileUuid);
}
