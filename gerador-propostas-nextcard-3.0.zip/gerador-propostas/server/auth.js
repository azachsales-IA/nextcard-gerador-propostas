import crypto from 'node:crypto';
import { q } from './db.js';

const SESSAO_DIAS = 14;
const MAX_FALHAS = 8;
const BLOQUEIO_MIN = 15;
export const COOKIE = 'nx_s';

export function hashSenha(senha) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(String(senha), salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64')}$${h.toString('base64')}`;
}
export function confereSenha(senha, hash) {
  const [alg, s, h] = String(hash || '').split('$');
  if (alg !== 'scrypt' || !s || !h) return false;
  const esperado = Buffer.from(h, 'base64');
  const got = crypto.scryptSync(String(senha), Buffer.from(s, 'base64'), esperado.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(got, esperado);
}
export function senhaForte(s) {
  return typeof s === 'string' && s.length >= 10 && /[a-zA-Z]/.test(s) && /\d/.test(s);
}
const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');

export function publico(u) {
  return { id: u.id, email: u.email, nome: u.nome, sigla: u.sigla, telefone: u.telefone, roles: u.roles, ativo: u.ativo };
}

export async function login(email, senha) {
  const r = await q('select * from users where lower(email) = lower($1)', [String(email || '').trim()]);
  const u = r.rows[0];
  // mesma resposta para usuário inexistente e senha errada
  if (!u || !u.ativo) { confereSenha(senha, hashSenha('x')); return { erro: 'credenciais' }; }
  if (u.bloqueado_ate && new Date(u.bloqueado_ate) > new Date()) return { erro: 'bloqueado' };
  if (!confereSenha(senha, u.pass_hash)) {
    const f = u.falhas_login + 1;
    await q('update users set falhas_login = $2, bloqueado_ate = $3 where id = $1', [u.id, f >= MAX_FALHAS ? 0 : f, f >= MAX_FALHAS ? new Date(Date.now() + BLOQUEIO_MIN * 60000) : null]);
    return { erro: 'credenciais' };
  }
  await q('update users set falhas_login = 0, bloqueado_ate = null where id = $1', [u.id]);
  const token = crypto.randomBytes(32).toString('base64url');
  const exp = new Date(Date.now() + SESSAO_DIAS * 864e5);
  await q('insert into sessions (token_hash, user_id, expires_at) values ($1, $2, $3)', [sha(token), u.id, exp]);
  await q('delete from sessions where expires_at < now()');
  return { user: publico(u), token, exp };
}

export async function usuarioDaSessao(token) {
  if (!token) return null;
  const r = await q('select u.* from sessions s join users u on u.id = s.user_id where s.token_hash = $1 and s.expires_at > now() and u.ativo', [sha(token)]);
  return r.rows[0] || null;
}
export const logout = (token) => (token ? q('delete from sessions where token_hash = $1', [sha(token)]) : null);
export const encerraSessoes = (userId) => q('delete from sessions where user_id = $1', [userId]);

export function cookieSessao(token, exp, seguro) {
  return `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Expires=${exp.toUTCString()}${seguro ? '; Secure' : ''}`;
}
export const cookieLimpo = (seguro) => `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${seguro ? '; Secure' : ''}`;
export function lerCookie(req) {
  const m = String(req.headers.cookie || '').match(new RegExp(`(?:^|;\\s*)${COOKIE}=([^;]+)`));
  return m ? m[1] : null;
}

export const tem = (u, ...roles) => !!u && roles.some((r) => (u.roles || []).includes(r));
