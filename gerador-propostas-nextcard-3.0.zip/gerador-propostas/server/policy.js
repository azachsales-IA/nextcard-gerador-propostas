// Regras comerciais verificadas no servidor (funções puras, testáveis sem banco).
// O navegador nunca é a fonte do preço oficial: cada linha é recalculada a partir da configuração publicada.
import crypto from 'node:crypto';
import { totemPreco, comandaFaixa, isNil, calcNextcard, calcTeloos } from '../src/core.js';

// Dia corrente no fuso de Brasília (AAAA-MM-DD): vigências de alçada seguem o calendário comercial
export const diaBR = (d = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo' }).format(d);
const CATALOGO = ['totem', 'catraca', 'comanda', 'servico', 'plano', 'adicional', 'implantacao'];
const LIVRES = ['avulso', 'frete'];
const inteiro = (v) => Number.isInteger(v) && v >= 0;

function fatorModalidade(prop, cfg) {
  const m = (cfg.nextcard?.modalidades || []).find((x) => x.id === prop.modalidade);
  return m && !isNil(m.fatorTotem) ? m.fatorTotem : 1;
}

// Preço oficial unitário (centavos) da linha, ou { erro } quando o item não existe no catálogo vigente.
export function precoOficial(linha, prop, cfg) {
  const N = cfg.nextcard || {}, T = cfg.teloos || {};
  const by = (lista, id) => (lista || []).find((x) => x.id === id);
  switch (linha.kind) {
    case 'totem': {
      const cheio = totemPreco(N.totem, linha.config || {});
      if (isNil(cheio)) return { erro: 'modelo de totem fora do catálogo' };
      for (const g of ['sistema', 'pinpad', 'leitor', 'impressora', 'adesivagem']) {
        const id = linha.config?.[g];
        if (!isNil(id) && !by(N.totem.opcoes[g], id)) return { erro: `opção de totem inválida (${g})` };
      }
      return { cheio, oficial: Math.round(cheio * fatorModalidade(prop, cfg)) };
    }
    case 'catraca': { const c = by(N.catracas, linha.refId); return c ? { cheio: c.cents, oficial: c.cents } : { erro: 'catraca fora do catálogo' }; }
    case 'comanda': {
      const c = by(N.comandas, linha.refId);
      if (!c) return { erro: 'comanda fora do catálogo' };
      const f = comandaFaixa(c.tiers, linha.qtd);
      return f ? { cheio: f.cents, oficial: f.cents, tiers: c.tiers } : { erro: 'comanda sem faixa de preço' };
    }
    case 'servico': { const s = by(N.servicos, linha.refId); return s ? { cheio: s.cents, oficial: s.cents } : { erro: 'serviço fora do catálogo' }; }
    case 'plano': {
      const p = by(T.planos, linha.refId);
      if (!p) return { erro: 'plano fora do catálogo' };
      return { cheio: p.cents, oficial: p.cents, comCupom: Math.round(p.cents * (1 - (prop.teloos?.cupom || 0) / 100)) };
    }
    case 'adicional': {
      const a = by(T.adicionais, linha.refId);
      if (!a) return { erro: 'adicional fora do catálogo' };
      const c = a.cents ?? 0;
      return { cheio: c, oficial: c, comCupom: Math.round(c * (1 - (prop.teloos?.cupom || 0) / 100)) };
    }
    case 'implantacao': { const i = by(T.implantacao, linha.refId); return i ? { cheio: i.cents, oficial: i.cents } : { erro: 'implantação fora do catálogo' }; }
    default: return { erro: 'tipo de item desconhecido' };
  }
}

// Recalcula a proposta contra a configuração oficial.
// Retorna a proposta normalizada (preços de tabela regravados), erros que impedem a emissão e a análise de desconto.
export function analisar(propIn, cfg) {
  const prop = JSON.parse(JSON.stringify(propIn || {}));
  const erros = [];
  const motivos = [];
  if (!['nextcard', 'teloos'].includes(prop.empresa)) erros.push('empresa inválida');
  if (!Array.isArray(prop.itens) || !prop.itens.length) erros.push('a proposta não tem itens');
  if (erros.length) return { prop, erros, motivos, base: 0, desconto: 0, pct: 0, kindsComDesconto: [], exigeAprovacao: false };

  const cupons = cfg.teloos?.cupons || [0];
  if (prop.empresa === 'teloos' && !cupons.includes(prop.teloos?.cupom || 0)) erros.push('cupom inexistente na política');
  if (prop.empresa === 'nextcard' && !(cfg.nextcard.modalidades || []).some((m) => m.id === prop.modalidade)) erros.push('modalidade inválida');

  let base = 0, desconto = 0;
  const kinds = new Set();
  let temAvulso = false;
  prop.itens = prop.itens.map((l, i) => {
    const rot = l.nome || `item ${i + 1}`;
    if (!Number.isInteger(l.qtd) || l.qtd < 0 || l.qtd > 1e6) { erros.push(`quantidade inválida em ${rot}`); return l; }
    if (!isNil(l.preco) && !inteiro(l.preco)) { erros.push(`preço inválido em ${rot}`); return l; }
    if (LIVRES.includes(l.kind)) {
      if (!inteiro(l.tabela ?? 0)) { erros.push(`valor inválido em ${rot}`); return l; }
      if (l.kind === 'avulso') temAvulso = true;
      return { ...l, tabela: l.tabela ?? 0, piso: 'zero' };
    }
    if (!CATALOGO.includes(l.kind)) { erros.push(`tipo de item desconhecido em ${rot}`); return l; }
    const o = precoOficial(l, prop, cfg);
    if (o.erro) { erros.push(`${rot}: ${o.erro}`); return l; }
    const tabela = isNil(o.comCupom) ? o.oficial : o.comCupom;
    const unit = isNil(l.preco) ? tabela : l.preco;
    base += o.oficial * l.qtd;
    if (unit < o.oficial) { desconto += (o.oficial - unit) * l.qtd; kinds.add(l.kind); }
    const n = { ...l, tabela, tabelaCheia: o.cheio };
    if (o.tiers) { n.tiers = o.tiers.map((t) => ({ ...t })); delete n.tabela; delete n.tabelaCheia; }
    return n;
  });

  let calc = null;
  if (!erros.length) {
    const pg = prop.pagamento || {};
    for (const [k, v] of Object.entries(pg.entradas || {})) if (!isNil(v) && !(Number.isFinite(v) && v >= 0 && v <= 100)) erros.push(`entrada inválida em ${k}`);
    if (prop.empresa === 'nextcard') {
      const ids = new Set(cfg.nextcard.condicoes.map((c) => c.id));
      for (const c of pg.condicoes || []) if (!ids.has(c)) erros.push(`condição de pagamento inexistente: ${c}`);
      calc = calcNextcard(prop, cfg);
      for (const [k, v] of Object.entries(pg.overrides || {})) {
        if (isNil(v) || !(pg.condicoes || []).includes(k)) continue;
        if (!inteiro(v)) { erros.push(`valor inválido na condição ${k}`); continue; }
        // Nenhuma condição pode ficar abaixo do valor à vista: seria um desconto disfarçado.
        if (v < calc.valorFinal) motivos.push({ tipo: 'condicao_abaixo_avista', condicao: k, valor: v, minimo: calc.valorFinal });
      }
    } else {
      const ids = new Set(cfg.teloos.periodicidades.map((c) => c.id));
      for (const c of pg.periodicidades || []) if (!ids.has(c)) erros.push(`periodicidade inexistente: ${c}`);
      calc = calcTeloos(prop, cfg);
    }
  }
  const pct = base > 0 ? (desconto / base) * 100 : 0;
  if (desconto > 0) motivos.push({ tipo: 'desconto', pct: Number(pct.toFixed(4)), valor: desconto, base });
  if (temAvulso) motivos.push({ tipo: 'item_fora_do_catalogo' });
  return { prop, erros, motivos, base, desconto, pct, kindsComDesconto: [...kinds], temAvulso, calc, valorFinal: calc ? calc.valorFinal : 0 };
}

// Alçada vigente que cobre o desconto (ou null). `alcadas`: linhas da tabela já filtradas por usuário.
export function alcadaQueCobre(analise, alcadas, hoje = new Date()) {
  const dia = diaBR(hoje);
  const vig = (alcadas || []).filter((a) => !a.revogada_em && String(a.inicio).slice(0, 10) <= dia && (!a.fim || String(a.fim).slice(0, 10) >= dia));
  const cobre = vig.filter((a) => Number(a.pct) + 1e-9 >= analise.pct && (!a.kinds || analise.kindsComDesconto.every((k) => a.kinds.includes(k))));
  cobre.sort((a, b) => Number(a.pct) - Number(b.pct));
  return cobre[0] || null;
}
export function limiteVigente(alcadas, hoje = new Date()) {
  const dia = diaBR(hoje);
  return (alcadas || []).filter((a) => !a.revogada_em && String(a.inicio).slice(0, 10) <= dia && (!a.fim || String(a.fim).slice(0, 10) >= dia))
    .reduce((m, a) => Math.max(m, Number(a.pct)), 0);
}

// Decide se a emissão pode seguir. Sem alçada = limite zero. Itens livres e condição abaixo do à vista sempre pedem aprovação.
export function decidir(analise, { alcadas = [], aprovador = false, exigeAprovacaoAvulso = true } = {}) {
  if (analise.erros.length) return { ok: false, bloqueio: 'invalida', erros: analise.erros };
  const pend = [];
  let alcada = null;
  for (const m of analise.motivos) {
    if (m.tipo === 'desconto') { alcada = alcadaQueCobre(analise, alcadas); if (!alcada) pend.push(m); }
    else if (m.tipo === 'item_fora_do_catalogo') { if (exigeAprovacaoAvulso) pend.push(m); }
    else pend.push(m);
  }
  if (!pend.length) return { ok: true, alcada, via: alcada ? 'alcada' : 'tabela' };
  if (aprovador) return { ok: true, alcada: null, via: 'aprovador', pendencias: pend };
  return { ok: false, bloqueio: 'aprovacao', pendencias: pend, limite: limiteVigente(alcadas) };
}

// Impressão digital do que foi aprovado: qualquer mudança de item, preço ou condição invalida a aprovação.
export function fingerprint(prop, analise) {
  const itens = (analise.prop.itens || []).map((l) => [l.kind, l.refId ?? null, l.config ?? null, l.qtd, isNil(l.preco) ? null : l.preco, LIVRES.includes(l.kind) ? [l.nome, l.tabela] : null]);
  const pg = prop.pagamento || {};
  const ov = Object.entries(pg.overrides || {}).filter(([, v]) => !isNil(v)).sort();
  const dados = [prop.empresa, prop.modalidade ?? null, prop.teloos?.cupom ?? 0, itens, [...(pg.condicoes || [])].sort(), [...(pg.periodicidades || [])].sort(), ov];
  return crypto.createHash('sha256').update(JSON.stringify(dados)).digest('hex');
}

// Código comercial: DDMMAAAA/SEQ+SUFIXO, com a data de emissão no fuso de Brasília.
export function codigoComercial(data, seq, sufixo) {
  const p = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', year: 'numeric' }).formatToParts(data);
  const g = (t) => p.find((x) => x.type === t).value;
  return `${g('day')}${g('month')}${g('year')}/${seq}${String(sufixo || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3)}`;
}
export const nomeArquivoSeguro = (numero) => `Proposta_${String(numero).replace(/[^A-Za-z0-9]+/g, '_')}.pdf`;

// Validação estrutural mínima da configuração antes de publicar (evita NaN, negativos e listas quebradas).
export function validarConfig(c) {
  const e = [];
  const num = (v, rot, { nulo = false } = {}) => { if (isNil(v)) { if (!nulo) e.push(`${rot}: valor ausente`); } else if (!Number.isFinite(v) || v < 0) e.push(`${rot}: valor inválido`); };
  if (!c || typeof c !== 'object' || !c.nextcard || !c.teloos) return ['estrutura de configuração inválida'];
  const N = c.nextcard, T = c.teloos;
  const ids = (lista, rot) => { const s = new Set(); for (const x of lista || []) { if (!x.id) e.push(`${rot}: item sem identificador`); if (s.has(x.id)) e.push(`${rot}: identificador repetido (${x.id})`); s.add(x.id); } };
  if (!Array.isArray(N.condicoes) || !N.condicoes.length) e.push('condições de pagamento ausentes');
  ids(N.condicoes, 'condições');
  for (const k of N.condicoes || []) { num(k.fator, `fator de ${k.nome}`, { nulo: true }); if (!isNil(k.fator) && k.fator < 1) e.push(`fator de ${k.nome} abaixo de 1 (seria desconto)`); num(k.parcelas, `parcelas de ${k.nome}`); num(k.entradaPadrao ?? 0, `entrada de ${k.nome}`); }
  if (!N.totem?.modelos?.length) e.push('modelos de totem ausentes');
  ids(N.totem?.modelos, 'totens');
  for (const m of N.totem?.modelos || []) num(m.base, `base do totem ${m.id}`);
  for (const [g, ops] of Object.entries(N.totem?.opcoes || {})) { ids(ops, `opções ${g}`); for (const o of ops) num(o.valor, `opção ${o.id}`); }
  ids(N.catracas, 'catracas'); for (const x of N.catracas || []) num(x.cents, `catraca ${x.id}`);
  ids(N.servicos, 'serviços'); for (const x of N.servicos || []) num(x.cents, `serviço ${x.id}`);
  ids(N.comandas, 'comandas'); for (const x of N.comandas || []) for (const t of x.tiers || []) num(t.cents, `comanda ${x.id}`);
  for (const m of N.modalidades || []) num(m.fatorTotem ?? 1, `modalidade ${m.id}`);
  ids(T.planos, 'planos'); for (const x of T.planos || []) num(x.cents, `plano ${x.id}`);
  ids(T.adicionais, 'adicionais'); for (const x of T.adicionais || []) num(x.cents, `adicional ${x.id}`, { nulo: true });
  ids(T.periodicidades, 'periodicidades'); for (const x of T.periodicidades || []) { num(x.fator, `periodicidade ${x.id}`); num(x.meses, `meses de ${x.id}`); }
  ids(T.implantacao, 'implantação'); for (const x of T.implantacao || []) num(x.cents, `implantação ${x.id}`);
  for (const x of T.cupons || []) if (!Number.isFinite(x) || x < 0 || x > 100) e.push('cupom inválido');
  return e;
}
