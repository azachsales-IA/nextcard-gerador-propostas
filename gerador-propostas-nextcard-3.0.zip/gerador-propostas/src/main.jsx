import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './ui/App.jsx';
import { ensureFonts } from './render.js';

class Boundary extends React.Component {
  constructor(p) { super(p); this.state = { err: null }; }
  static getDerivedStateFromError(err) { return { err }; }
  render() {
    if (this.state.err) return (
      <div style={{ padding: 40, fontFamily: 'Inter, sans-serif', color: '#fff' }}>
        <h2>Algo deu errado.</h2>
        <p style={{ opacity: .7 }}>{String(this.state.err && this.state.err.message)}</p>
        <button onClick={() => location.reload()} style={{ marginTop: 12, padding: '8px 14px' }}>Recarregar</button>
      </div>
    );
    return this.props.children;
  }
}
ensureFonts();
createRoot(document.getElementById('root')).render(<Boundary><App /></Boundary>);
