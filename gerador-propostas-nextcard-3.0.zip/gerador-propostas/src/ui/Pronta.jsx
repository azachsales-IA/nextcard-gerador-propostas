// Tela "Proposta pronta": prévia final, mensagem e envio (WhatsApp, download, cópia).
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Icon, Btn, Tag, Chips, Menu } from './common.jsx';
import { buildModel, renderPeca, renderPaginasPDF, canvasToBlob, downloadBlob, pdfBlob, temasProposta, temaDe } from '../render.js';
import { PHOTOS } from '../fotos.js';
import { fmtBRL, linhaCurtaCondicao, waNumero, diaSemana, validadeDe } from '../core.js';
import { ETAPAS } from '../defaults.js';
import * as api from '../api.js';

const REMOTO = api.REMOTO;
const nomePdf = (numero) => `Proposta_${String(numero).replace(/[^A-Za-z0-9]+/g, '_')}.pdf`;
const MAX_PDF = 4.2 * 1024 * 1024;

export function slug(s) {
  return String(s || 'proposta').normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'proposta';
}

// Mensagem padrão que acompanha a imagem (editável)
export function mensagemPadrao(prop, cfg, model) {
  const c = prop.cliente || {};
  const primeiro = (c.contato || '').trim().split(/\s+/)[0];
  const linhas = [`Olá${primeiro ? ', ' + primeiro : ''}! Tudo bem?`, ''];
  const val = validadeDe(prop, cfg[prop.empresa].empresa.validadePadrao);
  if (prop.empresa === 'teloos') {
    const r = model.calc;
    linhas.push(`Segue a proposta${prop.numero ? ' nº ' + prop.numero : ''}${c.empresa ? ' para ' + c.empresa : ''}: ${model.titulo}.`);
    linhas.push(`• Mensalidade: ${fmtBRL(r.mensal)}/mês`);
    const d = model.destaque;
    if (d && d.id !== 'mensal') linhas.push(`• ${d.curto.charAt(0).toUpperCase() + d.curto.slice(1)}`);
    if (r.unicos.length) linhas.push(`• Implantação e treinamento: ${r.implantacao === 0 ? 'inclusos' : fmtBRL(r.implantacao) + ' à vista'}${model.implLimite ? ` (condição válida até ${model.implLimite})` : ''}`);
    linhas.push('• Sem fidelidade');
  } else {
    const r = model.calc;
    linhas.push(`Segue a proposta${prop.numero ? ' nº ' + prop.numero : ''}${c.empresa ? ' para ' + c.empresa : ''}: ${model.titulo}.`);
    linhas.push(`• ${fmtBRL(r.valorFinal)} à vista no PIX`);
    const disp = r.condicoes.filter((k) => k.disponivel && k.tipo !== 'avista');
    const dest = disp.find((k) => k.id === prop.pagamento?.destaque);
    for (const k of dest ? [dest, ...disp.filter((x) => x !== dest)] : disp) linhas.push(`• ou ${fmtBRL(k.total)}: ${linhaCurtaCondicao(k)}${k.mediante ? ' (mediante aprovação)' : ''}`);
    if (model.frete === 'CIF') linhas.push('• Frete incluso');
  }
  linhas.push(`• Válida por ${val.label}, até ${diaSemana(val.data)}, ${val.dataTxt}`);
  linhas.push('', 'O detalhamento completo está no PDF. Fico à disposição para qualquer ajuste.');
  if (prop.responsavel) linhas.push('', prop.responsavel);
  return linhas.join('\n');
}

const mobile = () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(pointer: coarse)').matches;

// Com servidor: a proposta emitida é desenhada com a configuração da versão em que foi emitida (não a de hoje).
export default function Pronta(props) {
  const { prop, cfg, cfgVersion } = props;
  const v = prop._srv?.configVersion;
  const [hist, setHist] = useState(null);
  useEffect(() => {
    let vivo = true;
    setHist(null);
    if (REMOTO && v && v !== cfgVersion) api.getConfigVersao(v).then((d) => { if (vivo) setHist({ v, data: d }); }).catch((e) => props.toast(e.message, 'warn'));
    return () => { vivo = false; };
  }, [v, cfgVersion]);
  const precisa = REMOTO && v && v !== cfgVersion;
  if (precisa && (!hist || hist.v !== v)) return <div className="preview-loading"><span className="spinner" /> Carregando a proposta como foi emitida…</div>;
  const resp = prop.responsavelContato ? [prop.responsavelContato] : [];
  const cfgUso = precisa ? { ...hist.data, responsaveis: [...resp, ...(cfg.responsaveis || [])] } : resp.length ? { ...cfg, responsaveis: [...resp, ...(cfg.responsaveis || [])] } : cfg;
  return <ProntaInner {...props} cfg={cfgUso} />;
}

function ProntaInner({ prop, cfg, fotos, toast, onEditar, onNova, onDuplicar, onEtapa, onAjuste, onSrv }) {
  const srv = prop._srv || {};
  const [kommo, setKommo] = useState({ estado: 'parado', erro: null });
  const [versoes, setVersoes] = useState(null);
  const [imgs, setImgs] = useState(null);
  const [page, setPage] = useState(0);
  const [blobs, setBlobs] = useState({});
  const [busy, setBusy] = useState(false);
  const [envio, setEnvio] = useState(null); // passos do envio no computador (fica na tela, não some)
  const model = useMemo(() => buildModel(prop, cfg, fotos, PHOTOS), [prop, cfg, fotos]);
  const [msg, setMsg] = useState(() => mensagemPadrao(prop, cfg, model));
  const msgKey = useRef(prop.id + prop.versao);
  useEffect(() => { if (msgKey.current !== prop.id + prop.versao) { msgKey.current = prop.id + prop.versao; setMsg(mensagemPadrao(prop, cfg, model)); } }, [prop.id, prop.versao]);

  const renderKey = `${prop.id}:${prop.versao}:${prop.emitidaEm}:${prop.temaProposta || 'escuro'}`;
  useEffect(() => {
    let alive = true;
    setImgs(null); setPage(0); setBlobs({}); setEnvio(null);
    (async () => {
      try {
        const peca = await renderPeca(model, cfg, 1, { modo: 'imagem' });
        const paginas = await renderPaginasPDF(model, cfg, 1);
        if (!alive) return;
        setImgs([peca.toDataURL('image/jpeg', 0.9), ...paginas.map((d) => d.toDataURL('image/jpeg', 0.85))]);
        const jpg = await canvasToBlob(peca, 'image/jpeg', 0.92);
        const png = await canvasToBlob(peca, 'image/png');
        if (!alive) return;
        setBlobs((b) => ({ ...b, jpg, png }));
        let pdf = await pdfBlob(await renderPaginasPDF(model, cfg, 1.5));
        if (REMOTO && pdf.size > MAX_PDF) pdf = await pdfBlob(await renderPaginasPDF(model, cfg, 1.1)); // limite de envio do servidor
        if (alive) setBlobs((b) => ({ ...b, pdf }));
      } catch (e) {
        console.error(e);
        toast('Erro ao desenhar a proposta: ' + e.message, 'warn');
      }
    })();
    return () => { alive = false; };
  }, [renderKey]);

  // Guarda o PDF emitido no servidor (uma vez por versão) e, com negócio vinculado, anexa ao Kommo.
  const anexar = async () => {
    if (!prop.kommo?.leadId) return;
    setKommo({ estado: 'enviando', erro: null });
    try {
      const r = await api.anexarKommo(prop.id, prop.versao, prop.kommo.leadId, prop.kommo.nome);
      onSrv && onSrv({ kommo: { leadId: prop.kommo.leadId, nome: prop.kommo.nome, url: r.url, status: 'anexado', anexadoEm: r.anexadoEm } });
      setKommo({ estado: 'anexado', erro: null, em: r.anexadoEm });
    } catch (e) {
      onSrv && onSrv({ kommo: { leadId: prop.kommo.leadId, nome: prop.kommo.nome, url: prop.kommo.url, status: 'falha', erro: e.message } });
      setKommo({ estado: 'falha', erro: e.message });
    }
  };
  const guardou = useRef(null);
  useEffect(() => {
    if (!REMOTO || !prop.numero || !blobs.pdf) return;
    const chave = `${prop.id}:${prop.versao}`;
    if (guardou.current === chave) return;
    guardou.current = chave;
    (async () => {
      try {
        if (!srv.temPdf) { await api.putPdf(prop.id, prop.versao, blobs.pdf); onSrv && onSrv({ temPdf: true }); }
        if (api.ctx.kommo && prop.kommo?.leadId && srv.kommo?.status !== 'anexado') await anexar();
      } catch (e) { guardou.current = null; toast(`O PDF ainda não foi guardado no servidor: ${e.message}`, 'warn'); }
    })();
  }, [blobs.pdf, prop.id, prop.versao]);
  useEffect(() => { setKommo({ estado: srv.kommo?.status === 'anexado' ? 'anexado' : srv.kommo?.status === 'falha' ? 'falha' : 'parado', erro: srv.kommo?.erro || null }); setVersoes(null); }, [prop.id, prop.versao]);
  // PDF oficial: sempre o arquivo guardado na emissão, idêntico ao que foi para o cliente e para o Kommo
  const baixarPdf = async (versao = prop.versao) => {
    if (REMOTO && prop.numero && (srv.temPdf || versao !== prop.versao)) {
      try { downloadBlob(await api.getPdf(prop.id, versao), nomePdf(prop.numero)); return; } catch (e) { if (versao !== prop.versao) { toast(e.message, 'warn'); return; } }
    }
    if (blobs.pdf) downloadBlob(blobs.pdf, REMOTO && prop.numero ? nomePdf(prop.numero) : base + '.pdf');
  };
  const compartilhou = () => {
    if (!REMOTO) { onEtapa('enviada', true); return; }
    // abrir o WhatsApp não confirma o envio: registra só que o compartilhamento começou
    api.situacao(prop.id, { compartilhamento: 'iniciado' }).then(() => onSrv && onSrv({ compartilhamento: 'iniciado' })).catch(() => {});
  };

  const base = `Proposta-${prop.empresa === 'teloos' ? 'Teloos' : 'NEXTCARD'}-${slug(prop.cliente?.empresa)}${prop.numero ? '-' + slug(prop.numero) : ''}`;
  const run = async (fn) => { setBusy(true); try { await fn(); } catch (e) { console.error(e); toast('Não foi possível concluir: ' + e.message, 'warn'); } setBusy(false); };
  const copiarImagem = async () => {
    if (!blobs.png || !navigator.clipboard || typeof window.ClipboardItem === 'undefined') return false;
    try { await navigator.clipboard.write([new window.ClipboardItem({ 'image/png': blobs.png })]); return true; } catch (e) { return false; }
  };
  const copiarTexto = async (t) => { try { await navigator.clipboard.writeText(t); return true; } catch (e) { return false; } };
  const tel = waNumero(prop.cliente?.telefone);
  const abrirWhats = () => window.open(`https://wa.me/${tel}?text=${encodeURIComponent(msg)}`, '_blank', 'noopener');

  const enviar = async () => {
    if (!blobs.jpg) return;
    const files = [new File([blobs.jpg], base + '.jpg', { type: 'image/jpeg' })];
    if (blobs.pdf) files.push(new File([blobs.pdf], base + '.pdf', { type: 'application/pdf' }));
    if (mobile() && navigator.canShare && navigator.canShare({ files })) {
      await copiarTexto(msg); // alguns apps descartam o texto junto com arquivos
      try {
        await navigator.share({ files, text: msg, title: base });
        compartilhou();
      } catch (e) {
        if (e && e.name !== 'AbortError') { abrirWhats(); compartilhou(); }
      }
      return;
    }
    const ok = await copiarImagem();
    if (!ok) downloadBlob(blobs.jpg, base + '.jpg'); // sem permissão para copiar: a imagem já sai baixada
    abrirWhats();
    setEnvio({ copiou: ok });
    compartilhou();
  };

  const pronto = !!blobs.jpg;
  const v = validadeDe(prop, cfg[prop.empresa].empresa.validadePadrao);
  return (
    <div className="ready">
      <section className="ready-prev">
        <div className="ready-tabs">
          {(imgs || [null]).map((_, i) => (
            <button key={i} type="button" className={page === i ? 'on' : ''} onClick={() => setPage(i)} disabled={!imgs}>
              {i === 0 ? 'Imagem (WhatsApp)' : `PDF · pág. ${i}`}
            </button>
          ))}
        </div>
        <div className="ready-stage">
          {imgs ? <img src={imgs[page]} alt="Proposta gerada" data-testid="preview-img" /> : <div className="preview-loading"><span className="spinner" /> Desenhando a proposta…</div>}
        </div>
      </section>

      <section className="ready-side">
        <div className="ready-head">
          <span className="ready-ok"><Icon n="check" s={20} w={2.6} /></span>
          <div>
            <span className="eyebrow">Proposta pronta</span>
            <h2>Nº {prop.numero}{prop.versao > 1 ? <small> · versão {prop.versao}</small> : null}</h2>
            <span className="muted small">{prop.cliente?.empresa || 'Cliente sem nome'} · válida até {diaSemana(v.data)}, {v.dataTxt}</span>
          </div>
        </div>

        <Btn variant="primary" icon="wa" className="btn-xl btn-block" onClick={() => run(enviar)} disabled={!pronto || busy}>
          {pronto ? 'Enviar pelo WhatsApp' : 'Preparando arquivos…'}
        </Btn>
        <p className="tiny muted ready-note">
          {mobile() ? 'Abre o compartilhamento do celular com a imagem e o PDF.' : tel ? `Abre a conversa com ${prop.cliente.telefone} e copia a imagem para colar.` : 'Sem WhatsApp do cliente: você escolhe o contato no WhatsApp.'}
        </p>
        {envio && (
          <div className="hint send-steps" data-testid={envio.copiou ? 'envio-passos' : 'envio-alternativo'} role="status">
            <Icon n={envio.copiou ? 'check' : 'info'} s={16} />
            <div>
              <b>{envio.copiou ? 'Imagem copiada. Na conversa do WhatsApp:' : 'Este navegador não deixou copiar a imagem, então ela foi baixada. Na conversa do WhatsApp:'}</b>
              <ol>
                {envio.copiou ? <li>cole a imagem (Ctrl+V; no Mac, ⌘V) e envie;</li> : <li>clique no clipe, escolha “Fotos e vídeos” e selecione a imagem baixada;</li>}
                <li>anexe também o PDF completo, como documento;</li>
                <li>a mensagem já vai preenchida na conversa.</li>
              </ol>
              <div className="row-gap">
                <Btn small icon="download" onClick={() => downloadBlob(blobs.jpg, base + '.jpg')}>{envio.copiou ? 'Baixar imagem' : 'Baixar imagem de novo'}</Btn>
                <Btn small icon="file" disabled={!blobs.pdf} onClick={() => baixarPdf()}>Baixar PDF</Btn>
                <button type="button" className="link tiny" onClick={() => setEnvio(null)}>fechar</button>
              </div>
            </div>
          </div>
        )}

        {REMOTO && (
          <div className={`kommo-card kommo-${kommo.estado}`} data-testid="kommo-status" data-estado={kommo.estado}>
            <Icon n={kommo.estado === 'anexado' ? 'check' : kommo.estado === 'falha' ? 'alert' : 'info'} s={16} />
            <div>
              {!api.ctx.kommo ? <><b>Kommo não configurado</b><span className="muted small">A integração ainda não foi ativada pelo administrador. O PDF fica guardado no histórico.</span></>
                : !prop.kommo?.leadId ? <><b>Sem negócio vinculado</b><span className="muted small">Para anexar ao Kommo, clique em Editar e escolha o negócio no passo Cliente.</span></>
                  : kommo.estado === 'anexado' ? <><b>Proposta emitida e anexada ao Kommo</b><span className="muted small">{prop.numero} · {prop.kommo.nome || `negócio #${prop.kommo.leadId}`}{srv.kommo?.anexadoEm || kommo.em ? ` · ${new Date(srv.kommo?.anexadoEm || kommo.em).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}` : ''} · {prop.responsavel}</span></>
                    : kommo.estado === 'falha' ? <><b>Falha ao anexar ao Kommo</b><span className="muted small">{kommo.erro}. A proposta, o número e o PDF estão preservados.</span></>
                      : kommo.estado === 'enviando' ? <><b>Anexando ao Kommo…</b><span className="muted small">{prop.kommo.nome || `negócio #${prop.kommo.leadId}`}</span></>
                        : <><b>Aguardando o PDF para anexar</b><span className="muted small">{prop.kommo.nome || `negócio #${prop.kommo.leadId}`}</span></>}
              <div className="row-gap">
                {api.ctx.kommo && prop.kommo?.leadId && kommo.estado === 'falha' && <Btn small variant="primary" onClick={anexar} data-testid="kommo-repetir">Tentar novamente</Btn>}
                {(srv.kommo?.url || prop.kommo?.url) && <a className="link small" href={srv.kommo?.url || prop.kommo.url} target="_blank" rel="noopener noreferrer">Abrir negócio no Kommo</a>}
              </div>
            </div>
          </div>
        )}
        {REMOTO && srv.compartilhamento === 'iniciado' && prop.etapa !== 'enviada' && (
          <p className="tiny muted">Compartilhamento iniciado. Quando confirmar que o cliente recebeu, marque a situação como “Enviada”.</p>
        )}

        <div className="ready-grid">
          <Btn icon="download" variant="line" disabled={!blobs.jpg} onClick={() => downloadBlob(blobs.jpg, base + '.jpg')}>Imagem JPG</Btn>
          <Btn icon="file" variant="line" disabled={!blobs.pdf} onClick={() => baixarPdf()} data-testid="baixar-pdf">{blobs.pdf ? 'PDF completo' : 'Gerando PDF…'}</Btn>
          <Btn icon="copy" disabled={!blobs.png} onClick={async () => toast((await copiarImagem()) ? 'Imagem copiada. Cole no WhatsApp.' : 'Este navegador não permite copiar imagem. Use “Imagem JPG”.', 'info')}>Copiar imagem</Btn>
          <Btn icon="download" disabled={!blobs.png} onClick={() => downloadBlob(blobs.png, base + '.png')}>Imagem PNG</Btn>
        </div>

        <div className="ready-msg">
          <div className="row-gap"><b className="small">Mensagem</b><span className="tiny muted">edite à vontade</span>
            <button type="button" className="link tiny" style={{ marginLeft: 'auto' }} onClick={async () => toast((await copiarTexto(msg)) ? 'Mensagem copiada' : 'Não foi possível copiar', 'info')}>copiar</button>
          </div>
          <textarea className="inp" rows={9} value={msg} onChange={(e) => setMsg(e.target.value)} aria-label="Mensagem para o cliente" />
          <button type="button" className="link tiny" onClick={() => setMsg(mensagemPadrao(prop, cfg, model))}>restaurar mensagem sugerida</button>
        </div>

        <div className="ready-tema" data-testid="tema-proposta-pronta">
          <span className="field-label">Tema da proposta (PDF e imagem)</span>
          <Chips size="sm" value={temaDe(prop.empresa, prop.temaProposta)} onChange={(v) => onAjuste && onAjuste({ temaProposta: v })} ariaLabel="Tema da proposta" options={temasProposta(prop.empresa)} />
        </div>

        <div className="ready-etapa">
          <span className="field-label">Situação da proposta</span>
          <Chips size="sm" value={prop.etapa} onChange={(e) => onEtapa(e)} options={ETAPAS.map((e) => ({ value: e.id, label: e.nome }))} />
        </div>

        {REMOTO && prop.versao > 1 && (
          <div className="ready-versoes">
            <button type="button" className="link small" onClick={async () => { try { setVersoes(versoes ? null : (await api.listVersoes(prop.id)).versoes); } catch (e) { toast(e.message, 'warn'); } }}>{versoes ? 'ocultar versões emitidas' : `ver as ${prop.versao} versões emitidas`}</button>
            {versoes && versoes.map((x) => (
              <div key={x.versao} className="row-gap small"><span>Versão {x.versao} · {new Date(x.emitida_em).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })} · {fmtBRL(x.valor_final)}</span>
                {x.tem_pdf && <button type="button" className="link small" onClick={() => baixarPdf(x.versao)}>baixar PDF</button>}</div>
            ))}
          </div>
        )}

        <div className="ready-foot">
          <Btn icon="edit" onClick={onEditar}>Editar</Btn>
          <Btn icon="duplicate" onClick={onDuplicar}>Duplicar</Btn>
          <Btn icon="plus" onClick={onNova}>Nova proposta</Btn>
        </div>
      </section>
    </div>
  );
}
