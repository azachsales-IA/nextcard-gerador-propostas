import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { fmtBRL, parseBRL, isNil } from '../core.js';

const P = {
  home: 'M3 11.5 12 4l9 7.5M5.5 9.8V20h13V9.8',
  grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
  plus: 'M12 5v14M5 12h14',
  kanban: 'M4 4h4v16H4zM10 4h4v10h-4zM16 4h4v13h-4z',
  book: 'M5 4h9a4 4 0 0 1 4 4v12H9a4 4 0 0 1-4-4zM5 16a3 3 0 0 1 3-3h10',
  gear: 'M12 8.5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7zM12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1',
  search: 'M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14zM20 20l-4-4',
  download: 'M12 4v11M7 10l5 5 5-5M5 20h14',
  copy: 'M9 9h10v11H9zM5 15V4h10',
  file: 'M6 3h8l4 4v14H6zM14 3v4h4',
  check: 'M5 12.5l4.5 4.5L19 7.5',
  x: 'M6 6l12 12M18 6 6 18',
  trash: 'M5 7h14M10 11v6M14 11v6M7 7l1 13h8l1-13M9 7V4h6v3',
  edit: 'M4 20h4L19 9l-4-4L4 16zM13 7l4 4',
  right: 'M9 5l7 7-7 7',
  left: 'M15 5l-7 7 7 7',
  list: 'M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01',
  image: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M15 9h.01',
  upload: 'M12 20V9M7 13l5-5 5 5M5 4h14',
  duplicate: 'M8 8h11v12H8zM5 16V4h11',
  spark: 'M12 3v5M12 16v5M3 12h5M16 12h5M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3',
  alert: 'M12 4 2.5 20h19zM12 10v5M12 18h.01',
  send: 'M4 12 20 4l-6 16-3-7z',
  bolt: 'M13 3 5 13h6l-1 8 8-10h-6z',
  cube: 'M12 3 20 7.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12v9M12 12 4 7.5',
  user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
  card: 'M3 6h18v12H3zM3 10h18',
  pix: 'M12 3 21 12 12 21 3 12z',
  info: 'M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18zM12 11v6M12 7.5h.01',
  dots: 'M5 12h.01M12 12h.01M19 12h.01',
  wa: 'M4 20l1.3-4A8 8 0 1 1 8 18.7zM9 9.5c0 3 2.5 5.5 5.5 5.5l1-1.5-2-1-1 1c-1-.5-2-1.5-2.5-2.5l1-1-1-2z',
  eye: 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12zM12 9a3 3 0 1 1 0 6 3 3 0 0 1 0-6z',
  star: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z',
  undo: 'M9 14 4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3',
  share: 'M16 6l-4-4-4 4M12 2v13M5 12v8h14v-8',
  calendar: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',
  truck: 'M3 6h11v10H3zM14 10h4l3 3v3h-7M7 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM17 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4z',
  gift: 'M4 11h16v9H4zM3 7h18v4H3zM12 7v13M12 7c-2-4-6-3-6 0M12 7c2-4 6-3 6 0',
  up: 'M6 15l6-6 6 6',
  down: 'M6 9l6 6 6-6',
  sun: 'M12 7.5a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9zM12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4',
  moon: 'M20 14.2A8.2 8.2 0 1 1 9.8 4a6.6 6.6 0 0 0 10.2 10.2z',
};
export function Icon({ n, s = 18, w = 1.8, style }) {
  return (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" style={style} aria-hidden="true">
      <path d={P[n] || P.info} />
    </svg>
  );
}

export function Btn({ children, variant = 'ghost', icon, onClick, disabled, title, type = 'button', small, className = '', ...rest }) {
  return (
    <button type={type} className={`btn btn-${variant}${small ? ' btn-sm' : ''} ${className}`} onClick={onClick} disabled={disabled} title={title} {...rest}>
      {icon && <Icon n={icon} s={small ? 15 : 17} />}
      {children && <span>{children}</span>}
    </button>
  );
}

// Campo com rótulo. É um grupo (div), não <label>: rótulos envolvendo botões (chips, +/−) disparariam o primeiro botão.
export function Field({ label, hint, children, span }) {
  const id = React.useId();
  const focusFirst = (e) => { const el = e.currentTarget.parentElement.querySelector('input:not([type=hidden]):not([type=checkbox]),select,textarea'); if (el) el.focus(); };
  return (
    <div className="field" role="group" aria-labelledby={id} style={span ? { gridColumn: `span ${span}` } : undefined}>
      <span className="field-label" id={id} onClick={focusFirst}>{label}</span>
      {children}
      {hint && <span className="field-hint">{hint}</span>}
    </div>
  );
}

export function Text({ value, onChange, placeholder, type = 'text', ...rest }) {
  return <input className="inp" type={type} value={value ?? ''} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} {...rest} />;
}

export function Select({ value, onChange, options, ...rest }) {
  return (
    <select className="inp" value={value ?? ''} onChange={(e) => onChange(e.target.value)} {...rest}>
      {options.map((o) => (
        <option key={o.value} value={o.value} disabled={o.disabled}>{o.label}</option>
      ))}
    </select>
  );
}

// Campo monetário: mantém texto enquanto edita, confirma no blur/enter.
// `min` = piso (se definido, valores abaixo voltam para o piso e disparam onFloor).
export function Money({ cents, onCommit, min, placeholder, onFloor, className = '', allowEmpty = false, ariaLabel }) {
  const [txt, setTxt] = useState(isNil(cents) ? '' : fmtBRL(cents, { noSymbol: true }));
  const [focus, setFocus] = useState(false);
  const initial = useRef('');
  useEffect(() => { if (!focus) setTxt(isNil(cents) ? '' : fmtBRL(cents, { noSymbol: true })); }, [cents, focus]);
  const commit = () => {
    if (txt === initial.current) return; // sem alteração: não grava nada
    const v = parseBRL(txt);
    if (isNil(v)) {
      if (allowEmpty) onCommit(null);
      else setTxt(isNil(cents) ? '' : fmtBRL(cents, { noSymbol: true }));
      return;
    }
    if (!isNil(min) && v < min) {
      onFloor && onFloor(min);
      onCommit(min);
      setTxt(fmtBRL(min, { noSymbol: true }));
      return;
    }
    onCommit(v);
  };
  return (
    <div className={`money ${className}`}>
      <span className="money-sym">R$</span>
      <input
        className="inp inp-money"
        inputMode="decimal"
        aria-label={ariaLabel}
        value={txt}
        placeholder={placeholder}
        onFocus={(e) => { initial.current = txt; setFocus(true); const t = e.target; setTimeout(() => t.select(), 0); }}
        onChange={(e) => setTxt(e.target.value)}
        onBlur={() => { setFocus(false); commit(); }}
        onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }}
      />
    </div>
  );
}

export function Qty({ value, onChange, min = 0, step = 1, ariaLabel }) {
  const [txt, setTxt] = useState(String(value ?? 0));
  useEffect(() => setTxt(String(value ?? 0)), [value]);
  const commit = (v) => {
    const n = Math.max(min, Math.floor(Number(String(v).replace(/\D/g, '')) || 0));
    onChange(n);
    setTxt(String(n));
  };
  return (
    <div className="qty">
      <button type="button" onClick={() => commit((value || 0) - step)} aria-label="diminuir">−</button>
      <input inputMode="numeric" aria-label={ariaLabel} value={txt} onChange={(e) => setTxt(e.target.value)} onBlur={(e) => commit(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }} />
      <button type="button" onClick={() => commit((value || 0) + step)} aria-label="aumentar">+</button>
    </div>
  );
}

// Diálogos (modal e folha): foco entra ao abrir, fica preso no Tab e volta ao botão de origem ao fechar.
const FOCAVEIS = 'a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';
function useFocoNoDialogo(open, ref) {
  useEffect(() => {
    if (!open) return;
    const origem = document.activeElement;
    const t = setTimeout(() => {
      const el = ref.current;
      if (!el || el.contains(document.activeElement)) return; // respeita autoFocus de um campo
      const corpo = el.querySelector('.modal-body, .sheet-body');
      const primeiro = (corpo && corpo.querySelector(FOCAVEIS)) || el.querySelector(FOCAVEIS);
      (primeiro || el).focus({ preventScroll: true });
    }, 0);
    const k = (e) => {
      const el = ref.current;
      if (e.key !== 'Tab' || !el) return;
      const f = [...el.querySelectorAll(FOCAVEIS)].filter((x) => x.getClientRects().length);
      if (!f.length) { e.preventDefault(); return; }
      const a = f[0], z = f[f.length - 1], at = document.activeElement;
      if (!el.contains(at)) { e.preventDefault(); (e.shiftKey ? z : a).focus(); }
      else if (e.shiftKey && at === a) { e.preventDefault(); z.focus(); }
      else if (!e.shiftKey && at === z) { e.preventDefault(); a.focus(); }
    };
    document.addEventListener('keydown', k);
    return () => {
      clearTimeout(t);
      document.removeEventListener('keydown', k);
      // devolve o foco só se ninguém o pegou (ex.: o construtor foca o campo da empresa ao abrir)
      const at = document.activeElement;
      if (origem && origem.focus && document.contains(origem) && (!at || at === document.body)) origem.focus({ preventScroll: true });
    };
  }, [open]);
}

export function Modal({ open, onClose, title, children, wide, footer }) {
  const ref = useRef();
  useFocoNoDialogo(open, ref);
  useEffect(() => {
    if (!open) return;
    const k = (e) => { if (e.key === 'Escape') onClose && onClose(); };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-back" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose && onClose(); }}>
      <div className={`modal ${wide ? 'modal-wide' : ''}`} ref={ref} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1}>
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="icon-btn" onClick={onClose} aria-label="Fechar"><Icon n="x" /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Tag({ children, tone = 'default' }) {
  return <span className={`tag tag-${tone}`}>{children}</span>;
}

export function Empty({ icon = 'spark', title, text, action }) {
  return (
    <div className="empty">
      <div className="empty-ico"><Icon n={icon} s={28} /></div>
      <h4>{title}</h4>
      {text && <p>{text}</p>}
      {action}
    </div>
  );
}

export function Seg({ value, onChange, options }) {
  return (
    <div className="seg" role="tablist">
      {options.map((o) => (
        <button key={o.value} role="tab" aria-selected={value === o.value} className={value === o.value ? 'on' : ''} onClick={() => onChange(o.value)} type="button">
          {o.icon && <Icon n={o.icon} s={15} />}
          <span>{o.label}</span>
        </button>
      ))}
    </div>
  );
}

export function Toggle({ checked, onChange, label }) {
  return (
    <label className="toggle">
      <input type="checkbox" checked={!!checked} onChange={(e) => onChange(e.target.checked)} />
      <span className="toggle-track"><span className="toggle-dot" /></span>
      {label && <span className="toggle-label">{label}</span>}
    </label>
  );
}

export function Check({ checked, onChange, children }) {
  return (
    <label className={`chk ${checked ? 'on' : ''}`}>
      <input type="checkbox" checked={!!checked} onChange={(e) => onChange(e.target.checked)} />
      <span className="chk-box"><Icon n="check" s={13} w={2.6} /></span>
      <span className="chk-txt">{children}</span>
    </label>
  );
}

export function Stat({ label, value, sub, tone }) {
  return (
    <div className={`stat ${tone ? 'stat-' + tone : ''}`}>
      <span className="stat-label">{label}</span>
      <span className="stat-value">{value}</span>
      {sub && <span className="stat-sub">{sub}</span>}
    </div>
  );
}

// Grupo de escolha única em "chips" (reconhecer em vez de lembrar).
// Teclado no padrão de grupo de rádio: um único ponto de Tab; setas, Home e End mudam a escolha.
const SETAS = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 };
export function Chips({ value, onChange, options, size = 'md', ariaLabel, wrap = true }) {
  const ref = useRef();
  const ativos = options.filter((o) => !o.disabled);
  const alvo = ativos.some((o) => o.value === value) ? value : ativos[0]?.value;
  const onKey = (e) => {
    const i = ativos.findIndex((o) => String(o.value) === e.target.dataset.v);
    if (i < 0) return;
    const n = e.key in SETAS ? (i + SETAS[e.key] + ativos.length) % ativos.length : e.key === 'Home' ? 0 : e.key === 'End' ? ativos.length - 1 : null;
    if (n === null) return;
    e.preventDefault();
    const o = ativos[n];
    if (o.value !== value) onChange(o.value);
    requestAnimationFrame(() => { const b = ref.current && [...ref.current.querySelectorAll('[role=radio]')].find((x) => x.dataset.v === String(o.value)); if (b) b.focus(); });
  };
  return (
    <div className={`chips chips-${size} ${wrap ? '' : 'nowrap'}`} role="radiogroup" aria-label={ariaLabel} ref={ref} onKeyDown={onKey}>
      {options.map((o) => (
        <button key={o.value} type="button" role="radio" aria-checked={value === o.value} disabled={o.disabled} data-v={String(o.value)} tabIndex={o.value === alvo ? 0 : -1}
          className={`chip ${value === o.value ? 'on' : ''}`} onClick={() => onChange(o.value)} title={o.title}>
          {o.img !== undefined && <span className="chip-img">{o.img ? <img src={o.img} alt="" /> : <Icon n="image" s={18} />}</span>}
          <span className="chip-main">{o.label}</span>
          {o.sub && <span className="chip-sub">{o.sub}</span>}
        </button>
      ))}
    </div>
  );
}

export function Disclosure({ label, children, defaultOpen = false, className = '' }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className={`disc ${open ? 'open' : ''} ${className}`}>
      <button type="button" className="disc-btn" onClick={() => setOpen(!open)} aria-expanded={open}>
        <Icon n="right" s={15} /><span>{label}</span>
      </button>
      {open && <div className="disc-body">{children}</div>}
    </div>
  );
}

export function DropZone({ onFile, children, accept = 'image/*' }) {
  const [over, setOver] = useState(false);
  return (
    <label className={`drop ${over ? 'over' : ''}`}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); const f = e.dataTransfer.files && e.dataTransfer.files[0]; if (f) onFile(f); }}>
      <input type="file" accept={accept} hidden onChange={(e) => { const f = e.target.files && e.target.files[0]; if (f) onFile(f); e.target.value = ''; }} />
      {children}
    </label>
  );
}

// Menu de ações (⋯). O menu abre num portal com posição fixa para não ser cortado pelos cartões chanfrados.
export function Menu({ items, label = 'Mais ações' }) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState(null);
  const btn = useRef();
  const pop = useRef();
  const posiciona = () => {
    if (!btn.current) return;
    const r = btn.current.getBoundingClientRect();
    if (r.bottom < 0 || r.top > window.innerHeight) { setOpen(false); return; }
    const h = pop.current ? pop.current.offsetHeight : 200;
    const up = r.bottom + h + 12 > window.innerHeight && r.top > h + 12;
    setPos({ top: up ? r.top - h - 6 : r.bottom + 6, right: Math.max(8, window.innerWidth - r.right) });
  };
  useLayoutEffect(() => { if (open) posiciona(); }, [open]);
  useEffect(() => {
    if (!open) return;
    const h = (e) => { if (!(btn.current && btn.current.contains(e.target)) && !(pop.current && pop.current.contains(e.target))) setOpen(false); };
    const k = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', h);
    document.addEventListener('keydown', k);
    window.addEventListener('scroll', posiciona, true); // acompanha a rolagem em vez de fechar
    window.addEventListener('resize', posiciona);
    return () => { document.removeEventListener('mousedown', h); document.removeEventListener('keydown', k); window.removeEventListener('scroll', posiciona, true); window.removeEventListener('resize', posiciona); };
  }, [open]);
  return (
    <div className="menu" onClick={(e) => e.stopPropagation()} onKeyDown={(e) => e.stopPropagation()}>
      <button type="button" ref={btn} className="icon-btn" aria-label={label} aria-haspopup="menu" aria-expanded={open} onClick={() => { setPos(null); setOpen(!open); }}><Icon n="dots" s={18} /></button>
      {open && createPortal(
        <div className="menu-pop" role="menu" ref={pop} style={pos ? { top: pos.top, right: pos.right } : { visibility: 'hidden', top: 0, right: 0 }} onClick={(e) => e.stopPropagation()}>
          {items.filter(Boolean).map((it, i) => it.sep ? <div key={i} className="menu-sep" /> : (
            <button key={i} type="button" role="menuitem" className={it.danger ? 'danger' : ''} onClick={() => { setOpen(false); it.onClick(); }}>
              {it.icon && <Icon n={it.icon} s={15} />}<span>{it.label}</span>
            </button>
          ))}
        </div>, document.body)}
    </div>
  );
}

export function Sheet({ open, onClose, title, children }) {
  const ref = useRef();
  useFocoNoDialogo(open, ref);
  useEffect(() => {
    if (!open) return;
    const k = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  if (!open) return null;
  return createPortal(
    <div className="sheet-back" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="sheet" role="dialog" aria-modal="true" aria-label={title} ref={ref} tabIndex={-1}>
        <div className="sheet-head"><b>{title}</b><button className="icon-btn" onClick={onClose} aria-label="Fechar"><Icon n="x" /></button></div>
        <div className="sheet-body">{children}</div>
      </div>
    </div>, document.body);
}
