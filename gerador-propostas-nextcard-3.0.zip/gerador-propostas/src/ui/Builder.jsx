import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Icon, Btn, Field, Text, Select, Money, Tag, Chips, Toggle, Check, Disclosure, DropZone, Empty, Sheet } from './common.jsx';
import { TotemCard, CatracaCard, ComandaCard, ServicoCard, LinhaCard, TeloosPlanos, TeloosAdicionais, TeloosImplantacao } from './Cards.jsx';
import { fmtBRL, fmtData, addDias, calcNextcard, calcTeloos, isNil, linhaCurtaCondicao, VALIDADES, validadeDe, diaSemana } from '../core.js';
import { linhaTotem, linhaCatraca, linhaComanda, linhaServico, linhaAvulsa, linhaPlano, linhaAdicional, linhaImplantacao, aplicaCupom, aplicaModalidade, autoInclusos, freteSugerido, nomeSugerido } from '../model.js';
import { SEGMENTOS } from '../defaults.js';
import * as api from '../api.js';
import { descontoLocal } from '../model.js';
import { fileToDataURL, uid } from '../store.js';
import { PHOTOS } from '../fotos.js';
import { buildModel, renderPeca, renderPaginasPDF, temasProposta, temaDe } from '../render.js';

export const STEPS = [
  { n: 1, t: 'Cliente', d: 'Para quem é' },
  { n: 2, t: 'Solução', d: 'O que vai na proposta' },
  { n: 3, t: 'Condições', d: 'Pagamento e validade' },
];

export default function Builder({ prop, setProp, cfg, fotos, propostas, onGerar, toast, step, setStep, salvoEm }) {
  const calc = useMemo(() => (prop.empresa === 'teloos' ? calcTeloos(prop, cfg) : calcNextcard(prop, cfg)), [prop, cfg]);
  const [prevOpen, setPrevOpen] = useState(false);
  const upd = (patch) => setProp((p) => {
    const n = typeof patch === 'function' ? patch(p) : { ...p, ...patch };
    if (n.inclusosAuto) n.inclusos = autoInclusos(n, cfg);
    return n;
  });
  const done = { 1: !!prop.cliente.empresa.trim(), 2: prop.itens.some((l) => l.kind !== 'implantacao' && l.qtd > 0), 3: !!prop.numero };
  const ir = (n) => { setStep(n); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  // condições marcadas que ainda não têm valor (sem fator e sem o total do simulador): não entram na imagem nem no PDF
  const semValor = prop.empresa === 'teloos' ? [] : calc.condicoes.filter((c) => !c.disponivel);
  const irSemValor = () => { setStep(3); setTimeout(() => document.querySelector('[data-testid=aviso-sem-valor]')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 80); };
  return (
    <div className="builder2">
      <div className="b-main">
        <nav className="stepper2" aria-label="Etapas">
          {STEPS.map((s) => (
            <button key={s.n} type="button" className={`st ${step === s.n ? 'on' : ''} ${done[s.n] && step !== s.n ? 'done' : ''}`} onClick={() => ir(s.n)} aria-current={step === s.n ? 'step' : undefined}>
              <span className="st-n">{done[s.n] && step !== s.n ? <Icon n="check" s={14} w={2.6} /> : s.n}</span>
              <span className="st-txt"><b>{s.t}</b><small>{s.d}</small></span>
            </button>
          ))}
        </nav>

        {step === 1 && <StepCliente prop={prop} upd={upd} cfg={cfg} propostas={propostas} toast={toast} />}
        {step === 2 && <StepSolucao prop={prop} upd={upd} cfg={cfg} fotos={fotos} toast={toast} calc={calc} />}
        {step === 3 && <StepCondicoes prop={prop} upd={upd} cfg={cfg} calc={calc} toast={toast} />}

        <div className="step-nav">
          {step > 1 ? <Btn icon="left" onClick={() => ir(step - 1)}>Voltar</Btn> : <span />}
          {step < 3
            ? <Btn variant="primary" onClick={() => ir(step + 1)} className="btn-lg">Continuar <Icon n="right" s={17} /></Btn>
            : <Btn variant="primary" icon="bolt" onClick={onGerar} className="btn-lg btn-gerar">Gerar proposta</Btn>}
        </div>
      </div>

      <aside className="b-side" aria-label="Prévia da proposta">
        <LivePreview prop={prop} cfg={cfg} fotos={fotos} salvoEm={salvoEm} onExpand={() => setPrevOpen(true)} />
        <Resumo prop={prop} calc={calc} cfg={cfg} done={done} ir={ir} semValor={semValor} irSemValor={irSemValor} />
        <Btn variant="primary" icon="bolt" onClick={onGerar} className="btn-lg btn-block btn-gerar">Gerar proposta</Btn>
      </aside>

      {/* Celular: barra fixa */}
      <div className="m-bar">
        <div className="m-bar-val">
          {semValor.length > 0
            ? <button type="button" className="m-bar-warn" onClick={irSemValor} data-testid="pend-sem-valor-cel"><Icon n="alert" s={12} /> {semValor.length === 1 ? '1 condição sem valor' : `${semValor.length} condições sem valor`}</button>
            : <span>{prop.empresa === 'teloos' ? 'Mensalidade' : 'Total à vista'}</span>}
          <b data-testid="valor-final">{fmtBRL(calc.valorFinal)}{prop.empresa === 'teloos' && <small>/mês</small>}</b>
        </div>
        <Btn icon="eye" onClick={() => setPrevOpen(true)} small>Prévia</Btn>
        {step < 3 ? <Btn variant="primary" small onClick={() => ir(step + 1)}>Continuar</Btn> : <Btn variant="primary" small icon="bolt" onClick={onGerar}>Gerar</Btn>}
      </div>

      <Sheet open={prevOpen} onClose={() => setPrevOpen(false)} title="Prévia da proposta">
        <LivePreview prop={prop} cfg={cfg} fotos={fotos} big />
      </Sheet>
    </div>
  );
}

// ───────────── Prévia ao vivo ─────────────
function LivePreview({ prop, cfg, fotos, salvoEm, onExpand, big }) {
  const [modo, setModo] = useState('img');
  const [pagina, setPagina] = useState(0);
  const [paginas, setPaginas] = useState(1);
  const [busy, setBusy] = useState(false);
  const box = useRef();
  const token = useRef(0);
  useEffect(() => {
    const t = ++token.current;
    setBusy(true);
    const h = setTimeout(async () => {
      try {
        const model = buildModel(prop, cfg, fotos, PHOTOS);
        const w = box.current ? box.current.clientWidth : 360;
        const scale = Math.min(1, Math.max(0.35, (w * (window.devicePixelRatio || 1)) / 1080));
        let cv;
        if (modo === 'img') cv = await renderPeca(model, cfg, scale, { modo: 'imagem' });
        else { const ps = await renderPaginasPDF(model, cfg, scale); setPaginas(ps.length); cv = ps[Math.min(pagina, ps.length - 1)]; }
        if (t !== token.current || !box.current) return;
        cv.className = 'lp-canvas';
        box.current.replaceChildren(cv);
      } catch (e) { console.error(e); }
      if (t === token.current) setBusy(false);
    }, 220);
    return () => clearTimeout(h);
  }, [prop, cfg, fotos, modo, pagina]);
  return (
    <div className={`lp ${big ? 'lp-big' : ''}`}>
      <div className="lp-head">
        <div className="seg seg-sm" role="tablist">
          <button type="button" className={modo === 'img' ? 'on' : ''} onClick={() => { setModo('img'); setPagina(0); }}>Imagem</button>
          <button type="button" className={modo === 'pdf' ? 'on' : ''} onClick={() => setModo('pdf')}>PDF</button>
        </div>
        {modo === 'pdf' && paginas > 1 && (
          <div className="lp-pages">
            <button type="button" className="icon-btn" disabled={pagina === 0} onClick={() => setPagina(pagina - 1)} aria-label="Página anterior"><Icon n="left" s={15} /></button>
            <span className="tiny mono">{pagina + 1}/{paginas}</span>
            <button type="button" className="icon-btn" disabled={pagina >= paginas - 1} onClick={() => setPagina(pagina + 1)} aria-label="Próxima página"><Icon n="right" s={15} /></button>
          </div>
        )}
        {!big && <span className="lp-saved tiny">{busy ? <><span className="dot-pulse" /> atualizando</> : salvoEm ? <><Icon n="check" s={12} w={2.6} /> salvo {salvoEm}</> : 'prévia'}</span>}
      </div>
      <div className="lp-stage" ref={box} onClick={onExpand} role={onExpand ? 'button' : undefined} title={onExpand ? 'Ampliar' : undefined} />
    </div>
  );
}

function Resumo({ prop, calc, cfg, done, ir, semValor = [], irSemValor }) {
  const tel = prop.empresa === 'teloos';
  const val = validadeDe(prop, cfg[prop.empresa].empresa.validadePadrao);
  let linha2 = '';
  if (tel) {
    const d = calc.periodicidades.find((p) => p.id === prop.pagamento.destaque) || calc.periodicidades[0];
    linha2 = d ? d.curto : '';
  } else {
    const c = calc.condicoes.find((x) => x.id === prop.pagamento.destaque && x.disponivel) || calc.condicoes.find((x) => x.disponivel && x.tipo !== 'avista');
    linha2 = c ? `ou ${fmtBRL(c.total)} · ${linhaCurtaCondicao(c)}` : 'somente à vista';
  }
  const pend = [
    !done[1] && { t: 'Informe o cliente', n: 1 },
    !done[2] && { t: 'Adicione itens', n: 2 },
    !prop.responsavel && { t: 'Defina o consultor', n: 1 },
  ].filter(Boolean);
  const dl = api.REMOTO ? descontoLocal(prop) : { desconto: 0, pct: 0, avulso: false };
  const limite = api.ctx.alcadaPct || 0;
  const pctTxt = (n) => String(Number(n.toFixed(2))).replace('.', ',');
  const acima = dl.desconto > 0 && dl.pct > limite + 1e-9 && !api.tem('aprovador');
  const temPend = pend.length > 0 || semValor.length > 0;
  return (
    <div className="resumo">
      <span className="resumo-label">{tel ? 'Mensalidade' : 'Total à vista (PIX)'}</span>
      <b className="resumo-big" data-testid="valor-final-side">{fmtBRL(calc.valorFinal)}{tel && <small>/mês</small>}</b>
      <span className="resumo-sub">{linha2}</span>
      {tel && calc.unicos.length > 0 && <span className="resumo-sub">Implantação {calc.implantacao === 0 ? 'inclusa' : fmtBRL(calc.implantacao) + ' à vista'}</span>}
      <span className="resumo-sub"><Icon n="calendar" s={13} /> Válida até {diaSemana(val.data)}, {val.dataTxt} · {val.label}</span>
      {api.REMOTO && dl.desconto > 0 && (
        <div className={`resumo-desc ${acima ? 'acima' : ''}`} data-testid="resumo-desconto">
          <span>Tabela {fmtBRL(dl.base)}</span>
          <span>Desconto {pctTxt(dl.pct)}% · {fmtBRL(dl.desconto)}</span>
          <span>{api.tem('aprovador') ? 'Você é a autoridade comercial: o desconto fica registrado em seu nome.' : `Sua alçada: ${pctTxt(limite)}%${acima ? '. Acima dela, a emissão pede aprovação.' : ` · saldo ${pctTxt(Math.max(0, limite - dl.pct))} p.p.`}`}</span>
        </div>
      )}
      {api.REMOTO && dl.avulso && !api.tem('aprovador') && <div className="resumo-desc acima"><span>Item livre (fora do catálogo): a emissão pede aprovação.</span></div>}
      {temPend && (
        <div className="resumo-pend">
          {pend.map((p) => <button key={p.t} type="button" onClick={() => ir(p.n)}><Icon n="alert" s={13} /> {p.t}</button>)}
          {semValor.map((c) => <button key={c.id} type="button" onClick={irSemValor} data-testid="pend-sem-valor"><Icon n="alert" s={13} /> {c.nome}: falta o valor do simulador</button>)}
        </div>
      )}
    </div>
  );
}

// ───────────── Passo 1 · Cliente ─────────────
function StepCliente({ prop, upd, cfg, propostas, toast }) {
  const c = prop.cliente;
  const setC = (k) => (v) => upd((p) => ({ ...p, cliente: { ...p.cliente, [k]: v } }));
  const anteriores = useMemo(() => {
    const m = new Map();
    for (const p of [...propostas].sort((a, b) => (a.atualizadaEm || '').localeCompare(b.atualizadaEm || ''))) if (p.cliente?.empresa && p.id !== prop.id) m.set(p.cliente.empresa.trim().toLowerCase(), p.cliente);
    return m;
  }, [propostas, prop.id]);
  const onEmpresa = (v) => {
    const ant = anteriores.get(v.trim().toLowerCase());
    if (ant && !c.contato && !c.telefone) {
      upd((p) => ({ ...p, cliente: { ...ant, empresa: v } }));
      toast('Dados do cliente preenchidos com a última proposta', 'info');
    } else setC('empresa')(v);
  };
  const onLogo = async (f) => {
    try { setC('logo')(await fileToDataURL(f, 520, 'image/png')); } catch (e) { toast('Não foi possível ler a imagem', 'warn'); }
  };
  const resp = cfg.responsaveis || [];
  const mods = cfg[prop.empresa].modalidades;
  return (
    <section className="card step-card">
      <header className="card-head"><div><h3>Para quem é a proposta?</h3><span className="muted small">Só o nome da empresa é necessário para começar.</span></div></header>
      {api.REMOTO && api.ctx.kommo && <KommoPicker prop={prop} upd={upd} toast={toast} />}
      <div className="form-grid">
        <Field label="Empresa ou nome fantasia" span={2}>
          <input className="inp inp-lg" list="clientes-ant" value={c.empresa} onChange={(e) => onEmpresa(e.target.value)} placeholder="Ex.: Restaurante Modelo" autoFocus data-testid="cliente-empresa" />
          <datalist id="clientes-ant">{[...anteriores.values()].map((x) => <option key={x.empresa} value={x.empresa} />)}</datalist>
        </Field>
        <Field label="Contato (A/C)"><Text value={c.contato} onChange={setC('contato')} placeholder="Quem decide" /></Field>
        <Field label="WhatsApp do cliente" hint="Usado no botão “Enviar pelo WhatsApp”"><Text value={c.telefone} onChange={setC('telefone')} placeholder="(41) 90000-0000" inputMode="tel" /></Field>
        <Field label="E-mail"><Text value={c.email} onChange={setC('email')} type="email" placeholder="opcional" /></Field>
        <Field label="Cidade / UF"><Text value={c.cidade} onChange={setC('cidade')} placeholder="opcional" /></Field>
      </div>
      <div className="logo-row">
        <DropZone onFile={onLogo}>
          <div className="drop-in">
            <div className="logo-prev">{c.logo ? <img src={c.logo} alt="Logo do cliente" /> : <Icon n="image" s={24} />}</div>
            <div><b>{c.logo ? 'Trocar logo do cliente' : 'Logo do cliente'}</b><span className="muted small">Arraste a imagem aqui ou clique. Aparece no topo da proposta.</span></div>
          </div>
        </DropZone>
        {c.logo && <Btn small icon="trash" onClick={() => setC('logo')(null)}>Remover</Btn>}
      </div>
      <Disclosure label="Mais opções: segmento, tipo de venda, consultor e nome da proposta">
        <div className="form-grid">
          <Field label="Segmento"><Select value={c.segmento} onChange={setC('segmento')} options={[{ value: '', label: 'Não informado' }, ...SEGMENTOS.map((s) => ({ value: s, label: s }))]} /></Field>
          <Field label="Cliente"><Chips value={c.tipo} onChange={setC('tipo')} options={[{ value: 'PJ', label: 'Pessoa jurídica' }, { value: 'PF', label: 'Pessoa física' }]} /></Field>
          {mods.length > 1 && (
            <Field label="Tipo de venda" span={2}>
              <Chips value={prop.modalidade} onChange={(v) => upd((p) => { const n = { ...p, modalidade: v }; if (p.empresa === 'nextcard') n.itens = aplicaModalidade(n, cfg); return n; })}
                options={mods.map((m) => ({ value: m.id, label: m.nome, sub: m.descricao }))} />
            </Field>
          )}
          <Field label="Consultor responsável" hint={api.REMOTO ? 'É a conta que está usando o sistema' : undefined}>
            <input className="inp" list="resp-list" value={prop.responsavel} onChange={(e) => upd({ responsavel: e.target.value })} placeholder="Seu nome" readOnly={api.REMOTO} />
            <datalist id="resp-list">{resp.map((r) => <option key={r.nome} value={r.nome} />)}</datalist>
          </Field>
          <Field label="Nome da proposta" hint={prop.nome ? undefined : 'Automático pelo que você escolher'}>
            <Text value={prop.nome} onChange={(v) => upd({ nome: v })} placeholder={nomeSugerido(prop, cfg)} />
          </Field>
        </div>
      </Disclosure>
    </section>
  );
}

// Busca e seleção do negócio no Kommo. O consultor sempre confirma o negócio: nada é escolhido sozinho.
function KommoPicker({ prop, upd, toast }) {
  const [q, setQ] = useState('');
  const [res, setRes] = useState(null);
  const [busy, setBusy] = useState(false);
  const k = prop.kommo;
  const buscar = async () => {
    if (q.trim().length < 2) return;
    setBusy(true);
    try { setRes((await api.buscarLeads(q.trim())).leads); } catch (e) { toast(e.message, 'warn'); setRes(null); }
    setBusy(false);
  };
  const escolher = async (l) => {
    setBusy(true);
    try {
      const d = (await api.detalheLead(l.id)).lead;
      upd((p) => ({
        ...p,
        kommo: { leadId: d.id, nome: d.nome, pipeline: d.pipeline, etapa: d.etapa, responsavel: d.responsavel, url: d.url },
        // completa só o que está vazio: nada do que o consultor digitou é trocado, e nada é gravado no CRM
        cliente: { ...p.cliente, empresa: p.cliente.empresa || d.empresa?.nome || d.contato?.nome || '', contato: p.cliente.contato || d.contato?.nome || '', telefone: p.cliente.telefone || d.contato?.telefone || '', email: p.cliente.email || d.contato?.email || '' },
      }));
      setRes(null); setQ('');
      toast('Negócio vinculado. Confira os dados do cliente.', 'info');
    } catch (e) { toast(e.message, 'warn'); }
    setBusy(false);
  };
  if (k?.leadId) {
    return (
      <div className="kommo-sel" data-testid="kommo-vinculado">
        <Icon n="check" s={16} />
        <div><b>Negócio no Kommo: {k.nome || `#${k.leadId}`}</b><span className="muted small">#{k.leadId}{k.pipeline ? ` · ${k.pipeline}` : ''}{k.etapa ? ` · ${k.etapa}` : ''}{k.responsavel ? ` · ${k.responsavel}` : ''}</span></div>
        {k.url && <a className="link small" href={k.url} target="_blank" rel="noopener noreferrer">abrir</a>}
        <button type="button" className="link small" onClick={() => upd((p) => ({ ...p, kommo: null }))}>trocar</button>
      </div>
    );
  }
  return (
    <div className="kommo-box">
      <span className="field-label">Negócio no Kommo</span>
      <div className="row-gap">
        <input className="inp" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); buscar(); } }} placeholder="Nome, empresa, telefone, e-mail ou nº do negócio" aria-label="Buscar negócio no Kommo" data-testid="kommo-busca" />
        <Btn icon="search" onClick={buscar} disabled={busy || q.trim().length < 2}>{busy ? 'Buscando…' : 'Buscar'}</Btn>
      </div>
      {res && !res.length && <span className="muted small">Nenhum negócio encontrado. Você pode seguir sem vincular e anexar depois.</span>}
      {res && res.length > 0 && (
        <div className="kommo-res" role="listbox" aria-label="Negócios encontrados">
          {res.map((l) => (
            <button key={l.id} type="button" onClick={() => escolher(l)} disabled={busy} data-testid="kommo-lead">
              <b>{l.nome || `Negócio #${l.id}`}</b>
              <small>#{l.id} · {l.pipeline} · {l.etapa}{l.responsavel ? ` · ${l.responsavel}` : ''}{l.criadoEm ? ` · criado em ${fmtData(l.criadoEm)}` : ''}</small>
            </button>
          ))}
        </div>
      )}
      <span className="tiny dim">A proposta emitida é anexada a este negócio. O cliente não recebe nada automaticamente.</span>
    </div>
  );
}

// ───────────── Passo 2 · Solução ─────────────
function StepSolucao({ prop, upd, cfg, fotos, toast, calc }) {
  const [novo, setNovo] = useState(null);
  const N = cfg.nextcard;
  const setItens = (fn) => upd((p) => ({ ...p, itens: fn(p.itens) }));
  const change = (u) => (patch) => setItens((its) => its.map((l) => (l.uid === u ? { ...l, ...patch } : l)));
  const replace = (u) => (linha) => setItens((its) => its.map((l) => (l.uid === u ? linha : l)));
  const remove = (u) => () => {
    let removido, idx;
    upd((p) => { idx = p.itens.findIndex((l) => l.uid === u); removido = p.itens[idx]; return { ...p, itens: p.itens.filter((l) => l.uid !== u) }; });
    toast('Item removido', 'info', { label: 'Desfazer', onClick: () => upd((p) => { const it = [...p.itens]; it.splice(Math.min(idx, it.length), 0, removido); return { ...p, itens: it }; }) });
  };
  const dup = (u) => () => setItens((its) => { const i = its.findIndex((l) => l.uid === u); const c = { ...its[i], uid: uid() }; const n = [...its]; n.splice(i + 1, 0, c); return n; });
  const add = (linha) => {
    upd((p) => {
      const n = { ...p, itens: [...p.itens, linha] };
      if (!p.itens.some((l) => l.kind === 'catraca') && linha.kind === 'catraca') n.pagamento = { ...n.pagamento, frete: freteSugerido(n) };
      return n;
    });
    setNovo(linha.uid);
    setTimeout(() => document.getElementById('it-' + linha.uid)?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 60);
  };

  if (prop.empresa === 'teloos') {
    const T = cfg.teloos;
    const cupom = prop.teloos?.cupom || 0;
    const onPlano = (pl) => upd((p) => {
      const itens = p.itens.filter((l) => l.kind !== 'plano');
      return { ...p, teloos: { ...p.teloos, plano: pl.id }, itens: [linhaPlano(pl, cupom), ...itens.filter((l) => l.kind !== 'adicional' || (T.adicionais.find((a) => a.id === l.refId)?.planos || []).includes(pl.id))] };
    });
    const onCupom = (c) => upd((p) => ({ ...p, teloos: { ...p.teloos, cupom: c }, itens: aplicaCupom(p.itens, c) }));
    const onImpl = (id) => upd((p) => { const imp = T.implantacao.find((x) => x.id === id); return { ...p, teloos: { ...p.teloos, implantacao: id }, itens: [...p.itens.filter((l) => l.kind !== 'implantacao'), linhaImplantacao(imp)] }; });
    const onQtd = (a, qtd) => upd((p) => {
      const ex = p.itens.find((l) => l.kind === 'adicional' && l.refId === a.id);
      let itens;
      if (qtd <= 0) itens = p.itens.filter((l) => !(l.kind === 'adicional' && l.refId === a.id));
      else if (ex) itens = p.itens.map((l) => (l === ex ? { ...l, qtd } : l));
      else { const imp = p.itens.filter((l) => l.kind === 'implantacao'); itens = [...p.itens.filter((l) => l.kind !== 'implantacao'), linhaAdicional(a, p.teloos?.cupom || 0, qtd), ...imp]; }
      return { ...p, itens };
    });
    const dataLimite = (d) => fmtData(addDias(new Date().toISOString(), d));
    return (
      <div className="stack">
        <TeloosPlanos prop={prop} cfg={cfg} onPlano={onPlano} onCupom={onCupom} />
        <TeloosAdicionais prop={prop} cfg={cfg} onQtd={onQtd} />
        <TeloosImplantacao prop={prop} cfg={cfg} onImpl={onImpl} dataLimite={dataLimite} />
        {prop.itens.length > 0 && (
          <Disclosure label="Ajustar valores praticados" className="card-disc">
            <div className="stack-sm">
              {prop.itens.map((l) => <div id={'it-' + l.uid} key={l.uid}><LinhaCard linha={l} cfg={cfg} fotos={fotos} onChange={change(l.uid)} onRemove={l.kind === 'adicional' ? remove(l.uid) : undefined} toast={toast} /></div>)}
            </div>
          </Disclosure>
        )}
      </div>
    );
  }

  const cat = (tipo) => N.catracas.find((c) => c.tipo === tipo && c.variante === 'Catraca acoplada') || N.catracas.find((c) => c.tipo === tipo);
  const quick = [
    { k: 'totem', t: 'Totem', i: 'cube', f: () => linhaTotem({ modelo: 'NX24-V', ...N.totem.referencia }, cfg, prop, 1) },
    { k: 'entrada', t: 'Catraca de entrada', i: 'right', f: () => linhaCatraca(cat('Dispensadora'), 1) },
    { k: 'saida', t: 'Catraca de saída', i: 'left', f: () => linhaCatraca(cat('Receptora'), 1) },
    { k: 'comanda', t: 'Comandas', i: 'card', f: () => linhaComanda(N.comandas.find((c) => c.id === 'CMD14x8-RFI') || N.comandas[0], 100) },
    ...N.servicos.map((s) => ({ k: s.id, t: s.nome.split(',')[0].replace('Deslocamento', 'Instalação'), i: 'gear', f: () => linhaServico(s) })),
    { k: 'avulso', t: 'Item livre', i: 'plus', f: () => linhaAvulsa('Novo item', '', 0, 1) },
  ];
  const itens = prop.itens.filter((l) => l.kind !== 'frete');
  const props = (l) => ({ linha: l, cfg, prop, fotos, toast, onChange: change(l.uid), onReplace: replace(l.uid), onRemove: remove(l.uid), onDuplicate: dup(l.uid), defaultOpen: novo === l.uid || (itens.length === 1 && l.kind !== 'servico') });
  return (
    <div className="stack">
      <section className="card step-card">
        <header className="card-head"><div><h3>O que vai na proposta?</h3><span className="muted small">Toque em um item para configurar. O preço segue a tabela; você pode ajustar para cima.</span></div></header>
        {itens.length === 0 && <Empty icon="cube" title="Nenhum item ainda" text="Escolha abaixo o primeiro item." />}
        <div className="stack-sm">
          {itens.map((l) => (
            <div id={'it-' + l.uid} key={l.uid}>
              {l.kind === 'totem' && <TotemCard {...props(l)} />}
              {l.kind === 'catraca' && <CatracaCard {...props(l)} />}
              {l.kind === 'comanda' && <ComandaCard {...props(l)} />}
              {(l.kind === 'servico' || l.kind === 'avulso') && <ServicoCard {...props(l)} />}
            </div>
          ))}
        </div>
        <div className="quick-add">
          <span className="tiny muted">Adicionar</span>
          {quick.map((q) => <button key={q.k} type="button" className="qa" onClick={() => add(q.f())}><Icon n={q.i} s={16} /><span>{q.t}</span></button>)}
        </div>
      </section>
    </div>
  );
}

// ───────────── Passo 3 · Condições ─────────────
function StepCondicoes({ prop, upd, cfg, calc, toast }) {
  const tel = prop.empresa === 'teloos';
  const pg = prop.pagamento;
  const setPg = (patch) => upd((p) => ({ ...p, pagamento: { ...p.pagamento, ...patch } }));
  const val = validadeDe(prop, cfg[prop.empresa].empresa.validadePadrao);
  return (
    <div className="stack">
      <section className="card step-card">
        <header className="card-head"><div><h3>Validade{tel ? '' : ' e frete'}</h3><span className="muted small">Válida até <b>{diaSemana(val.data)}, {val.dataTxt}</b> (conta a partir do envio)</span></div></header>
        <Field label="Validade da proposta">
          <Chips value={val.id} onChange={(v) => upd({ validadeOpcao: v, validadeDias: undefined })} options={VALIDADES.map((v) => {
            const d = validadeDe({ ...prop, validadeOpcao: v.id });
            return { value: v.id, label: v.label, sub: `até ${diaSemana(d.data)} ${d.dataTxt.slice(0, 5)}` };
          })} />
        </Field>
        {!tel && (
          <Field label="Frete">
            <Chips value={pg.frete === 'CIF' ? 'CIF' : 'FOB'} onChange={(v) => setPg({ frete: v })} options={[
              { value: 'CIF', label: 'CIF · incluso', sub: 'por conta da NEXTCARD' },
              { value: 'FOB', label: 'FOB · cliente', sub: 'por conta do destinatário' },
            ]} />
          </Field>
        )}
      </section>

      {tel ? <PeriodicidadesCard prop={prop} cfg={cfg} calc={calc} setPg={setPg} /> : <PagamentoCard prop={prop} cfg={cfg} calc={calc} setPg={setPg} toast={toast} />}

      <section className="card">
        <header className="card-head"><div><h3>Aparência da proposta</h3><span className="muted small">PDF e imagem usam sempre o mesmo tema. Fica salvo nesta proposta.</span></div></header>
        <div data-testid="tema-proposta"><Field label="Tema da proposta"><Chips value={temaDe(prop.empresa, prop.temaProposta)} onChange={(v) => upd({ temaProposta: v })} ariaLabel="Tema da proposta" options={temasProposta(prop.empresa)} /></Field></div>
        <div className="sep" />
        <div data-testid="incluir-cases">
          <Toggle checked={prop.incluirCases ?? prop.empresa === 'nextcard'} onChange={(v) => upd({ incluirCases: v })} label="Incluir cases de sucesso (faixa na imagem e seção na última página do PDF)" />
        </div>
      </section>

      <InclusosCard prop={prop} upd={upd} cfg={cfg} />

      <section className="card">
        <header className="card-head"><div><h3>Observações</h3><span className="muted small">Opcional · aparece no PDF</span></div></header>
        <textarea className="inp" rows={3} value={prop.observacoes} onChange={(e) => upd({ observacoes: e.target.value })} placeholder="Ex.: instalação prevista para a segunda quinzena de outubro." />
        {!tel && <div className="sep" />}
        {!tel && <Toggle checked={prop.usarFoto !== false} onChange={(v) => upd({ usarFoto: v })} label="Mostrar foto dos equipamentos na imagem" />}
      </section>
    </div>
  );
}

function PagamentoCard({ prop, cfg, calc, setPg, toast }) {
  const pg = prop.pagamento;
  const base = calc.valorFinal;
  const toggle = (id, on) => {
    const cond = on ? [...new Set([...pg.condicoes, id])] : pg.condicoes.filter((x) => x !== id);
    const patch = { condicoes: cond };
    if (!on && pg.destaque === id) patch.destaque = cond.find((x) => x !== 'pix') || null;
    if (on && !pg.destaque) patch.destaque = id;
    setPg(patch);
  };
  const pix = calc.condicoes.find((c) => c.id === 'pix');
  return (
    <section className="card step-card">
      <header className="card-head"><div><h3>Formas de pagamento</h3><span className="muted small">Marque as que o cliente pode escolher. A estrela define a que aparece em destaque na imagem.</span></div></header>
      <div className="pay-list">
        <div className="pay on fixed">
          <span className="pay-ico"><Icon n="pix" s={18} /></span>
          <div className="pay-main"><b>À vista (PIX)</b><span className="muted small">Preço de tabela, sempre incluído</span></div>
          <b className="mono pay-val">{fmtBRL(pix ? pix.total : base)}</b>
        </div>
        {cfg.nextcard.condicoes.filter((c) => c.tipo !== 'avista').map((c) => {
          const on = pg.condicoes.includes(c.id);
          const r = calc.condicoes.find((x) => x.id === c.id);
          const ov = pg.overrides?.[c.id];
          const semValor = on && !r?.disponivel;
          return (
            <div key={c.id} className={`pay ${on ? 'on' : ''}`} data-testid={`cond-${c.id}`}>
              <Check checked={on} onChange={(v) => toggle(c.id, v)}><span className="sr-only">incluir</span></Check>
              <div className="pay-main" onClick={() => toggle(c.id, !on)}>
                <b>{c.nome}</b>
                <span className="muted small">{r?.disponivel ? linhaCurtaCondicao(r) : isNil(c.fator) ? 'Precisa do total do simulador oficial' : `acréscimo de ${((c.fator - 1) * 100).toFixed(1).replace('.', ',')}% sobre o PIX`}</span>
              </div>
              {on && r?.disponivel && <b className="mono pay-val">{fmtBRL(r.total)}</b>}
              {on && <button type="button" className={`star ${pg.destaque === c.id ? 'on' : ''}`} onClick={() => setPg({ destaque: c.id })} aria-label="Destaque na imagem" aria-pressed={pg.destaque === c.id} title="Destaque na imagem"><Icon n="star" s={17} /></button>}
              {semValor && (
                <p className="hint warn pay-warn" data-testid="aviso-sem-valor" role="status">
                  <Icon n="alert" s={15} />
                  <span>Falta o total do simulador. Sem ele, esta condição não aparece na imagem nem no PDF{pg.destaque === c.id ? ', e a imagem vai destacar outra condição' : ''}.</span>
                </p>
              )}
              {on && (
                <Disclosure label={semValor ? 'Informe o valor do simulador' : 'Ajustar entrada ou valor do simulador'} defaultOpen={semValor} className="pay-adj">
                  <div className="form-grid">
                    <Field label="Total da condição" hint={isNil(c.fator) ? 'Cole o total do simulador oficial' : !isNil(ov) ? 'Valor do simulador' : 'Calculado pelo fator da política'}>
                      <Money cents={isNil(ov) ? (r?.disponivel ? r.total : null) : ov} min={base} allowEmpty placeholder="valor do simulador"
                        onFloor={(m) => toast(`Não pode ficar abaixo do PIX: voltou para ${fmtBRL(m)}`, 'warn')}
                        onCommit={(v) => setPg({ overrides: { ...pg.overrides, [c.id]: v } })} ariaLabel={`total ${c.nome}`} />
                      {!isNil(ov) && <button className="link tiny" type="button" onClick={() => setPg({ overrides: { ...pg.overrides, [c.id]: null } })}>usar cálculo padrão</button>}
                    </Field>
                    <Field label="Entrada">
                      <Chips size="sm" value={String(pg.entradas?.[c.id] ?? c.entradaPadrao ?? 0)} onChange={(v) => setPg({ entradas: { ...pg.entradas, [c.id]: Number(v) } })}
                        options={[0, 10, 20, 30, 40, 50].map((x) => ({ value: String(x), label: x ? `${x}%` : 'Sem' }))} />
                    </Field>
                  </div>
                </Disclosure>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function PeriodicidadesCard({ prop, cfg, calc, setPg }) {
  const pg = prop.pagamento;
  const toggle = (id, on) => setPg({ periodicidades: on ? [...new Set([...pg.periodicidades, id])] : pg.periodicidades.filter((x) => x !== id), ...(on || pg.destaque !== id ? {} : { destaque: pg.periodicidades.find((x) => x !== id) || 'mensal' }) });
  return (
    <section className="card step-card">
      <header className="card-head"><div><h3>Formas de contratação</h3><span className="muted small">Marque as opções oferecidas. A estrela define o valor grande da imagem.</span></div></header>
      <div className="pay-list">
        {cfg.teloos.periodicidades.map((p) => {
          const on = pg.periodicidades.includes(p.id);
          const r = calc.periodicidades.find((x) => x.id === p.id);
          const base = calc.mensal;
          const preview = p.avista ? Math.round(base * p.meses * p.fator) : Math.round(base * p.fator);
          return (
            <div key={p.id} className={`pay ${on ? 'on' : ''}`}>
              <Check checked={on} onChange={(v) => toggle(p.id, v)}><span className="sr-only">incluir</span></Check>
              <div className="pay-main" onClick={() => toggle(p.id, !on)}>
                <b>{p.nome} <span className="muted">· {p.forma}</span></b>
                <span className="muted small">{p.fator === 1 ? 'Valor de tabela' : `${Math.round((1 - p.fator) * 100)}% de economia`}</span>
              </div>
              <b className="mono pay-val">{p.avista ? fmtBRL(r ? r.total : preview) : `${fmtBRL(r ? r.porMes : preview)}/mês`}</b>
              {on && <button type="button" className={`star ${pg.destaque === p.id ? 'on' : ''}`} onClick={() => setPg({ destaque: p.id })} aria-label="Destaque na imagem"><Icon n="star" s={17} /></button>}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function InclusosCard({ prop, upd, cfg }) {
  const [novo, setNovo] = useState('');
  const list = prop.inclusos || [];
  const set = (arr) => upd({ inclusos: arr.slice(0, 8), inclusosAuto: false });
  const addIt = () => { if (novo.trim()) { set([...list, novo.trim()]); setNovo(''); } };
  return (
    <section className="card">
      <header className="card-head"><div><h3>O que está incluso</h3><span className="muted small">Os primeiros (até 4, conforme o espaço) aparecem na imagem; todos aparecem no PDF.</span></div>
        {!prop.inclusosAuto && <button className="link tiny" type="button" onClick={() => upd({ inclusosAuto: true })}>restaurar sugestão</button>}
      </header>
      <ul className="incl">
        {list.map((t, i) => (
          <li key={i} className={i < 4 ? 'on-img' : ''}>
            <Icon n="check" s={14} w={2.4} />
            <input className="inp inp-flat" value={t} onChange={(e) => set(list.map((x, k) => (k === i ? e.target.value : x)))} aria-label={`incluso ${i + 1}`} />
            {i > 0 && <button className="icon-btn" type="button" onClick={() => { const n = [...list]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; set(n); }} aria-label="subir"><Icon n="up" s={14} /></button>}
            <button className="icon-btn" type="button" onClick={() => set(list.filter((_, k) => k !== i))} aria-label="remover incluso"><Icon n="x" s={14} /></button>
          </li>
        ))}
      </ul>
      {list.length < 8 && (
        <div className="row-gap">
          <input className="inp" value={novo} onChange={(e) => setNovo(e.target.value)} placeholder="Adicionar item incluso" onKeyDown={(e) => { if (e.key === 'Enter') addIt(); }} />
          <Btn small icon="plus" onClick={addIt}>Incluir</Btn>
        </div>
      )}
    </section>
  );
}
