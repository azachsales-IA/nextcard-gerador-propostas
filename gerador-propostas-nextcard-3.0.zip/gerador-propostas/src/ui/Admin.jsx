// Telas corporativas: login, administração (usuários, alçadas, numeração, importação, histórico) e aprovações.
import React, { useEffect, useMemo, useState } from 'react';
import { Icon, Btn, Field, Text, Tag, Modal, Seg, Empty, Select, Chips } from './common.jsx';
import * as api from '../api.js';
import { fmtBRL, fmtData } from '../core.js';
import { IMG } from '../assets.js';

const PAPEIS = [
  { value: 'consultor', label: 'Consultor', sub: 'cria e emite propostas' },
  { value: 'gestor', label: 'Gestor', sub: 'acompanha a equipe' },
  { value: 'aprovador', label: 'Aprovador', sub: 'alçadas e exceções' },
  { value: 'owner', label: 'Proprietário', sub: 'catálogo, taxas, usuários' },
];
const nomePapel = (r) => (PAPEIS.find((p) => p.value === r) || { label: r }).label;
const dataHora = (d) => (d ? `${fmtData(d)} ${new Date(d).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : '—');
const dia = (s) => (s ? String(s).slice(0, 10).split('-').reverse().join('/') : '—');

export function Login({ onOk, offline }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState(null);
  const [busy, setBusy] = useState(false);
  const entrar = async (e) => {
    e.preventDefault();
    setBusy(true); setErro(null);
    try { await api.login(email, senha); await onOk(); } catch (x) { setErro(x.message); }
    setBusy(false);
  };
  return (
    <div className="login">
      <div className="bg-fx" aria-hidden="true"><span className="orb o1" /><span className="orb o2" /><span className="grid-fx" /></div>
      <form className="login-card" onSubmit={entrar}>
        <img src={IMG.logoNextcardNeg} alt="NEXTCARD" className="login-logo" />
        <h1>Gerador de propostas</h1>
        <p className="muted small">Entre com a sua conta para criar e emitir propostas.</p>
        {offline && <div className="hint warn" role="alert"><Icon n="alert" s={15} /><span>{offline}</span></div>}
        <Field label="E-mail"><Text value={email} onChange={setEmail} type="email" autoComplete="username" autoFocus data-testid="login-email" /></Field>
        <Field label="Senha"><Text value={senha} onChange={setSenha} type="password" autoComplete="current-password" data-testid="login-senha" /></Field>
        {erro && <p className="warn small" role="alert" data-testid="login-erro">{erro}</p>}
        <Btn type="submit" variant="primary" className="btn-lg btn-block" disabled={busy || !email || !senha}>{busy ? 'Entrando…' : 'Entrar'}</Btn>
        <span className="tiny dim">Acesso restrito à equipe NEXTCARD. Esqueceu a senha? Peça ao administrador.</span>
      </form>
    </div>
  );
}

// Barra de salvamento da configuração oficial: nunca mostra "salvo" antes da confirmação do servidor
export function BarraSalvar({ estado, erro, onSalvar, onDescartar, onRecarregar }) {
  if (estado === 'limpo') return null;
  const txt = { sujo: 'Alterações não salvas na configuração oficial', salvando: 'Salvando…', salvo: 'Salvo com sucesso. A equipe já usa a nova configuração.', erro: `Falha ao salvar: ${erro || ''}`, conflito: 'Outra sessão alterou a configuração. Recarregue para ver a versão atual; suas alterações não foram aplicadas.' }[estado];
  return (
    <div className={`savebar savebar-${estado}`} role="status" data-testid="savebar" data-estado={estado}>
      <Icon n={estado === 'salvo' ? 'check' : estado === 'salvando' ? 'info' : 'alert'} s={16} />
      <span>{txt}</span>
      {(estado === 'sujo' || estado === 'erro') && <><Btn small onClick={onDescartar}>Descartar</Btn><Btn small variant="primary" icon="check" onClick={onSalvar} data-testid="savebar-salvar">Salvar alterações</Btn></>}
      {estado === 'conflito' && <Btn small variant="primary" onClick={onRecarregar}>Recarregar</Btn>}
    </div>
  );
}

export function MinhaConta({ toast, onSair }) {
  const u = api.ctx.user;
  const [atual, setAtual] = useState(''); const [nova, setNova] = useState('');
  const trocar = async () => { try { await api.trocarSenha(atual, nova); setAtual(''); setNova(''); toast('Senha alterada'); } catch (e) { toast(e.message, 'warn'); } };
  return (
    <section className="card">
      <header className="card-head"><div><h3>Minha conta</h3><span className="muted small">{u.email} · {u.roles.map(nomePapel).join(', ')} · sufixo {u.sigla || '—'} · alçada de desconto {String(api.ctx.alcadaPct).replace('.', ',')}%</span></div><Btn small icon="x" onClick={onSair}>Sair</Btn></header>
      <div className="form-grid">
        <Field label="Senha atual"><Text value={atual} onChange={setAtual} type="password" autoComplete="current-password" /></Field>
        <Field label="Nova senha" hint="10 caracteres ou mais, com letras e números"><Text value={nova} onChange={setNova} type="password" autoComplete="new-password" /></Field>
      </div>
      <Btn variant="line" disabled={!atual || nova.length < 10} onClick={trocar}>Trocar senha</Btn>
      <div className="sep" />
      <h4>Propostas da versão anterior</h4>
      <p className="muted small">Se você exportou suas propostas na versão antiga (arquivo .json), importe aqui. Elas entram na sua lista como rascunhos, com o número antigo anotado, e não recebem número novo.</p>
      <label className="btn btn-line"><Icon n="upload" s={17} /><span>Importar arquivo de propostas</span><input type="file" accept="application/json" hidden data-testid="importar-propostas" onChange={(e) => {
        const f = e.target.files && e.target.files[0]; if (!f) return;
        const fr = new FileReader();
        fr.onload = async () => { try { const d = JSON.parse(fr.result); if (!Array.isArray(d)) throw new Error('Arquivo inválido'); const r = await api.importarPropostas(d); toast(`${r.importadas} proposta(s) importada(s)`); setTimeout(() => window.location.reload(), 900); } catch (x) { toast(x.message || 'Arquivo inválido', 'warn'); } };
        fr.readAsText(f); e.target.value = '';
      }} /></label>
    </section>
  );
}

// ───────────── Aprovações ─────────────
const descreveMotivo = (m) => (m.tipo === 'desconto' ? `Desconto de ${String(Number(m.pct).toFixed(2)).replace('.', ',')}% (${fmtBRL(m.valor)} sobre ${fmtBRL(m.base)} de tabela)`
  : m.tipo === 'condicao_abaixo_avista' ? `Condição de pagamento abaixo do valor à vista (${fmtBRL(m.valor)} contra ${fmtBRL(m.minimo)})`
    : m.tipo === 'item_fora_do_catalogo' ? 'Item livre, fora do catálogo oficial' : m.tipo);
export { descreveMotivo };

export function Aprovacoes({ toast, abrir, recarregar }) {
  const [lista, setLista] = useState(null);
  const [dec, setDec] = useState(null); // { a, aprovar }
  const [resp, setResp] = useState('');
  const pode = api.tem('aprovador');
  const carregar = async () => { try { setLista((await api.listAprovacoes()).aprovacoes); } catch (e) { toast(e.message, 'warn'); setLista([]); } };
  useEffect(() => { carregar(); }, []);
  const decidir = async () => {
    try { await api.decidirAprovacao(dec.a.id, dec.aprovar, resp); toast(dec.aprovar ? 'Condição aprovada. O consultor já pode emitir.' : 'Pedido recusado'); setDec(null); setResp(''); await carregar(); recarregar && recarregar(); }
    catch (e) { toast(e.message, 'warn'); }
  };
  if (!lista) return <div className="preview-loading"><span className="spinner" /> Carregando…</div>;
  if (!lista.length) return <Empty icon="check" title="Nenhum pedido de aprovação" text={pode ? 'Quando um consultor pedir uma condição fora da alçada, o pedido aparece aqui.' : 'Descontos acima da sua alçada e itens fora do catálogo passam por aqui antes da emissão.'} />;
  return (
    <div className="stack">
      {lista.map((a) => (
        <section key={a.id} className="card" data-testid="aprovacao">
          <header className="card-head">
            <div><h3>{a.cliente_nome || 'Cliente sem nome'}{a.numero ? ` · ${a.numero}` : ''}</h3>
              <span className="muted small">Pedido de {a.solicitante_nome} em {dataHora(a.created_at)}</span></div>
            <Tag tone={a.status === 'pendente' ? 'warn' : a.status === 'aprovada' ? 'accent' : 'default'}>{a.status === 'pendente' ? 'Aguardando decisão' : a.status === 'aprovada' ? 'Aprovada' : 'Recusada'}</Tag>
          </header>
          <ul className="plain">{(a.motivos || []).map((m, i) => <li key={i}><Icon n="alert" s={13} /> {descreveMotivo(m)}</li>)}</ul>
          {a.justificativa && <p className="small"><b>Justificativa:</b> {a.justificativa}</p>}
          {a.status !== 'pendente' && <p className="small muted">{a.status === 'aprovada' ? 'Aprovada' : 'Recusada'} por {a.decisor_nome || '—'} em {dataHora(a.decidido_em)}{a.resposta ? ` · ${a.resposta}` : ''}</p>}
          <div className="row-gap wrap">
            {abrir && <Btn small icon="eye" onClick={() => abrir(a.proposta_id)}>Ver proposta</Btn>}
            {pode && a.status === 'pendente' && <><Btn small variant="primary" icon="check" onClick={() => setDec({ a, aprovar: true })}>Aprovar</Btn><Btn small icon="x" onClick={() => setDec({ a, aprovar: false })}>Recusar</Btn></>}
          </div>
        </section>
      ))}
      <Modal open={!!dec} onClose={() => setDec(null)} title={dec?.aprovar ? 'Aprovar condição excepcional' : 'Recusar pedido'}
        footer={<><Btn onClick={() => setDec(null)}>Cancelar</Btn><Btn variant="primary" disabled={!dec?.aprovar && !resp.trim()} onClick={decidir}>{dec?.aprovar ? 'Aprovar' : 'Recusar'}</Btn></>}>
        <p className="muted small">{dec?.aprovar ? 'A aprovação vale só para esta proposta, com exatamente estes itens, preços e condições. Qualquer mudança exige novo pedido.' : 'Informe o motivo para o consultor.'}</p>
        <Field label={dec?.aprovar ? 'Observação (opcional)' : 'Motivo'}><textarea className="inp" rows={3} value={resp} onChange={(e) => setResp(e.target.value)} /></Field>
      </Modal>
    </div>
  );
}

// ───────────── Administração ─────────────
export default function Administracao({ toast, cfg, setCfg }) {
  const owner = api.tem('owner'), aprov = api.tem('aprovador');
  const tabs = [
    ...(aprov || owner ? [{ value: 'alcadas', label: 'Alçadas de desconto' }] : []),
    { value: 'usuarios', label: 'Usuários' },
    ...(owner || aprov ? [{ value: 'numeracao', label: 'Numeração' }] : []),
    { value: 'painel', label: 'Painel' },
    ...(owner ? [{ value: 'importar', label: 'Importar dados antigos' }] : []),
    ...(owner || aprov ? [{ value: 'historico', label: 'Histórico de alterações' }] : []),
  ];
  const [tab, setTab] = useState(tabs[0].value);
  const [users, setUsers] = useState([]);
  const carregaUsers = async () => { try { setUsers((await api.listUsers()).users); } catch (e) { toast(e.message, 'warn'); } };
  useEffect(() => { carregaUsers(); }, []);
  return (
    <div className="stack">
      <div className="toolbar"><Seg value={tab} onChange={setTab} options={tabs} /></div>
      {tab === 'usuarios' && <Usuarios users={users} recarregar={carregaUsers} toast={toast} owner={owner} />}
      {tab === 'alcadas' && <Alcadas users={users} toast={toast} pode={aprov} />}
      {tab === 'numeracao' && <Numeracao toast={toast} owner={owner} />}
      {tab === 'painel' && <Painel toast={toast} />}
      {tab === 'importar' && <Importacoes toast={toast} cfg={cfg} setCfg={setCfg} />}
      {tab === 'historico' && <Historico toast={toast} />}
    </div>
  );
}

function Usuarios({ users, recarregar, toast, owner }) {
  const [ed, setEd] = useState(null);
  const novo = () => setEd({ novo: true, nome: '', email: '', sigla: '', telefone: '', roles: ['consultor'], senha: '', ativo: true });
  const salvar = async () => {
    try {
      if (ed.novo) await api.criarUser(ed);
      else await api.alterarUser(ed.id, { nome: ed.nome, sigla: ed.sigla, telefone: ed.telefone, roles: ed.roles, ativo: ed.ativo, ...(ed.senha ? { senha: ed.senha } : {}) });
      toast(ed.novo ? 'Usuário criado' : 'Usuário atualizado'); setEd(null); recarregar();
    } catch (e) { toast(e.message, 'warn'); }
  };
  const alterna = (r) => setEd((x) => ({ ...x, roles: x.roles.includes(r) ? x.roles.filter((y) => y !== r) : [...x.roles, r] }));
  return (
    <section className="card">
      <header className="card-head"><div><h3>Usuários</h3><span className="muted small">Cada pessoa entra com a própria conta. O sufixo completa o número da proposta (ex.: 10112026/1275<b>HF</b>).</span></div>
        {owner && <Btn small icon="plus" variant="line" onClick={novo} data-testid="novo-usuario">Novo usuário</Btn>}</header>
      <div className="tbl-wrap"><table className="tbl">
        <thead><tr><th>Nome</th><th>E-mail</th><th>Sufixo</th><th>Papéis</th><th>Situação</th><th /></tr></thead>
        <tbody>{users.map((u) => (
          <tr key={u.id}><td><b>{u.nome}</b></td><td>{u.email}</td><td className="mono">{u.sigla || '—'}</td><td>{u.roles.map(nomePapel).join(', ')}</td><td>{u.ativo ? <Tag tone="accent">Ativo</Tag> : <Tag>Desativado</Tag>}</td>
            <td>{owner && <Btn small icon="edit" onClick={() => setEd({ ...u, senha: '' })}>Editar</Btn>}</td></tr>
        ))}</tbody>
      </table></div>
      <Modal open={!!ed} onClose={() => setEd(null)} title={ed?.novo ? 'Novo usuário' : 'Editar usuário'}
        footer={<><Btn onClick={() => setEd(null)}>Cancelar</Btn><Btn variant="primary" icon="check" onClick={salvar} disabled={!ed || !ed.nome.trim() || (ed.novo && (!ed.email || ed.senha.length < 10))}>Salvar</Btn></>}>
        {ed && (
          <div className="form-grid">
            <Field label="Nome" span={2}><Text value={ed.nome} onChange={(v) => setEd({ ...ed, nome: v })} data-testid="user-nome" /></Field>
            <Field label="E-mail" span={2}><Text value={ed.email} onChange={(v) => setEd({ ...ed, email: v })} type="email" disabled={!ed.novo} data-testid="user-email" /></Field>
            <Field label="Sufixo do número" hint="até 3 letras"><Text value={ed.sigla} onChange={(v) => setEd({ ...ed, sigla: v.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3) })} placeholder="HF" data-testid="user-sigla" /></Field>
            <Field label="WhatsApp"><Text value={ed.telefone} onChange={(v) => setEd({ ...ed, telefone: v })} inputMode="tel" /></Field>
            <Field label={ed.novo ? 'Senha inicial' : 'Nova senha (deixe vazio para manter)'} span={2} hint="10 caracteres ou mais, com letras e números"><Text value={ed.senha} onChange={(v) => setEd({ ...ed, senha: v })} type="password" autoComplete="new-password" data-testid="user-senha" /></Field>
            <Field label="Papéis" span={2}>
              <div className="chips chips-md">{PAPEIS.map((p) => <button key={p.value} type="button" className={`chip ${ed.roles.includes(p.value) ? 'on' : ''}`} onClick={() => alterna(p.value)} aria-pressed={ed.roles.includes(p.value)}><span className="chip-main">{p.label}</span><span className="chip-sub">{p.sub}</span></button>)}</div>
            </Field>
            {!ed.novo && <Field label="Situação" span={2}><Chips size="sm" value={ed.ativo ? 's' : 'n'} onChange={(v) => setEd({ ...ed, ativo: v === 's' })} options={[{ value: 's', label: 'Ativo' }, { value: 'n', label: 'Desativado', sub: 'não entra mais' }]} /></Field>}
          </div>
        )}
      </Modal>
    </section>
  );
}

const KINDS = [['totem', 'Totens'], ['catraca', 'Catracas'], ['comanda', 'Comandas'], ['servico', 'Serviços'], ['plano', 'Planos Teloos'], ['adicional', 'Adicionais Teloos'], ['implantacao', 'Implantação Teloos']];
function Alcadas({ users, toast, pode }) {
  const [lista, setLista] = useState(null);
  const [f, setF] = useState({ userId: '', pct: '', inicio: '', fim: '', kinds: [], condicoes: '' });
  const carregar = async () => { try { setLista((await api.listAlcadas()).alcadas); } catch (e) { toast(e.message, 'warn'); setLista([]); } };
  useEffect(() => { carregar(); }, []);
  const hoje = new Date().toISOString().slice(0, 10);
  const vigente = (a) => !a.revogada_em && a.inicio <= hoje && (!a.fim || a.fim >= hoje);
  const conceder = async () => {
    try { await api.concederAlcada({ ...f, pct: Number(String(f.pct).replace(',', '.')) }); toast('Alçada registrada'); setF({ userId: '', pct: '', inicio: '', fim: '', kinds: [], condicoes: '' }); carregar(); }
    catch (e) { toast(e.message, 'warn'); }
  };
  const pctOk = f.pct !== '' && Number.isFinite(Number(String(f.pct).replace(',', '.')));
  return (
    <div className="stack">
      <section className="card">
        <header className="card-head"><div><h3>Alçadas de desconto</h3>
          <span className="muted small">Sem alçada vigente, o limite do consultor é zero: qualquer desconto precisa de aprovação. A alçada vale sobre o total de tabela dos itens de catálogo (frete e itens livres ficam de fora). A política V2/2026 exige autorização da Diretoria Comercial: cada alçada fica registrada com aprovador, data e vigência.</span></div></header>
        {pode ? (
          <>
            <div className="form-grid four">
              <Field label="Consultor"><Select value={f.userId} onChange={(v) => setF({ ...f, userId: v })} options={[{ value: '', label: 'Selecione' }, ...users.filter((u) => u.ativo).map((u) => ({ value: u.id, label: u.nome }))]} data-testid="alcada-user" /></Field>
              <Field label="Limite (%)"><Text value={f.pct} onChange={(v) => setF({ ...f, pct: v })} inputMode="decimal" placeholder="0" data-testid="alcada-pct" /></Field>
              <Field label="Início" hint="vazio = hoje"><Text value={f.inicio} onChange={(v) => setF({ ...f, inicio: v })} type="date" /></Field>
              <Field label="Fim" hint="vazio = sem prazo"><Text value={f.fim} onChange={(v) => setF({ ...f, fim: v })} type="date" /></Field>
            </div>
            <Field label="Categorias" hint="nenhuma marcada = todas">
              <div className="chips chips-sm">{KINDS.map(([k, t]) => <button key={k} type="button" className={`chip ${f.kinds.includes(k) ? 'on' : ''}`} aria-pressed={f.kinds.includes(k)} onClick={() => setF({ ...f, kinds: f.kinds.includes(k) ? f.kinds.filter((x) => x !== k) : [...f.kinds, k] })}>{t}</button>)}</div>
            </Field>
            <Field label="Condições e observações"><Text value={f.condicoes} onChange={(v) => setF({ ...f, condicoes: v })} placeholder="Ex.: válida para pagamento à vista" /></Field>
            <Btn variant="primary" icon="check" disabled={!f.userId || !pctOk} onClick={conceder} data-testid="alcada-conceder">Registrar alçada</Btn>
          </>
        ) : <p className="muted small">Somente a autoridade comercial (papel Aprovador) registra ou revoga alçadas.</p>}
      </section>
      <section className="card">
        <header className="card-head"><h3>Registro de alçadas</h3></header>
        {!lista ? <span className="spinner" /> : !lista.length ? <p className="muted small">Nenhuma alçada registrada. Todos os consultores estão com limite zero.</p> : (
          <div className="tbl-wrap"><table className="tbl">
            <thead><tr><th>Consultor</th><th>Limite</th><th>Abrangência</th><th>Vigência</th><th>Aprovado por</th><th>Situação</th><th /></tr></thead>
            <tbody>{lista.map((a) => (
              <tr key={a.id}><td><b>{a.usuario}</b></td><td className="mono">{String(a.pct).replace('.', ',')}%</td>
                <td>{a.kinds ? a.kinds.map((k) => (KINDS.find((x) => x[0] === k) || [k, k])[1]).join(', ') : 'Todas as categorias'}{a.condicoes ? <small className="muted"> · {a.condicoes}</small> : null}</td>
                <td>{dia(a.inicio)} a {a.fim ? dia(a.fim) : 'sem prazo'}</td><td>{a.aprovador}<small className="muted"> · {dataHora(a.aprovado_em)}</small></td>
                <td>{a.revogada_em ? <Tag>Revogada</Tag> : vigente(a) ? <Tag tone="accent">Vigente</Tag> : <Tag tone="warn">{a.inicio > hoje ? 'Futura' : 'Expirada'}</Tag>}</td>
                <td>{pode && !a.revogada_em && <Btn small icon="x" onClick={async () => { try { await api.revogarAlcada(a.id); toast('Alçada revogada'); carregar(); } catch (e) { toast(e.message, 'warn'); } }}>Revogar</Btn>}</td></tr>
            ))}</tbody>
          </table></div>
        )}
      </section>
    </div>
  );
}

function Numeracao({ toast, owner }) {
  const [s, setS] = useState(null);
  const [n, setN] = useState('');
  const carregar = async () => { try { const r = await api.getSequencia(); setS(r); setN(r.proximo ? String(r.proximo) : ''); } catch (e) { toast(e.message, 'warn'); } };
  useEffect(() => { carregar(); }, []);
  return (
    <section className="card">
      <header className="card-head"><div><h3>Numeração das propostas</h3>
        <span className="muted small">Padrão: DDMMAAAA/sequência + sufixo do consultor (ex.: 10112026/1275HF). A sequência é única para toda a empresa, gerada pelo servidor no momento da emissão. Rascunhos e falhas não consomem número; revisões mantêm o número e a data da primeira emissão.</span></div></header>
      {!s ? <span className="spinner" /> : (
        <div className="form-grid">
          <Field label="Próximo número" hint={`Último usado neste sistema: ${s.ultimoUsado || 'nenhum'}`}><Text value={n} onChange={(v) => setN(v.replace(/\D/g, ''))} inputMode="numeric" disabled={!owner} data-testid="seq-proximo" /></Field>
          <div style={{ alignSelf: 'end' }}>{owner && <Btn variant="primary" icon="check" disabled={!n || Number(n) === s.proximo} onClick={async () => { try { await api.putSequencia(Number(n)); toast('Numeração atualizada'); carregar(); } catch (e) { toast(e.message, 'warn'); } }}>Salvar</Btn>}</div>
        </div>
      )}
      {s && !s.proximo && <div className="hint warn"><Icon n="alert" s={15} /><span>A numeração ainda não foi definida. Confira o último número usado nas propostas anteriores e informe o próximo: até lá a emissão fica bloqueada.</span></div>}
    </section>
  );
}

function Painel({ toast }) {
  const [d, setD] = useState(null);
  useEffect(() => { api.getDashboard().then(setD).catch((e) => toast(e.message, 'warn')); }, []);
  if (!d) return <div className="preview-loading"><span className="spinner" /> Carregando…</div>;
  const st = (k) => d.porStatus.find((x) => x.status === k) || { n: 0, valor: 0 };
  const km = (k) => (d.kommo.find((x) => x.status === k) || { n: 0 }).n;
  return (
    <div className="stack">
      <div className="stats">
        <div className="stat"><span className="stat-label">Emitidas</span><b className="stat-value">{st('emitida').n}</b><span className="stat-sub">{fmtBRL(st('emitida').valor)} propostos</span></div>
        <div className="stat"><span className="stat-label">Rascunhos</span><b className="stat-value">{st('rascunho').n}</b></div>
        <div className="stat"><span className="stat-label">Aguardando aprovação</span><b className="stat-value">{d.aprovacoesPendentes}</b></div>
        <div className="stat"><span className="stat-label">Anexadas ao Kommo</span><b className="stat-value">{km('anexado')}</b><span className="stat-sub">{km('falha')} com falha</span></div>
      </div>
      <p className="tiny muted">Valor proposto considera a versão vigente de cada proposta (revisões não somam) e não representa vendas realizadas.</p>
      <section className="card"><header className="card-head"><h3>Propostas emitidas por consultor</h3></header>
        {!d.porConsultor.length ? <p className="muted small">Nenhuma proposta emitida ainda.</p> : (
          <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Consultor</th><th>Propostas</th><th>Valor proposto</th></tr></thead>
            <tbody>{d.porConsultor.map((c) => <tr key={c.nome}><td>{c.nome}</td><td className="mono">{c.n}</td><td className="mono">{fmtBRL(c.valor)}</td></tr>)}</tbody></table></div>
        )}
      </section>
    </div>
  );
}

// Lê o que está salvo neste navegador pela versão antiga (localStorage)
export function lerDadosAntigos() {
  const ler = (k) => { try { const v = window.localStorage.getItem(k); return v ? JSON.parse(v) : null; } catch (e) { return null; } };
  return { config: ler('nxp.config'), propostas: ler('nxp.propostas') || [], fotos: ler('nxp.fotos') || {}, perfil: ler('nxp.perfil') };
}
// Diferenças de preço e taxa entre duas configurações (para a conferência do administrador)
export function compararConfigs(a, b) {
  const out = [];
  const par = (rot, x, y, fmt = (v) => v) => { if (JSON.stringify(x) !== JSON.stringify(y)) out.push({ rot, atual: x === undefined || x === null ? '—' : fmt(x), importado: y === undefined || y === null ? '—' : fmt(y) }); };
  const lista = (rot, la, lb, campo, fmt) => { const mb = new Map((lb || []).map((x) => [x.id, x])); const ma = new Map((la || []).map((x) => [x.id, x])); for (const id of new Set([...ma.keys(), ...mb.keys()])) par(`${rot} · ${(ma.get(id) || mb.get(id)).nome || id}`, ma.get(id)?.[campo], mb.get(id)?.[campo], fmt); };
  const N = a.nextcard || {}, M = b.nextcard || {};
  lista('Condição (fator)', N.condicoes, M.condicoes, 'fator');
  par('Arredondamento', N.arredondamento, M.arredondamento);
  lista('Totem (base R$)', N.totem?.modelos, M.totem?.modelos, 'base', (v) => Number(v).toFixed(2));
  for (const g of Object.keys(N.totem?.opcoes || {})) lista(`Opcional ${g} (R$)`, (N.totem.opcoes[g] || []).map((o) => ({ ...o, nome: o.label })), (M.totem?.opcoes?.[g] || []).map((o) => ({ ...o, nome: o.label })), 'valor', (v) => Number(v).toFixed(2));
  lista('Catraca', N.catracas, M.catracas, 'cents', fmtBRL);
  lista('Serviço', N.servicos, M.servicos, 'cents', fmtBRL);
  const tiers = (l) => (l || []).map((c) => ({ id: c.id, nome: c.nome, t: (c.tiers || []).map((t) => `${t.ate}: ${fmtBRL(t.cents)}`).join(' | ') }));
  lista('Comanda (faixas)', tiers(N.comandas), tiers(M.comandas), 't');
  lista('Modalidade (fator totem)', N.modalidades, M.modalidades, 'fatorTotem');
  const T = a.teloos || {}, U = b.teloos || {};
  lista('Plano Teloos', T.planos, U.planos, 'cents', fmtBRL);
  lista('Adicional Teloos', T.adicionais, U.adicionais, 'cents', fmtBRL);
  lista('Periodicidade (fator)', T.periodicidades, U.periodicidades, 'fator');
  lista('Implantação', T.implantacao, U.implantacao, 'cents', fmtBRL);
  return out;
}

function Importacoes({ toast, cfg, setCfg }) {
  const [lista, setLista] = useState(null);
  const [ver, setVer] = useState(null);
  const carregar = async () => { try { setLista((await api.listImportacoes()).importacoes); } catch (e) { toast(e.message, 'warn'); setLista([]); } };
  useEffect(() => { carregar(); }, []);
  const diffs = useMemo(() => (ver?.payload?.config ? compararConfigs(cfg, ver.payload.config) : []), [ver, cfg]);
  const usar = async () => {
    const { responsaveis, proximoNumero, version, fotosVersao, textosVersao, ...resto } = ver.payload.config;
    setCfg((c) => ({ ...c, ...resto }));
    await api.statusImportacao(ver.id, 'aplicada').catch(() => {});
    toast('Configuração carregada no editor. Revise e clique em “Salvar alterações” para publicar.', 'info');
    setVer(null); carregar();
  };
  return (
    <section className="card">
      <header className="card-head"><div><h3>Configurações que estavam nos navegadores</h3>
        <span className="muted small">Na versão anterior, cada computador guardava a própria configuração. Cada pessoa envia a sua pelo aviso da tela inicial; aqui você compara com a configuração oficial e decide. Nada é aplicado automaticamente.</span></div></header>
      {!lista ? <span className="spinner" /> : !lista.length ? <p className="muted small">Nenhum envio recebido.</p> : (
        <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Enviado por</th><th>Quando</th><th>Origem</th><th>Situação</th><th /></tr></thead>
          <tbody>{lista.map((i) => (
            <tr key={i.id}><td>{i.autor}</td><td>{dataHora(i.created_at)}</td><td className="small">{i.origem}</td><td><Tag tone={i.status === 'pendente' ? 'warn' : 'default'}>{i.status}</Tag></td>
              <td><Btn small icon="eye" onClick={() => setVer(i)}>Comparar</Btn></td></tr>
          ))}</tbody></table></div>
      )}
      <Modal open={!!ver} onClose={() => setVer(null)} wide title={`Comparação com a configuração oficial · ${ver?.autor || ''}`}
        footer={<><Btn onClick={async () => { await api.statusImportacao(ver.id, 'descartada').catch(() => {}); setVer(null); carregar(); }}>Descartar envio</Btn><Btn variant="primary" disabled={!diffs.length} onClick={usar}>Carregar no editor para revisar</Btn></>}>
        {!ver?.payload?.config ? <p className="muted">Este envio não tem configuração.</p> : !diffs.length ? <p>Preços e taxas idênticos à configuração oficial.</p> : (
          <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Item</th><th>Oficial hoje</th><th>Neste envio</th></tr></thead>
            <tbody>{diffs.map((d, k) => <tr key={k}><td>{d.rot}</td><td className="mono">{String(d.atual)}</td><td className="mono"><b>{String(d.importado)}</b></td></tr>)}</tbody></table></div>
        )}
      </Modal>
    </section>
  );
}

function Historico({ toast }) {
  const [ev, setEv] = useState(null);
  useEffect(() => { api.getAudit().then((r) => setEv(r.eventos)).catch((e) => { toast(e.message, 'warn'); setEv([]); }); }, []);
  const nome = { 'config.publicada': 'Configuração publicada', 'proposta.emitida': 'Proposta emitida', 'alcada.concedida': 'Alçada registrada', 'alcada.revogada': 'Alçada revogada', 'aprovacao.solicitada': 'Aprovação solicitada', 'aprovacao.aprovada': 'Exceção aprovada', 'aprovacao.rejeitada': 'Exceção recusada', 'usuario.criado': 'Usuário criado', 'usuario.alterado': 'Usuário alterado', 'kommo.anexado': 'PDF anexado ao Kommo', 'kommo.falha': 'Falha no Kommo', 'acesso.negado': 'Acesso negado', 'sequencia.definida': 'Numeração alterada', 'proposta.cancelada': 'Proposta cancelada', login: 'Entrada no sistema' };
  if (!ev) return <div className="preview-loading"><span className="spinner" /> Carregando…</div>;
  return (
    <section className="card">
      <header className="card-head"><div><h3>Histórico de alterações</h3><span className="muted small">Últimos 300 eventos. Cada publicação de configuração mostra o que mudou.</span></div></header>
      <div className="tbl-wrap"><table className="tbl"><thead><tr><th>Quando</th><th>Quem</th><th>Evento</th><th>Detalhe</th></tr></thead>
        <tbody>{ev.filter((e) => e.acao !== 'login').map((e) => (
          <tr key={e.id}><td className="small">{dataHora(e.at)}</td><td>{e.usuario || '—'}</td><td>{nome[e.acao] || e.acao} <span className="muted small">{e.alvo}</span></td>
            <td className="small">{e.detalhe?.alteracoes ? e.detalhe.alteracoes.slice(0, 6).map((a, k) => <div key={k}><span className="mono">{a.campo}</span>: {a.antes ?? '—'} → <b>{a.depois ?? '—'}</b></div>) : e.detalhe && Object.keys(e.detalhe).length ? Object.entries(e.detalhe).filter(([, v]) => v !== null && v !== '').map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`).join(' · ') : ''}
              {e.detalhe?.alteracoes?.length > 6 && <div className="muted">+ {e.detalhe.alteracoes.length - 6} alterações</div>}</td></tr>
        ))}</tbody></table></div>
    </section>
  );
}
