import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Icon, Btn, Modal, Tag, Field, Text } from './common.jsx';
import Builder from './Builder.jsx';
import Pronta from './Pronta.jsx';
import Configuracao from './Config.jsx';
import { Inicio, Catalogo, Propostas, Politica, valorProposta, SolucaoPicker } from './Screens.jsx';
import { loadConfig, saveConfig, loadPropostas, savePropostas, loadFotos, saveFotos, loadUI, saveUI, loadPerfil, savePerfil, storageOk, uid, novoId } from '../store.js';
import * as api from '../api.js';
import Administracao, { Login, BarraSalvar, Aprovacoes, MinhaConta, descreveMotivo, lerDadosAntigos } from './Admin.jsx';
import { CONFIG_VERSION } from '../defaults.js';
import { IMG } from '../assets.js';
import { novaProposta, TIPOS_SOLUCAO, linhaTotem, linhaCatraca, linhaComanda, linhaServico, linhaPlano, linhaAdicional, autoInclusos, freteSugerido, nomeSugerido, emitir } from '../model.js';
import { calcNextcard, calcTeloos, fmtBRL } from '../core.js';

const REMOTO = api.REMOTO;
const NAV_BASE = [
  { id: 'inicio', t: 'Início', i: 'home' },
  { id: 'propostas', t: 'Propostas', i: 'kanban' },
  { id: 'catalogo', t: 'Catálogo', i: 'grid' },
  { id: 'politica', t: 'Política comercial', i: 'book' },
  { id: 'aprovacoes', t: 'Aprovações', i: 'check', remoto: true },
  { id: 'admin', t: 'Administração', i: 'user', remoto: true, roles: ['owner', 'aprovador', 'gestor'] },
  { id: 'config', t: 'Configuração', i: 'gear' },
];
const navDe = () => NAV_BASE.filter((n) => (!n.remoto || REMOTO) && (!n.roles || api.tem(...n.roles)));
const consultorDe = (u) => ({ nome: u.nome, sigla: u.sigla, telefone: u.telefone, email: u.email });

const init = (() => {
  const { config, aviso } = REMOTO ? { config: null, aviso: null } : loadConfig();
  const ui = loadUI();
  return { config, aviso, propostas: REMOTO ? [] : loadPropostas(), fotos: REMOTO ? {} : loadFotos(), perfil: REMOTO ? null : loadPerfil(), brand: ui.brand === 'teloos' ? 'teloos' : 'nextcard', tema: ui.tema === 'claro' ? 'claro' : 'escuro', temaProposta: ['claro', 'cinza'].includes(ui.temaProposta) ? ui.temaProposta : 'escuro' };
})();
const hhmm = () => new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

// Com servidor: confere a sessão, carrega configuração oficial, fotos e propostas, e só então abre o aplicativo.
export default function App() {
  const [st, setSt] = useState(REMOTO ? { fase: 'carregando' } : { fase: 'ok', boot: init });
  const carregar = useCallback(async () => {
    try {
      await api.carregarSessao();
      const [c, f, ps] = await Promise.all([api.getConfig(), api.getFotos(), api.listPropostas()]);
      for (const p of ps.propostas) api.registrarRev(p.id, p._srv.rev);
      setSt({ fase: 'ok', boot: { ...init, config: { ...c.data, responsaveis: [consultorDe(api.ctx.user)] }, cfgVersion: c.version, propostas: ps.propostas, fotos: f.fotos, perfil: consultorDe(api.ctx.user) } });
    } catch (e) {
      if (e.status === 401) setSt({ fase: 'login' });
      else setSt({ fase: 'login', offline: e.status === 503 ? e.message : `Não foi possível falar com o servidor (${e.message}). Tente novamente em instantes.` });
    }
  }, []);
  useEffect(() => { if (REMOTO) { api.onSessaoExpirada(() => setSt({ fase: 'login', offline: 'Sua sessão terminou. Entre de novo para continuar.' })); carregar(); } }, []);
  if (st.fase === 'carregando') return <div className="login"><div className="preview-loading"><span className="spinner" /> Carregando…</div></div>;
  if (st.fase === 'login') return <Login onOk={carregar} offline={st.offline} />;
  return <AppInner key={REMOTO ? api.ctx.user.id : 'local'} boot={st.boot} sair={async () => { await api.logout(); setSt({ fase: 'login' }); }} />;
}

function AppInner({ boot, sair }) {
  const init = boot; // eslint-disable-line no-shadow
  const NAV = navDe();
  const [cfg, setCfg] = useState(init.config);
  const [propostas, setPropostas] = useState(init.propostas);
  const [fotos, setFotosLocal] = useState(init.fotos);
  const [perfil, setPerfil] = useState(init.perfil);
  const [perfilOpen, setPerfilOpen] = useState(!REMOTO && !init.perfil);
  // Configuração oficial: versão publicada que este navegador tem e estado do salvamento
  const [cfgBase, setCfgBase] = useState(() => ({ version: init.cfgVersion || null, json: REMOTO ? JSON.stringify(api.configLimpa(init.config)) : '' }));
  const [cfgSave, setCfgSave] = useState({ estado: 'limpo', erro: null });
  const [pedido, setPedido] = useState(null); // emissão bloqueada: pedido de aprovação
  const [justif, setJustif] = useState('');
  const [emitindo, setEmitindo] = useState(false);
  const [legado, setLegado] = useState(() => { if (!REMOTO) return null; try { if (window.localStorage.getItem('nxp.migrado')) return null; } catch (e) { return null; } const d = lerDadosAntigos(); return d.config || d.propostas.length ? d : null; });
  const [brand, setBrand] = useState(init.brand);
  const [tema, setTema] = useState(init.tema); // tema da interface: escuro (padrão) ou claro, salvo neste navegador
  const [temaProposta, setTemaProposta] = useState(init.temaProposta); // padrão das novas propostas (Configuração → Aparência)
  const [route, setRoute] = useState('inicio');
  const [draft, setDraft] = useState(null);
  const [step, setStep] = useState(1);
  const [salvoEm, setSalvoEm] = useState(null);
  const [toasts, setToasts] = useState([]);
  const [confirm, setConfirm] = useState(null);
  const [picker, setPicker] = useState(false);
  const [catFiltro, setCatFiltro] = useState(null);
  const [q, setQ] = useState('');
  const [qOpen, setQOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const [buscaPropostas, setBuscaPropostas] = useState('');

  const toast = useCallback((msg, tone = 'ok', action) => {
    const id = uid();
    setToasts((t) => [...t.slice(-2), { id, msg, tone, action }]);
    // confirmação some rápido; alerta e aviso com ação ficam mais tempo (e sempre podem ser fechados)
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), action ? 7000 : tone === 'ok' ? 3500 : 6500);
  }, []);
  const fechaToast = (id) => setToasts((t) => t.filter((x) => x.id !== id));

  useEffect(() => { if (init.aviso) toast(init.aviso, 'info'); if (!storageOk()) toast('O navegador bloqueou o armazenamento: os dados não serão salvos ao fechar.', 'warn'); }, []);
  useEffect(() => {
    document.documentElement.dataset.brand = brand;
    document.documentElement.dataset.theme = tema === 'claro' ? 'light' : 'dark';
    saveUI({ brand, tema, temaProposta });
  }, [brand, tema, temaProposta]);
  useEffect(() => { if (!REMOTO) saveConfig(cfg); }, [cfg]);
  useEffect(() => { if (REMOTO) return; const r = savePropostas(propostas); if (r.quota) toast('Armazenamento cheio: remova logos ou fotos enviadas', 'warn'); }, [propostas]);
  useEffect(() => { if (REMOTO) return; const r = saveFotos(fotos); if (r.quota) toast('Armazenamento cheio: remova fotos enviadas em Configuração', 'warn'); }, [fotos]);

  // ── Configuração oficial no servidor ──
  const cfgJson = useMemo(() => (REMOTO ? JSON.stringify(api.configLimpa(cfg)) : ''), [cfg]);
  const cfgSuja = REMOTO && cfgJson !== cfgBase.json;
  const estadoCfg = cfgSave.estado === 'salvando' || cfgSave.estado === 'conflito' ? cfgSave.estado : cfgSuja ? (cfgSave.estado === 'erro' ? 'erro' : 'sujo') : cfgSave.estado === 'salvo' ? 'salvo' : 'limpo';
  const aplicaCfg = (c) => { setCfg({ ...c.data, responsaveis: [consultorDe(api.ctx.user)] }); setCfgBase({ version: c.version, json: JSON.stringify(api.configLimpa(c.data)) }); api.ctx.configVersion = c.version; };
  const salvarCfg = async () => {
    if (!api.tem('owner')) return;
    setCfgSave({ estado: 'salvando' });
    try {
      const r = await api.putConfig(cfgBase.version, api.configLimpa(cfg), '');
      setCfgBase({ version: r.version, json: cfgJson }); api.ctx.configVersion = r.version;
      setCfgSave({ estado: 'salvo' });
      setTimeout(() => setCfgSave((x) => (x.estado === 'salvo' ? { estado: 'limpo' } : x)), 6000);
    } catch (e) { setCfgSave(e.code === 'conflito' ? { estado: 'conflito' } : { estado: 'erro', erro: (e.body.erros || []).slice(0, 3).join('; ') || e.message }); }
  };
  const recarregarCfg = async () => { try { aplicaCfg(await api.getConfig()); setCfgSave({ estado: 'limpo' }); } catch (e) { toast(e.message, 'warn'); } };
  const descartarCfg = () => { setCfg({ ...JSON.parse(cfgBase.json), responsaveis: [consultorDe(api.ctx.user)] }); setCfgSave({ estado: 'limpo' }); };
  // Outro usuário publicou tabela nova: ao voltar para a aba, busca a versão vigente (sem atropelar edição em curso)
  const sujaRef = useRef(false); sujaRef.current = cfgSuja;
  useEffect(() => {
    if (!REMOTO) return undefined;
    const ver = async () => {
      if (document.visibilityState !== 'visible' || sujaRef.current) return;
      try { const antes = api.ctx.configVersion; const me = await api.carregarSessao(); if (me.configVersion !== antes) { aplicaCfg(await api.getConfig()); toast('Tabela e condições atualizadas pela administração', 'info'); } } catch (e) { /* sessão expirada é tratada pelo cliente da API */ }
    };
    document.addEventListener('visibilitychange', ver);
    const sair_ = (e) => { if (sujaRef.current || api.temPendencia()) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', sair_);
    return () => { document.removeEventListener('visibilitychange', ver); window.removeEventListener('beforeunload', sair_); };
  }, []);

  // Fotos enviadas pelo administrador: grava no servidor o que mudou
  const setFotos = (n) => {
    const ant = fotos || {};
    setFotosLocal(n);
    if (!REMOTO) return;
    for (const k of new Set([...Object.keys(ant), ...Object.keys(n || {})])) {
      if (ant[k] === (n || {})[k]) continue;
      ((n || {})[k] ? api.putFoto(k, n[k]) : api.delFoto(k)).catch((e) => toast(`Foto não salva no servidor: ${e.message}`, 'warn'));
    }
  };
  const errSync = useRef(0);
  const aoSincronizar = (estado, e) => {
    if (estado === 'salvo') setSalvoEm(hhmm());
    if (estado === 'erro' && Date.now() - errSync.current > 15000) { errSync.current = Date.now(); setSalvoEm(null); toast(`Rascunho ainda não salvo no servidor: ${e ? e.message : ''}. Nova tentativa na próxima alteração.`, 'warn'); }
  };

  // autosave do rascunho: só depois que o consultor mexeu (evita rascunhos vazios)
  const relevante = (d) => !!d && (d.tocada || !!d.cliente?.empresa?.trim() || propostas.some((p) => p.id === d.id));
  const tRef = useRef();
  useEffect(() => {
    if (!draft || route !== 'nova' || !relevante(draft)) return;
    clearTimeout(tRef.current);
    tRef.current = setTimeout(() => { upsert(draft); if (!REMOTO) setSalvoEm(hhmm()); }, REMOTO ? 900 : 400);
    return () => clearTimeout(tRef.current);
  }, [draft]);

  // Ao fechar ou trocar de aba, grava o rascunho na hora (o autosave tem espera de 400 ms)
  const vivo = useRef({});
  vivo.current = { draft, propostas, route, relevante };
  useEffect(() => {
    const salvaJa = () => {
      const { draft: d, propostas: ps, route: r, relevante: rel } = vivo.current;
      if (!d || r !== 'nova' || !rel(d)) return;
      const n = { ...d, atualizadaEm: new Date().toISOString() };
      if (REMOTO) { api.salvarRascunho(n); return; }
      savePropostas(ps.some((x) => x.id === n.id) ? ps.map((x) => (x.id === n.id ? n : x)) : [n, ...ps]);
    };
    const vis = () => { if (document.visibilityState === 'hidden') salvaJa(); };
    window.addEventListener('pagehide', salvaJa);
    window.addEventListener('beforeunload', salvaJa);
    document.addEventListener('visibilitychange', vis);
    return () => { window.removeEventListener('pagehide', salvaJa); window.removeEventListener('beforeunload', salvaJa); document.removeEventListener('visibilitychange', vis); };
  }, []);

  const upsert = (p) => {
    const n = { ...p, atualizadaEm: new Date().toISOString() };
    setPropostas((list) => (list.some((x) => x.id === n.id) ? list.map((x) => (x.id === n.id ? n : x)) : [n, ...list]));
    if (REMOTO) api.salvarRascunho(n, aoSincronizar);
    return n;
  };
  const flush = () => { if (route === 'nova' && relevante(draft)) { clearTimeout(tRef.current); upsert(draft); } };
  const setProp = useCallback((fn) => setDraft((d) => {
    const n = typeof fn === 'function' ? fn(d) : fn;
    return n === d ? d : { ...n, tocada: true };
  }), []);

  const topo = () => window.scrollTo({ top: 0 });
  const go = (r) => { flush(); setRoute(r); setMenu(false); setQOpen(false); setBuscaPropostas(''); topo(); };
  const iniciar = (tipo) => {
    flush();
    const b = TIPOS_SOLUCAO[tipo]?.brand || brand;
    setBrand(b);
    setDraft({ ...novaProposta(b, cfg, tipo, perfil), temaProposta });
    setStep(1); setSalvoEm(null); setPicker(false); setMenu(false);
    setRoute('nova'); topo();
  };
  const abrir = (id) => {
    flush();
    const p = propostas.find((x) => x.id === id);
    if (!p) return;
    setBrand(p.empresa || 'nextcard');
    setDraft(JSON.parse(JSON.stringify(p)));
    setSalvoEm(null); setQOpen(false); setQ(''); setMenu(false);
    if (p.numero) setRoute('pronta');
    else { setStep(p.cliente?.empresa ? 2 : 1); setRoute('nova'); }
    topo();
  };
  const editar = () => { setStep(2); setRoute('nova'); topo(); };

  const trocaEmpresa = (b) => { if (b !== brand) { flush(); setBrand(b); if (route === 'nova' || route === 'pronta') setRoute('inicio'); } };

  const addToProposal = ({ kind, id }) => {
    let d = draft && route !== 'pronta' && draft.empresa === brand && !draft.numero ? draft : { ...novaProposta(brand, cfg, undefined, perfil), temaProposta };
    if (d !== draft) flush();
    const N = cfg.nextcard;
    let linha = null;
    if (kind === 'totem') linha = linhaTotem({ modelo: id, ...N.totem.referencia }, cfg, d, 1);
    if (kind === 'catraca') linha = linhaCatraca(N.catracas.find((c) => c.id === id));
    if (kind === 'comanda') linha = linhaComanda(N.comandas.find((c) => c.id === id), 100);
    if (kind === 'servico') linha = linhaServico(N.servicos.find((c) => c.id === id));
    if (kind === 'plano') {
      const pl = cfg.teloos.planos.find((p) => p.id === id);
      d = { ...d, teloos: { ...d.teloos, plano: id }, itens: [linhaPlano(pl, d.teloos.cupom), ...d.itens.filter((l) => l.kind !== 'plano')] };
    }
    if (kind === 'adicional') {
      const a = cfg.teloos.adicionais.find((x) => x.id === id);
      const ex = d.itens.find((l) => l.kind === 'adicional' && l.refId === id);
      d = { ...d, itens: ex ? d.itens.map((l) => (l === ex ? { ...l, qtd: l.qtd + 1 } : l)) : [...d.itens.filter((l) => l.kind !== 'implantacao'), linhaAdicional(a, d.teloos.cupom), ...d.itens.filter((l) => l.kind === 'implantacao')] };
    }
    if (linha) {
      const first = !d.itens.some((l) => l.kind === 'catraca');
      d = { ...d, itens: [...d.itens, linha] };
      if (first && linha.kind === 'catraca') d.pagamento = { ...d.pagamento, frete: freteSugerido(d) };
    }
    if (d.inclusosAuto) d.inclusos = autoInclusos(d, cfg);
    setDraft({ ...d, tocada: true });
    setStep(2);
    setRoute('nova'); topo();
    toast('Adicionado à proposta. Ajuste aqui se precisar.');
  };

  const dadosDe = (d) => { const { _srv, tocada, ...data } = { ...d, nome: d.nome || nomeSugerido(d, cfg) }; return data; };
  const gerarRemoto = async () => {
    if (!draft || emitindo) return;
    clearTimeout(tRef.current);
    setEmitindo(true);
    try {
      const r = await api.emitir(draft.id, dadosDe(draft));
      const n = r.proposta;
      api.registrarRev(n.id, n._srv.rev);
      setPropostas((l) => (l.some((x) => x.id === n.id) ? l.map((x) => (x.id === n.id ? n : x)) : [n, ...l]));
      setDraft(n);
      if (n._srv.configVersion !== cfgBase.version && !cfgSuja) { recarregarCfg(); toast('A tabela foi atualizada pela administração: a proposta saiu com os valores vigentes.', 'info'); }
      setRoute('pronta'); topo();
    } catch (e) {
      if (e.code === 'aprovacao_necessaria') { setJustif(''); setPedido({ pendencias: e.body.pendencias || [], limite: e.body.limite, pct: e.body.pct }); }
      else toast((e.body.erros || []).slice(0, 3).join('; ') || e.message, 'warn');
    }
    setEmitindo(false);
  };
  const pedirAprovacao = async () => {
    try {
      await api.pedirAprovacao(draft.id, dadosDe(draft), justif);
      setPedido(null);
      await recarregarPropostas(); // a lista passa a ter exatamente o que foi enviado para aprovação
      toast('Pedido enviado para aprovação. Você será avisado em Aprovações.', 'info');
      setRoute('aprovacoes'); topo();
    } catch (e) { toast(e.message, 'warn'); }
  };
  const recarregarPropostas = async () => { try { const ps = (await api.listPropostas()).propostas; for (const p of ps) api.registrarRev(p.id, p._srv.rev); setPropostas(ps); } catch (e) { toast(e.message, 'warn'); } };
  const gerar = () => {
    if (!draft) return;
    if (REMOTO) { gerarRemoto(); return; }
    clearTimeout(tRef.current);
    const em = emitir(draft, cfg);
    const now = new Date().toISOString();
    const calc = draft.empresa === 'teloos' ? calcTeloos(draft, cfg) : calcNextcard(draft, cfg);
    const versao = (draft.versao || 0) + 1;
    const n = {
      ...draft,
      nome: draft.nome || nomeSugerido(draft, cfg),
      numero: em.numero,
      emitidaEm: now,
      primeiraEmissao: draft.primeiraEmissao || now,
      versao,
      historico: [...(draft.historico || []), { versao, data: now, valorFinal: calc.valorFinal }],
    };
    if (em.proximo !== cfg.proximoNumero) setCfg((c) => ({ ...c, proximoNumero: em.proximo }));
    setDraft(upsert(n));
    setRoute('pronta'); topo();
  };
  const mover = (id, etapa, comDesfazer) => {
    const antes = propostas.find((p) => p.id === id)?.etapa;
    if (!antes || antes === etapa) return;
    const aplica = (e) => {
      setPropostas((l) => l.map((p) => (p.id === id ? { ...p, etapa: e, atualizadaEm: new Date().toISOString(), ...(e === 'enviada' && !p.enviadaEm ? { enviadaEm: new Date().toISOString() } : {}) } : p)));
      setDraft((d) => (d && d.id === id ? { ...d, etapa: e } : d));
    };
    aplica(etapa);
    if (REMOTO) api.situacao(id, { etapa }).catch((e) => toast(e.message, 'warn'));
    const nome = { rascunho: 'Rascunho', enviada: 'Enviada', negociacao: 'Em negociação', ganho: 'Ganho', perdido: 'Perdido' }[etapa];
    toast(comDesfazer ? 'Marcada como enviada' : `Movida para ${nome}`, 'ok', { label: 'Desfazer', onClick: () => { aplica(antes); if (REMOTO) api.situacao(id, { etapa: antes }).catch(() => {}); } });
  };
  const duplicar = (id) => {
    const p = propostas.find((x) => x.id === id);
    if (!p) return;
    const n = { ...JSON.parse(JSON.stringify(p)), id: novoId(), _srv: undefined, numero: null, versao: 0, emitidaEm: null, primeiraEmissao: null, enviadaEm: null, historico: [], etapa: 'rascunho', criadaEm: new Date().toISOString(), nome: p.nome ? p.nome + ' (cópia)' : '', tocada: true };
    upsert(n);
    return n;
  };
  const duplicarEAbrir = (id) => {
    const n = duplicar(id);
    if (!n) return;
    setBrand(n.empresa); setDraft(n); setStep(1); setRoute('nova'); topo();
    toast('Cópia criada. Troque o cliente e gere a nova proposta.', 'info');
  };
  const excluir = (id) => {
    const p = propostas.find((x) => x.id === id);
    if (!p) return;
    if (REMOTO) {
      setConfirm({ title: p.numero ? `Cancelar a proposta ${p.numero}?` : 'Excluir este rascunho?', text: p.numero ? 'O número e os documentos emitidos ficam preservados no histórico, mas a proposta sai da sua lista.' : 'O rascunho será apagado.', ok: async () => {
        try { await api.excluirProposta(id); setPropostas((l) => l.filter((x) => x.id !== id)); if (draft?.id === id && route !== 'nova') setDraft(null); toast(p.numero ? 'Proposta cancelada' : 'Rascunho excluído'); } catch (e) { toast(e.message, 'warn'); }
      } });
      return;
    }
    setPropostas((l) => l.filter((x) => x.id !== id));
    if (draft?.id === id && route !== 'nova') setDraft(null);
    toast('Proposta excluída', 'ok', { label: 'Desfazer', onClick: () => setPropostas((l) => (l.some((x) => x.id === id) ? l : [p, ...l])) });
  };
  const descartarRascunho = () => {
    if (!draft) return;
    const id = draft.id;
    const salvo = propostas.find((x) => x.id === id);
    clearTimeout(tRef.current);
    setPropostas((l) => l.filter((x) => x.id !== id));
    setDraft(null); setRoute('inicio'); topo();
    if (REMOTO) { if (salvo) api.excluirProposta(id).catch(() => {}); return; }
    if (salvo) toast('Rascunho descartado', 'ok', { label: 'Desfazer', onClick: () => setPropostas((l) => [salvo, ...l]) });
  };

  const salvarPerfil = (p) => {
    setPerfil(p); savePerfil(p); setPerfilOpen(false);
    setCfg((c) => {
      const list = c.responsaveis || [];
      const i = list.findIndex((r) => r.nome.trim().toLowerCase() === p.nome.trim().toLowerCase() || (perfil && r.nome === perfil.nome));
      const reg = { nome: p.nome, sigla: p.sigla, telefone: p.telefone, email: p.email };
      return { ...c, responsaveis: i >= 0 ? list.map((r, k) => (k === i ? { ...r, ...reg } : r)) : [...list, reg] };
    });
    if (draft && !draft.numero && (!draft.responsavel || draft.responsavel === perfil?.nome)) setDraft((d) => ({ ...d, responsavel: p.nome }));
    toast(`Tudo certo, ${p.nome.split(' ')[0]}!`);
  };

  // busca global
  const resultados = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (s.length < 2) return [];
    const out = [];
    for (const p of propostas) {
      const hay = `${p.cliente?.empresa} ${p.nome} ${p.numero} ${p.cliente?.contato}`.toLowerCase();
      if (hay.includes(s)) out.push({ tipo: p.empresa === 'teloos' ? 'Teloos' : 'Proposta', t: p.cliente?.empresa || 'Sem cliente', sub: `${p.numero || 'Rascunho'} · ${valorProposta(p, cfg).txt}`, act: () => abrir(p.id) });
    }
    const N = cfg.nextcard;
    const cat = [
      ...N.totem.modelos.map((m) => ({ b: 'nextcard', f: 'totem', t: m.nome, sub: m.id })),
      ...N.catracas.map((c) => ({ b: 'nextcard', f: 'catraca', t: c.nome, sub: `${c.codigo} · ${fmtBRL(c.cents)}` })),
      ...N.comandas.map((c) => ({ b: 'nextcard', f: 'comanda', t: c.nome, sub: c.codigoBase })),
      ...cfg.teloos.planos.map((p) => ({ b: 'teloos', f: 'planos', t: p.nomeCaps, sub: `${fmtBRL(p.cents)}/mês` })),
      ...cfg.teloos.adicionais.map((a) => ({ b: 'teloos', f: 'adicionais', t: a.nome, sub: 'Adicional Teloos' })),
    ];
    for (const c of cat) if (`${c.t} ${c.sub}`.toLowerCase().includes(s)) out.push({ tipo: 'Catálogo', t: c.t, sub: c.sub, act: () => { flush(); setBrand(c.b); setCatFiltro(c.f); setRoute('catalogo'); setQOpen(false); setQ(''); } });
    return out.slice(0, 12);
  }, [q, propostas, cfg]);

  const noBuilder = route === 'nova' && draft;
  const titulo = noBuilder
    ? (draft.numero ? `Editando Nº ${draft.numero}` : TIPOS_SOLUCAO[draft.tipoSolucao]?.nome || 'Nova proposta')
    : route === 'pronta' ? 'Proposta pronta' : NAV.find((n) => n.id === route)?.t;
  // tema claro: logo de letras escuras (arquivo oficial); tema escuro: logo negativo
  const logo = brand === 'teloos' ? (tema === 'claro' ? IMG.logoTeloos : IMG.logoTeloosNeg) : (tema === 'claro' ? IMG.logoNextcard : IMG.logoNextcardNeg);
  const abertas = propostas.filter((p) => ['enviada', 'negociacao'].includes(p.etapa)).length;
  const iniciais = (perfil?.nome || '?').trim().split(/\s+/).map((x) => x[0]).slice(0, 2).join('').toUpperCase();

  return (
    <div className={`app route-${route}`}>
      <div className="bg-fx" aria-hidden="true"><span className="orb o1" /><span className="orb o2" /><span className="grid-fx" /></div>
      {menu && <div className="side-back" onClick={() => setMenu(false)} />}
      <aside className={`side ${menu ? 'open' : ''}`}>
        <div className="side-logo"><img src={logo} alt={brand === 'teloos' ? 'Teloos' : 'NEXTCARD'} /></div>
        <span className="side-caption">Gerador de propostas</span>
        <Btn variant="primary" icon="plus" className="btn-block side-new" onClick={() => { setMenu(false); setPicker(true); }}>Nova proposta</Btn>
        <nav className="side-nav">
          {NAV.map((n) => (
            <button key={n.id} className={`nav ${route === n.id ? 'on' : ''}`} onClick={() => go(n.id)} type="button">
              <Icon n={n.i} s={18} /><span>{n.t}</span>
              {n.id === 'propostas' && abertas > 0 && <span className="nav-count">{abertas}</span>}
              {n.id === 'aprovacoes' && api.ctx.aprovacoesPendentes > 0 && <span className="nav-count">{api.ctx.aprovacoesPendentes}</span>}
            </button>
          ))}
        </nav>
        <div className="side-foot">
          <button type="button" className="me" onClick={() => (REMOTO ? go('config') : setPerfilOpen(true))} data-testid="perfil-btn">
            <span className="me-av">{iniciais}</span>
            <span className="me-txt"><b>{perfil?.nome || 'Quem é você?'}</b><small>{REMOTO ? `Sufixo ${perfil.sigla || '—'} · alçada ${String(api.ctx.alcadaPct).replace('.', ',')}%` : perfil ? `Sigla ${perfil.sigla || '—'} · editar perfil` : 'Cadastre seu perfil'}</small></span>
          </button>
          {REMOTO ? <span className="tiny ok">● dados salvos no servidor da empresa</span> : <span className={`tiny ${storageOk() ? 'ok' : 'warn'}`}>{storageOk() ? '● salvo neste navegador' : '● sem armazenamento: dados temporários'}</span>}
          <span className="tiny dim mono">{REMOTO ? `Configuração v${cfgBase.version}` : CONFIG_VERSION} · ProntoIA</span>
        </div>
      </aside>

      <main className="main">
        <header className="top">
          <button className="icon-btn burger" onClick={() => setMenu(!menu)} aria-label="Menu"><Icon n="list" /></button>
          {(noBuilder || route === 'pronta') && <button className="icon-btn back" onClick={() => (route === 'pronta' ? go('propostas') : go('inicio'))} aria-label="Voltar"><Icon n="left" /></button>}
          <div className="top-title">
            <span className="eyebrow">{brand === 'teloos' ? 'Teloos' : 'NEXTCARD'}</span>
            <h2>{titulo}{noBuilder && draft.cliente?.empresa ? <span className="muted"> · {draft.cliente.empresa}</span> : null}</h2>
          </div>
          <div className="top-search">
            <Icon n="search" s={16} />
            <input value={q} onChange={(e) => { setQ(e.target.value); setQOpen(true); }} onFocus={() => setQOpen(true)} onBlur={() => setTimeout(() => setQOpen(false), 180)} placeholder="Buscar cliente, proposta ou produto" aria-label="Busca global" />
            {qOpen && resultados.length > 0 && (
              <div className="search-drop">
                {resultados.map((r, i) => (
                  <button key={i} type="button" onMouseDown={(e) => e.preventDefault()} onClick={r.act}><Tag>{r.tipo}</Tag><span><b>{r.t}</b><small>{r.sub}</small></span></button>
                ))}
              </div>
            )}
          </div>
          <button type="button" className="theme-btn" role="switch" aria-checked={tema === 'claro'} onClick={() => setTema(tema === 'claro' ? 'escuro' : 'claro')}
            title={tema === 'claro' ? 'Mudar para o tema escuro' : 'Mudar para o tema claro'} aria-label="Tema claro" data-testid="tema-ui">
            <Icon n={tema === 'claro' ? 'sun' : 'moon'} s={17} /><span>{tema === 'claro' ? 'Claro' : 'Escuro'}</span>
          </button>
          {noBuilder ? (
            <div className="top-act">
              <button type="button" className="link tiny" onClick={descartarRascunho} disabled={!!draft.numero} hidden={!!draft.numero}>descartar rascunho</button>
            </div>
          ) : route !== 'pronta' && (
            <div className="brand-switch" role="tablist" aria-label="Empresa">
              <button className={brand === 'nextcard' ? 'on' : ''} onClick={() => { setBuscaPropostas(''); trocaEmpresa('nextcard'); }} type="button" role="tab" aria-selected={brand === 'nextcard'}>NEXTCARD</button>
              <button className={brand === 'teloos' ? 'on' : ''} onClick={() => { setBuscaPropostas(''); trocaEmpresa('teloos'); }} type="button" role="tab" aria-selected={brand === 'teloos'}>Teloos</button>
              <span className="brand-switch-ind" />
            </div>
          )}
        </header>

        {REMOTO && <BarraSalvar estado={estadoCfg} erro={cfgSave.erro} onSalvar={salvarCfg} onDescartar={descartarCfg} onRecarregar={recarregarCfg} />}
        <div className="content" key={brand + route}>
          {route === 'inicio' && legado && (
            <div className="hint legado" data-testid="aviso-legado" role="status">
              <Icon n="info" s={16} />
              <span>Este navegador guarda dados da versão anterior{legado.propostas.length ? `: ${legado.propostas.length} proposta(s)` : ''}{legado.config ? ' e uma configuração de preços e taxas' : ''}. Envie para o servidor: as propostas entram na sua lista como rascunhos (com o número antigo anotado) e a configuração vai para conferência do administrador. Nada é publicado automaticamente.</span>
              <Btn small variant="primary" onClick={async () => {
                try {
                  const r = legado.propostas.length ? await api.importarPropostas(legado.propostas.map((p) => ({ ...p, cliente: { ...(p.cliente || {}) } }))) : { importadas: 0 };
                  if (legado.config) await api.enviarImportacao({ config: legado.config, perfil: legado.perfil }, `${legado.perfil?.nome || api.ctx.user.nome} · ${navigator.platform || ''}`);
                  try { window.localStorage.setItem('nxp.migrado', new Date().toISOString()); } catch (e) { /* sem armazenamento */ }
                  setLegado(null); await recarregarPropostas();
                  toast(`${r.importadas} proposta(s) importada(s)${legado.config ? '; configuração enviada para conferência' : ''}`);
                } catch (e) { toast(e.message, 'warn'); }
              }}>Enviar ao servidor</Btn>
              <button type="button" className="link small" onClick={() => setLegado(null)}>agora não</button>
            </div>
          )}
          {route === 'inicio' && <Inicio propostas={propostas} cfg={cfg} perfil={perfil} fotos={fotos} iniciar={iniciar} abrir={abrir} go={go} mover={mover} />}
          {route === 'catalogo' && <Catalogo cfg={cfg} brand={brand} fotos={fotos} addToProposal={addToProposal} filtroInicial={catFiltro} />}
          {noBuilder && (
            <Builder prop={draft} setProp={setProp} cfg={cfg} fotos={fotos} propostas={propostas} onGerar={gerar} toast={toast} step={step} setStep={setStep} salvoEm={salvoEm} />
          )}
          {route === 'pronta' && draft && (
            <Pronta prop={draft} cfg={cfg} cfgVersion={cfgBase.version} fotos={fotos} toast={toast} onEditar={editar}
              onSrv={(patch) => { const up = (x) => ({ ...x, _srv: { ...(x._srv || {}), ...patch } }); setDraft((d) => (d ? up(d) : d)); setPropostas((l) => l.map((x) => (x.id === draft.id ? up(x) : x))); }} onNova={() => setPicker(true)} onDuplicar={() => duplicarEAbrir(draft.id)} onEtapa={(e, desf) => mover(draft.id, e, desf)}
              onAjuste={(patch) => setDraft(upsert({ ...draft, ...patch }))} />
          )}
          {route === 'propostas' && <Propostas propostas={propostas} cfg={cfg} brand={brand} abrir={abrir} mover={mover} duplicar={(id) => { duplicar(id); toast('Proposta duplicada'); }} excluir={excluir} nova={() => setPicker(true)} trocaMarca={(b, busca) => { setBuscaPropostas(busca); trocaEmpresa(b); }} buscaInicial={buscaPropostas} />}
          {route === 'politica' && <Politica cfg={cfg} brand={brand} />}
          {route === 'aprovacoes' && <Aprovacoes toast={toast} abrir={abrir} recarregar={() => { recarregarPropostas(); api.carregarSessao().catch(() => {}); }} />}
          {route === 'admin' && <Administracao toast={toast} cfg={cfg} setCfg={setCfg} />}
          {route === 'config' && <Configuracao cfg={cfg} setCfg={setCfg} brand={brand} fotos={fotos} setFotos={setFotos} propostas={propostas} setPropostas={setPropostas} toast={toast} tema={tema} setTema={setTema} temaProposta={temaProposta} setTemaProposta={setTemaProposta} cfgVersion={cfgBase.version} sair={sair} />}
        </div>
      </main>

      {/* Celular: navegação inferior (fora do construtor) */}
      {!noBuilder && (
        <nav className="bottom-nav" aria-label="Navegação">
          <button type="button" className={route === 'inicio' ? 'on' : ''} onClick={() => go('inicio')}><Icon n="home" s={20} /><span>Início</span></button>
          <button type="button" className={route === 'propostas' ? 'on' : ''} onClick={() => go('propostas')}><Icon n="kanban" s={20} /><span>Propostas</span></button>
          <button type="button" className="bn-new" onClick={() => setPicker(true)} aria-label="Nova proposta"><Icon n="plus" s={24} w={2.4} /></button>
          <button type="button" className={route === 'catalogo' ? 'on' : ''} onClick={() => go('catalogo')}><Icon n="grid" s={20} /><span>Catálogo</span></button>
          <button type="button" onClick={() => setMenu(true)}><Icon n="list" s={20} /><span>Mais</span></button>
        </nav>
      )}

      <Modal open={picker} onClose={() => setPicker(false)} wide title="O que você vai propor?">
        <SolucaoPicker iniciar={iniciar} fotos={fotos} />
      </Modal>

      <Modal open={!!pedido} onClose={() => setPedido(null)} title="Esta condição precisa de aprovação"
        footer={<><Btn onClick={() => setPedido(null)}>Voltar e ajustar</Btn><Btn variant="primary" icon="send" onClick={pedirAprovacao} data-testid="pedir-aprovacao">Solicitar aprovação</Btn></>}>
        <p className="small">A proposta não foi emitida e nenhum número foi usado. O rascunho está salvo.</p>
        <ul className="plain">{(pedido?.pendencias || []).map((m, i) => <li key={i}><Icon n="alert" s={13} /> {descreveMotivo(m)}</li>)}</ul>
        <p className="muted small">Sua alçada de desconto hoje: {String(pedido?.limite ?? 0).replace('.', ',')}%. Você pode voltar e ajustar os valores, ou pedir a aprovação da autoridade comercial. A aprovação vale só para esta proposta, exatamente como está.</p>
        <Field label="Justificativa para o aprovador"><textarea className="inp" rows={3} value={justif} onChange={(e) => setJustif(e.target.value)} placeholder="Ex.: cliente fecha hoje com pagamento à vista" data-testid="justificativa" /></Field>
      </Modal>

      <PerfilModal open={perfilOpen} perfil={perfil} onClose={() => setPerfilOpen(false)} onSave={salvarPerfil} />

      <Modal open={!!confirm} onClose={() => setConfirm(null)} title={confirm?.title}
        footer={<><Btn onClick={() => setConfirm(null)}>Cancelar</Btn><Btn variant="primary" onClick={() => { confirm.ok(); setConfirm(null); }}>Confirmar</Btn></>}>
        <p>{confirm?.text}</p>
      </Modal>

      <div className="toasts" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.tone}`}>
            <Icon n={t.tone === 'warn' ? 'alert' : t.tone === 'info' ? 'info' : 'check'} s={16} />
            <span className="toast-msg">{t.msg}</span>
            {t.action && <button type="button" className="toast-act" onClick={() => { t.action.onClick(); fechaToast(t.id); }}>{t.action.label}</button>}
            <button type="button" className="toast-x" onClick={() => fechaToast(t.id)} aria-label="Fechar aviso"><Icon n="x" s={14} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

function PerfilModal({ open, perfil, onClose, onSave }) {
  const [f, setF] = useState(perfil || { nome: '', sigla: '', telefone: '', email: '' });
  const [siglaManual, setSiglaManual] = useState(!!perfil?.sigla);
  useEffect(() => { if (open) { setF(perfil || { nome: '', sigla: '', telefone: '', email: '' }); setSiglaManual(!!perfil?.sigla); } }, [open]);
  const set = (k) => (v) => setF((x) => {
    const n = { ...x, [k]: v };
    if (k === 'nome' && !siglaManual) n.sigla = v.trim().charAt(0).toUpperCase();
    if (k === 'sigla') n.sigla = v.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3);
    return n;
  });
  const ok = f.nome.trim().length > 1;
  return (
    <Modal open={open} onClose={onClose} title={perfil ? 'Seu perfil' : 'Boas-vindas! Quem está usando?'}
      footer={<><Btn onClick={onClose}>{perfil ? 'Cancelar' : 'Agora não'}</Btn><Btn variant="primary" icon="check" disabled={!ok} onClick={() => onSave({ ...f, nome: f.nome.trim() })}>Salvar</Btn></>}>
      <p className="muted small">Seu nome e contato saem no rodapé da proposta. A sigla completa o número (ex.: 30092026/1218<b>{f.sigla || 'H'}</b>). Fica salvo só neste navegador.</p>
      <div className="form-grid">
        <Field label="Seu nome" span={2}><Text value={f.nome} onChange={set('nome')} placeholder="Nome e sobrenome" autoFocus data-testid="perfil-nome" /></Field>
        <Field label="Sigla"><Text value={f.sigla} onChange={(v) => { setSiglaManual(true); set('sigla')(v); }} placeholder="H" /></Field>
        <Field label="Seu WhatsApp"><Text value={f.telefone} onChange={set('telefone')} placeholder="(41) 90000-0000" inputMode="tel" /></Field>
        <Field label="E-mail" span={2}><Text value={f.email} onChange={set('email')} type="email" placeholder="opcional" /></Field>
      </div>
    </Modal>
  );
}
