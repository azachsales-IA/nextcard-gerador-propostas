import React, { useMemo, useState } from 'react';
import { Icon, Btn, Tag, Seg, Empty, Stat, Money, Menu } from './common.jsx';
import { fmtBRL, fmtData, calcNextcard, calcTeloos, totemPreco, isNil, arredonda, validadeDe } from '../core.js';
import { ETAPAS, PENDENCIAS } from '../defaults.js';
import { IMG } from '../assets.js';
import { PHOTOS } from '../fotos.js';
import { resolveFoto } from '../render.js';

export function valorProposta(p, cfg) {
  try {
    if (p.empresa === 'teloos') { const r = calcTeloos(p, cfg); return { v: r.mensal, impl: r.implantacao, txt: `${fmtBRL(r.mensal)}/mês` }; }
    const r = calcNextcard(p, cfg); return { v: r.valorFinal, impl: 0, txt: fmtBRL(r.valorFinal) };
  } catch (e) { return { v: 0, impl: 0, txt: '—' }; }
}

// ───────────── Utilidades de tempo ─────────────
export function haQuanto(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const min = Math.round((Date.now() - d.getTime()) / 60000);
  if (min < 1) return 'agora';
  if (min < 60) return `há ${min} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `há ${h} h`;
  const dias = Math.round(h / 24);
  if (dias === 1) return 'ontem';
  if (dias < 7) return `há ${dias} dias`;
  return fmtData(d);
}
export function statusValidade(p, cfg) {
  if (!p.emitidaEm) return null;
  const v = validadeDe(p, cfg[p.empresa || 'nextcard'].empresa.validadePadrao);
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const alvo = new Date(v.data); alvo.setHours(0, 0, 0, 0);
  const dias = Math.round((alvo - hoje) / 86400000);
  if (dias < 0) return { tone: 'bad', txt: `vencida em ${v.dataTxt.slice(0, 5)}` };
  if (dias === 0) return { tone: 'warn', txt: 'vence hoje' };
  if (dias === 1) return { tone: 'warn', txt: 'vence amanhã' };
  return { tone: 'default', txt: `vence em ${dias} dias` };
}

// ───────────── Escolha do tipo de solução ─────────────
export const SOLUCOES = [
  { tipo: 'totem', brand: 'nextcard', t: 'Totem de autoatendimento', d: 'Começa no NX24-V configurado', img: 'totem-nx24v' },
  { tipo: 'catraca', brand: 'nextcard', t: 'Catracas + comandas', d: 'Entrada, saída, 200 comandas e instalação', img: 'catraca-c120' },
  { tipo: 'comanda', brand: 'nextcard', t: 'Comandas eletrônicas', d: '100 comandas 14 × 8 RFID', icon: 'card', img: 'comanda-14x8' },
  { tipo: 'teloos', brand: 'teloos', t: 'Sistema Teloos', d: 'Plano, adicionais e implantação', logo: true },
  { tipo: 'livre', brand: 'nextcard', t: 'Sob medida', d: 'Monte item por item', icon: 'plus' },
];
// foto pequena no cartão compacto do catálogo (catracas e comandas)
const FotoCatalogo = ({ src, alt }) => <div className="cat-img sm">{src ? <img src={src} alt={alt} /> : <div className="nofoto"><Icon n="image" s={24} /><span>sem foto aprovada</span></div>}</div>;

export function SolucaoPicker({ iniciar, fotos }) {
  return (
    <div className="sol-grid">
      {SOLUCOES.map((s) => {
        const src = s.img ? (fotos && fotos[s.img]) || PHOTOS[s.img] : null;
        return (
          <button key={s.tipo} type="button" className={`sol sol-${s.brand} sol-${s.tipo}`} onClick={() => iniciar(s.tipo)} data-testid={`sol-${s.tipo}`}>
            <span className="sol-media">
              {src ? <img src={src} alt="" /> : s.logo ? <img src={IMG.teloosSymbol} alt="" className="sol-logo" /> : <Icon n={s.icon} s={34} w={1.6} />}
            </span>
            <span className="sol-txt">
              <span className="sol-brand">{s.brand === 'teloos' ? 'Teloos' : 'NEXTCARD'}</span>
              <b>{s.t}</b>
              <small>{s.d}</small>
            </span>
            <span className="sol-go"><Icon n="right" s={18} /></span>
          </button>
        );
      })}
    </div>
  );
}

// ───────────── Início ─────────────
export function Inicio({ propostas, cfg, perfil, fotos, iniciar, abrir, go, mover }) {
  const ordenadas = [...propostas].sort((a, b) => (b.atualizadaEm || '').localeCompare(a.atualizadaEm || ''));
  const rascunhos = ordenadas.filter((p) => p.etapa === 'rascunho' && !p.numero).slice(0, 4);
  const aguardando = ordenadas.filter((p) => ['enviada', 'negociacao'].includes(p.etapa) || (p.etapa === 'rascunho' && p.numero)).slice(0, 6);
  const ativas = propostas.filter((p) => ['enviada', 'negociacao'].includes(p.etapa));
  const ganhos = propostas.filter((p) => p.etapa === 'ganho').length;
  const perdidos = propostas.filter((p) => p.etapa === 'perdido').length;
  const taxa = ganhos + perdidos ? Math.round((ganhos / (ganhos + perdidos)) * 100) : null;
  const nomeCurto = (perfil?.nome || '').trim().split(/\s+/)[0];
  return (
    <div className="stack home">
      <section className="home-hero">
        <span className="eyebrow">Gerador de propostas</span>
        <h1>{nomeCurto ? `Olá, ${nomeCurto}. ` : ''}O que vamos propor hoje?</h1>
        <p className="muted">Escolha o tipo de proposta. Os preços vêm da tabela oficial e a imagem para o WhatsApp é montada enquanto você preenche.</p>
      </section>
      <SolucaoPicker iniciar={iniciar} fotos={fotos} />

      {rascunhos.length > 0 && (
        <section className="card">
          <header className="card-head"><div><h3>Continuar de onde parou</h3><span className="muted small">Rascunhos salvos automaticamente</span></div></header>
          <div className="recent-grid">{rascunhos.map((p) => <PropCard key={p.id} p={p} cfg={cfg} onClick={() => abrir(p.id)} />)}</div>
        </section>
      )}

      <section className="card">
        <header className="card-head">
          <div><h3>Aguardando resposta</h3><span className="muted small">{ativas.length ? `${ativas.length} enviada(s) · taxa de ganho ${taxa === null ? '—' : taxa + '%'}` : 'Propostas enviadas aparecem aqui para o follow-up'}</span></div>
          <Btn small icon="kanban" onClick={() => go('propostas')}>Ver todas</Btn>
        </header>
        {aguardando.length ? (
          <div className="follow-list">
            {aguardando.map((p) => {
              const st = statusValidade(p, cfg);
              return (
                <div key={p.id} className="follow">
                  <button type="button" className="follow-main" onClick={() => abrir(p.id)}>
                    <Tag tone={p.empresa === 'teloos' ? 'accent' : 'default'}>{p.empresa === 'teloos' ? 'Teloos' : 'NEXTCARD'}</Tag>
                    <span className="follow-txt"><b>{p.cliente?.empresa || 'Cliente sem nome'}</b><small className="muted">{p.nome || '—'} · Nº {p.numero}</small></span>
                    <span className="follow-val mono">{valorProposta(p, cfg).txt}</span>
                    {st && <Tag tone={st.tone}>{st.txt}</Tag>}
                  </button>
                  <div className="follow-act">
                    {p.etapa === 'rascunho' && <Btn small icon="send" onClick={() => mover(p.id, 'enviada')}>Enviei</Btn>}
                    <Btn small icon="check" onClick={() => mover(p.id, 'ganho')}>Ganhou</Btn>
                    <Btn small icon="x" onClick={() => mover(p.id, 'perdido')}>Perdeu</Btn>
                  </div>
                </div>
              );
            })}
          </div>
        ) : <Empty icon="send" title="Nada aguardando resposta" text="Gere uma proposta e envie pelo WhatsApp. Ela aparece aqui até o cliente responder." />}
      </section>
    </div>
  );
}

export function PropCard({ p, cfg, onClick, draggable, onDragStart, menu }) {
  const v = valorProposta(p, cfg);
  const et = ETAPAS.find((e) => e.id === p.etapa);
  const st = ['enviada', 'negociacao'].includes(p.etapa) ? statusValidade(p, cfg) : null;
  return (
    <article className="pcard" onClick={onClick} onKeyDown={(e) => { if (e.key === 'Enter' && e.target === e.currentTarget) onClick(); }} tabIndex={0} role="button" draggable={draggable} onDragStart={onDragStart} data-testid="prop-card">
      <span className="pcard-top">
        <span className="mono tiny dim">{p.numero ? `Nº ${p.numero}${p.versao > 1 ? ' · v' + p.versao : ''}` : 'Rascunho'}</span>
        <span className="row-gap">
          <Tag tone={p.etapa === 'ganho' ? 'ok' : p.etapa === 'perdido' ? 'bad' : 'default'}>{et?.nome}</Tag>
          {menu && <Menu items={menu} />}
        </span>
      </span>
      <b className="pcard-client">{p.cliente?.empresa || 'Cliente sem nome'}</b>
      <span className="pcard-name muted">{p.nome || '—'}</span>
      <span className="pcard-bottom"><span className="mono pcard-val">{v.txt}</span><span className={`tiny ${st && st.tone !== 'default' ? st.tone : 'dim'}`}>{st ? st.txt : haQuanto(p.atualizadaEm || p.criadaEm)}</span></span>
    </article>
  );
}

// ───────────── Catálogo ─────────────
export function Catalogo({ cfg, brand, fotos, addToProposal, filtroInicial }) {
  const tel = brand === 'teloos';
  const [f, setF] = useState(filtroInicial || (tel ? 'planos' : 'totem'));
  const [q, setQ] = useState('');
  const N = cfg.nextcard;
  const conds = N.condicoes.filter((c) => c.tipo !== 'avista' && !isNil(c.fator));
  const precoCond = (cents) => conds.slice(-1).map((c) => `${c.nome.replace('Cartão de crédito ', '')}: ${fmtBRL(arredonda(Math.round(cents * c.fator), N.arredondamento))}`)[0];
  const match = (s) => !q || s.toLowerCase().includes(q.toLowerCase());
  let body;
  if (tel) {
    const opts = [{ value: 'planos', label: 'Planos' }, { value: 'adicionais', label: 'Adicionais' }];
    body = (
      <>
        <div className="toolbar"><Seg value={f === 'adicionais' ? 'adicionais' : 'planos'} onChange={setF} options={opts} /><Search q={q} setQ={setQ} /></div>
        {f !== 'adicionais' ? (
          <div className="cat-grid">
            {cfg.teloos.planos.filter((p) => match(p.nomeCaps + p.recursos.join(' '))).map((p) => (
              <article key={p.id} className="cat-card plan-card">
                <div className="cat-plan-head"><span className="eyebrow">Plano</span><h4>{p.nomeCaps}</h4></div>
                <ul className="cat-feats">{p.recursos.map((r) => <li key={r}><Icon n="check" s={13} w={2.4} />{r}</li>)}</ul>
                <div className="cat-price"><span className="big mono">{fmtBRL(p.cents)}<small>/mês</small></span>
                  <span className="muted small">{cfg.teloos.periodicidades.filter((x) => x.fator !== 1).map((x) => x.avista ? `Anual PIX ${fmtBRL(Math.round(p.cents * 12 * x.fator))}` : `${x.nome} ${fmtBRL(Math.round(p.cents * x.fator))}/mês`).join(' · ')}</span></div>
                <Btn variant="primary" icon="plus" onClick={() => addToProposal({ kind: 'plano', id: p.id })}>Propor este plano</Btn>
              </article>
            ))}
          </div>
        ) : (
          <div className="addon-table">
            {cfg.teloos.adicionais.filter((a) => match(a.nome)).map((a) => (
              <div key={a.id} className="pick-row">
                <div><b>{a.nome}</b><span className="muted small">Disponível em: {a.planos.map((x) => cfg.teloos.planos.find((p) => p.id === x)?.nomeCaps.replace('TELOOS ', '')).join(', ')}</span></div>
                <span className="mono">{isNil(a.cents) ? 'ver tabela' : `${fmtBRL(a.cents)}/mês`}</span>
                <Btn small variant="line" icon="plus" onClick={() => addToProposal({ kind: 'adicional', id: a.id })}>Adicionar</Btn>
              </div>
            ))}
          </div>
        )}
      </>
    );
  } else {
    const opts = [{ value: 'totem', label: 'Totens' }, { value: 'catraca', label: 'Catracas' }, { value: 'comanda', label: 'Comandas' }, { value: 'servico', label: 'Serviços' }];
    let cards = [];
    if (f === 'totem') {
      cards = N.totem.modelos.filter((m) => match(m.id + m.nome + m.formato)).map((m) => {
        const sel = { modelo: m.id, ...N.totem.referencia };
        const v = totemPreco(N.totem, sel);
        const foto = resolveFoto({ kind: 'totem', config: { modelo: m.id } }, cfg, fotos, PHOTOS);
        return (
          <article key={m.id} className="cat-card">
            <div className="cat-img">{foto ? <img src={foto} alt={m.nome} /> : <div className="nofoto"><Icon n="image" s={28} /><span>sem foto aprovada</span></div>}<span className="cat-badge">{m.formato}</span></div>
            <div className="cat-info">
              <span className="mono tiny dim">{m.id}</span>
              <h4>{m.nome}</h4>
              <span className="muted small">Tela {m.tela} touch Full HD · aço carbono SAE 1040</span>
              <div className="cat-price"><span className="big mono">{fmtBRL(v)}</span><span className="muted small">Config. referência: Win 10 · i3 · 4GB · 120GB · pinpad · impressora · adesivagem</span><span className="small">{precoCond(v)}</span></div>
            </div>
            <Btn variant="primary" icon="plus" onClick={() => addToProposal({ kind: 'totem', id: m.id })}>Configurar na proposta</Btn>
          </article>
        );
      });
    } else if (f === 'catraca') {
      cards = N.catracas.filter((c) => match(c.nome + c.variante + c.modelo)).map((c) => (
        <article key={c.id} className="cat-card compact">
          <FotoCatalogo src={resolveFoto({ kind: 'catraca', refId: c.id }, cfg, fotos, PHOTOS)} alt={c.nome} />
          <div className="cat-info">
            <span className="mono tiny dim">{c.codigo}</span>
            <h4>{c.tipo} {c.modelo}</h4>
            <span className="muted small">{c.variante}{c.compat ? ` · ${c.compat}` : ''}</span>
            <div className="cat-price"><span className="big mono">{fmtBRL(c.cents)}</span><span className="small">{precoCond(c.cents)}</span></div>
          </div>
          <Btn variant="line" icon="plus" onClick={() => addToProposal({ kind: 'catraca', id: c.id })}>Adicionar</Btn>
        </article>
      ));
    } else if (f === 'comanda') {
      cards = N.comandas.filter((c) => match(c.nome + c.tamanho)).map((c) => (
        <article key={c.id} className="cat-card compact">
          <FotoCatalogo src={resolveFoto({ kind: 'comanda', refId: c.id }, cfg, fotos, PHOTOS)} alt={c.nome} />
          <div className="cat-info">
            <span className="mono tiny dim">{c.codigoBase}</span>
            <h4>{c.nome}</h4>
            <span className="muted small">{c.spec}</span>
            <table className="mini-table"><tbody>{c.tiers.map((t) => <tr key={t.ate}><td>até {t.ate}</td><td className="mono">{fmtBRL(t.cents)}</td></tr>)}</tbody></table>
          </div>
          <Btn variant="line" icon="plus" onClick={() => addToProposal({ kind: 'comanda', id: c.id })}>Adicionar</Btn>
        </article>
      ));
    } else {
      cards = N.servicos.map((s) => (
        <article key={s.id} className="cat-card compact">
          <div className="cat-info"><span className="mono tiny dim">{s.codigo}</span><h4>{s.nome}</h4><span className="muted small">{s.spec}</span><div className="cat-price"><span className="big mono">{fmtBRL(s.cents)}</span><span className="small muted">Pode sair como “incluso”</span></div></div>
          <Btn variant="line" icon="plus" onClick={() => addToProposal({ kind: 'servico', id: s.id })}>Adicionar</Btn>
        </article>
      ));
    }
    body = (
      <>
        <div className="toolbar"><Seg value={f} onChange={setF} options={opts} /><Search q={q} setQ={setQ} /></div>
        <div className={`cat-grid ${f !== 'totem' ? 'dense' : ''}`}>{cards.length ? cards : <Empty title="Nada encontrado" />}</div>
      </>
    );
  }
  return <div className="stack">{body}</div>;
}

function Search({ q, setQ }) {
  return <div className="search-mini"><Icon n="search" s={15} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Filtrar catálogo" /></div>;
}

// ───────────── Propostas (kanban + lista) ─────────────
export function Propostas({ propostas, cfg, brand, abrir, mover, duplicar, excluir, nova, trocaMarca, buscaInicial }) {
  const [modo, setModo] = useState(() => (typeof window !== 'undefined' && window.innerWidth < 900 ? 'lista' : 'kanban'));
  const [drag, setDrag] = useState(null);
  const [over, setOver] = useState(null);
  const [q, setQ] = useState(buscaInicial || '');
  const s = q.trim().toLowerCase();
  const casa = (p) => !s || `${p.cliente?.empresa} ${p.cliente?.contato} ${p.nome} ${p.numero} ${p.responsavel}`.toLowerCase().includes(s);
  const minhas = propostas
    .filter((p) => (p.empresa || 'nextcard') === brand)
    .filter(casa)
    .sort((a, b) => (b.atualizadaEm || '').localeCompare(a.atualizadaEm || ''));
  // a lista mostra só a marca do topo: avisa quando há propostas da outra marca (inclusive na busca)
  const outraMarca = brand === 'teloos' ? 'nextcard' : 'teloos';
  const outraNome = outraMarca === 'teloos' ? 'Teloos' : 'NEXTCARD';
  const nOutras = propostas.filter((p) => (p.empresa || 'nextcard') === outraMarca).filter(casa).length;
  const menu = (p) => [
    { label: p.numero ? 'Ver e enviar' : 'Continuar editando', icon: p.numero ? 'send' : 'edit', onClick: () => abrir(p.id) },
    { label: 'Duplicar', icon: 'duplicate', onClick: () => duplicar(p.id) },
    { sep: true },
    ...ETAPAS.filter((e) => e.id !== p.etapa).map((e) => ({ label: `Mover para ${e.nome}`, icon: 'right', onClick: () => mover(p.id, e.id) })),
    { sep: true },
    { label: 'Excluir', icon: 'trash', danger: true, onClick: () => excluir(p.id) },
  ];
  return (
    <div className="stack">
      <div className="toolbar">
        <Seg value={modo} onChange={setModo} options={[{ value: 'kanban', label: 'Quadro', icon: 'kanban' }, { value: 'lista', label: 'Lista', icon: 'list' }]} />
        <div className="search-mini grow"><Icon n="search" s={15} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cliente, número ou consultor" aria-label="Buscar propostas" /></div>
        <Btn variant="primary" icon="plus" onClick={nova}>Nova proposta</Btn>
      </div>
      {nOutras > 0 && trocaMarca && (
        <div className="hint other-brand" data-testid="outra-marca" role="status">
          <Icon n="info" s={15} />
          <span>{s
            ? `${nOutras === 1 ? '1 proposta' : `${nOutras} propostas`} ${outraNome} também ${nOutras === 1 ? 'corresponde' : 'correspondem'} a “${q.trim()}”.`
            : `Mostrando só propostas ${brand === 'teloos' ? 'Teloos' : 'NEXTCARD'}. ${nOutras === 1 ? 'Há 1 proposta' : `Há ${nOutras} propostas`} ${outraNome}.`}</span>
          <button type="button" className="link small" onClick={() => trocaMarca(outraMarca, q)}>Ver {outraNome}</button>
        </div>
      )}
      {modo === 'kanban' ? (
        <div className="kanban">
          {ETAPAS.map((e) => {
            const lst = minhas.filter((p) => p.etapa === e.id);
            const tot = lst.reduce((acc, p) => acc + valorProposta(p, cfg).v, 0);
            return (
              <div key={e.id} className={`kcol kcol-${e.id} ${over === e.id ? 'over' : ''}`} data-etapa={e.id}
                onDragOver={(ev) => { ev.preventDefault(); setOver(e.id); }}
                onDragLeave={() => setOver(null)}
                onDrop={(ev) => { ev.preventDefault(); const id = drag || ev.dataTransfer.getData('text/plain'); if (id) mover(id, e.id); setDrag(null); setOver(null); }}>
                <div className="kcol-head"><span>{e.nome}</span><span className="mono tiny">{lst.length} · {fmtBRL(tot)}</span></div>
                <div className="kcol-body">
                  {lst.map((p) => (
                    <PropCard key={p.id} p={p} cfg={cfg} menu={menu(p)} onClick={() => abrir(p.id)} draggable onDragStart={(ev) => { setDrag(p.id); ev.dataTransfer.setData('text/plain', p.id); ev.dataTransfer.effectAllowed = 'move'; }} />
                  ))}
                  {!lst.length && <div className="kcol-empty">Arraste propostas para cá</div>}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <section className="card">
          {minhas.length ? (
            <div className="plist">
              {minhas.map((p) => {
                const st = ['enviada', 'negociacao'].includes(p.etapa) ? statusValidade(p, cfg) : null;
                return (
                  <div key={p.id} className="prow" data-testid="prop-row">
                    <button type="button" className="prow-main" onClick={() => abrir(p.id)}>
                      <span className="prow-txt"><b>{p.cliente?.empresa || 'Cliente sem nome'}</b><small className="muted">{p.numero ? `Nº ${p.numero}${p.versao > 1 ? ' · v' + p.versao : ''}` : 'Rascunho'} · {p.nome || '—'}</small></span>
                      <span className="mono prow-val">{valorProposta(p, cfg).txt}</span>
                    </button>
                    <select className="inp inp-sm prow-etapa" value={p.etapa} onChange={(e) => mover(p.id, e.target.value)} aria-label="etapa">
                      {ETAPAS.map((e) => <option key={e.id} value={e.id}>{e.nome}</option>)}
                    </select>
                    <span className={`tiny prow-when ${st && st.tone !== 'default' ? st.tone : 'dim'}`}>{st ? st.txt : haQuanto(p.atualizadaEm || p.criadaEm)}</span>
                    <Menu items={menu(p)} />
                  </div>
                );
              })}
            </div>
          ) : <Empty icon="file" title={s ? 'Nenhuma proposta encontrada' : 'Sem propostas'} action={!s && <Btn variant="primary" icon="plus" onClick={nova}>Nova proposta</Btn>} />}
        </section>
      )}
    </div>
  );
}

// ───────────── Política ─────────────
export function Politica({ cfg, brand }) {
  const secs = brand === 'teloos' ? politicaTeloos(cfg) : politicaNextcard(cfg);
  secs.push({ id: 'validar', t: 'Pontos a validar', body: (
    <>
      <p>Itens que dependem de confirmação dos fundadores. Enquanto isso, o gerador usa o valor indicado e permite ajuste manual.</p>
      <div className="pend">
        {PENDENCIAS.map((p, i) => <div key={i} className="pend-row"><Tag tone="warn">{p.tema}</Tag><span>{p.texto}</span></div>)}
      </div>
    </>
  ) });
  return (
    <div className="policy">
      <nav className="policy-nav">
        <span className="eyebrow">Índice</span>
        {secs.map((s) => <a key={s.id} href={`#pol-${s.id}`} onClick={(e) => { e.preventDefault(); document.getElementById(`pol-${s.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); }}>{s.t}</a>)}
      </nav>
      <article className="policy-doc">
        {secs.map((s) => (
          <section key={s.id} id={`pol-${s.id}`} className="policy-sec">
            <h2>{s.t}</h2>
            {s.body}
          </section>
        ))}
      </article>
    </div>
  );
}

function politicaNextcard(cfg) {
  const N = cfg.nextcard;
  return [
    { id: 'fonte', t: 'Fonte e vigência', body: <p>Política Interna de Condições Comerciais de Pagamento, versão 2.0, vigente desde 02/01/2026 (Diretoria Financeira). Validade escolhida em cada proposta: <b>2, 3 ou 5 dias úteis, ou 7 dias corridos</b>, contada a partir do envio (dias úteis excluem sábados, domingos e feriados nacionais). A tabela pode ser atualizada sem aviso; propostas emitidas valem até o fim da validade.</p> },
    { id: 'primeira', t: 'Primeira compra (PF ou PJ)', body: (
      <ul>
        <li>Valor pela tabela vigente ou pelo Omie. <b>Não há desconto percentual para pagamento à vista.</b></li>
        <li>A primeira compra deve ser paga à vista. Para iniciar o pedido (equipamentos ou arte de comandas), é necessário pagamento; sem pagamento integral, mínimo de <b>50% no ato</b> e o saldo quando o pedido estiver pronto para envio, com liberação pelo financeiro.</li>
        <li>Também pode ser paga no cartão de crédito em 1x (para o vencimento do cartão).</li>
        <li>Após 180 dias sem compras, o cliente volta a ser “primeira compra”.</li>
        <li>Projetos acima de R$ 7.000,00, mediante solicitação formal, podem ter condições das cláusulas 3.2.1 ou 3.2.2.</li>
        <li>Exceções: análise e autorização prévia da Diretoria Comercial.</li>
      </ul>
    ) },
    { id: 'boleto', t: 'Venda recorrente · boleto (somente PJ)', body: (
      <>
        <p>Recorrente = segunda compra do mesmo cadastro em até 180 dias. PF não é faturada por boleto. Com aprovação financeira:</p>
        <table className="table compact"><thead><tr><th>Valor total da compra</th><th>Condição</th></tr></thead><tbody>
          <tr><td>Até R$ 2.000,00</td><td>Boleto 7/21 dias</td></tr>
          <tr><td>De R$ 2.001,00 a R$ 3.999,00</td><td>Boleto 7/21/42 dias</td></tr>
          <tr><td>A partir de R$ 4.000,00</td><td>Boleto 21/42/63 dias</td></tr>
        </tbody></table>
        <p>Todo parcelamento tem acréscimo de juros calculado no simulador oficial. Prazos maiores são exceção (Diretoria Comercial).</p>
      </>
    ) },
    { id: 'cartao', t: 'Venda recorrente · cartão (PF ou PJ)', body: (
      <>
        <table className="table compact"><thead><tr><th>Valor total da compra</th><th>Condição</th></tr></thead><tbody>
          <tr><td>Até R$ 3.000,00</td><td>Até 3x com juros</td></tr>
          <tr><td>De R$ 3.001,00 a R$ 4.999,00</td><td>Até 6x com juros</td></tr>
          <tr><td>A partir de R$ 5.000,00</td><td>Até 12x com juros</td></tr>
        </tbody></table>
        <p><b>Dica comercial:</b> sem constar formalmente na proposta, o consultor pode usar até 3x sem juros no cartão em momentos oportunos da negociação. O playbook indica parcela mínima de R$ 700,00.</p>
      </>
    ) },
    { id: 'inad', t: 'Clientes inadimplentes', body: <ul><li>Boletos em atraso suspendem novas concessões de prazo até a regularização.</li><li>Próximas compras só à vista ou cartão para o vencimento.</li><li>Novos faturamentos dependem da Diretoria Financeira.</li></ul> },
    { id: 'simulador', t: 'Simulador e fatores usados no gerador', body: (
      <>
        <p>O simulador de pagamentos é obrigatório na formalização. No gerador, cada condição tem um fator sobre o valor à vista e aceita colar o valor do simulador.</p>
        <table className="table compact"><thead><tr><th>Condição</th><th>Fator atual</th><th>Entrada padrão</th></tr></thead><tbody>
          {N.condicoes.map((c) => <tr key={c.id}><td>{c.nome}</td><td className="mono">{c.tipo === 'avista' ? '1 (tabela)' : isNil(c.fator) ? 'a definir' : String(c.fator).replace('.', ',')}</td><td>{c.entradaPadrao ? `${c.entradaPadrao}%` : '—'}</td></tr>)}
        </tbody></table>
        <p className="muted small">Arredondamento dos valores com acréscimo: {N.arredondamento === 'cent' ? 'centavos' : `múltiplos de R$ ${N.arredondamento}`}.</p>
      </>
    ) },
    { id: 'excecoes', t: 'Descontos e exceções', body: <ul><li>Nenhum desconto sem análise e autorização prévia da Diretoria Comercial.</li><li>Preços no Omie seguem a tabela oficial; ajustes exigem autorização formal.</li><li>Exceções por e-mail ou WhatsApp à Diretoria Comercial. Aprovações verbais não valem.</li><li>Propostas fora da política só valem após aprovação formal registrada por e-mail.</li></ul> },
    { id: 'formato', t: 'Formato padrão das condições', body: <div className="quote">Para pagamento à vista: R$ 3.870,00 (PIX)<br />Ou R$ 3.986,00 com entrada de 50% no pedido e saldo em 21 dias via boleto bancário (mediante aprovação).<br />Ou R$ 4.102,00 com entrada de 50% no pedido e saldo em 21/42 dias via boleto bancário (mediante aprovação).<br />Ou R$ 4.225,00 parcelado em até 6x no cartão de crédito.</div> },
    { id: 'totens', t: 'Totens de autoatendimento', body: (
      <>
        <p>Preço pela composição da tabela V7 (modelo + sistema + pinpad + leitor + impressora + adesivagem), arredondado para cima. Parceiros: <b>revenda com 6% de desconto</b> sobre a tabela; <b>indicação</b> pelo valor de tabela.</p>
        <p>Estrutura em aço carbono SAE 1040 com pintura eletrostática; monitor touch LED Full HD; saídas VGA, DVI e HDMI; LAN 10/100/1000; áudio on board; Windows 10 ou Android 11. Garantia on-site de 12 meses. Embarque em até 20 dias úteis.</p>
      </>
    ) },
    { id: 'catracas', t: 'Catracas de comandas (Tecnibra)', body: (
      <ul>
        <li>C150: expedidora e receptora somente para comanda 9x7x3,5 mm.</li>
        <li>C120, C180 e C250: compatíveis com todos os tamanhos.</li>
        <li>Recomendado: C150 → 9x7x3,5 RFID · C120 → 9x7x5 ou 14x8 RFID · C180 e C250 → 14x8 ou 15x10 RFID.</li>
        <li>Garantia: equipamento 1 ano direto da fábrica (balcão) e instalação 3 meses. Suporte remoto gratuito por 90 dias.</li>
        <li>Infraestrutura elétrica, de rede e servidor por conta do cliente.</li>
      </ul>
    ) },
    { id: 'comandas', t: 'Comandas eletrônicas', body: <p>Preço unitário por faixa de quantidade (até 30, 50, 100, 200, 300, 500 e 1.000 unidades), tabela V1/2025. Tamanhos 15x10, 14x8, 9x7x5 e 9x7x3,5 mm; tecnologias personalizada, antifurto, RFID, Mifare e combinações. A produção começa após a aprovação da arte e o pagamento.</p> },
  ];
}

function politicaTeloos(cfg) {
  const T = cfg.teloos;
  return [
    { id: 'planos', t: 'Planos e mensalidades', body: (
      <table className="table compact"><thead><tr><th>Plano</th><th className="r">Mensal</th><th className="r">Semestral</th><th className="r">Anual cartão</th><th className="r">Anual PIX</th></tr></thead><tbody>
        {T.planos.map((p) => <tr key={p.id}><td>{p.nomeCaps}</td>{T.periodicidades.map((x) => <td key={x.id} className="r mono">{x.avista ? fmtBRL(Math.round(p.cents * 12 * x.fator)) : `${fmtBRL(Math.round(p.cents * x.fator))}`}</td>)}</tr>)}
      </tbody></table>
    ) },
    { id: 'period', t: 'Periodicidade', body: <ul>{T.periodicidades.map((p) => <li key={p.id}><b>{p.nome}</b> ({p.forma}): {p.fator === 1 ? 'valor de tabela' : `${Math.round((1 - p.fator) * 100)}% de desconto${p.avista ? ' sobre 12 mensalidades, pago à vista' : ' na mensalidade'}`}.</li>)}<li>Nenhum plano tem fidelidade.</li></ul> },
    { id: 'impl', t: 'Implantação e cupons', body: (
      <>
        <table className="table compact"><thead><tr><th>Condição</th><th className="r">Valor à vista</th><th>Pitch</th></tr></thead><tbody>
          <tr><td>Treinamento e implantação</td><td className="r mono">R$ 950,00</td><td>—</td></tr>
          <tr><td>Cupom semanal (−21%)</td><td className="r mono">R$ 750,00</td><td>“Estamos com uma condição especial esta semana!”</td></tr>
          <tr><td>Cupom D+1 (−32%)</td><td className="r mono">R$ 650,00</td><td>“Se você garantir o pagamento até amanhã.”</td></tr>
          <tr><td>Pagamento imediato (−42%)</td><td className="r mono">R$ 550,00</td><td>“Exclusivo: pagamento hoje; amanhã já não consigo.”</td></tr>
        </tbody></table>
        <p>É crucial entender o timing da negociação e o momento do cliente para oferecer a condição correta. Cupom do consultor na mensalidade: 5% (2 por mês) e 10% (2 por mês); no máximo 1 cupom por cliente.</p>
      </>
    ) },
    { id: 'obs', t: 'Observações importantes (A a Z)', body: (
      <ul>
        <li><b>Chamador via WhatsApp:</b> exige o adicional Mensageria ativo.</li>
        <li><b>Chama senha com divulgação:</b> parceria com a Sell4u para materiais visuais.</li>
        <li><b>Chopeira via RFID:</b> exige contrato com a parceira Easychopp.</li>
        <li><b>CRM Ploomes:</b> exige plano com a Ploomes.</li>
        <li><b>Destaxapro (conciliador):</b> ativação solicitada ao suporte da RevendaX.</li>
        <li><b>Gestor tributário Imendes:</b> exige contrato com a parceira.</li>
        <li><b>HUB e-commerce/marketplace:</b> tarifa por pedido/mês — até 1.000: R$ 1,35; 1.001 a 5.000: R$ 1,30; 5.001 a 10.000: R$ 1,25; acima: R$ 1,20. Com nota fiscal sobre a licença, +15%.</li>
        <li><b>Integração Qlic:</b> rebate de R$ 0,05 por transação para revendas, pago no dia 25 do segundo mês.</li>
        <li><b>PagBank:</b> aquisição da SmartPOS obrigatória.</li>
        <li><b>PIX Destaxa:</b> bancos homologados R$ 45,00 por CNPJ; não homologados R$ 45,00 + R$ 0,75 por transação.</li>
        <li><b>Serviços bancários Sicredi e C6:</b> exigem conta-corrente na instituição; régua de cobrança inclusa.</li>
        <li><b>Totem autoatendimento:</b> aluguel via parceiros fabricantes.</li>
        <li><b>Wireless TEFPOS:</b> adquirentes homologadas GetNet, Stone, PagBank, Cielo e Rede.</li>
      </ul>
    ) },
  ];
}
