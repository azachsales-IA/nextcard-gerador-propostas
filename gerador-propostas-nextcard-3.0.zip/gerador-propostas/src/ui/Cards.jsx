// Cartões de item com configuração no próprio cartão (passo "Solução").
import React, { useState } from 'react';
import { Icon, Btn, Field, Text, Money, Qty, Tag, Chips, Menu, Toggle } from './common.jsx';
import { REMOTO } from '../api.js';
import { fmtBRL, totemPreco, comandaFaixa, precoTabelaLinha, pisoLinha, isNil } from '../core.js';
import { linhaTotem, linhaCatraca, linhaComanda, tipoCatraca } from '../model.js';
import { FOTOS_PADRAO } from '../defaults.js';
import { PHOTOS } from '../fotos.js';
import { resolveFoto, fotoIdDe } from '../render.js';

const delta = (v) => (v > 0 ? `+ ${fmtBRL(v)}` : v < 0 ? `− ${fmtBRL(-v)}` : 'incluso');
const fotoSrc = (id, fotos) => (id ? (fotos && fotos[id]) || PHOTOS[id] || null : null);

// Casca comum: miniatura, título, quantidade, preço, total e ações
function Shell({ linha, fotos, cfg, children, open, setOpen, onChange, onRemove, onDuplicate, toast, qtyStep = 1, hideQty, badge }) {
  const tab = precoTabelaLinha(linha);
  // Com servidor, o piso é zero: desconto é conferido contra a alçada na emissão (acima dela, pede aprovação)
  const piso = REMOTO ? 0 : pisoLinha(linha);
  const unit = isNil(linha.preco) ? tab : linha.preco;
  const total = (linha.qtd || 0) * unit;
  const ajustado = !isNil(linha.preco) && linha.preco !== tab;
  const img = resolveFoto(linha, cfg, fotos, PHOTOS);
  const mensal = linha.kind === 'plano' || linha.kind === 'adicional';
  return (
    <article className={`icard ${open ? 'open' : ''}`} data-testid={`card-${linha.kind}`}>
      <div className="icard-head">
        <button type="button" className="icard-thumb" onClick={() => setOpen && setOpen(!open)} aria-label="Configurar">
          {img ? <img src={img} alt="" /> : <Icon n={linha.kind === 'comanda' ? 'card' : linha.kind === 'servico' ? 'gear' : 'cube'} s={22} />}
        </button>
        <div className="icard-title" onClick={() => setOpen && setOpen(!open)}>
          <b>{linha.nome}</b>
          <span className="muted small">{linha.spec}</span>
          {badge && <span className="icard-badge" onClick={(e) => e.stopPropagation()}>{badge}</span>}
        </div>
        <div className="icard-nums">
          {!hideQty && (
            <div className="icard-field">
              <span>Qtd.</span>
              <Qty value={linha.qtd} onChange={(v) => onChange({ qtd: v })} min={0} step={qtyStep} ariaLabel={`quantidade ${linha.nome}`} />
            </div>
          )}
          <div className="icard-field">
            <span>{mensal ? 'Mensal (un.)' : 'Valor unitário'}</span>
            <Money cents={unit} min={piso} className={ajustado ? 'up' : ''} ariaLabel={`preço ${linha.nome}`}
              onFloor={(m) => toast(`O mínimo é o preço de tabela: ${fmtBRL(m)}`, 'warn')}
              onCommit={(v) => onChange({ preco: v === tab ? null : v })} />
          </div>
          <div className="icard-total">
            <span>Total</span>
            <b className="mono">{total === 0 ? <Tag tone="accent">incluso</Tag> : fmtBRL(total)}{mensal && total !== 0 ? <small>/mês</small> : null}</b>
            {ajustado ? <button type="button" className="link tiny" onClick={() => onChange({ preco: null })}>voltar à tabela ({fmtBRL(tab)})</button> : <span className="tiny dim">preço de tabela</span>}
          </div>
        </div>
        <div className="icard-act">
          {setOpen && <button type="button" className={`icon-btn ${open ? 'on' : ''}`} onClick={() => setOpen(!open)} aria-label={open ? 'Fechar configuração' : 'Configurar'} title={open ? 'Fechar' : 'Configurar'}><Icon n={open ? 'check' : 'edit'} s={17} /></button>}
          {onRemove && <Menu items={[onDuplicate && { label: 'Duplicar item', icon: 'duplicate', onClick: onDuplicate }, { label: 'Remover item', icon: 'trash', danger: true, onClick: onRemove }]} />}
        </div>
      </div>
      {open && children && <div className="icard-body">{children}</div>}
    </article>
  );
}

function FotoPicker({ linha, cfg, fotos, onChange, familia, filtro }) {
  const opts = FOTOS_PADRAO.filter((f) => f.familia === familia && (!filtro || filtro(f)));
  const atual = fotoIdDe(linha, cfg);
  return (
    <Field label="Foto na proposta">
      <Chips size="img" value={linha.foto === 'none' ? 'none' : atual || 'none'} onChange={(v) => onChange({ foto: v })}
        options={[...opts.map((f) => ({ value: f.id, label: f.nome.replace(/^Totem |^Expedidora |^Receptora /, ''), img: fotoSrc(f.id, fotos) })), { value: 'none', label: 'Sem foto', img: null }]} />
    </Field>
  );
}

// ───────── Totem ─────────
export function TotemCard({ linha, cfg, prop, fotos, onReplace, onChange, onRemove, onDuplicate, toast, defaultOpen }) {
  const [open, setOpen] = useState(!!defaultOpen);
  const T = cfg.nextcard.totem;
  const sel = linha.config;
  const set = (k, v) => {
    const nsel = { ...sel, [k]: v };
    const nl = linhaTotem(nsel, cfg, prop, linha.qtd);
    const keepFoto = k === 'modelo' ? undefined : linha.foto;
    onReplace({ ...nl, uid: linha.uid, qtd: linha.qtd, preco: null, foto: keepFoto });
  };
  const precoCom = (k, v) => totemPreco(T, { ...sel, [k]: v });
  const base = (k) => precoCom(k, T.opcoes[k][0].id);
  const formatos = ['Pedestal', 'Bancada', 'Parede', 'Horizontal'];
  const modelo = T.modelos.find((m) => m.id === sel.modelo) || {};
  const grupo = (k, label) => (
    <Field label={label}>
      <Chips value={sel[k]} onChange={(v) => set(k, v)} ariaLabel={label}
        options={T.opcoes[k].map((o) => ({ value: o.id, label: o.label.replace('Windows 10 · ', 'Win 10 · ').replace(' (USB/Ethernet)', ''), sub: delta(precoCom(k, o.id) - base(k)) }))} />
    </Field>
  );
  return (
    <Shell linha={linha} fotos={fotos} cfg={cfg} open={open} setOpen={setOpen} onChange={onChange} onRemove={onRemove} onDuplicate={onDuplicate} toast={toast}>
      <div className="cfg-grid">
        <Field label="Modelo">
          <div className="model-groups">
            {formatos.map((f) => {
              const ms = T.modelos.filter((m) => m.formato === f);
              if (!ms.length) return null;
              return (
                <div key={f} className="model-group">
                  <span className="tiny muted">{f}</span>
                  <Chips value={sel.modelo} onChange={(v) => set('modelo', v)} ariaLabel={`Modelos ${f}`}
                    options={ms.map((m) => ({ value: m.id, label: m.tela, sub: fmtBRL(totemPreco(T, { ...sel, modelo: m.id })) }))} />
                </div>
              );
            })}
          </div>
        </Field>
        {grupo('sistema', 'Sistema e processador')}
        <div className="cfg-row3">
          {grupo('pinpad', 'Pinpad')}
          {grupo('impressora', 'Impressora')}
        </div>
        {grupo('leitor', 'Leitor')}
        {grupo('adesivagem', 'Adesivagem')}
        <FotoPicker linha={linha} cfg={cfg} fotos={fotos} onChange={onChange} familia="totem" filtro={(f) => f.formato === modelo.formato} />
        <p className="tiny dim">Código: <span className="mono">{linha.codigo}</span></p>
      </div>
    </Shell>
  );
}

// ───────── Catraca ─────────
const ORDEM_VAR = ['Catraca acoplada', 'Com catraca Smart', 'Com catraca Tecnew', 'Sem catraca'];
export function CatracaCard({ linha, cfg, fotos, onReplace, onChange, onRemove, onDuplicate, toast, defaultOpen }) {
  const [open, setOpen] = useState(!!defaultOpen);
  const C = cfg.nextcard.catracas;
  const atual = C.find((c) => c.id === linha.refId) || C[0];
  const pick = (tipo, modelo, variante) => {
    const cand = C.filter((c) => c.tipo === tipo);
    const m = cand.filter((c) => c.modelo === modelo);
    const c = m.find((x) => x.variante === variante) || m[0] || cand[0];
    const nl = linhaCatraca(c, linha.qtd);
    onReplace({ ...nl, uid: linha.uid, qtd: linha.qtd, preco: null });
  };
  const tipos = [...new Set(C.map((c) => c.tipo))];
  const modelos = [...new Set(C.filter((c) => c.tipo === atual.tipo).map((c) => c.modelo))];
  const variantes = C.filter((c) => c.tipo === atual.tipo && c.modelo === atual.modelo).sort((a, b) => ORDEM_VAR.indexOf(a.variante) - ORDEM_VAR.indexOf(b.variante));
  const fam = atual.tipo === 'Receptora' ? 'Receptora' : 'Dispensadora';
  return (
    <Shell linha={linha} fotos={fotos} cfg={cfg} open={open} setOpen={setOpen} onChange={onChange} onRemove={onRemove} onDuplicate={onDuplicate} toast={toast}
      badge={<Tag tone="accent">{atual.tipo === 'Receptora' ? 'Saída' : atual.tipo === 'Dispensadora' ? 'Entrada' : 'Entrada e saída'}</Tag>}>
      <div className="cfg-grid">
        <Field label="Função">
          <Chips value={atual.tipo} onChange={(t) => pick(t, null, atual.variante)} options={tipos.map((t) => ({ value: t, label: t === 'Dispensadora' ? 'Entrada · expedidora' : t === 'Receptora' ? 'Saída · receptora' : 'Entrada e saída' }))} />
        </Field>
        <Field label="Modelo">
          <Chips value={atual.modelo} onChange={(m) => pick(atual.tipo, m, atual.variante)} options={modelos.map((m) => {
            const min = Math.min(...C.filter((c) => c.tipo === atual.tipo && c.modelo === m).map((c) => c.cents));
            return { value: m, label: m, sub: `desde ${fmtBRL(min)}` };
          })} />
        </Field>
        <Field label="Tipo de catraca">
          <Chips value={atual.variante} onChange={(v) => pick(atual.tipo, atual.modelo, v)} options={variantes.map((c) => ({ value: c.variante, label: c.variante.replace('Com catraca ', ''), sub: fmtBRL(c.cents) }))} />
        </Field>
        {atual.compat && <p className="hint"><Icon n="info" s={15} /> Comandas compatíveis: {atual.compat}</p>}
        <FotoPicker linha={linha} cfg={cfg} fotos={fotos} onChange={onChange} familia="catraca" filtro={(f) => f.tipo === fam} />
      </div>
    </Shell>
  );
}

// ───────── Comanda ─────────
const TECH = { SIM: 'Personalizada', ANT: 'Antifurto', RFI: 'RFID', MIF: 'Mifare', REA: 'RFID + antifurto', MEA: 'Mifare + antifurto' };
export function ComandaCard({ linha, cfg, prop, fotos, onReplace, onChange, onRemove, onDuplicate, toast, defaultOpen }) {
  const [open, setOpen] = useState(!!defaultOpen);
  const C = cfg.nextcard.comandas;
  const atual = C.find((c) => c.id === linha.refId) || C[0];
  const tamanhos = [...new Set(C.map((c) => c.tamanho))];
  const set = (tam, tech) => {
    const c = C.find((x) => x.tamanho === tam && x.tech === tech) || C.find((x) => x.tamanho === tam);
    const nl = linhaComanda(c, linha.qtd);
    onReplace({ ...nl, uid: linha.uid, qtd: linha.qtd, preco: null });
  };
  const faixa = comandaFaixa(linha.tiers, linha.qtd);
  const idx = linha.tiers.findIndex((t) => t === faixa || t.ate === faixa?.ate);
  const prox = idx >= 0 && idx < linha.tiers.length - 1 ? linha.tiers[idx + 1] : null;
  // compatibilidade com expedidoras da proposta
  const exped = (prop.itens || []).filter((l) => l.kind === 'catraca').map((l) => cfg.nextcard.catracas.find((c) => c.id === l.refId)).filter((c) => c && c.tipo !== 'Receptora');
  const c150 = exped.some((c) => c.modelo === 'C150');
  return (
    <Shell linha={linha} fotos={fotos} cfg={cfg} open={open} setOpen={setOpen} onChange={onChange} onRemove={onRemove} onDuplicate={onDuplicate} toast={toast} qtyStep={10}
      badge={faixa ? <span className="tiny dim">Faixa até {faixa.ate} un. · {fmtBRL(faixa.cents)}/un.</span> : null}>
      <div className="cfg-grid">
        <Field label="Tamanho">
          <Chips value={atual.tamanho} onChange={(t) => set(t, atual.tech)} options={tamanhos.map((t) => ({ value: t, label: t.replace(/x/g, ' × '), sub: C.find((c) => c.tamanho === t).dimensao }))} />
        </Field>
        <Field label="Tecnologia">
          <Chips value={atual.tech} onChange={(t) => set(atual.tamanho, t)} options={C.filter((c) => c.tamanho === atual.tamanho).map((c) => ({ value: c.tech, label: TECH[c.tech] }))} />
        </Field>
        <div className="tier-bar" aria-label="Faixas de preço">
          {linha.tiers.map((t) => (
            <button type="button" key={t.ate} className={`tier ${faixa && faixa.ate === t.ate ? 'on' : ''}`} onClick={() => onChange({ qtd: t.ate })} title={`Usar ${t.ate} unidades`}>
              <span>até {t.ate}</span><b className="mono">{fmtBRL(t.cents).replace('R$ ', '')}</b>
            </button>
          ))}
        </div>
        {prox && <p className="hint"><Icon n="spark" s={15} /> Com {faixa.ate + 1} unidades ou mais, o preço cai para {fmtBRL(prox.cents)}/un.</p>}
        {c150 && atual.tamanho !== '9x7x3,5' && <p className="hint warn"><Icon n="alert" s={15} /> A expedidora C150 aceita somente comanda 9 × 7 × 3,5.</p>}
        <FotoPicker linha={linha} cfg={cfg} fotos={fotos} onChange={onChange} familia="comanda" />
      </div>
    </Shell>
  );
}

// ───────── Serviço / item livre ─────────
export function ServicoCard({ linha, cfg, fotos, onChange, onRemove, onDuplicate, toast }) {
  const [open, setOpen] = useState(false);
  const cortesia = linha.preco === 0;
  return (
    <Shell linha={linha} fotos={fotos} cfg={cfg} open={open} setOpen={setOpen} onChange={onChange} onRemove={onRemove} onDuplicate={onDuplicate} toast={toast}
      badge={<Toggle checked={cortesia} onChange={(v) => onChange({ preco: v ? 0 : null })} label="Cortesia: sai como “incluso”" />}>
      {linha.kind === 'avulso' || linha.kind === 'servico' ? (
        <div className="form-grid">
          <Field label="Descrição" span={2}><Text value={linha.nome} onChange={(v) => onChange({ nome: v })} /></Field>
          <Field label="Detalhe" span={2}><Text value={linha.spec} onChange={(v) => onChange({ spec: v })} /></Field>
        </div>
      ) : null}
    </Shell>
  );
}

// Linha simples (valores praticados na Teloos): sem configuração
export function LinhaCard({ linha, cfg, fotos, onChange, onRemove, toast }) {
  return <Shell linha={linha} fotos={fotos} cfg={cfg} onChange={onChange} onRemove={onRemove} toast={toast} hideQty={linha.kind !== 'adicional'} />;
}

// ───────── Teloos ─────────
export function TeloosPlanos({ prop, cfg, onPlano, onCupom }) {
  const T = cfg.teloos;
  const plano = prop.teloos?.plano;
  const cupom = prop.teloos?.cupom || 0;
  return (
    <section className="card">
      <header className="card-head"><div><h3>Plano</h3><span className="muted small">Mensalidade de tabela · sem fidelidade</span></div></header>
      <div className="plans">
        {T.planos.map((pl) => (
          <button key={pl.id} type="button" className={`plan ${plano === pl.id ? 'on' : ''}`} onClick={() => onPlano(pl)} data-testid={`plano-${pl.id}`} aria-pressed={plano === pl.id}>
            <span className="plan-name">{pl.nomeCaps.replace('TELOOS ', '')}</span>
            <span className="plan-price">{fmtBRL(pl.cents)}<small>/mês</small></span>
            <ul>{pl.recursos.slice(0, 3).map((r) => <li key={r}><Icon n="check" s={13} w={2.4} />{r}</li>)}{pl.recursos.length > 3 && <li className="muted">+ {pl.recursos.length - 3} recursos</li>}</ul>
            {plano === pl.id && <span className="plan-ok"><Icon n="check" s={14} w={2.6} /></span>}
          </button>
        ))}
      </div>
      <Field label="Cupom do consultor (na mensalidade)">
        <Chips value={String(cupom)} onChange={(v) => onCupom(Number(v))} options={T.cupons.map((c) => ({ value: String(c), label: c ? `${c}%` : 'Sem cupom' }))} />
      </Field>
    </section>
  );
}

export function TeloosImplantacao({ prop, cfg, onImpl, dataLimite }) {
  const T = cfg.teloos;
  return (
    <section className="card">
      <header className="card-head"><div><h3>Implantação e treinamento</h3><span className="muted small">Pagamento à vista · escolha a condição conforme o momento do cliente</span></div></header>
      <Chips value={prop.teloos?.implantacao || 'padrao'} onChange={onImpl}
        options={T.implantacao.map((i) => ({ value: i.id, label: fmtBRL(i.cents), sub: i.id === 'padrao' ? 'Valor padrão' : `${i.nome}${isNil(i.validadeDias) ? '' : ` · até ${dataLimite(i.validadeDias)}`}` }))} />
    </section>
  );
}

export function TeloosAdicionais({ prop, cfg, onQtd }) {
  const T = cfg.teloos;
  const [q, setQ] = useState('');
  const [todos, setTodos] = useState(false);
  const plano = prop.teloos?.plano;
  const qtdDe = (id) => prop.itens.find((l) => l.kind === 'adicional' && l.refId === id)?.qtd || 0;
  const lista = T.adicionais.filter((a) => (!plano || a.planos.includes(plano)) && (!q || a.nome.toLowerCase().includes(q.toLowerCase())));
  const sel = lista.filter((a) => qtdDe(a.id) > 0);
  const resto = lista.filter((a) => qtdDe(a.id) === 0);
  const LIM = 8;
  const visiveis = q || todos ? resto : resto.slice(0, LIM);
  return (
    <section className="card">
      <header className="card-head">
        <div><h3>Adicionais</h3><span className="muted small">{sel.length ? `${sel.length} selecionado(s) · valores mensais` : 'Opcional · valores mensais'}</span></div>
        <div className="search-mini"><Icon n="search" s={15} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Buscar entre ${lista.length} adicionais`} aria-label="Buscar adicional" /></div>
      </header>
      {!plano && <p className="hint"><Icon n="info" s={15} /> Escolha um plano para ver só os adicionais disponíveis nele.</p>}
      <div className="addons">
        {[...sel, ...visiveis].map((a) => {
          const n = qtdDe(a.id);
          return (
            <div key={a.id} className={`addon ${n ? 'on' : ''}`}>
              <div><b title={a.nome}>{a.nome}</b><span className="mono small muted">{isNil(a.cents) ? 'ver tabela' : `${fmtBRL(a.cents)}/mês`}</span></div>
              {n ? <Qty value={n} onChange={(v) => onQtd(a, v)} min={0} ariaLabel={`quantidade ${a.nome}`} /> : <Btn small icon="plus" onClick={() => onQtd(a, 1)} className="add-btn">Adicionar</Btn>}
            </div>
          );
        })}
      </div>
      {!q && resto.length > LIM && (
        <button type="button" className="link small more-btn" onClick={() => setTodos(!todos)}>{todos ? 'Mostrar menos' : `Ver todos os ${resto.length} adicionais`}</button>
      )}
      {q && !lista.length && <p className="muted small">Nenhum adicional com “{q}”.</p>}
    </section>
  );
}
