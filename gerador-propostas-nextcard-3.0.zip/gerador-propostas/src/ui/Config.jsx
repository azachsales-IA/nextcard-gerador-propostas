import React, { useState } from 'react';
import { Icon, Btn, Field, Text, Select, Money, Qty, Tag, Seg, Check, Empty, Chips, DropZone } from './common.jsx';
import { fmtBRL, isNil, totemPreco, VALIDADES } from '../core.js';
import { CONFIG_VERSION, defaultConfig, PENDENCIAS, FOTOS_PADRAO } from '../defaults.js';
import * as api from '../api.js';
import { MinhaConta } from './Admin.jsx';
import { PHOTOS } from '../fotos.js';
import { fileToDataURL } from '../store.js';
import { downloadBlob } from '../render.js';
import { CASES_PADRAO } from '../cases.js';

// Recorta as margens brancas de uma imagem (data URL) para os logos ficarem maiores na faixa de cases
function recortaMargens(src) {
  return new Promise((res) => {
    const im = new Image();
    im.onload = () => {
      const c = document.createElement('canvas'); c.width = im.width; c.height = im.height;
      const x = c.getContext('2d'); x.drawImage(im, 0, 0);
      const d = x.getImageData(0, 0, c.width, c.height).data;
      let x0 = c.width, y0 = c.height, x1 = -1, y1 = -1;
      for (let yy = 0; yy < c.height; yy += 2) for (let xx = 0; xx < c.width; xx += 2) {
        const i = (yy * c.width + xx) * 4;
        if (d[i + 3] > 20 && (d[i] < 238 || d[i + 1] < 238 || d[i + 2] < 238)) { if (xx < x0) x0 = xx; if (xx > x1) x1 = xx; if (yy < y0) y0 = yy; if (yy > y1) y1 = yy; }
      }
      if (x1 < 0) return res(src);
      const p = 16; x0 = Math.max(0, x0 - p); y0 = Math.max(0, y0 - p); x1 = Math.min(c.width, x1 + p); y1 = Math.min(c.height, y1 + p);
      const o = document.createElement('canvas'); o.width = x1 - x0; o.height = y1 - y0;
      const ox = o.getContext('2d'); ox.fillStyle = '#FFFFFF'; ox.fillRect(0, 0, o.width, o.height); ox.drawImage(c, x0, y0, o.width, o.height, 0, 0, o.width, o.height);
      res(o.toDataURL('image/webp', 0.88));
    };
    im.onerror = () => res(src);
    im.src = src;
  });
}

function Num({ value, onChange, placeholder, ariaLabel }) {
  const [t, setT] = useState(isNil(value) ? '' : String(value).replace('.', ','));
  React.useEffect(() => setT(isNil(value) ? '' : String(value).replace('.', ',')), [value]);
  return (
    <input className="inp inp-sm mono" value={t} placeholder={placeholder} aria-label={ariaLabel}
      onChange={(e) => setT(e.target.value)}
      onBlur={() => { const s = t.trim(); if (s === '') return onChange(null); const n = Number(s.replace(/\./g, '').replace(',', '.')); if (Number.isFinite(n)) onChange(n); else setT(isNil(value) ? '' : String(value).replace('.', ',')); }} />
  );
}

export default function Configuracao({ cfg, setCfg, brand, fotos, setFotos, propostas, setPropostas, toast, tema, setTema, temaProposta, setTemaProposta, cfgVersion, sair }) {
  const REMOTO = api.REMOTO;
  const dono = !REMOTO || api.tem('owner'); // só o proprietário administrativo vê e edita a configuração oficial
  const [tab, setTab] = useState(dono ? 'empresa' : 'conta');
  const tel = brand === 'teloos';
  const B = cfg[brand];
  const setB = (fn) => setCfg((c) => ({ ...c, [brand]: fn(c[brand]) }));
  const setE = (k) => (v) => setB((b) => ({ ...b, empresa: { ...b.empresa, [k]: v } }));
  const tabs = [
    ...(REMOTO ? [{ value: 'conta', label: 'Minha conta' }] : []),
    ...(dono ? [{ value: 'empresa', label: 'Empresa' }] : []),
    ...(REMOTO ? [] : [{ value: 'consultores', label: 'Consultores' }]),
    ...(dono ? [{ value: 'condicoes', label: tel ? 'Periodicidade' : 'Condições' }, { value: 'catalogo', label: 'Catálogo e preços' }] : []),
    ...(dono && !tel ? [{ value: 'fotos', label: 'Fotos dos produtos' }] : []),
    ...(dono ? [{ value: 'textos', label: 'Textos' }] : []),
    { value: 'aparencia', label: 'Aparência' },
    ...(dono ? [{ value: 'backup', label: REMOTO ? 'Exportar e pendências' : 'Backup JSON' }] : []),
  ];
  return (
    <div className="stack">
      <div className="toolbar"><Seg value={tab} onChange={setTab} options={tabs} /><Tag tone="accent">{REMOTO ? `Configuração oficial v${cfgVersion}` : `Política ${CONFIG_VERSION}`}</Tag></div>
      {REMOTO && !dono && <p className="muted small">Catálogo, preços, taxas e textos oficiais são mantidos pelo proprietário administrativo. Você pode ajustar a aparência e a sua conta.</p>}
      {tab === 'conta' && REMOTO && <MinhaConta toast={toast} onSair={sair} />}
      {tab === 'aparencia' && (
        <div className="grid-2">
          <section className="card">
            <header className="card-head"><div><h3>Tema da interface</h3><span className="muted small">Fica salvo neste navegador. Também muda pelo botão no topo.</span></div></header>
            <Field label="Tema"><Chips value={tema} onChange={setTema} ariaLabel="Tema da interface" options={[{ value: 'escuro', label: 'Escuro', sub: 'padrão' }, { value: 'claro', label: 'Claro' }]} /></Field>
          </section>
          <section className="card">
            <header className="card-head"><div><h3>Tema padrão das propostas</h3><span className="muted small">Vale para as novas propostas (PDF e imagem). Cada proposta pode trocar no passo Condições ou na tela final. Na Teloos, Cinza sai como Branco.</span></div></header>
            <div data-testid="tema-proposta-padrao"><Field label="Tema da proposta"><Chips value={temaProposta} onChange={setTemaProposta} ariaLabel="Tema padrão das propostas" options={[{ value: 'escuro', label: 'Preto', sub: 'padrão' }, { value: 'claro', label: 'Branco' }, { value: 'cinza', label: 'Cinza', sub: 'NEXTCARD' }]} /></Field></div>
          </section>
          {dono && <section className="card span-2" data-testid="cases-config">
            <header className="card-head"><div><h3>Cases de sucesso</h3><span className="muted small">Faixa na imagem do WhatsApp e seção na última página do PDF. Cada proposta pode desligar no passo Condições (ligado por padrão na NEXTCARD).</span></div>
              {fotos && fotos['cases-sucesso'] && <Btn small icon="undo" onClick={() => { const n = { ...fotos }; delete n['cases-sucesso']; setFotos(n); toast('Imagem padrão dos cases restaurada'); }}>Restaurar padrão</Btn>}
            </header>
            <div className="cases-prev"><img src={(fotos && fotos['cases-sucesso']) || CASES_PADRAO.src} alt="Logos dos clientes (cases de sucesso)" /></div>
            <DropZone onFile={async (f) => {
              try { const src = await recortaMargens(await fileToDataURL(f, 1620, 'image/webp', 0.88)); setFotos({ ...(fotos || {}), 'cases-sucesso': src }); toast('Imagem dos cases atualizada'); }
              catch (e) { toast('Não foi possível ler a imagem', 'warn'); }
            }}>
              <div className="drop-in"><div className="logo-prev"><Icon n="upload" s={22} /></div><div><b>Trocar imagem dos cases</b><span className="muted small">Arraste aqui ou clique. Fica com até 1620 px de largura e sem as margens brancas.</span></div></div>
            </DropZone>
          </section>}
        </div>
      )}
      {tab === 'empresa' && (
        <div className="grid-2">
          <section className="card">
            <header className="card-head"><h3>Dados da empresa · {B.empresa.nome}</h3></header>
            <div className="form-grid">
              <Field label="Nome"><Text value={B.empresa.nome} onChange={setE('nome')} /></Field>
              <Field label="Descritor"><Text value={B.empresa.descritor} onChange={setE('descritor')} /></Field>
              <Field label="WhatsApp comercial"><Text value={B.empresa.whatsapp} onChange={setE('whatsapp')} /></Field>
              <Field label="Site"><Text value={B.empresa.site} onChange={setE('site')} /></Field>
              <Field label="E-mail comercial"><Text value={B.empresa.email} onChange={setE('email')} /></Field>
              <Field label="Validade sugerida em novas propostas" span={2}><Chips size="sm" value={B.empresa.validadePadrao || '7c'} onChange={setE('validadePadrao')} options={VALIDADES.map((v) => ({ value: v.id, label: v.label }))} /></Field>
              <Field label="Rodapé da peça (2º item)" span={2}><Text value={B.rodape.impostos} onChange={(v) => setB((b) => ({ ...b, rodape: { ...b.rodape, impostos: v } }))} /></Field>
              <Field label="Frase de abertura (capa do PDF)" span={2}><Text value={B.fraseAbertura || ''} onChange={(v) => setB((b) => ({ ...b, fraseAbertura: v }))} /></Field>
              <Field label="Frase de encerramento (fim do detalhamento)" span={2}><Text value={B.fraseEncerramento || ''} onChange={(v) => setB((b) => ({ ...b, fraseEncerramento: v }))} /></Field>
              <Field label="Frase de fechamento (detalhamento)" span={2}><Text value={B.fraseFinal} onChange={(v) => setB((b) => ({ ...b, fraseFinal: v }))} /></Field>
            </div>
          </section>
          <section className="card">
            <header className="card-head"><h3>Numeração</h3></header>
            {REMOTO ? <p className="muted small">Formato: DDMMAAAA/sequência + sufixo (ex.: 10112026/1275HF). A sequência é única para a empresa e fica em Administração → Numeração.</p> : <>
            <p className="muted small">Formato: DDMMAAAA/sequencial + sigla do consultor (ex.: 26092026/1218H). A sequência é deste navegador.</p>
            <Field label="Próximo número"><Qty value={cfg.proximoNumero} onChange={(v) => setCfg((c) => ({ ...c, proximoNumero: v }))} min={1} /></Field></>}
            {!tel && (
              <>
                <div className="sep" />
                <h4>Modalidades</h4>
                {cfg.nextcard.modalidades.map((m, i) => (
                  <div key={m.id} className="form-grid">
                    <Field label={m.nome} span={2}><Text value={m.descricao} onChange={(v) => setB((b) => ({ ...b, modalidades: b.modalidades.map((x, k) => (k === i ? { ...x, descricao: v } : x)) }))} /></Field>
                    <Field label="Fator sobre a tabela de totens" hint="1 = tabela · 0,94 = 6% de desconto"><Num value={m.fatorTotem} onChange={(v) => setB((b) => ({ ...b, modalidades: b.modalidades.map((x, k) => (k === i ? { ...x, fatorTotem: isNil(v) ? 1 : v } : x)) }))} /></Field>
                  </div>
                ))}
              </>
            )}
          </section>
        </div>
      )}
      {tab === 'consultores' && <Consultores cfg={cfg} setCfg={setCfg} />}
      {tab === 'condicoes' && (tel ? <PeriodicidadesCfg cfg={cfg} setB={setB} /> : <CondicoesCfg cfg={cfg} setB={setB} />)}
      {tab === 'catalogo' && (tel ? <CatalogoTeloos cfg={cfg} setB={setB} /> : <CatalogoNextcard cfg={cfg} setB={setB} />)}
      {tab === 'fotos' && <Fotos cfg={cfg} fotos={fotos} setFotos={setFotos} setB={setB} toast={toast} />}
      {tab === 'textos' && <Textos cfg={cfg} setB={setB} tel={tel} />}
      {tab === 'backup' && <Backup cfg={cfg} setCfg={setCfg} propostas={propostas} setPropostas={setPropostas} toast={toast} />}
    </div>
  );
}

function Consultores({ cfg, setCfg }) {
  const list = cfg.responsaveis || [];
  const set = (arr) => setCfg((c) => ({ ...c, responsaveis: arr }));
  return (
    <section className="card">
      <header className="card-head"><h3>Consultores</h3><Btn small icon="plus" variant="line" onClick={() => set([...list, { nome: '', sigla: '', telefone: '', email: '' }])}>Adicionar consultor</Btn></header>
      {!list.length && <Empty icon="user" title="Nenhum consultor cadastrado" text="O nome, WhatsApp e e-mail saem na peça; a sigla completa o número da proposta. Quem usa este navegador se cadastra pelo perfil (canto inferior do menu)." />}
      {list.map((r, i) => (
        <div key={i} className="form-grid four">
          <Field label="Nome"><Text value={r.nome} onChange={(v) => set(list.map((x, k) => (k === i ? { ...x, nome: v } : x)))} /></Field>
          <Field label="Sigla"><Text value={r.sigla} onChange={(v) => set(list.map((x, k) => (k === i ? { ...x, sigla: v.toUpperCase().slice(0, 3) } : x)))} placeholder="H" /></Field>
          <Field label="WhatsApp"><Text value={r.telefone} onChange={(v) => set(list.map((x, k) => (k === i ? { ...x, telefone: v } : x)))} /></Field>
          <Field label="E-mail"><div className="row-gap"><Text value={r.email} onChange={(v) => set(list.map((x, k) => (k === i ? { ...x, email: v } : x)))} /><button className="icon-btn" onClick={() => set(list.filter((_, k) => k !== i))} aria-label="remover consultor"><Icon n="trash" s={16} /></button></div></Field>
        </div>
      ))}
    </section>
  );
}

function CondicoesCfg({ cfg, setB }) {
  const C = cfg.nextcard.condicoes;
  const setC = (i, patch) => setB((b) => ({ ...b, condicoes: b.condicoes.map((x, k) => (k === i ? { ...x, ...patch } : x)) }));
  return (
    <section className="card">
      <header className="card-head"><h3>Condições de pagamento</h3>
        <Field label="Arredondamento dos valores com acréscimo">
          <Select value={cfg.nextcard.arredondamento} onChange={(v) => setB((b) => ({ ...b, arredondamento: v }))} options={[{ value: 'cent', label: 'Centavos' }, { value: '1', label: 'R$ 1' }, { value: '5', label: 'R$ 5' }, { value: '10', label: 'R$ 10' }]} />
        </Field>
      </header>
      <p className="muted small">Fator = total da condição ÷ valor à vista. Deixe vazio quando o valor vier do simulador oficial em cada proposta.</p>
      <div className="table-wrap"><table className="table">
        <thead><tr><th>Condição</th><th>Fator</th><th>Parcelas</th><th>Prazos (dias)</th><th>Entrada padrão</th><th>Marcada por padrão</th></tr></thead>
        <tbody>{C.map((c, i) => (
          <tr key={c.id}>
            <td><Text value={c.nome} onChange={(v) => setC(i, { nome: v })} /></td>
            <td>{c.tipo === 'avista' ? <span className="mono">1</span> : <Num value={c.fator} onChange={(v) => setC(i, { fator: v })} placeholder="simulador" ariaLabel={`fator ${c.nome}`} />}</td>
            <td className="mono">{c.parcelas || '—'}</td>
            <td>{c.tipo === 'boleto' ? <Text value={c.prazos} onChange={(v) => setC(i, { prazos: v })} /> : '—'}</td>
            <td>{c.tipo === 'avista' ? '—' : <Select value={String(c.entradaPadrao || 0)} onChange={(v) => setC(i, { entradaPadrao: Number(v) })} options={[0, 10, 20, 30, 40, 50].map((x) => ({ value: String(x), label: x ? `${x}%` : 'Sem' }))} />}</td>
            <td><Check checked={!!c.padrao} onChange={(v) => setC(i, { padrao: v })}>{c.padrao ? 'sim' : 'não'}</Check></td>
          </tr>
        ))}</tbody>
      </table></div>
    </section>
  );
}

function PeriodicidadesCfg({ cfg, setB }) {
  const T = cfg.teloos;
  return (
    <div className="grid-2">
      <section className="card">
        <header className="card-head"><h3>Periodicidade</h3></header>
        <table className="table"><thead><tr><th>Periodicidade</th><th>Forma</th><th>Fator</th><th>Meses</th></tr></thead><tbody>
          {T.periodicidades.map((p, i) => (
            <tr key={p.id}><td>{p.nome}</td><td><Text value={p.forma} onChange={(v) => setB((b) => ({ ...b, periodicidades: b.periodicidades.map((x, k) => (k === i ? { ...x, forma: v } : x)) }))} /></td>
              <td><Num value={p.fator} onChange={(v) => setB((b) => ({ ...b, periodicidades: b.periodicidades.map((x, k) => (k === i ? { ...x, fator: isNil(v) ? 1 : v } : x)) }))} /></td><td className="mono">{p.meses}</td></tr>
          ))}
        </tbody></table>
      </section>
      <section className="card">
        <header className="card-head"><h3>Implantação e cupons</h3></header>
        {T.implantacao.map((m, i) => (
          <div className="pick-row" key={m.id}><div><b>{m.nome}</b><span className="muted small">{isNil(m.validadeDias) ? 'validade padrão' : `sugere validade de ${m.validadeDias} dia(s)`}</span></div>
            <Money cents={m.cents} onCommit={(v) => setB((b) => ({ ...b, implantacao: b.implantacao.map((x, k) => (k === i ? { ...x, cents: v } : x)) }))} /></div>
        ))}
        <Field label="Cupons do consultor (%)" hint="Separados por vírgula"><Text value={T.cupons.join(', ')} onChange={(v) => setB((b) => ({ ...b, cupons: [...new Set([0, ...v.split(',').map((x) => Number(x.trim())).filter((x) => Number.isFinite(x) && x >= 0 && x < 100)])] }))} /></Field>
      </section>
    </div>
  );
}

function CatalogoNextcard({ cfg, setB }) {
  const [f, setF] = useState('totem');
  const N = cfg.nextcard;
  return (
    <section className="card">
      <header className="card-head"><h3>Catálogo e preços</h3><Seg value={f} onChange={setF} options={[{ value: 'totem', label: 'Totens' }, { value: 'catraca', label: 'Catracas' }, { value: 'comanda', label: 'Comandas' }, { value: 'servico', label: 'Serviços' }]} /></header>
      {f === 'totem' && (
        <>
          <p className="muted small">Valores de venda de cada componente (tabela V7). Preço do totem = soma arredondada para cima. Base do modelo inclui terminal, tela, garantia on-site e itens fixos.</p>
          <div className="grid-2 tight">
            <table className="table compact"><thead><tr><th>Modelo</th><th>Base (R$)</th><th className="r">Config. referência</th></tr></thead><tbody>
              {N.totem.modelos.map((m, i) => (
                <tr key={m.id}><td><b>{m.id}</b> <span className="muted tiny">{m.formato} {m.tela}</span></td>
                  <td><Num value={m.base} onChange={(v) => setB((b) => ({ ...b, totem: { ...b.totem, modelos: b.totem.modelos.map((x, k) => (k === i ? { ...x, base: isNil(v) ? x.base : v } : x)) } }))} /></td>
                  <td className="r mono">{fmtBRL(totemPreco(N.totem, { modelo: m.id, ...N.totem.referencia }))}</td></tr>
              ))}
            </tbody></table>
            <div>
              {Object.entries(N.totem.opcoes).map(([g, ops]) => (
                <table key={g} className="table compact"><thead><tr><th>{g}</th><th>Valor (R$)</th></tr></thead><tbody>
                  {ops.map((o, i) => (
                    <tr key={o.id}><td>{o.label}</td><td><Num value={o.valor} onChange={(v) => setB((b) => ({ ...b, totem: { ...b.totem, opcoes: { ...b.totem.opcoes, [g]: b.totem.opcoes[g].map((x, k) => (k === i ? { ...x, valor: isNil(v) ? 0 : v } : x)) } } }))} /></td></tr>
                  ))}
                </tbody></table>
              ))}
            </div>
          </div>
        </>
      )}
      {f === 'catraca' && (
        <table className="table compact"><thead><tr><th>Código</th><th>Descrição (tabela)</th><th>Compatibilidade</th><th>Valor</th></tr></thead><tbody>
          {N.catracas.map((c, i) => (
            <tr key={c.id}><td className="mono tiny">{c.codigo}</td><td>{c.descricaoTabela}</td><td><Text value={c.compat} onChange={(v) => setB((b) => ({ ...b, catracas: b.catracas.map((x, k) => (k === i ? { ...x, compat: v } : x)) }))} /></td>
              <td><Money cents={c.cents} onCommit={(v) => setB((b) => ({ ...b, catracas: b.catracas.map((x, k) => (k === i ? { ...x, cents: v } : x)) }))} /></td></tr>
          ))}
        </tbody></table>
      )}
      {f === 'comanda' && (
        <div className="table-wrap"><table className="table compact"><thead><tr><th>Comanda</th>{N.comandas[0].tiers.map((t) => <th key={t.ate}>até {t.ate}</th>)}</tr></thead><tbody>
          {N.comandas.map((c, i) => (
            <tr key={c.id}><td><b>{c.tamanho}</b> <span className="muted tiny">{c.nome.split('— ')[1]}</span></td>
              {c.tiers.map((t, j) => <td key={t.ate}><Money cents={t.cents} className="sm" onCommit={(v) => setB((b) => ({ ...b, comandas: b.comandas.map((x, k) => (k === i ? { ...x, tiers: x.tiers.map((y, z) => (z === j ? { ...y, cents: v } : y)) } : x)) }))} /></td>)}</tr>
          ))}
        </tbody></table></div>
      )}
      {f === 'servico' && (
        <>
          {N.servicos.map((s, i) => (
            <div key={s.id} className="form-grid four">
              <Field label="Nome" span={2}><Text value={s.nome} onChange={(v) => setB((b) => ({ ...b, servicos: b.servicos.map((x, k) => (k === i ? { ...x, nome: v } : x)) }))} /></Field>
              <Field label="Detalhe"><Text value={s.spec} onChange={(v) => setB((b) => ({ ...b, servicos: b.servicos.map((x, k) => (k === i ? { ...x, spec: v } : x)) }))} /></Field>
              <Field label="Valor"><div className="row-gap"><Money cents={s.cents} onCommit={(v) => setB((b) => ({ ...b, servicos: b.servicos.map((x, k) => (k === i ? { ...x, cents: v } : x)) }))} /><button className="icon-btn" onClick={() => setB((b) => ({ ...b, servicos: b.servicos.filter((_, k) => k !== i) }))} aria-label="remover serviço"><Icon n="trash" s={16} /></button></div></Field>
            </div>
          ))}
          <Btn icon="plus" variant="line" small onClick={() => setB((b) => ({ ...b, servicos: [...b.servicos, { id: 'SRV-' + Date.now().toString(36).toUpperCase(), codigo: 'SRV', nome: 'Novo serviço', spec: '', cents: 0 }] }))}>Adicionar serviço</Btn>
        </>
      )}
    </section>
  );
}

function CatalogoTeloos({ cfg, setB }) {
  const T = cfg.teloos;
  return (
    <div className="grid-2">
      <section className="card">
        <header className="card-head"><h3>Planos</h3></header>
        {T.planos.map((p, i) => (
          <div key={p.id} className="pick-row"><div><b>{p.nomeCaps}</b><span className="muted small">{p.recursos.length} recursos · aba alternativa: {fmtBRL(p.centsAlternativo)}</span></div>
            <Money cents={p.cents} onCommit={(v) => setB((b) => ({ ...b, planos: b.planos.map((x, k) => (k === i ? { ...x, cents: v } : x)) }))} /></div>
        ))}
      </section>
      <section className="card">
        <header className="card-head"><h3>Adicionais (mensal)</h3></header>
        <div className="scroll-y">
          {T.adicionais.map((a, i) => (
            <div key={a.id} className="pick-row"><div><b>{a.nome}</b></div>
              <Money cents={a.cents} allowEmpty placeholder="ver tabela" onCommit={(v) => setB((b) => ({ ...b, adicionais: b.adicionais.map((x, k) => (k === i ? { ...x, cents: v } : x)) }))} /></div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Fotos({ cfg, fotos, setFotos, setB, toast }) {
  const N = cfg.nextcard;
  const src = (id) => (id ? fotos[id] || PHOTOS[id] || null : null);
  const up = async (id, f) => {
    try {
      const d = await fileToDataURL(f, 1100, 'image/webp', 0.86);
      setFotos((x) => ({ ...x, [id]: d }));
      toast('Foto substituída neste navegador');
    } catch (err) { toast('Não foi possível ler a imagem', 'warn'); }
  };
  const opts = (familia) => [{ value: '', label: 'Sem foto' }, ...FOTOS_PADRAO.filter((f) => f.familia === familia).map((f) => ({ value: f.id, label: f.nome }))];
  const setModelo = (i, foto) => setB((b) => ({ ...b, totem: { ...b.totem, modelos: b.totem.modelos.map((x, k) => (k === i ? { ...x, foto: foto || null } : x)) } }));
  const setCat = (i, foto) => setB((b) => ({ ...b, catracas: b.catracas.map((x, k) => (k === i ? { ...x, foto: foto || null } : x)) }));
  const setComanda = (i, foto) => setB((b) => ({ ...b, comandas: b.comandas.map((x, k) => (k === i ? { ...x, foto: foto || null } : x)) }));
  return (
    <div className="stack">
      <section className="card">
        <header className="card-head"><div><h3>Biblioteca de fotos</h3><span className="muted small">Fotos oficiais recortadas. Para trocar, arraste uma imagem (PNG com fundo transparente fica melhor). A troca vale só neste navegador.</span></div></header>
        <div className="photo-grid">
          {FOTOS_PADRAO.map((f) => (
            <div key={f.id} className="photo-slot">
              <DropZone onFile={(file) => up(f.id, file)}>
                <div className="photo-img">{src(f.id) ? <img src={src(f.id)} alt={f.nome} /> : <div className="nofoto"><Icon n="image" s={26} /><span>sem foto</span></div>}</div>
              </DropZone>
              <b>{f.nome}</b>
              <span className="tiny muted">{fotos[f.id] ? 'foto enviada neste navegador' : 'foto oficial'}</span>
              {fotos[f.id] && <Btn small icon="undo" onClick={() => setFotos((x) => { const n = { ...x }; delete n[f.id]; return n; })}>Voltar à oficial</Btn>}
            </div>
          ))}
        </div>
      </section>
      <div className="grid-2">
        <section className="card">
          <header className="card-head"><div><h3>Foto de cada totem</h3><span className="muted small">Usada automaticamente na proposta. O consultor pode trocar no item. <Tag tone="warn">validar</Tag></span></div></header>
          <div className="map-list">
            {N.totem.modelos.map((m, i) => (
              <div key={m.id} className="map-row">
                <span className="map-thumb">{src(m.foto) ? <img src={src(m.foto)} alt="" /> : <Icon n="image" s={16} />}</span>
                <span><b className="mono small">{m.id}</b><small className="muted"> {m.formato} {m.tela}</small></span>
                <Select value={m.foto || ''} onChange={(v) => setModelo(i, v)} options={opts('totem')} aria-label={`foto ${m.id}`} />
              </div>
            ))}
          </div>
        </section>
        <section className="card">
          <header className="card-head"><div><h3>Foto de cada catraca</h3><span className="muted small">Entrada (expedidora) e saída (receptora) aparecem lado a lado na imagem. <Tag tone="warn">validar</Tag></span></div></header>
          <div className="map-list scroll-y">
            {N.catracas.map((c, i) => (
              <div key={c.id} className="map-row">
                <span className="map-thumb">{src(c.foto) ? <img src={src(c.foto)} alt="" /> : <Icon n="image" s={16} />}</span>
                <span><b className="small">{c.tipo === 'Dispensadora' ? 'Expedidora' : c.tipo === 'Receptora' ? 'Receptora' : 'Exp. + rec.'} {c.modelo}</b><small className="muted"> {c.variante}</small></span>
                <Select value={c.foto || ''} onChange={(v) => setCat(i, v)} options={opts('catraca')} aria-label={`foto ${c.id}`} />
              </div>
            ))}
          </div>
        </section>
      </div>
      <section className="card">
        <header className="card-head"><div><h3>Foto de cada comanda</h3><span className="muted small">Aparece em destaque nas propostas só de comandas. <Tag tone="warn">validar</Tag></span></div></header>
        <div className="map-list">
          {N.comandas.map((c, i) => (
            <div key={c.id} className="map-row">
              <span className="map-thumb">{src(c.foto) ? <img src={src(c.foto)} alt="" /> : <Icon n="image" s={16} />}</span>
              <span><b className="small">{c.tamanho.replace(/x/g, ' × ')}</b><small className="muted"> {c.nome}</small></span>
              <Select value={c.foto || ''} onChange={(v) => setComanda(i, v)} options={opts('comanda')} aria-label={`foto ${c.id}`} />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function ListEditor({ label, value, onChange, rows = 5, hint = 'Um item por linha' }) {
  return <Field label={label} hint={hint}><textarea className="inp" rows={rows} value={(value || []).join('\n')} onChange={(e) => onChange(e.target.value.split('\n'))} onBlur={(e) => onChange(e.target.value.split('\n').map((s) => s.trim()).filter(Boolean))} /></Field>;
}

function Textos({ cfg, setB, tel }) {
  if (tel) {
    const T = cfg.teloos;
    return (
      <div className="grid-2">
        <section className="card"><ListEditor label="Contratação e suporte (detalhamento)" value={T.prazos} onChange={(v) => setB((b) => ({ ...b, prazos: v }))} /></section>
        <section className="card"><ListEditor label="Inclusos extras sugeridos" value={T.inclusosExtras} onChange={(v) => setB((b) => ({ ...b, inclusosExtras: v }))} /></section>
      </div>
    );
  }
  const N = cfg.nextcard;
  return (
    <div className="grid-2">
      {['totem', 'catraca', 'comanda', 'servico'].map((k) => (
        <section className="card" key={k}><ListEditor label={`Inclusos sugeridos · ${k}`} value={N.inclusos[k]} onChange={(v) => setB((b) => ({ ...b, inclusos: { ...b.inclusos, [k]: v } }))} rows={4} /></section>
      ))}
      {['totem', 'catraca', 'comanda', 'geral'].map((k) => (
        <section className="card" key={'p' + k}><ListEditor label={`Prazos, garantia e suporte · ${k}`} value={N.prazos[k]} onChange={(v) => setB((b) => ({ ...b, prazos: { ...b.prazos, [k]: v } }))} rows={4} /></section>
      ))}
      <section className="card"><ListEditor label="Infraestrutura para catracas (responsabilidade do cliente)" hint="Um item por linha. Linha que começa com “- ” vira subitem do anterior; “Rótulo: texto” destaca o rótulo." value={N.infraCatraca} onChange={(v) => setB((b) => ({ ...b, infraCatraca: v }))} rows={8} /></section>
      <section className="card"><ListEditor label="Integração das catracas" hint="1º parágrafo: como funciona. 2º parágrafo: destaque (software comunicador)." value={N.integracaoCatraca || []} onChange={(v) => setB((b) => ({ ...b, integracaoCatraca: v }))} rows={4} /></section>
    </div>
  );
}

function Backup({ cfg, setCfg, propostas, setPropostas, toast }) {
  const exp = (obj, name) => downloadBlob(new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' }), name);
  const imp = (e, kind) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const fr = new FileReader();
    fr.onload = () => {
      try {
        const d = JSON.parse(fr.result);
        if (kind === 'config') {
          if (!d.nextcard || !d.teloos) throw new Error('formato');
          if (api.REMOTO) { const { responsaveis, proximoNumero, version, ...resto } = d; setCfg((c) => ({ ...c, ...resto })); toast('Configuração carregada no editor. Revise e salve para publicar.', 'info'); return; }
          setCfg({ ...d, version: CONFIG_VERSION });
          toast('Configuração importada');
        } else {
          if (!Array.isArray(d)) throw new Error('formato');
          const ids = new Set(propostas.map((p) => p.id));
          setPropostas([...propostas, ...d.filter((p) => p && p.id && !ids.has(p.id))]);
          toast(`${d.length} propostas lidas`);
        }
      } catch (err) { toast('Arquivo inválido', 'warn'); }
    };
    fr.readAsText(f);
    e.target.value = '';
  };
  const hoje = new Date().toISOString().slice(0, 10);
  return (
    <div className="grid-2">
      <section className="card">
        <header className="card-head"><h3>Configuração (tabela e política)</h3></header>
        <p className="muted small">{api.REMOTO ? 'A configuração oficial fica no servidor e vale para toda a equipe. Exporte para guardar uma cópia; ao importar um arquivo, ele entra no editor e só vale depois de salvar.' : 'O gestor exporta a configuração atualizada e distribui para o time, que importa aqui.'}</p>
        <div className="row-gap wrap">
          <Btn icon="download" variant="primary" onClick={() => exp(cfg, `nextcard-config-${hoje}.json`)}>Exportar configuração</Btn>
          <label className="btn btn-line"><Icon n="upload" s={17} /><span>Importar configuração</span><input type="file" accept="application/json" hidden onChange={(e) => imp(e, 'config')} /></label>
          {!api.REMOTO && <Btn icon="alert" onClick={() => { setCfg({ ...defaultConfig(), responsaveis: cfg.responsaveis, proximoNumero: cfg.proximoNumero }); toast(`Política restaurada para ${CONFIG_VERSION}`); }}>Restaurar padrão do código</Btn>}
        </div>
      </section>
      <section className="card">
        <header className="card-head"><h3>Propostas</h3></header>
        <p className="muted small">{api.REMOTO ? `${propostas.length} propostas visíveis para a sua conta. Exporte para guardar uma cópia.` : `${propostas.length} propostas neste navegador. Exporte para backup ou para passar a outro computador.`}</p>
        <div className="row-gap wrap">
          <Btn icon="download" variant="line" onClick={() => exp(propostas, `propostas-${hoje}.json`)}>Exportar propostas</Btn>
          {!api.REMOTO && <label className="btn btn-line"><Icon n="upload" s={17} /><span>Importar propostas</span><input type="file" accept="application/json" hidden onChange={(e) => imp(e, 'props')} /></label>}
        </div>
      </section>
      <section className="card span-2">
        <header className="card-head"><h3>Pontos a validar com os fundadores</h3></header>
        <div className="pend">{PENDENCIAS.map((p, i) => <div key={i} className="pend-row"><Tag tone="warn">{p.tema}</Tag><span>{p.texto}</span></div>)}</div>
      </section>
    </div>
  );
}
