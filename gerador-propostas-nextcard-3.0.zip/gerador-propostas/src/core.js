// Núcleo de cálculo — funções puras, testáveis em Node.
// Regra de ouro: todo valor monetário é inteiro em CENTAVOS.
// Zero é valor válido: nunca usar `||` ou `!x` para testar ausência de preço.

export const isNil = (v) => v === null || v === undefined;

export function fmtBRL(cents, opts = {}) {
  if (isNil(cents) || !Number.isFinite(cents)) return '—';
  const neg = cents < 0;
  const abs = Math.abs(Math.round(cents));
  const reais = Math.floor(abs / 100);
  const cent = abs % 100;
  const r = reais.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  const s = (opts.noSymbol ? '' : 'R$ ') + r + ',' + String(cent).padStart(2, '0');
  return neg ? '− ' + s : s;
}

// Aceita "1.234,56", "1234,56", "1234.56", "R$ 1.234", "0" → centavos (inteiro) ou null se vazio/ inválido
export function parseBRL(input) {
  if (isNil(input)) return null;
  let s = String(input).trim().replace(/R\$\s?/i, '').replace(/\s/g, '');
  if (s === '') return null;
  if (/,/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
  else if (/^\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');
  const n = Number(s);
  if (!Number.isFinite(n) || n < 0) return null;
  return Math.round(n * 100);
}

export function parseIntSafe(input, min = 0) {
  if (isNil(input) || String(input).trim() === '') return null;
  const n = Math.floor(Number(String(input).replace(/\D/g, '')));
  if (!Number.isFinite(n)) return null;
  return Math.max(min, n);
}

// Divide `cents` em n parcelas; a diferença de centavos vai na PRIMEIRA parcela.
export function splitParcelas(cents, n) {
  if (!n || n < 1) return [];
  const base = Math.floor(cents / n);
  const resto = cents - base * n;
  const arr = new Array(n).fill(base);
  arr[0] = base + resto;
  return arr;
}

// Entrada = Total × (pct/100); Financiado = Total − Entrada; Parcela = Financiado ÷ n
export function calcEntradaParcelas(totalCents, pct, n) {
  const p = isNil(pct) ? 0 : pct;
  const entrada = Math.round((totalCents * p) / 100);
  const financiado = totalCents - entrada;
  const parcelas = n > 0 ? splitParcelas(financiado, n) : [];
  return { total: totalCents, pct: p, entrada, financiado, parcelas };
}

export function descreveParcelas(parcelas) {
  if (!parcelas.length) return '';
  const n = parcelas.length;
  if (n === 1) return `1x de ${fmtBRL(parcelas[0])}`;
  const outras = parcelas[1];
  if (parcelas[0] === outras) return `${n}x de ${fmtBRL(outras)}`;
  return `${n}x de ${fmtBRL(outras)} (1ª de ${fmtBRL(parcelas[0])})`;
}

export function arredonda(cents, regra) {
  const step = { cent: 1, '1': 100, '5': 500, '10': 1000 }[regra || 'cent'] || 1;
  return Math.round(cents / step) * step;
}

// ───────────── Datas ─────────────
export function addDias(dateISO, dias) {
  const d = new Date(dateISO);
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() + (dias || 0));
  return d;
}
export function fmtData(d) {
  const x = d instanceof Date ? d : new Date(d);
  return `${String(x.getDate()).padStart(2, '0')}/${String(x.getMonth() + 1).padStart(2, '0')}/${x.getFullYear()}`;
}
export function fmtDataCompacta(d) {
  const x = d instanceof Date ? d : new Date(d);
  return `${String(x.getDate()).padStart(2, '0')}${String(x.getMonth() + 1).padStart(2, '0')}${x.getFullYear()}`;
}

// ───────────── Totem (composição de valor de venda) ─────────────
// Preço = ARREDONDAR.PARA.CIMA(base do modelo + Σ opcionais; 0) — mesma lógica da planilha V7.
export function totemPreco(totemCfg, sel) {
  const m = totemCfg.modelos.find((x) => x.id === sel.modelo);
  if (!m) return null;
  let micro = Math.round(m.base * 1e6);
  for (const grupo of ['sistema', 'pinpad', 'leitor', 'impressora', 'adesivagem']) {
    const o = (totemCfg.opcoes[grupo] || []).find((x) => x.id === sel[grupo]);
    if (o) micro += Math.round(o.valor * 1e6);
  }
  const reais = Math.ceil(micro / 1e6 - 1e-9);
  return reais * 100;
}

export function totemCodigo(totemCfg, sel) {
  const o = (g) => (totemCfg.opcoes[g] || []).find((x) => x.id === sel[g]) || { code: '' };
  const so = o('sistema').code;
  return `${sel.modelo} (${so}${o('impressora').code}${o('pinpad').code}${o('leitor').code})`;
}

export function totemResumo(totemCfg, sel) {
  const m = totemCfg.modelos.find((x) => x.id === sel.modelo) || {};
  const o = (g) => (totemCfg.opcoes[g] || []).find((x) => x.id === sel[g]) || {};
  const partes = [o('sistema').curto, o('pinpad').curto, o('impressora').curto, o('leitor').curto, o('adesivagem').curto].filter(Boolean);
  return { modelo: m, spec: `Tela ${m.tela} touch Full HD · ` + partes.join(' · '), partes };
}

// ───────────── Comandas (preço por faixa de quantidade) ─────────────
export function comandaFaixa(tiers, qtd) {
  if (!tiers || !tiers.length) return null;
  const q = Math.max(0, qtd || 0);
  for (const t of tiers) if (q <= t.ate) return t;
  return tiers[tiers.length - 1];
}

// ───────────── Linhas da proposta ─────────────
export function precoTabelaLinha(linha) {
  if (linha.kind === 'comanda') {
    const f = comandaFaixa(linha.tiers, linha.qtd);
    return f ? f.cents : 0;
  }
  return isNil(linha.tabela) ? 0 : linha.tabela;
}
export function pisoLinha(linha) {
  return linha.piso === 'zero' ? 0 : precoTabelaLinha(linha);
}
export function precoUnitario(linha) {
  return isNil(linha.preco) ? precoTabelaLinha(linha) : linha.preco;
}
export function totalLinha(linha) {
  const q = isNil(linha.qtd) ? 0 : linha.qtd;
  return q * precoUnitario(linha);
}

// ───────────── NEXTCARD: valor final e condições ─────────────
export function calcNextcard(prop, cfg) {
  const linhas = (prop.itens || []).map((l) => ({ ...l, unit: precoUnitario(l), total: totalLinha(l), tabelaAtual: precoTabelaLinha(l) }));
  const valorFinal = linhas.reduce((s, l) => s + l.total, 0);
  const regra = cfg.nextcard.arredondamento;
  const sel = prop.pagamento?.condicoes || [];
  const condicoes = [];
  for (const c of cfg.nextcard.condicoes) {
    if (!sel.includes(c.id)) continue;
    const ov = prop.pagamento?.overrides?.[c.id];
    let total = null;
    let origem = 'fator';
    if (!isNil(ov)) { total = ov; origem = 'simulador'; }
    else if (c.tipo === 'avista') total = valorFinal;
    else if (!isNil(c.fator)) total = arredonda(Math.round(valorFinal * c.fator), regra);
    if (isNil(total)) { condicoes.push({ ...c, disponivel: false }); continue; }
    const pct = c.tipo === 'avista' ? 0 : (prop.pagamento?.entradas?.[c.id] ?? c.entradaPadrao ?? 0);
    const n = c.tipo === 'avista' ? 0 : c.parcelas;
    const ep = calcEntradaParcelas(total, pct, n);
    condicoes.push({ ...c, disponivel: true, origem, ...ep, texto: textoCondicao(c, ep) });
  }
  return { linhas, valorFinal, condicoes };
}

export function textoCondicao(c, ep) {
  const { total, entrada, parcelas, pct } = ep;
  if (c.tipo === 'avista') return `${fmtBRL(total)} à vista (PIX)`;
  const med = c.mediante ? ' (mediante aprovação)' : '';
  if (c.tipo === 'boleto') {
    const prazos = c.prazos ? ` (${c.prazos} dias)` : '';
    if (pct > 0) {
      const saldo = parcelas.length === 1 ? `saldo de ${fmtBRL(parcelas[0])} em ${c.prazos || ''} dias` : `saldo em ${descreveParcelas(parcelas)}${prazos}`;
      return `${fmtBRL(total)} com entrada de ${pct}% (${fmtBRL(entrada)}) no pedido e ${saldo} no boleto bancário${med}`;
    }
    return `${fmtBRL(total)} em ${descreveParcelas(parcelas)} no boleto bancário${prazos}${med}`;
  }
  // cartão
  const entr = pct > 0 ? `entrada de ${fmtBRL(entrada)} + ` : '';
  const parc = parcelas.length === 1 ? 'em 1x' : `em ${entr}${descreveParcelas(parcelas)}`;
  return `${fmtBRL(total)} ${parcelas.length === 1 ? 'no cartão de crédito em 1x' : parc + ' no cartão de crédito'}`;
}

// Resumo de condição em uma linha curta (para a peça)
export function linhaCurtaCondicao(c) {
  if (!c.disponivel) return '';
  if (c.tipo === 'avista') return `${fmtBRL(c.total)} à vista no PIX`;
  if (c.tipo === 'boleto') {
    if (c.pct > 0) {
      if (c.parcelas.length === 1) return `Entrada de ${fmtBRL(c.entrada)} + ${fmtBRL(c.parcelas[0])} em ${c.prazos} dias no boleto`;
      return `Entrada de ${fmtBRL(c.entrada)} + ${descreveParcelas(c.parcelas)} no boleto (${c.prazos} dias)`;
    }
    return `${descreveParcelas(c.parcelas)} no boleto (${c.prazos} dias)`;
  }
  const entr = c.pct > 0 ? `Entrada de ${fmtBRL(c.entrada)} + ` : '';
  return c.parcelas.length === 1 ? `1x no cartão de crédito` : `${entr}${descreveParcelas(c.parcelas)} no cartão`;
}

// ───────────── Teloos: mensalidade, periodicidade, implantação ─────────────
export function calcTeloos(prop, cfg) {
  const linhas = (prop.itens || []).map((l) => ({ ...l, unit: precoUnitario(l), total: totalLinha(l), tabelaAtual: precoTabelaLinha(l) }));
  const mensais = linhas.filter((l) => l.kind === 'plano' || l.kind === 'adicional');
  const unicos = linhas.filter((l) => l.kind !== 'plano' && l.kind !== 'adicional');
  const mensal = mensais.reduce((s, l) => s + l.total, 0);
  const implantacao = unicos.reduce((s, l) => s + l.total, 0);
  const sel = prop.pagamento?.periodicidades || [];
  const periodicidades = [];
  for (const p of cfg.teloos.periodicidades) {
    if (!sel.includes(p.id)) continue;
    let porMes, total, texto, curto;
    if (p.avista) {
      total = Math.round(mensal * p.meses * p.fator);
      porMes = Math.round(total / p.meses);
      texto = `Plano ${p.nome.toLowerCase()}: ${fmtBRL(total)} à vista (${p.forma})`;
      curto = `${fmtBRL(total)} no plano anual à vista (${p.forma})`;
    } else {
      porMes = Math.round(mensal * p.fator);
      total = porMes * p.meses;
      texto = p.meses === 1 ? `Plano mensal: ${fmtBRL(porMes)}/mês (${p.forma})` : `Plano ${p.nome.toLowerCase()}: ${p.meses}x de ${fmtBRL(porMes)} (${p.forma})`;
      curto = p.meses === 1 ? `${fmtBRL(porMes)}/mês no plano mensal (${p.forma})` : `${p.meses}x de ${fmtBRL(porMes)} no plano ${p.nome.toLowerCase()} (${p.forma})`;
    }
    periodicidades.push({ ...p, porMes, total, texto, curto });
  }
  return { linhas, mensais, unicos, mensal, implantacao, periodicidades, valorFinal: mensal };
}

// Família predominante (para textos padrão)
export function familias(itens) {
  const f = new Set();
  for (const l of itens || []) {
    if (['totem', 'catraca', 'comanda', 'servico', 'plano', 'adicional', 'implantacao'].includes(l.kind)) f.add(l.kind);
  }
  return f;
}
export function familiaPrincipal(itens) {
  let best = null, bestV = -1;
  const soma = {};
  for (const l of itens || []) {
    if (!['totem', 'catraca', 'comanda', 'plano'].includes(l.kind)) continue;
    soma[l.kind] = (soma[l.kind] || 0) + totalLinha(l) + 1;
  }
  for (const k in soma) if (soma[k] > bestV) { best = k; bestV = soma[k]; }
  return best;
}

// ───────────── Validade: dias úteis (seg–sex, sem feriados nacionais) ou dias corridos ─────────────
// Feriados nacionais (Lei 662/1949, 6.802/1980, 14.759/2023) + Sexta-feira Santa. [VALIDAR: estaduais/municipais]
const FERIADOS = new Set([
  '2026-01-01', '2026-04-03', '2026-04-21', '2026-05-01', '2026-09-07', '2026-10-12', '2026-11-02', '2026-11-15', '2026-11-20', '2026-12-25',
  '2027-01-01', '2027-03-26', '2027-04-21', '2027-05-01', '2027-09-07', '2027-10-12', '2027-11-02', '2027-11-15', '2027-11-20', '2027-12-25',
  '2028-01-01', '2028-04-14', '2028-04-21', '2028-05-01', '2028-09-07', '2028-10-12', '2028-11-02', '2028-11-15', '2028-11-20', '2028-12-25',
]);
const isoDia = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export function ehDiaUtil(d) {
  const w = d.getDay();
  return w !== 0 && w !== 6 && !FERIADOS.has(isoDia(d));
}
export function addDiasUteis(dateISO, n) {
  const d = new Date(dateISO);
  d.setHours(12, 0, 0, 0);
  let k = 0;
  while (k < n) { d.setDate(d.getDate() + 1); if (ehDiaUtil(d)) k++; }
  return d;
}
export const VALIDADES = [
  { id: '2u', label: '2 dias úteis', tipo: 'uteis', dias: 2 },
  { id: '3u', label: '3 dias úteis', tipo: 'uteis', dias: 3 },
  { id: '5u', label: '5 dias úteis', tipo: 'uteis', dias: 5 },
  { id: '7c', label: '7 dias', tipo: 'corridos', dias: 7 },
];
export function validadeDe(prop, padrao = '7c') {
  let v = VALIDADES.find((x) => x.id === prop.validadeOpcao);
  if (!v && !isNil(prop.validadeDias)) v = { id: 'custom', label: `${prop.validadeDias} dias`, tipo: 'corridos', dias: prop.validadeDias };
  if (!v) v = VALIDADES.find((x) => x.id === padrao) || VALIDADES[3];
  const base = prop.emitidaEm || new Date().toISOString();
  const data = v.tipo === 'uteis' ? addDiasUteis(base, v.dias) : addDias(base, v.dias);
  return { ...v, data, dataTxt: fmtData(data) };
}
const SEMANA = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
export const diaSemana = (d) => SEMANA[(d instanceof Date ? d : new Date(d)).getDay()];

// Telefone → formato internacional para wa.me (assume Brasil quando sem DDI)
// Lista sem repetidos: compara sem diferenciar maiúsculas, espaços extras e pontuação final; mantém a primeira grafia
export function semRepetidos(lista) {
  const vistos = new Set();
  return (lista || []).filter((t) => {
    const k = String(t || '').normalize('NFC').replace(/\s+/g, ' ').trim().replace(/[.;:,!]+$/, '').toLocaleLowerCase('pt-BR');
    if (!k || vistos.has(k)) return false;
    vistos.add(k);
    return true;
  }).map((t) => String(t).replace(/\s+/g, ' ').trim());
}

export function waNumero(tel) {
  const d = String(tel || '').replace(/\D/g, '');
  if (!d) return '';
  if (d.length >= 12 && d.startsWith('55')) return d;
  if (d.length === 10 || d.length === 11) return '55' + d;
  return d;
}
