// Renderização da peça (1080 × 1920) e das páginas de detalhamento em canvas.
import { IMG } from './assets.js';
import { CASES_PADRAO } from './cases.js';
import { desenhaTelas, TELAS_DIM, TELAS_VIS_MIN } from './telas.js';
import { fmtBRL, fmtData, addDias, calcNextcard, calcTeloos, linhaCurtaCondicao, familias, familiaPrincipal, isNil, descreveParcelas, validadeDe, semRepetidos } from './core.js';

export const W = 1080;
export const H = 1920;

// ───────────── Fontes e imagens ─────────────
// NX Sans (derivada da Raleway, OFL): propostas NEXTCARD. Inter: propostas Teloos (tipografia mantida).
export const NX = 'NX Sans';
export const FACES = [[NX, [400, 600, 700, 800]], ['Inter', [400, 500, 600, 700, 800]]];
let fontsReady = null;
// Espera cada peso carregar antes de desenhar. Se algum não carregar, falha: a peça nunca sai com a fonte de reserva.
export function ensureFonts() {
  if (fontsReady) return fontsReady;
  fontsReady = (async () => {
    if (!document.fonts || !document.fonts.load) throw new Error('Navegador sem suporte a fontes embutidas');
    const faltam = [];
    await Promise.all(FACES.flatMap(([fam, ws]) => ws.map(async (w) => {
      const faces = await document.fonts.load(`${w} 24px "${fam}"`, 'AaÇã0R$');
      if (!faces.some((f) => f.status === 'loaded' && String(f.weight) === String(w))) faltam.push(`${fam} ${w}`);
    })));
    if (faltam.length) throw new Error(`Fonte não carregada: ${faltam.join(', ')}`);
  })();
  fontsReady.catch(() => { fontsReady = null; }); // permite tentar de novo
  return fontsReady;
}

const imgCache = new Map();
export function loadImage(src) {
  if (!src) return Promise.resolve(null);
  if (imgCache.has(src)) return imgCache.get(src);
  const p = new Promise((res) => {
    const im = new Image();
    im.onload = () => res(im);
    im.onerror = () => res(null);
    im.src = src;
  });
  imgCache.set(src, p);
  return p;
}

// ───────────── Tema da proposta (escuro | claro) por marca ─────────────
// Todas as cores do desenho vêm daqui. Tema claro: fundo branco, painéis cinza bem claros, texto grafite,
// vermelho da marca em rótulos e destaques (NEXTCARD); azul-escuro e azul da marca (Teloos).
const BASE = {
  nextcard: { display: `"${NX}"`, body: `"${NX}"`, mono: `"${NX}"`, radius: 0, chamfer: 26, barra: ['#C81D24', '#FF4B55', '#C81D24'], bullet: '#E0232C' },
  teloos: { display: 'Inter', body: 'Inter', mono: 'Inter', radius: 34, chamfer: 0, barra: ['#9DB5F3', '#4566E9', '#FF7F0E'], bullet: '#FF7F0E' },
};
const PALETAS = {
  nextcard: {
    escuro: {
      bg: '#08080A', text: '#F4F4F5', muted: '#A1A1AA', dim: '#8A8A94', accent: '#E0232C', accent2: '#FF4B55', tone: '#FF4B55', hi: '#FF4B55', laranja: '#FF4B55',
      line: 'rgba(255,255,255,0.10)', panelTop: 'rgba(255,255,255,0.07)', panelBottom: 'rgba(255,255,255,0.025)', borda: null,
      valorTop: 'rgba(224,35,44,0.15)', valorBottom: 'rgba(255,255,255,0.03)', heroTop: 'rgba(255,255,255,0.07)', heroBottom: 'rgba(255,255,255,0.025)',
      preco: ['#FFFFFF'], precoGlow: 'rgba(255,45,58,0.6)', precoSufixo: '#FF4B55',
      clienteFill: 'rgba(255,255,255,0.97)', clienteStroke: null, clienteSombra: 'rgba(0,0,0,0.45)', clienteTexto: '#16161A',
      regua: ['#E0232C', 'rgba(224,35,44,0.25)', 'rgba(224,35,44,0)'], palco: 'neon', sombraFoto: 'rgba(0,0,0,0.65)',
      chipFill: 'rgba(224,35,44,0.16)', chipTexto: '#FF4B55', check: { fill: 'rgba(224,35,44,0.18)', stroke: '#E0232C', mark: '#FF4B55' },
      selo: 'rgba(224,35,44,0.9)', seloTexto: '#FFFFFF', surface: 'rgba(255,255,255,0.06)', totalFill: 'rgba(224,35,44,0.16)', contatoFill: 'rgba(255,255,255,0.055)',
      hud: 'rgba(255,75,85,0.5)', hudPonto: '#FF4B55', hudAnel: 'rgba(255,75,85,0.35)', brilho: 'rgba(200,29,36,0.30)', frase: '#FF4B55', logo: 'logoNextcardNeg',
    },
    claro: {
      bg: '#FFFFFF', text: '#1F1F23', muted: '#52525B', dim: '#63636B', accent: '#C81D24', accent2: '#C81D24', tone: '#C81D24', hi: '#C81D24', laranja: '#C81D24',
      line: 'rgba(31,31,35,0.12)', panelTop: '#F7F7F8', panelBottom: '#F2F2F4', borda: 'rgba(31,31,35,0.10)',
      valorTop: 'rgba(200,29,36,0.07)', valorBottom: '#F7F7F8', heroTop: '#F7F7F8', heroBottom: '#F2F2F4',
      preco: ['#1F1F23'], precoGlow: null, precoSufixo: '#C81D24',
      clienteFill: null, clienteStroke: 'rgba(31,31,35,0.22)', clienteSombra: null, clienteTexto: '#1F1F23',
      regua: ['#C81D24', 'rgba(200,29,36,0.25)', 'rgba(200,29,36,0)'], palco: 'claro', sombraFoto: 'rgba(0,0,0,0.16)',
      chipFill: 'rgba(200,29,36,0.08)', chipTexto: '#C81D24', check: { fill: 'rgba(200,29,36,0.08)', stroke: '#C81D24', mark: '#C81D24' },
      selo: '#C81D24', seloTexto: '#FFFFFF', surface: 'rgba(31,31,35,0.045)', totalFill: 'rgba(200,29,36,0.07)', contatoFill: '#F7F7F8',
      hud: 'rgba(200,29,36,0.4)', hudPonto: '#C81D24', hudAnel: 'rgba(200,29,36,0.25)', brilho: 'rgba(200,29,36,0.06)', frase: '#C81D24', logo: 'logoNextcard',
    },
    // Cinza: outro formato. Fundo cinza-claro (como as seções do site), faixa grafite no cabeçalho com o logo
    // branco e o filete vermelho, blocos em cartões brancos. Textos ≥ 4,5:1 sobre o cinza e sobre o branco.
    cinza: {
      bg: '#E5E5E8', text: '#1C1C20', muted: '#47474E', dim: '#55555C', accent: '#C81D24', accent2: '#C81D24', tone: '#B3161D', hi: '#B3161D', laranja: '#B3161D',
      line: 'rgba(28,28,32,0.14)', panelTop: '#FFFFFF', panelBottom: '#FBFBFC', borda: 'rgba(28,28,32,0.10)',
      valorTop: '#FFFFFF', valorBottom: '#FFF3F3', heroTop: '#FFFFFF', heroBottom: '#FBFBFC',
      preco: ['#1C1C20'], precoGlow: null, precoSufixo: '#B3161D',
      clienteFill: '#FFFFFF', clienteStroke: null, clienteSombra: 'rgba(0,0,0,0.35)', clienteTexto: '#1C1C20',
      regua: ['#E0232C', '#C81D24', 'rgba(200,29,36,0.15)'], palco: 'claro', sombraFoto: 'rgba(0,0,0,0.22)',
      chipFill: 'rgba(200,29,36,0.10)', chipTexto: '#B3161D', check: { fill: 'rgba(200,29,36,0.10)', stroke: '#C81D24', mark: '#B3161D' },
      selo: '#C81D24', seloTexto: '#FFFFFF', surface: 'rgba(28,28,32,0.05)', totalFill: '#FFFFFF', contatoFill: '#FFFFFF',
      hud: 'rgba(200,29,36,0.4)', hudPonto: '#C81D24', hudAnel: 'rgba(200,29,36,0.25)', brilho: 'rgba(200,29,36,0.05)', frase: '#B3161D', logo: 'logoNextcardNeg',
      iconeFundo: '#FFFFFF',
      banda: ['#34353B', '#222327'], bandaTexto: '#FFFFFF', bandaMuted: '#C9C9CF', bandaTone: '#FF5A63',
    },
  },
  teloos: {
    escuro: {
      bg: '#050B2A', text: '#F3F3F3', muted: '#AFC0EE', dim: '#8193C6', accent: '#4566E9', accent2: '#FF7F0E', tone: '#9DB5F3', hi: '#FF9A45', laranja: '#FFB27A',
      line: 'rgba(157,181,243,0.20)', panelTop: 'rgba(255,255,255,0.07)', panelBottom: 'rgba(255,255,255,0.025)', borda: ['rgba(157,181,243,0.55)', 'rgba(69,102,233,0.25)', 'rgba(255,127,14,0.55)'],
      valorTop: 'rgba(69,102,233,0.30)', valorBottom: 'rgba(255,127,14,0.08)', heroTop: 'rgba(69,102,233,0.22)', heroBottom: 'rgba(11,27,91,0.35)',
      preco: ['#FFFFFF', '#DCE4FF', '#FFB27A'], precoGlow: 'rgba(69,102,233,0.75)', precoSufixo: '#9DB5F3',
      clienteFill: 'rgba(255,255,255,0.97)', clienteStroke: null, clienteSombra: 'rgba(0,0,0,0.45)', clienteTexto: '#16161A',
      regua: ['#4566E9', '#FF7F0E', 'rgba(255,127,14,0)'], palco: 'neon', sombraFoto: 'rgba(0,0,0,0.65)',
      chipFill: 'rgba(69,102,233,0.25)', chipTexto: '#FFFFFF', check: null,
      selo: 'rgba(255,127,14,0.92)', seloTexto: '#FFFFFF', surface: 'rgba(255,255,255,0.06)', totalFill: 'rgba(69,102,233,0.25)', contatoFill: 'rgba(255,255,255,0.055)',
      hud: 'rgba(157,181,243,0.5)', hudPonto: '#9DB5F3', hudAnel: 'rgba(157,181,243,0.35)', brilho: 'rgba(69,102,233,0.40)', frase: '#FFB27A', logo: 'logoTeloosNeg',
    },
    claro: {
      bg: '#FFFFFF', text: '#0B1B5B', muted: '#3B4A7E', dim: '#56649A', accent: '#4566E9', accent2: '#C2570C', tone: '#3350C8', hi: '#B45309', laranja: '#B45309',
      line: 'rgba(11,27,91,0.12)', panelTop: '#F5F7FE', panelBottom: '#EEF2FD', borda: ['rgba(69,102,233,0.45)', 'rgba(69,102,233,0.18)', 'rgba(255,127,14,0.45)'],
      valorTop: 'rgba(69,102,233,0.10)', valorBottom: 'rgba(255,127,14,0.05)', heroTop: 'rgba(69,102,233,0.08)', heroBottom: '#F5F7FE',
      preco: ['#0B1B5B', '#2E47B8', '#C2570C'], precoGlow: null, precoSufixo: '#3350C8',
      clienteFill: null, clienteStroke: 'rgba(11,27,91,0.2)', clienteSombra: null, clienteTexto: '#0B1B5B',
      regua: ['#4566E9', '#FF7F0E', 'rgba(255,127,14,0)'], palco: 'claro', sombraFoto: 'rgba(11,27,91,0.16)',
      chipFill: 'rgba(69,102,233,0.10)', chipTexto: '#2E47B8', check: null,
      selo: '#C2570C', seloTexto: '#FFFFFF', surface: 'rgba(11,27,91,0.045)', totalFill: 'rgba(69,102,233,0.10)', contatoFill: '#F5F7FE',
      hud: 'rgba(69,102,233,0.4)', hudPonto: '#4566E9', hudAnel: 'rgba(69,102,233,0.25)', brilho: 'rgba(69,102,233,0.08)', frase: '#C2570C', logo: 'logoTeloos',
    },
  },
};
export function paleta(brand, tema) {
  const b = brand === 'teloos' ? 'teloos' : 'nextcard';
  const t = temaDe(b, tema);
  // claro = fundo claro (Branco e Cinza): bordas finas, sombras leves, sem brilho
  return { brand: b, tema: t, claro: t !== 'escuro', ...BASE[b], ...PALETAS[b][t] };
}
// Temas da proposta: NEXTCARD tem Preto, Branco e Cinza; Teloos, Escuro e Claro (Cinza vira Claro)
export function temasProposta(brand) {
  return brand === 'teloos' ? [{ value: 'escuro', label: 'Escuro' }, { value: 'claro', label: 'Claro' }]
    : [{ value: 'escuro', label: 'Preto' }, { value: 'claro', label: 'Branco' }, { value: 'cinza', label: 'Cinza' }];
}
export function temaDe(brand, v) {
  if (v === 'claro') return 'claro';
  if (v === 'cinza') return brand === 'teloos' ? 'claro' : 'cinza';
  return 'escuro';
}
// faixa grafite do tema Cinza atrás do cabeçalho (logo, cliente e régua)
function faixaCabecalho(ctx, th, h) {
  if (!th.banda) return;
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, th.banda[0]); g.addColorStop(1, th.banda[1]);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, h);
  const r = ctx.createRadialGradient(W - 120, 0, 0, W - 120, 0, 520);
  r.addColorStop(0, 'rgba(224,35,44,0.28)'); r.addColorStop(1, 'rgba(224,35,44,0)');
  ctx.fillStyle = r; ctx.fillRect(0, 0, W, h);
}
export const TEMAS_PROPOSTA = [{ value: 'escuro', label: 'Escuro' }, { value: 'claro', label: 'Claro' }]; // Teloos; a NEXTCARD usa temasProposta()

// ───────────── Utilidades de desenho ─────────────
// NX Sans tem os pesos 400, 600, 700 e 800: o 500 (médio) usa o 600.
function font(ctx, weight, size, fam) {
  const w = String(fam).includes(NX) && weight === 500 ? 600 : weight;
  ctx.font = `${w} ${size}px ${fam}`;
}
// Rótulos em caixa alta na NX Sans: espaçamento entre letras de 0,08em (a Teloos mantém o espaçamento atual)
const pxDe = (ctx) => Number((/(\d+(?:\.\d+)?)px/.exec(ctx.font) || [])[1] || 0);
const espac = (ctx, spacing) => (ctx.font.includes(NX) ? 0.08 * pxDe(ctx) : spacing);

function spaced(ctx, text, x, y, spacing, align = 'left') {
  spacing = espac(ctx, spacing);
  const chars = [...text];
  const widths = chars.map((c) => ctx.measureText(c).width);
  const total = widths.reduce((s, w) => s + w, 0) + spacing * Math.max(0, chars.length - 1);
  let cx = align === 'right' ? x - total : align === 'center' ? x - total / 2 : x;
  const prev = ctx.textAlign;
  ctx.textAlign = 'left';
  chars.forEach((c, i) => { ctx.fillText(c, cx, y); cx += widths[i] + spacing; });
  ctx.textAlign = prev;
  return total;
}
function spacedWidth(ctx, text, spacing) {
  spacing = espac(ctx, spacing);
  const chars = [...text];
  return chars.reduce((s, c) => s + ctx.measureText(c).width, 0) + spacing * Math.max(0, chars.length - 1);
}

// quebra com linhas de largura parecida (sem palavra sozinha na última linha): mesma quantidade de linhas, menor largura
export function wrapEquilibrado(ctx, text, maxW) {
  const base = wrap(ctx, text, maxW);
  if (base.length < 2) return base;
  let lo = maxW / base.length, hi = maxW;
  for (let i = 0; i < 12; i++) { const mid = (lo + hi) / 2; if (wrap(ctx, text, mid).length > base.length) lo = mid; else hi = mid; }
  return wrap(ctx, text, Math.min(maxW, hi + 1));
}
export function wrap(ctx, text, maxW) {
  const words = String(text || '').split(/\s+/).filter(Boolean);
  const lines = [];
  let cur = '';
  for (const w of words) {
    const t = cur ? cur + ' ' + w : w;
    if (ctx.measureText(t).width <= maxW || !cur) cur = t;
    else { lines.push(cur); cur = w; }
  }
  if (cur) lines.push(cur);
  // quebra palavras gigantes
  return lines.flatMap((l) => {
    if (ctx.measureText(l).width <= maxW) return [l];
    const out = []; let s = '';
    for (const ch of l) { if (ctx.measureText(s + ch).width > maxW) { out.push(s); s = ch; } else s += ch; }
    if (s) out.push(s);
    return out;
  });
}
function clampLines(ctx, lines, max, maxW) {
  if (lines.length <= max) return lines;
  const out = lines.slice(0, max);
  let last = out[max - 1];
  while (ctx.measureText(last + '…').width > maxW && last.length) last = last.slice(0, -1);
  out[max - 1] = last.trimEnd() + '…';
  return out;
}

function shapePath(ctx, x, y, w, h, th) {
  ctx.beginPath();
  if (th.chamfer) {
    const c = Math.min(th.chamfer, h / 3);
    ctx.moveTo(x + c, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w, y + h - c); ctx.lineTo(x + w - c, y + h); ctx.lineTo(x, y + h); ctx.lineTo(x, y + c); ctx.closePath();
  } else {
    const r = Math.min(th.radius, h / 2, w / 2);
    ctx.roundRect ? ctx.roundRect(x, y, w, h, r) : ctx.rect(x, y, w, h);
  }
}
function roundPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, r);
  else { ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
}

function panel(ctx, x, y, w, h, th, opts = {}) {
  ctx.save();
  shapePath(ctx, x, y, w, h, th);
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, opts.fillTop || th.panelTop);
  g.addColorStop(1, opts.fillBottom || th.panelBottom);
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = 1.5;
  if (th.chamfer) {
    ctx.strokeStyle = th.borda || th.line;
  } else {
    const gb = ctx.createLinearGradient(x, y, x + w, y + h);
    const bb = th.borda || ['rgba(157,181,243,0.55)', 'rgba(69,102,233,0.25)', 'rgba(255,127,14,0.55)'];
    gb.addColorStop(0, bb[0]); gb.addColorStop(0.55, bb[1]); gb.addColorStop(1, bb[2]);
    ctx.strokeStyle = opts.border || gb;
  }
  ctx.stroke();
  if (th.chamfer && opts.accentEdge !== false) {
    // cantoneira de destaque (HUD)
    ctx.strokeStyle = th.accent;
    ctx.lineWidth = 3;
    const c = Math.min(th.chamfer, h / 3);
    ctx.beginPath(); ctx.moveTo(x, y + c + 34); ctx.lineTo(x, y + c); ctx.lineTo(x + c, y); ctx.lineTo(x + c + 34, y); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x + w, y + h - c - 34); ctx.lineTo(x + w, y + h - c); ctx.lineTo(x + w - c, y + h); ctx.lineTo(x + w - c - 34, y + h); ctx.stroke();
  }
  ctx.restore();
}

function drawContain(ctx, img, x, y, w, h, align = 'center') {
  if (!img) return null;
  const s = Math.min(w / img.width, h / img.height);
  const dw = img.width * s, dh = img.height * s;
  const dx = align === 'left' ? x : align === 'right' ? x + w - dw : x + (w - dw) / 2;
  const dy = y + (h - dh) / 2;
  ctx.drawImage(img, dx, dy, dw, dh);
  return { x: dx, y: dy, w: dw, h: dh };
}

function check(ctx, x, y, size, th) {
  ctx.save();
  if (th.chamfer) {
    ctx.fillStyle = th.check.fill;
    ctx.strokeStyle = th.check.stroke;
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x + size * 0.3, y); ctx.lineTo(x + size, y); ctx.lineTo(x + size, y + size * 0.7); ctx.lineTo(x + size * 0.7, y + size); ctx.lineTo(x, y + size); ctx.lineTo(x, y + size * 0.3); ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.strokeStyle = th.check.mark;
  } else {
    const g = ctx.createLinearGradient(x, y, x + size, y + size);
    g.addColorStop(0, '#4566E9'); g.addColorStop(1, '#FF7F0E');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
  }
  ctx.lineWidth = size * 0.12;
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.moveTo(x + size * 0.28, y + size * 0.52); ctx.lineTo(x + size * 0.44, y + size * 0.68); ctx.lineTo(x + size * 0.74, y + size * 0.34); ctx.stroke();
  ctx.restore();
}

// ───────────── Ícones de linha (grade 24 × 24), para inclusos, infraestrutura e integração ─────────────
const ICONES = {
  escudo: (c) => { c.moveTo(12, 2.5); c.lineTo(19.5, 5.5); c.lineTo(19.5, 11); c.bezierCurveTo(19.5, 15.8, 16.3, 19.3, 12, 21.5); c.bezierCurveTo(7.7, 19.3, 4.5, 15.8, 4.5, 11); c.lineTo(4.5, 5.5); c.closePath(); c.moveTo(8.5, 12); c.lineTo(11, 14.5); c.lineTo(15.5, 9.5); },
  fone: (c) => { c.moveTo(4.5, 14); c.lineTo(4.5, 12); c.arc(12, 12, 7.5, Math.PI, 0); c.lineTo(19.5, 14); c.moveTo(3.5, 13); c.lineTo(6.5, 13); c.lineTo(6.5, 18.5); c.lineTo(3.5, 18.5); c.closePath(); c.moveTo(20.5, 13); c.lineTo(17.5, 13); c.lineTo(17.5, 18.5); c.lineTo(20.5, 18.5); c.closePath(); c.moveTo(19.5, 18.5); c.quadraticCurveTo(19.5, 21, 14, 21); },
  chave: (c) => { c.moveTo(4.5, 19.5); c.lineTo(12.5, 11.5); c.moveTo(13.6, 4.2); c.arc(16, 8, 4.5, -2.1, 2.6); c.moveTo(13.6, 4.2); c.lineTo(15.4, 7.6); c.lineTo(19.7, 10.6); },
  foguete: (c) => { c.moveTo(12, 2.5); c.bezierCurveTo(16, 5.5, 16.8, 10.5, 15, 15.5); c.lineTo(9, 15.5); c.bezierCurveTo(7.2, 10.5, 8, 5.5, 12, 2.5); c.closePath(); c.moveTo(13.6, 9); c.arc(12, 9, 1.6, 0, Math.PI * 2); c.moveTo(9, 13); c.lineTo(6, 17); c.lineTo(9.2, 16.2); c.moveTo(15, 13); c.lineTo(18, 17); c.lineTo(14.8, 16.2); c.moveTo(10.5, 18.5); c.lineTo(12, 21.5); c.lineTo(13.5, 18.5); },
  plug: (c) => { c.moveTo(9, 2.5); c.lineTo(9, 7); c.moveTo(15, 2.5); c.lineTo(15, 7); c.moveTo(6, 7); c.lineTo(18, 7); c.lineTo(18, 10); c.bezierCurveTo(18, 13.5, 15.5, 15, 12, 15); c.bezierCurveTo(8.5, 15, 6, 13.5, 6, 10); c.closePath(); c.moveTo(12, 15); c.lineTo(12, 18); c.quadraticCurveTo(12, 21, 16, 21); c.lineTo(20, 21); },
  fabrica: (c) => { c.moveTo(3, 21); c.lineTo(21, 21); c.moveTo(4, 21); c.lineTo(4, 11); c.lineTo(9, 14); c.lineTo(9, 11); c.lineTo(14, 14); c.lineTo(14, 4); c.lineTo(18, 4); c.lineTo(18, 21); c.moveTo(7, 17.5); c.lineTo(8.5, 17.5); c.moveTo(11, 17.5); c.lineTo(12.5, 17.5); },
  engrenagem: (c) => { c.moveTo(18.5, 12); c.arc(12, 12, 6.5, 0, Math.PI * 2); c.moveTo(14.6, 12); c.arc(12, 12, 2.6, 0, Math.PI * 2); for (let i = 0; i < 8; i++) { const a = (i * Math.PI) / 4; c.moveTo(12 + Math.cos(a) * 6.5, 12 + Math.sin(a) * 6.5); c.lineTo(12 + Math.cos(a) * 9.2, 12 + Math.sin(a) * 9.2); } },
  doc: (c) => { c.moveTo(6, 2.5); c.lineTo(14.5, 2.5); c.lineTo(18.5, 6.5); c.lineTo(18.5, 21.5); c.lineTo(6, 21.5); c.closePath(); c.moveTo(14.5, 2.5); c.lineTo(14.5, 6.5); c.lineTo(18.5, 6.5); c.moveTo(9, 11); c.lineTo(15.5, 11); c.moveTo(9, 14.5); c.lineTo(15.5, 14.5); c.moveTo(9, 18); c.lineTo(13, 18); },
  marca: (c) => { c.moveTo(3, 12); c.lineTo(12, 3); c.lineTo(21, 3); c.lineTo(21, 12); c.lineTo(12, 21); c.closePath(); c.moveTo(18, 7.5); c.arc(16.5, 7.5, 1.5, 0, Math.PI * 2); },
  impressora: (c) => { c.moveTo(7, 9); c.lineTo(7, 3); c.lineTo(17, 3); c.lineTo(17, 9); c.moveTo(7, 17); c.lineTo(4, 17); c.lineTo(4, 9); c.lineTo(20, 9); c.lineTo(20, 17); c.lineTo(17, 17); c.moveTo(7, 14); c.lineTo(17, 14); c.lineTo(17, 21); c.lineTo(7, 21); c.closePath(); },
  cartao: (c) => { c.moveTo(6, 2.5); c.lineTo(18, 2.5); c.lineTo(18, 21.5); c.lineTo(6, 21.5); c.closePath(); c.moveTo(8.5, 5); c.lineTo(15.5, 5); c.lineTo(15.5, 10); c.lineTo(8.5, 10); c.closePath(); for (let r = 0; r < 3; r++) for (let k = 0; k < 3; k++) { c.moveTo(9.4 + k * 2.6, 13.5 + r * 2.6); c.arc(9 + k * 2.6, 13.5 + r * 2.6, 0.4, 0, Math.PI * 2); } },
  pessoas: (c) => { c.moveTo(12, 8); c.arc(9, 8, 3, 0, Math.PI * 2); c.moveTo(3.5, 20); c.bezierCurveTo(3.5, 15.5, 6, 13.5, 9, 13.5); c.bezierCurveTo(12, 13.5, 14.5, 15.5, 14.5, 20); c.moveTo(18.5, 9); c.arc(16.5, 9, 2, 0, Math.PI * 2); c.moveTo(16.5, 13.5); c.bezierCurveTo(19, 13.5, 20.5, 15.5, 20.5, 19); },
  info: (c) => { c.moveTo(21, 12); c.arc(12, 12, 9, 0, Math.PI * 2); c.moveTo(12, 11); c.lineTo(12, 16.5); c.moveTo(12.5, 7.6); c.arc(12, 7.6, 0.5, 0, Math.PI * 2); },
  tomada: (c) => { c.moveTo(13, 2.5); c.lineTo(6.5, 13); c.lineTo(11.5, 13); c.lineTo(10.5, 21.5); c.lineTo(17.5, 10.5); c.lineTo(12.5, 10.5); c.closePath(); },
  rede: (c) => { c.moveTo(9.5, 2.5); c.lineTo(14.5, 2.5); c.lineTo(14.5, 7.5); c.lineTo(9.5, 7.5); c.closePath(); c.moveTo(12, 7.5); c.lineTo(12, 12); c.moveTo(5, 16.5); c.lineTo(5, 12); c.lineTo(19, 12); c.lineTo(19, 16.5); c.moveTo(2.5, 16.5); c.lineTo(7.5, 16.5); c.lineTo(7.5, 21.5); c.lineTo(2.5, 21.5); c.closePath(); c.moveTo(16.5, 16.5); c.lineTo(21.5, 16.5); c.lineTo(21.5, 21.5); c.lineTo(16.5, 21.5); c.closePath(); },
  check: (c) => { c.moveTo(5, 12.5); c.lineTo(10, 17.5); c.lineTo(19, 7); },
};
const semAcento = (t) => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
// Ícone pelo assunto do texto (garantia, suporte, instalação…); o resto fica com o "check"
export function iconeDe(texto) {
  const t = semAcento(texto);
  const regras = [[/impressora/, 'impressora'], [/pinpad/, 'cartao'], [/garantia/, 'escudo'], [/suporte|remoto|chamado|whatsapp|chat/, 'fone'],
    [/document/, 'doc'], [/instala|treinamento/, 'chave'], [/implanta/, 'foguete'], [/integra|ifood/, 'plug'], [/fabrica|nacional|aco |estrutura/, 'fabrica'],
    [/manutenc|robust/, 'engrenagem'], [/personaliz|marca|adesiv/, 'marca'], [/usuario|pessoa/, 'pessoas']];
  return (regras.find(([re]) => re.test(t)) || [null, 'check'])[1];
}
// quadrado com cantos arredondados (tom da marca) + ícone de linha centralizado
function icone(ctx, th, nome, x, y, s, opts = {}) {
  ctx.save();
  if (!opts.semFundo) {
    if (th.chamfer) shapePath(ctx, x, y, s, s, { chamfer: Math.round(s * 0.22) }); else roundPath(ctx, x, y, s, s, s * 0.28);
    ctx.fillStyle = th.iconeFundo || th.chipFill; ctx.fill();
  }
  const k = (s * (opts.semFundo ? 1 : 0.7)) / 24, ox = x + (s - 24 * k) / 2, oy = y + (s - 24 * k) / 2;
  ctx.translate(ox, oy); ctx.scale(k, k);
  ctx.beginPath(); (ICONES[nome] || ICONES.check)(ctx);
  ctx.strokeStyle = opts.cor || th.iconeTraco || th.tone; ctx.lineWidth = 1.9; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.stroke();
  ctx.restore();
}

// ───────────── Fundo ─────────────
function background(ctx, th, brand, symbol) {
  const claro = th.claro;
  ctx.fillStyle = th.bg;
  ctx.fillRect(0, 0, W, H);
  if (brand === 'nextcard') {
    let g = ctx.createRadialGradient(930, 250, 0, 930, 250, 820);
    g.addColorStop(0, claro ? 'rgba(200,29,36,0.08)' : 'rgba(200,29,36,0.55)'); g.addColorStop(0.45, claro ? 'rgba(200,29,36,0.03)' : 'rgba(200,29,36,0.16)'); g.addColorStop(1, 'rgba(200,29,36,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    g = ctx.createRadialGradient(60, 1500, 0, 60, 1500, 720);
    g.addColorStop(0, claro ? 'rgba(200,29,36,0.04)' : 'rgba(200,29,36,0.20)'); g.addColorStop(1, 'rgba(200,29,36,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // grade
    ctx.strokeStyle = claro ? 'rgba(31,31,35,0.035)' : 'rgba(255,255,255,0.035)'; ctx.lineWidth = 1;
    for (let x = 0; x <= W; x += 54) { ctx.beginPath(); ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, H); ctx.stroke(); }
    for (let y = 0; y <= H; y += 54) { ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(W, y + 0.5); ctx.stroke(); }
    // X da marca em marca d'água
    ctx.save(); ctx.globalAlpha = claro ? 0.05 : 0.07; ctx.lineCap = 'butt'; ctx.lineWidth = 120;
    ctx.strokeStyle = '#9A9A9A'; ctx.beginPath(); ctx.moveTo(700, -60); ctx.lineTo(1220, 700); ctx.stroke();
    ctx.strokeStyle = '#E0232C'; ctx.globalAlpha = claro ? 0.06 : 0.12; ctx.beginPath(); ctx.moveTo(1220, -60); ctx.lineTo(700, 700); ctx.stroke();
    ctx.restore();
  } else {
    let g = ctx.createLinearGradient(0, 0, 0, H);
    const f = claro ? ['#FFFFFF', '#F7F9FF', '#EEF2FD'] : ['#0B1B5B', '#07113D', '#040920'];
    g.addColorStop(0, f[0]); g.addColorStop(0.55, f[1]); g.addColorStop(1, f[2]);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    const blob = (x, y, r, c) => { const gg = ctx.createRadialGradient(x, y, 0, x, y, r); gg.addColorStop(0, c); gg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = gg; ctx.fillRect(0, 0, W, H); };
    blob(120, 180, 620, claro ? 'rgba(69,102,233,0.10)' : 'rgba(69,102,233,0.55)');
    blob(1020, 520, 560, claro ? 'rgba(255,127,14,0.08)' : 'rgba(255,127,14,0.28)');
    blob(900, 1650, 700, claro ? 'rgba(69,102,233,0.06)' : 'rgba(69,102,233,0.30)');
    if (symbol) { ctx.save(); ctx.globalAlpha = claro ? 0.05 : 0.09; ctx.drawImage(symbol, 480, 40, 980, 980 * symbol.height / symbol.width); ctx.restore(); }
    // pontos
    ctx.fillStyle = claro ? 'rgba(69,102,233,0.10)' : 'rgba(157,181,243,0.10)';
    for (let y = 30; y < H; y += 48) for (let x = 30; x < W; x += 48) { ctx.beginPath(); ctx.arc(x, y, 1.6, 0, Math.PI * 2); ctx.fill(); }
  }
}

// "Palco" sob o equipamento: anel de neon (escuro) ou piso claro com sombra suave (claro)
function palco(ctx, th, cx, baseY, raio) {
  // achatamento: acima de 110 px de raio o anel não passa de ~20 px abaixo da base (não invade o rótulo)
  const k = Math.min(1, 110 / raio);
  if (th.palco === 'neon') {
    const gg = ctx.createRadialGradient(cx, baseY, 0, cx, baseY, raio * 1.25);
    gg.addColorStop(0, th.brand === 'teloos' ? 'rgba(69,102,233,0.5)' : 'rgba(224,35,44,0.5)'); gg.addColorStop(1, 'rgba(224,35,44,0)');
    ctx.save(); ctx.translate(cx, baseY); ctx.scale(1, 0.2 * k); ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(0, 0, raio * 1.25, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    ctx.save(); ctx.translate(cx, baseY); ctx.scale(1, 0.18 * k);
    ctx.strokeStyle = 'rgba(255,75,85,0.95)'; ctx.lineWidth = 5; ctx.shadowColor = '#FF2D3A'; ctx.shadowBlur = 30;
    ctx.beginPath(); ctx.arc(0, 0, raio * 0.85, 0, Math.PI * 2); ctx.stroke();
    ctx.shadowBlur = 0; ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, raio, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
    ctx.save(); ctx.translate(cx, baseY - 2); ctx.scale(1, 0.12 * k); const sg = ctx.createRadialGradient(0, 0, 0, 0, 0, raio * 0.72); sg.addColorStop(0, 'rgba(0,0,0,0.9)'); sg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(0, 0, raio * 0.72, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    return;
  }
  // claro: disco de piso cinza muito claro + sombra de contato
  ctx.save(); ctx.translate(cx, baseY); ctx.scale(1, 0.16 * k);
  const pg = ctx.createRadialGradient(0, 0, 0, 0, 0, raio);
  pg.addColorStop(0, th.brand === 'teloos' ? 'rgba(69,102,233,0.10)' : 'rgba(31,31,35,0.10)'); pg.addColorStop(0.7, th.brand === 'teloos' ? 'rgba(69,102,233,0.05)' : 'rgba(31,31,35,0.05)'); pg.addColorStop(1, 'rgba(31,31,35,0)');
  ctx.fillStyle = pg; ctx.beginPath(); ctx.arc(0, 0, raio, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = 'rgba(31,31,35,0.08)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, raio * 0.85, 0, Math.PI * 2); ctx.stroke();
  ctx.restore();
  ctx.save(); ctx.translate(cx, baseY - 2); ctx.scale(1, 0.1 * k); const sg = ctx.createRadialGradient(0, 0, 0, 0, 0, raio * 0.6); sg.addColorStop(0, 'rgba(0,0,0,0.35)'); sg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(0, 0, raio * 0.6, 0, Math.PI * 2); ctx.fill(); ctx.restore();
}

// ───────────── Modelo de dados da peça ─────────────
const FAMILIA_LABEL = { totem: 'TOTEM DE AUTOATENDIMENTO', catraca: 'CATRACAS DE COMANDAS', comanda: 'COMANDAS ELETRÔNICAS', misto: 'PROJETO DE AUTOMAÇÃO', plano: 'GESTÃO PARA FOOD SERVICE' };

// Foto de um item: escolha da linha ('none' = sem foto) → padrão do catálogo. Fotos enviadas no navegador têm prioridade.
export function fotoPadraoId(linha, cfg) {
  if (!linha) return null;
  if (linha.kind === 'totem') return cfg.nextcard.totem.modelos.find((x) => x.id === linha.config?.modelo)?.foto || null;
  if (linha.kind === 'catraca') return cfg.nextcard.catracas.find((x) => x.id === linha.refId)?.foto || null;
  if (linha.kind === 'comanda') return cfg.nextcard.comandas.find((x) => x.id === linha.refId)?.foto || null;
  return null;
}
export function fotoIdDe(linha, cfg) {
  if (!linha || linha.foto === 'none') return null;
  return linha.foto || fotoPadraoId(linha, cfg);
}
export function resolveFoto(linha, cfg, fotosUser, PHOTOS) {
  const id = fotoIdDe(linha, cfg);
  if (!id) return null;
  return (fotosUser && fotosUser[id]) || PHOTOS[id] || null;
}

// Equipamentos com foto que vão em destaque: totens primeiro, depois catraca de entrada, entrada e saída, saída (até 4)
const ORDEM_CATRACA = { Dispensadora: 1, 'Dispensadora e receptora': 2, Receptora: 3 };
function equipamentosDestaque(linhas, cfg, fotosUser, PHOTOS) {
  const out = [];
  for (const l of linhas) {
    if (!(l.qtd > 0) || (l.kind !== 'totem' && l.kind !== 'catraca')) continue;
    const foto = resolveFoto(l, cfg, fotosUser, PHOTOS);
    if (!foto) continue;
    const un = `${l.qtd} un.`;
    if (l.kind === 'totem') {
      const T = cfg.nextcard.totem;
      const m = T.modelos.find((x) => x.id === l.config?.modelo) || {};
      const o = (g) => (T.opcoes[g] || []).find((x) => x.id === l.config?.[g]) || {};
      const espec = [m.tela ? `Tela ${m.tela} touch` : '', o('sistema').curto, o('pinpad').curto].filter(Boolean).join(' · ');
      out.push({ uid: l.uid, foto, ordem: 0, total: l.total, rotulo: 'TOTEM', nome: `Totem ${m.id || ''}`, un, espec });
    } else {
      const c = cfg.nextcard.catracas.find((k) => k.id === l.refId) || {};
      const nomeTipo = c.tipo === 'Receptora' ? 'Receptora' : c.tipo === 'Dispensadora' ? 'Expedidora' : 'Expedidora e receptora';
      const rotulo = c.tipo === 'Receptora' ? 'SAÍDA' : c.tipo === 'Dispensadora' ? 'ENTRADA' : 'ENTRADA E SAÍDA';
      out.push({ uid: l.uid, foto, ordem: ORDEM_CATRACA[c.tipo] || 4, total: l.total, rotulo, nome: `${nomeTipo} ${c.modelo || ''}`, un, espec: c.variante || '' });
    }
  }
  // só comandas (sem totem nem catraca com foto): as comandas vão em destaque, uma foto por tamanho
  if (!out.length) {
    const vistas = new Set();
    for (const l of [...linhas].sort((a, b) => b.total - a.total)) {
      if (!(l.qtd > 0) || l.kind !== 'comanda') continue;
      const id = fotoIdDe(l, cfg), foto = resolveFoto(l, cfg, fotosUser, PHOTOS);
      if (!foto || vistas.has(id)) continue;
      vistas.add(id);
      const c = cfg.nextcard.comandas.find((k) => k.id === l.refId) || {};
      out.push({ uid: l.uid, foto, ordem: 5, total: l.total, rotulo: 'COMANDA', nome: String(l.nome || '').replace(/^Comanda eletrônica /, 'Comanda '), un: `${l.qtd} un.`, espec: l.spec || c.spec || '' });
    }
  }
  return out.sort((a, b) => a.ordem - b.ordem || b.total - a.total).slice(0, 4);
}

export function buildModel(prop, cfg, fotosUser, PHOTOS) {
  const brand = prop.empresa || 'nextcard';
  const E = cfg[brand].empresa;
  const resp = (cfg.responsaveis || []).find((r) => r.nome === prop.responsavel) || (prop.responsavel ? { nome: prop.responsavel } : null);
  const emissao = prop.emitidaEm || new Date().toISOString();
  const val = validadeDe({ ...prop, emitidaEm: emissao }, E.validadePadrao);
  // inclusos sem repetidos: a lista salva na proposta pode ter o mesmo texto duas vezes (digitado à mão ou com espaço/maiúscula diferente)
  const inclTodos = semRepetidos(prop.inclusos);
  const base = {
    brand, E, resp,
    // tema da proposta salvo nela: reabrir e gerar de novo dá o mesmo resultado (propostas antigas = escuro)
    tema: temaDe(brand, prop.temaProposta),
    // cases de sucesso: por proposta; ligado por padrão na NEXTCARD (os logos são clientes NEXTCARD)
    incluirCases: prop.incluirCases ?? brand === 'nextcard',
    casesSrc: (fotosUser && fotosUser['cases-sucesso']) || CASES_PADRAO.src,
    numero: prop.numero || '',
    dataEmissao: fmtData(emissao),
    validade: val.dataTxt,
    validadeLabel: val.label,
    titulo: prop.nome || 'Proposta comercial',
    cliente: prop.cliente?.empresa || 'Cliente',
    contato: prop.cliente?.contato || '',
    logoCliente: prop.cliente?.logo || null,
    inclusosTodos: inclTodos,
    inclusos: inclTodos.slice(0, 4),
    observacoes: prop.observacoes || '',
  };
  const rodVal = ['VALIDADE', `${val.label} · até ${val.dataTxt}`];
  if (brand === 'teloos') {
    const r = calcTeloos(prop, cfg);
    const plano = r.linhas.find((l) => l.kind === 'plano');
    const planoCfg = plano ? cfg.teloos.planos.find((p) => p.id === plano.refId) : null;
    const destaque = r.periodicidades.find((p) => p.id === prop.pagamento?.destaque) || r.periodicidades[0];
    const imp = cfg.teloos.implantacao.find((i) => i.id === prop.teloos?.implantacao);
    const implLimite = imp && !isNil(imp.validadeDias) ? fmtData(addDias(emissao, imp.validadeDias)) : null;
    return {
      ...base, calc: r, familia: 'plano', familiaLabel: FAMILIA_LABEL.plano, equipamentos: [],
      plano, planoCfg, destaque, implLimite, cupom: prop.teloos?.cupom || 0,
      rodape: [rodVal, ['COBRANÇA', cfg.teloos.rodape.impostos], ['FIDELIDADE', 'Sem fidelidade contratual'], ['IMPLANTAÇÃO', implLimite ? `Condição até ${implLimite}` : 'Paga à vista']],
    };
  }
  const r = calcNextcard(prop, cfg);
  const fams = familias(prop.itens);
  const principal = familiaPrincipal(prop.itens);
  const famKeys = ['totem', 'catraca', 'comanda'].filter((f) => fams.has(f));
  const familia = famKeys.length > 1 ? 'misto' : (famKeys[0] || principal || 'misto');
  const equipamentos = prop.usarFoto !== false ? equipamentosDestaque(r.linhas, cfg, fotosUser, PHOTOS) : [];
  const frete = prop.pagamento?.frete || 'FOB';
  const freteTxt = frete === 'CIF' ? 'Frete CIF: por conta da NEXTCARD' : 'Frete FOB: por conta do destinatário';
  const freteCurto = frete === 'CIF' ? 'CIF · por conta da NEXTCARD' : 'FOB · por conta do destinatário';
  const prazo = cfg.nextcard.prazoCurto[familia === 'misto' ? principal : familia] || cfg.nextcard.prazoCurto.totem;
  // condições na imagem: destaque primeiro, no máximo 2 além do PIX
  const disp = r.condicoes.filter((c) => c.disponivel && c.tipo !== 'avista');
  const dest = disp.find((c) => c.id === prop.pagamento?.destaque);
  const ordem = dest ? [dest, ...disp.filter((c) => c !== dest)] : disp;
  return {
    ...base, calc: r, familia, familiaLabel: FAMILIA_LABEL[familia] || FAMILIA_LABEL.misto,
    equipamentos, frete, freteTxt,
    condImagem: ordem.slice(0, 1), condExtras: Math.max(0, ordem.length - 1), notaCredito: cfg.nextcard.rodape.impostos,
    rodape: [rodVal, ['CONDIÇÕES', cfg.nextcard.rodape.impostos], ['PRAZO', prazo], ['FRETE', freteCurto]],
  };
}

// ───────────── Espaçamento (base 1080 px): só múltiplos de 8 ─────────────
export const ESPACOS = [8, 16, 24, 32, 48, 64, 96];
export const MARGEM = 64; // margem lateral única: todo bloco começa e termina no mesmo x
const CWID = W - 2 * MARGEM;
const GAP_SECAO = 48, GAP_TITULO = 24, GAP_LISTA = 16, PAD = 32;
const LH = 40; // entrelinha constante do texto de 30 px
const PRECO_PX = 90; // era 118: −23,7% (a regra é 20–25% menor, nunca abaixo de 72)

// Registro da caixa de cada bloco: grade de depuração (?grid=1) e teste de alinhamento/sobreposição
function bloco(ctx, nome, x, y, w, h, tipo = 'secao') {
  (ctx.__blocos || (ctx.__blocos = [])).push({ nome, tipo, x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) });
}

// Grade de depuração (index.html?grid=1, no app ou no harness, ou opts.grid): margens, 12 colunas e a caixa de cada bloco
const gradeLigada = (opts) => !!(opts && opts.grid) || (typeof window !== 'undefined' && (!!window.NX_GRADE || /[?&]grid=1(&|$)/.test(window.location.search)));
export function desenhaGrade(ctx, blocos) {
  ctx.save();
  ctx.fillStyle = 'rgba(0,200,255,0.06)';
  const col = (CWID - 11 * GAP_TITULO) / 12;
  for (let i = 0; i < 12; i++) ctx.fillRect(MARGEM + i * (col + GAP_TITULO), 0, col, H);
  ctx.strokeStyle = 'rgba(0,200,255,0.9)'; ctx.lineWidth = 2;
  for (const x of [MARGEM, W - MARGEM]) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
  const cor = { secao: 'rgba(255,0,200,0.95)', ancora: 'rgba(255,0,200,0.6)', foto: 'rgba(0,220,255,0.95)', rotulo: 'rgba(255,210,0,0.95)' };
  for (const b of blocos || []) {
    ctx.strokeStyle = cor[b.tipo] || 'rgba(255,255,255,0.8)'; ctx.setLineDash(b.tipo === 'secao' ? [] : [8, 8]);
    ctx.strokeRect(b.x + 0.5, b.y + 0.5, b.w - 1, b.h - 1);
    ctx.setLineDash([]);
    ctx.font = '700 18px sans-serif'; ctx.fillStyle = cor[b.tipo] || '#FFFFFF';
    ctx.fillText(`${b.nome} · y ${b.y} · h ${b.h}`, b.x + 8, b.y + 20);
  }
  ctx.restore();
}

// ───────────── Peça principal (imagem do WhatsApp e capa do PDF) ─────────────
// Trunca com reticências para caber na largura
function fit(ctx, text, maxW) {
  let t = String(text || '');
  if (ctx.measureText(t).width <= maxW) return t;
  while (t.length && ctx.measureText(t + '…').width > maxW) t = t.slice(0, -1);
  return t.trimEnd() + '…';
}
// Reduz a fonte até caber; se ainda não couber, trunca
function fitFont(ctx, text, maxW, weight, size, minSize, fam) {
  let s = size;
  font(ctx, weight, s, fam);
  while (ctx.measureText(text).width > maxW && s > minSize) { s -= 1; font(ctx, weight, s, fam); }
  return fit(ctx, text, maxW);
}
// Rótulo em caixa alta (22 px, 700; na NX Sans com 0,08em entre letras)
function rotulo(ctx, th, texto, x, y, cor, align = 'left') {
  font(ctx, 700, 22, th.mono); ctx.fillStyle = cor || th.tone;
  return spaced(ctx, texto, x, y, 3, align);
}

// Cabeçalho: logo + moldura do cliente; régua; etiqueta e número; título; "para cliente · A/C"
function cabecalho(ctx, model, th, logo, cliLogo) {
  const X = MARGEM, top = GAP_SECAO, hh = 96;
  faixaCabecalho(ctx, th, top + hh + GAP_TITULO); // tema Cinza: a régua fecha a faixa grafite
  const logoH = model.brand === 'nextcard' ? 56 : 60;
  if (logo) ctx.drawImage(logo, X, top + (hh - logoH) / 2, logoH * logo.width / logo.height, logoH);
  const bw = 288, bx = W - X - bw;
  ctx.save();
  if (model.brand === 'nextcard') shapePath(ctx, bx, top, bw, hh, { chamfer: 16 }); else roundPath(ctx, bx, top, bw, hh, 24);
  // tema claro: moldura com borda fina (sem fundo branco, que sumiria na página branca)
  if (th.clienteFill) { ctx.fillStyle = th.clienteFill; if (th.clienteSombra) { ctx.shadowColor = th.clienteSombra; ctx.shadowBlur = 32; } ctx.fill(); }
  ctx.shadowBlur = 0;
  if (th.clienteStroke) { ctx.strokeStyle = th.clienteStroke; ctx.lineWidth = 2; ctx.stroke(); }
  ctx.restore();
  if (cliLogo) drawContain(ctx, cliLogo, bx + 24, top + 16, bw - 48, hh - 32);
  else {
    ctx.fillStyle = th.clienteTexto; font(ctx, 700, 30, th.display); ctx.textAlign = 'center';
    const ls = clampLines(ctx, wrap(ctx, model.cliente.toUpperCase(), bw - 48), 2, bw - 48);
    const lh = 32, y0 = top + (hh - ls.length * lh) / 2 + 24;
    ls.forEach((t, i) => ctx.fillText(fit(ctx, t, bw - 48), bx + bw / 2, y0 + i * lh));
    ctx.textAlign = 'left';
  }
  bloco(ctx, 'cabeçalho', X, top, CWID, hh);
  // régua
  let y = top + hh + GAP_TITULO;
  const g = ctx.createLinearGradient(X, 0, W - X, 0);
  g.addColorStop(0, th.regua[0]); g.addColorStop(0.5, th.regua[1]); g.addColorStop(1, th.regua[2]);
  ctx.fillStyle = g; ctx.fillRect(X, y - 1, CWID, 2);
  // etiqueta (esquerda) + número (direita); se não couberem na linha, o número desce
  y += GAP_TITULO;
  const yIdent = y;
  font(ctx, 700, 22, th.mono);
  const numTxt = model.numero ? `Nº ${model.numero}` : model.dataEmissao;
  const numW = spacedWidth(ctx, numTxt, 2);
  let tag = `PROPOSTA COMERCIAL · ${model.familiaLabel}`;
  if (32 + spacedWidth(ctx, tag, 3) > CWID) tag = 'PROPOSTA COMERCIAL';
  const umaLinha = 32 + spacedWidth(ctx, tag, 3) + 32 + numW <= CWID;
  ctx.fillStyle = th.tone;
  if (model.brand === 'nextcard') ctx.fillRect(X, y + 8, 16, 16); else { ctx.beginPath(); ctx.arc(X + 8, y + 16, 8, 0, Math.PI * 2); ctx.fill(); }
  rotulo(ctx, th, tag, X + 32, y + 24);
  font(ctx, 700, 22, th.mono); ctx.fillStyle = th.muted;
  if (umaLinha) spaced(ctx, numTxt, W - X, y + 24, 2, 'right');
  else { y += 32 + 8; spaced(ctx, numTxt, X + 32, y + 24, 2); }
  y += 32 + 16;
  // título: 1 linha de 56 px (reduz até 44 px para caber); se ainda não couber, 2 linhas de 56 px
  let ts = 56;
  font(ctx, 700, ts, th.display);
  while (ctx.measureText(model.titulo).width > CWID && ts > 44) { ts -= 4; font(ctx, 700, ts, th.display); }
  if (ctx.measureText(model.titulo).width > CWID) { ts = 56; font(ctx, 700, ts, th.display); }
  ctx.fillStyle = th.text;
  const tl = ctx.measureText(model.titulo).width <= CWID ? [model.titulo] : clampLines(ctx, wrap(ctx, model.titulo, CWID), 2, CWID);
  const tlh = tl.length === 1 ? 56 : 64;
  tl.forEach((t, i) => ctx.fillText(t, X, y + 44 + i * tlh));
  y += tl.length * tlh + 8;
  // "para Cliente · A/C Contato" (30 px); o contato desce se não couber
  font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted; ctx.fillText('para ', X, y + 30);
  const pw = ctx.measureText('para ').width;
  font(ctx, 700, 30, th.body); ctx.fillStyle = th.text;
  const cl = fit(ctx, model.cliente, CWID - pw);
  ctx.fillText(cl, X + pw, y + 30);
  const clw = ctx.measureText(cl).width;
  if (model.contato) {
    font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted;
    const ct = ` · A/C ${model.contato}`;
    if (pw + clw + ctx.measureText(ct).width <= CWID) ctx.fillText(ct, X + pw + clw, y + 30);
    else { y += LH; ctx.fillText(fit(ctx, `A/C ${model.contato}`, CWID), X, y + 30); }
  }
  y += LH;
  bloco(ctx, 'identificação', X, yIdent, CWID, y - yIdent);
  return y;
}

// ── Equipamentos em destaque: 1 → centralizado; 2 → lado a lado; 3+ → grade; todos com a mesma altura de foto
// Nome e quantidade na mesma linha quando cabem; senão a quantidade desce (sempre no máximo 2 linhas)
function linhasNome(ctx, th, e, larg) {
  font(ctx, 700, 30, th.body);
  const junto = `${e.nome} · ${e.un}`;
  return ctx.measureText(junto).width <= larg ? [junto] : [fit(ctx, e.nome, larg), e.un];
}
// Modelo único com o rótulo ao lado (à direita), centralizado na altura da foto
function desenhaUnicoAoLado(ctx, th, e, im, x, y, w, h, larguraRotulo) {
  const asp = im ? im.width / im.height : 0.5;
  const alt = Math.min(h, (w - larguraRotulo - GAP_SECAO) / asp);
  const fw = alt * asp;
  const fotoW = w - larguraRotulo - GAP_SECAO;
  const mid = x + fotoW / 2, top = y + (h - alt) / 2;
  palco(ctx, th, mid, top + alt, Math.min(fotoW / 2, fw * 0.9 + 64));
  if (im) { ctx.save(); ctx.shadowColor = th.sombraFoto; ctx.shadowBlur = 40; ctx.shadowOffsetY = 16; ctx.drawImage(im, mid - fw / 2, top, fw, alt); ctx.restore(); }
  bloco(ctx, 'foto 1', mid - fw / 2, top, fw, alt, 'foto');
  const lx = x + w - larguraRotulo;
  font(ctx, 700, 30, th.body);
  const nome = wrap(ctx, `${e.nome} · ${e.un}`, larguraRotulo);
  font(ctx, 400, 30, th.body);
  const esp = e.espec ? clampLines(ctx, wrap(ctx, e.espec.replace(/ · /g, ' · '), larguraRotulo), 4, larguraRotulo) : [];
  const lh = 32 + 8 + nome.length * LH + (esp.length ? GAP_LISTA + esp.length * LH : 0);
  let ly = top + (alt - lh) / 2;
  bloco(ctx, 'rótulo 1', lx, ly, larguraRotulo, lh, 'rotulo');
  rotulo(ctx, th, e.rotulo, lx, ly + 24);
  ly += 32 + 8;
  font(ctx, 700, 30, th.body); ctx.fillStyle = th.text;
  nome.forEach((t) => { ctx.fillText(t, lx, ly + 30); ly += LH; });
  if (esp.length) { ly += GAP_LISTA; font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted; esp.forEach((t) => { ctx.fillText(t, lx, ly + 30); ly += LH; }); }
  return alt;
}
function desenhaEquipamentos(ctx, th, eqs, imgs, x, y, w, h) {
  const n = eqs.length, gap = GAP_TITULO;
  const asp = imgs.map((im) => (im ? im.width / im.height : 0.5));
  if (n === 1) {
    // compara rótulo embaixo × ao lado e fica com a foto de maior área
    const larguraRotulo = 352;
    font(ctx, 400, 30, th.body);
    const espL = eqs[0].espec ? Math.min(2, wrap(ctx, eqs[0].espec, w).length) : 0;
    const lhBaixo = 32 + 8 + LH + espL * LH;
    const altBaixo = Math.min(h - lhBaixo - GAP_TITULO, w / asp[0]);
    const altLado = Math.min(h, (w - larguraRotulo - GAP_SECAO) / asp[0]);
    if (altLado > altBaixo * 1.05) return desenhaUnicoAoLado(ctx, th, eqs[0], imgs[0], x, y, w, h, larguraRotulo);
  }
  // largura mínima de cada célula para o rótulo (nome em até 2 linhas)
  font(ctx, 700, 30, th.body);
  const labMin = eqs.map((e) => Math.ceil(Math.min(ctx.measureText(`${e.nome} · ${e.un}`).width, Math.max(ctx.measureText(e.nome).width, ctx.measureText(e.un).width))) + GAP_LISTA);
  const alturaRotulo = (larguras) => {
    const nl = Math.max(...eqs.map((e, i) => linhasNome(ctx, th, e, larguras[i] - GAP_LISTA).length));
    let hh = 32 + 8 + nl * LH;
    if (n === 1 && eqs[0].espec) { font(ctx, 400, 30, th.body); hh += Math.min(2, wrap(ctx, eqs[0].espec, w).length) * LH; }
    return hh;
  };
  // procura a maior altura de foto em que fotos + rótulos cabem na largura (uma linha; 4 modelos também em 2×2)
  const tenta = (grupos) => {
    const larguraGrupo = (g, alt) => g.reduce((s2, i) => s2 + Math.max(asp[i] * alt, labMin[i]), 0) + (g.length - 1) * gap;
    let alt = Math.floor((h - grupos.length * (32 + 8 + 2 * LH + GAP_TITULO) - (grupos.length - 1) * gap) / grupos.length);
    while (alt > 120 && grupos.some((g) => larguraGrupo(g, alt) > w)) alt -= 4;
    const cels = grupos.map((g) => g.map((i) => Math.max(asp[i] * alt, labMin[i])));
    const lh = alturaRotulo(eqs.map((_, i) => { const gi = grupos.findIndex((g) => g.includes(i)); return cels[gi][grupos[gi].indexOf(i)]; }));
    // com o rótulo real, a foto pode crescer até ocupar a altura disponível
    let alt2 = Math.floor((h - grupos.length * (lh + GAP_TITULO) - (grupos.length - 1) * gap) / grupos.length);
    while (alt2 > alt && grupos.some((g) => larguraGrupo(g, alt2) > w)) alt2 -= 4;
    return { grupos, alt: Math.max(alt, Math.min(alt2, alt2)), lh };
  };
  const ops = [tenta([eqs.map((_, i) => i)])];
  if (n === 4) ops.push(tenta([[0, 1], [2, 3]]));
  const op = ops.sort((a, b2) => b2.alt - a.alt)[0];
  const alt = Math.max(0, op.alt);
  const alturaLinha = alt + GAP_TITULO + op.lh; // foto → rótulo: 24 (o anel do palco ocupa ~20)
  const blocoH = op.grupos.length * alturaLinha + (op.grupos.length - 1) * gap;
  let ry = y + Math.max(0, (h - blocoH) / 2);
  for (const grupo of op.grupos) {
    const fotosW = grupo.map((i) => alt * asp[i]);
    const cels = grupo.map((i, k) => Math.max(fotosW[k], labMin[i]));
    const sobra = w - cels.reduce((s2, v) => s2 + v, 0) - (grupo.length - 1) * gap;
    let cx = x;
    grupo.forEach((i, k) => {
      const cellW = cels[k] + sobra / grupo.length;
      const mid = cx + cellW / 2, base = ry + alt;
      palco(ctx, th, mid, base, Math.min(cellW / 2, fotosW[k] * 0.9 + 40));
      const im = imgs[i];
      if (im) { ctx.save(); ctx.shadowColor = th.sombraFoto; ctx.shadowBlur = 40; ctx.shadowOffsetY = 16; ctx.drawImage(im, mid - fotosW[k] / 2, ry, fotosW[k], alt); ctx.restore(); }
      bloco(ctx, `foto ${i + 1}`, mid - fotosW[k] / 2, ry, fotosW[k], alt, 'foto');
      // rótulo centralizado sob a foto
      let ly = base + GAP_TITULO;
      rotulo(ctx, th, eqs[i].rotulo, mid, ly + 24, th.tone, 'center');
      ly += 32 + 8;
      ctx.fillStyle = th.text; ctx.textAlign = 'center';
      linhasNome(ctx, th, eqs[i], cellW - GAP_LISTA).forEach((t) => { font(ctx, 700, 30, th.body); ctx.fillText(t, mid, ly + 30); ly += LH; });
      if (n === 1 && eqs[i].espec) { font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted; clampLines(ctx, wrap(ctx, eqs[i].espec, w), 2, w).forEach((t) => { ctx.fillText(t, mid, ly + 30); ly += LH; }); }
      ctx.textAlign = 'left';
      bloco(ctx, `rótulo ${i + 1}`, cx, base + GAP_TITULO, cellW, op.lh, 'rotulo');
      cx += cellW + gap;
    });
    ry += alturaLinha + gap;
  }
  return alt;
}

// ── Lista de itens: quantidade em coluna de largura fixa (alinhada à direita), nomes no mesmo x, valores à direita
function medeLista(ctx, th, linhas, maxRows, modo) {
  const mais = linhas.length > maxRows;
  const shown = linhas.slice(0, mais ? Math.max(0, maxRows - 1) : maxRows);
  const rows = shown.length + (mais ? 1 : 0);
  font(ctx, 700, 30, th.mono);
  const qcol = Math.max(64, ...shown.map((l) => Math.ceil(ctx.measureText(`${l.qtd}×`).width)));
  return {
    h: rows ? rows * LH + (rows - 1) * GAP_LISTA : 0,
    rows,
    draw(y) {
      const X = MARGEM, nx = X + qcol + GAP_LISTA;
      shown.forEach((l, i) => {
        const by = y + i * (LH + GAP_LISTA) + 30;
        font(ctx, 700, 30, th.mono); ctx.fillStyle = th.tone; ctx.textAlign = 'right'; ctx.fillText(`${l.qtd}×`, X + qcol, by);
        font(ctx, 600, 30, th.display);
        const val = l.total === 0 ? 'incluso' : fmtBRL(l.total);
        ctx.fillStyle = l.total === 0 ? th.hi : th.muted; ctx.fillText(val, X + CWID, by);
        const vw = ctx.measureText(val).width;
        ctx.textAlign = 'left';
        font(ctx, 400, 30, th.body); ctx.fillStyle = th.text;
        ctx.fillText(fit(ctx, l.nome, X + CWID - vw - GAP_TITULO - nx), nx, by);
      });
      if (mais) {
        const n = linhas.length - shown.length;
        font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted;
        ctx.fillText(`+ ${n} ${n === 1 ? 'item' : 'itens'} ${modo === 'pdf' ? 'na página 2' : 'no PDF'}`, nx, y + shown.length * (LH + GAP_LISTA) + 30);
      }
    },
  };
}

// ── Sem foto de equipamento: painel de escopo com os itens em linhas grandes
const ESC_LINHA = LH + 8 + LH; // nome + especificação
function escopoAltura(n) { return PAD + 32 + GAP_TITULO + n * ESC_LINHA + Math.max(0, n - 1) * GAP_LISTA + PAD; }
function desenhaEscopo(ctx, th, linhas, x, y, w, h, modo) {
  panel(ctx, x, y, w, h, th);
  const IW = w - 2 * PAD;
  rotulo(ctx, th, 'ESCOPO DA PROPOSTA', x + PAD, y + PAD + 24);
  rotulo(ctx, th, `${linhas.length} ${linhas.length === 1 ? 'ITEM' : 'ITENS'}`, x + w - PAD, y + PAD + 24, th.muted, 'right');
  let maxRows = 1;
  while (escopoAltura(maxRows + 1) <= h) maxRows++;
  const mais = linhas.length > maxRows;
  const show = linhas.slice(0, mais ? maxRows - 1 : maxRows);
  let ry = y + PAD + 32 + GAP_TITULO;
  font(ctx, 700, 30, th.mono);
  const qw = Math.max(80, ...show.map((l) => ctx.measureText(`${l.qtd}×`).width + 32));
  show.forEach((l) => {
    ctx.save(); shapePath(ctx, x + PAD, ry, qw, LH, { ...th, chamfer: th.chamfer ? 8 : 0, radius: 20 }); ctx.fillStyle = th.chipFill; ctx.fill(); ctx.restore();
    font(ctx, 700, 30, th.mono); ctx.fillStyle = th.chipTexto; ctx.textAlign = 'center'; ctx.fillText(`${l.qtd}×`, x + PAD + qw / 2, ry + 30);
    font(ctx, 600, 30, th.display); ctx.textAlign = 'right'; ctx.fillStyle = l.total === 0 ? th.hi : th.text;
    const val = l.total === 0 ? 'incluso' : fmtBRL(l.total);
    ctx.fillText(val, x + w - PAD, ry + 30);
    const vw = ctx.measureText(val).width;
    ctx.textAlign = 'left';
    const nx = x + PAD + qw + GAP_LISTA, nw = x + w - PAD - vw - GAP_TITULO - nx;
    font(ctx, 600, 30, th.body); ctx.fillStyle = th.text; ctx.fillText(fit(ctx, l.nome, nw), nx, ry + 30);
    font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted; ctx.fillText(fit(ctx, l.spec || l.codigo || '', IW - qw - GAP_LISTA), nx, ry + LH + 8 + 30);
    ry += ESC_LINHA + GAP_LISTA;
  });
  if (mais) { font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted; ctx.fillText(`+ ${linhas.length - show.length} itens ${modo === 'pdf' ? 'na página 2' : 'no PDF'}`, x + PAD, ry + 30); }
  // X da marca, discreto, no canto
  if (th.brand === 'nextcard') {
    ctx.save(); ctx.globalAlpha = 0.06; ctx.lineWidth = 64; ctx.strokeStyle = th.claro ? '#1F1F23' : '#FFFFFF';
    ctx.beginPath(); ctx.moveTo(x + w - 224, y + h - 256); ctx.lineTo(x + w - 24, y + h - 24); ctx.stroke();
    ctx.strokeStyle = '#E0232C'; ctx.globalAlpha = 0.14; ctx.beginPath(); ctx.moveTo(x + w - 24, y + h - 256); ctx.lineTo(x + w - 224, y + h - 24); ctx.stroke();
    ctx.restore();
  }
}

// ── Inclusos: 2 colunas quando todos cabem em uma linha; senão, 1 coluna com até 2 linhas por item
function medeInclusos(ctx, items, th) {
  if (!items.length) return { h: 0, draw() {} };
  const X = MARGEM, tx = 56, colW = (CWID - PAD) / 2; // ícone de 40 px por assunto + 16 de respiro
  font(ctx, 400, 30, th.body);
  const two = items.length > 1 && items.every((t) => ctx.measureText(t).width <= colW - tx);
  const blocks = two ? null : items.map((t) => clampLines(ctx, wrap(ctx, t, CWID - tx), 2, CWID - tx));
  const n = two ? Math.ceil(items.length / 2) : items.length;
  const corpo = two ? n * LH + (n - 1) * GAP_LISTA : blocks.reduce((s, ls) => s + ls.length * LH, 0) + (n - 1) * GAP_LISTA;
  const h = 32 + GAP_TITULO + corpo;
  return {
    h,
    draw(y) {
      const lw = rotulo(ctx, th, 'INCLUSO NA PROPOSTA', X, y + 24);
      ctx.fillStyle = th.line; ctx.fillRect(X + lw + GAP_LISTA, y + 16, CWID - lw - GAP_LISTA, 2);
      font(ctx, 400, 30, th.body);
      let cy = y + 32 + GAP_TITULO;
      if (two) {
        items.forEach((t, i) => {
          const cx = X + (i % 2) * (colW + PAD), ry = cy + Math.floor(i / 2) * (LH + GAP_LISTA);
          icone(ctx, th, iconeDe(t), cx, ry, 40); font(ctx, 400, 30, th.body); ctx.fillStyle = th.text; ctx.fillText(t, cx + tx, ry + 30);
        });
      } else {
        blocks.forEach((ls) => {
          icone(ctx, th, iconeDe(ls.join(' ')), X, cy, 40); font(ctx, 400, 30, th.body); ctx.fillStyle = th.text;
          ls.forEach((l, k) => ctx.fillText(l, X + tx, cy + 30 + k * LH));
          cy += ls.length * LH + GAP_LISTA;
        });
      }
    },
  };
}

// ── Faixa de cases de sucesso (imagem): rótulo + site (40) + 16 + painel branco com os logos; 12–15% da altura
const CASES_MIN = 232, CASES_MAX = 288;
function medeCases(ctx, th, model, img, alvo) {
  if (!img) return null;
  const inner = CWID - 2 * GAP_LISTA;
  const natural = 56 + 2 * GAP_LISTA + Math.round(inner * img.height / img.width);
  const h = Math.max(CASES_MIN, Math.min(CASES_MAX, alvo || natural));
  const site = String(model.E.site || '').replace(/^https?:\/\//, '').replace(/^www\./, '');
  return {
    h,
    draw(y) {
      const X = MARGEM;
      rotulo(ctx, th, model.brand === 'teloos' ? 'CASES DE SUCESSO' : 'CLIENTES QUE CONFIAM NA NEXTCARD', X, y + 28);
      if (site) { font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted; ctx.textAlign = 'right'; ctx.fillText(site, X + CWID, y + 30); ctx.textAlign = 'left'; }
      const py = y + 40 + GAP_LISTA, ph = h - 56;
      ctx.save();
      if (th.chamfer) shapePath(ctx, X, py, CWID, ph, { chamfer: 16 }); else roundPath(ctx, X, py, CWID, ph, 24);
      ctx.fillStyle = '#FFFFFF'; ctx.fill();
      if (th.claro) { ctx.strokeStyle = th.line; ctx.lineWidth = 2; ctx.stroke(); }
      ctx.restore();
      drawContain(ctx, img, X + GAP_LISTA, py + GAP_LISTA, CWID - 2 * GAP_LISTA, ph - 2 * GAP_LISTA);
      bloco(ctx, 'cases', X, y, CWID, h);
    },
  };
}

export async function renderPeca(model, cfg, scale = 1, opts = {}) {
  const modo = opts.modo === 'pdf' ? 'pdf' : 'imagem';
  await ensureFonts();
  const th = paleta(model.brand, model.tema);
  const cv = document.createElement('canvas');
  cv.width = W * scale; cv.height = H * scale;
  const ctx = cv.getContext('2d');
  ctx.scale(scale, scale);
  ctx.textBaseline = 'alphabetic';
  ctx.__blocos = [];
  const eqs = model.brand === 'nextcard' ? (model.equipamentos || []) : [];
  const [logo, symbol, cliLogo, casesImg, ...imgsEq] = await Promise.all([
    loadImage(IMG[th.logo]), loadImage(IMG.teloosSymbol), loadImage(model.logoCliente),
    modo === 'imagem' && model.incluirCases ? loadImage(model.casesSrc) : null,
    ...eqs.map((e) => loadImage(e.foto)),
  ]);
  background(ctx, th, model.brand, symbol);
  const X = MARGEM;
  const topo = cabecalho(ctx, model, th, logo, cliLogo);

  // ── Layout de cima para baixo com espaços fixos entre seções (48). Prioridade quando falta espaço:
  // equipamentos > preço e condição > itens > cases > "Incluso". Nada fica abaixo dos mínimos para caber.
  const valor = model.brand === 'teloos' ? medeValorTeloos(ctx, model, th, modo) : medeValorNextcard(ctx, model, th, modo);
  const casesOp = modo === 'imagem' && casesImg ? [medeCases(ctx, th, model, casesImg), medeCases(ctx, th, model, casesImg, 256), medeCases(ctx, th, model, casesImg, CASES_MIN), null] : [null];
  let cases = casesOp[0];
  const assinatura = modo === 'imagem' ? 40 : 0; // sem cases: site como assinatura discreta
  const rodape = modo === 'pdf' ? 32 : 0;
  // capa do PDF: frase de abertura (Configuração → Textos) logo abaixo da identificação, com filete da marca
  const abertura = modo === 'pdf' ? String(cfg[model.brand].fraseAbertura || '').trim() : '';
  let fraseAb = null;
  if (abertura) { font(ctx, 600, 30, th.body); const ls = clampLines(ctx, wrapEquilibrado(ctx, abertura, CWID - PAD), 2, CWID - PAD); fraseAb = { ls, y: topo + GAP_SECAO, h: ls.length * LH }; }
  const heroTop = (fraseAb ? fraseAb.y + fraseAb.h : topo) + GAP_SECAO;
  if (fraseAb) {
    ctx.fillStyle = th.accent; ctx.fillRect(X, fraseAb.y + 4, 6, fraseAb.h - 8);
    font(ctx, 600, 30, th.body); ctx.fillStyle = th.text;
    fraseAb.ls.forEach((l, j) => ctx.fillText(l, X + PAD, fraseAb.y + 30 + j * LH));
    bloco(ctx, 'frase de abertura', X, fraseAb.y, CWID, fraseAb.h);
  }
  const comFotos = eqs.length > 0 && imgsEq.some(Boolean);
  const linhas = model.calc.linhas.filter((l) => l.qtd > 0 || l.total > 0);
  const naFoto = new Set(comFotos ? eqs.map((e) => e.uid) : []);
  const outras = model.brand === 'teloos' ? [] : linhas.filter((l) => !naFoto.has(l.uid));
  const H_MIN = modo === 'pdf' ? 736 : 672, H_ALVO = modo === 'pdf' ? 800 : 768, H_MAX = modo === 'pdf' ? 864 : 960; // 38/35%, 42/40%, 45/50%
  const listaH = (r) => (r ? GAP_LISTA + r * LH + (r - 1) * GAP_LISTA : 0);
  const livreCom = (c) => H - 8 - GAP_TITULO - (c ? 0 : assinatura) - rodape - heroTop - GAP_SECAO - valor.h - (c ? GAP_SECAO + c.h : 0);
  let plano;
  if (comFotos) {
    // equipamentos com no mínimo H_MIN; depois o máximo de itens; depois a maior faixa de cases que couber
    const maxR = Math.min(3, outras.length);
    let esc = null;
    // 1º o máximo de itens com equipamentos ≥ H_MIN; 2º a faixa de cases cede altura (até 12%) para chegar ao alvo de 40%
    for (let r = maxR; r >= 0 && !esc; r--) {
      const ok = casesOp.filter((c) => c && livreCom(c) - listaH(r) >= H_MIN);
      if (ok.length) esc = { r, c: ok.find((c) => livreCom(c) - listaH(r) >= H_ALVO) || ok[ok.length - 1] };
      else if (casesOp.includes(null) && casesOp.length === 1 && livreCom(null) - listaH(r) >= H_MIN) esc = { r, c: null };
    }
    if (!esc) esc = { r: 0, c: casesOp.length > 1 ? null : null };
    cases = esc.c;
    const livre = livreCom(cases);
    let r = esc.r;
    const heroH = Math.max(0, Math.min(H_MAX, livre - listaH(r)));
    // espaço sobrando depois do limite dos equipamentos: mais linhas de itens (até 5)
    while (r < Math.min(5, outras.length) && livre - heroH - listaH(r + 1) >= 0) r++;
    plano = { heroH, r, sobra: livre - heroH - listaH(r) };
  } else if (model.brand === 'teloos') {
    // Prioridade: telas do sistema > preço > plano (itens) > cases. As telas têm proporção fixa: no alvo ocupam
    // a largura toda sem recorte; abaixo disso o painel é recortado com esmaecimento (nunca esticado).
    // 1º telas no alvo, com a faixa de cases cedendo altura (natural → 256 → 232) e o plano com 2 a 4 linhas;
    // 2º telas até o mínimo, plano com pelo menos 2 linhas; 3º plano com 1 linha.
    const opcoesCases = casesOp.filter(Boolean).length ? casesOp.filter(Boolean) : [null];
    let card = null;
    const tenta = (alvo, nMin) => {
      // no alvo, a faixa de cases fica o maior possível; abaixo dele, cede primeiro (as telas crescem)
      const ordem = alvo === TELAS_ALVO ? opcoesCases : [...opcoesCases].reverse();
      for (const c of ordem) for (let n = 4; n >= nMin; n--) {
        const m = medePlanoTeloos(ctx, model, th, n, symbol);
        if (livreCom(c) - GAP_SECAO - m.h >= alvo) { card = m; cases = c; return true; }
      }
      return false;
    };
    tenta(TELAS_ALVO, 2) || tenta(TELAS_MIN, 2) || tenta(TELAS_MIN, 1);
    if (!card) { card = medePlanoTeloos(ctx, model, th, 1, symbol); cases = opcoesCases[opcoesCases.length - 1]; }
    const A = livreCom(cases);
    const telasH = Math.max(0, Math.min(TELAS_MAX, A - GAP_SECAO - card.h));
    plano = { heroH: telasH, r: 0, sobra: Math.max(0, A - GAP_SECAO - card.h - telasH), teloos: true, card };
  } else {
    // sem foto: o painel de escopo tem a altura natural dos itens; o "Incluso" entra antes de o painel crescer
    const nat = escopoAltura(Math.max(1, linhas.length));
    plano = { heroH: Math.min(livreCom(cases), nat), r: 0, sobra: Math.max(0, livreCom(cases) - nat), escopo: true };
  }
  // "Incluso" só com espaço sobrando (a lista completa está no PDF)
  let incl = { h: 0, draw() {} };
  for (let k = Math.min(model.inclusos.length, 4); k > 0; k--) {
    const m = medeInclusos(ctx, model.inclusos.slice(0, k), th);
    if (plano.sobra >= GAP_SECAO + m.h) { incl = m; plano.sobra -= GAP_SECAO + m.h; break; }
  }
  // sem foto: o painel absorve o que sobrar (mantém os 48 px entre seções)
  if (plano.escopo) { plano.heroH += plano.sobra; plano.sobra = 0; }

  let y = heroTop;
  if (plano.teloos) {
    if (plano.heroH) { telasBloco(ctx, th, model, X, y, CWID, plano.heroH); bloco(ctx, 'telas do sistema', X, y, CWID, plano.heroH); y += plano.heroH + GAP_SECAO; }
    plano.card.draw(y); bloco(ctx, 'plano', X, y, CWID, plano.card.h); y += plano.card.h;
  } else {
    if (plano.escopo) desenhaEscopo(ctx, th, linhas, X, y, CWID, plano.heroH, modo);
    else desenhaEquipamentos(ctx, th, eqs, imgsEq, X, y, CWID, plano.heroH);
    y += plano.heroH;
    if (plano.r) { const lista = medeLista(ctx, th, outras, plano.r, modo); y += GAP_LISTA; lista.draw(y); y += lista.h; }
    bloco(ctx, 'equipamentos', X, heroTop, CWID, y - heroTop);
  }
  y += GAP_SECAO;
  valor.draw(y); bloco(ctx, 'investimento', X, y, CWID, valor.h); y += valor.h;
  if (incl.h) { y += GAP_SECAO; incl.draw(y); bloco(ctx, 'incluso', X, y, CWID, incl.h); y += incl.h; }
  if (cases) { y += GAP_SECAO; cases.draw(y); y += cases.h; }

  // Rodapé: imagem sem cases → site; capa do PDF → página n/N
  if (modo === 'imagem' && !cases) {
    const site = String(model.E.site || '').replace(/^https?:\/\//, '').replace(/^www\./, '');
    font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted; ctx.textAlign = 'right';
    ctx.fillText(site, W - X, H - 8 - GAP_TITULO - 10); ctx.textAlign = 'left';
    bloco(ctx, 'assinatura', X, H - 8 - GAP_TITULO - LH, CWID, LH, 'ancora');
  }
  if (modo === 'pdf') {
    const pg = opts.pagina || { n: 1, total: 1 };
    const fy = H - 8 - GAP_TITULO - rodape;
    ctx.fillStyle = th.line; ctx.fillRect(X, fy, CWID, 2);
    rotulo(ctx, th, `${pg.n}/${pg.total}`, W - X, fy + 28, th.muted, 'right');
    bloco(ctx, 'rodapé', X, fy, CWID, rodape, 'ancora');
  }
  const g = ctx.createLinearGradient(0, 0, W, 0);
  g.addColorStop(0, th.barra[0]); g.addColorStop(0.5, th.barra[1]); g.addColorStop(1, th.barra[2]);
  ctx.fillStyle = g; ctx.fillRect(0, H - 8, W, 8);
  cv.__blocos = ctx.__blocos;
  if (gradeLigada(opts)) desenhaGrade(ctx, ctx.__blocos);
  return cv;
}

// Condição em duas partes para a peça: forma (linha 1) e detalhe das parcelas (linha 2)
export function partesCondicao(c) {
  const d = c.parcelas || [];
  if (c.tipo === 'boleto') {
    const forma = `no boleto · ${c.prazos} dias${c.mediante ? '*' : ''}`;
    let det;
    if (c.pct > 0) det = d.length === 1 ? `Entrada de ${fmtBRL(c.entrada)} + ${fmtBRL(d[0])} em ${c.prazos} dias` : `Entrada de ${fmtBRL(c.entrada)} + ${descreveParcelas(d)}`;
    else det = descreveParcelas(d);
    return { forma, det };
  }
  const det = d.length === 1 ? 'Em 1x' : `${c.pct > 0 ? `Entrada de ${fmtBRL(c.entrada)} + ` : ''}${descreveParcelas(d)}`;
  return { forma: 'no cartão de crédito', det };
}

function validadeLinha(ctx, model, th, x, y, maxW) {
  const a = `Válida por ${model.validadeLabel}`, b2 = ` · até ${model.validade}`;
  font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted;
  const aw = ctx.measureText(a).width;
  ctx.fillText(a, x, y);
  font(ctx, 700, 30, th.body); ctx.fillStyle = th.text;
  ctx.fillText(fit(ctx, b2, maxW - aw), x + aw, y);
}

// Selo (FRETE INCLUSO, CUPOM…): 40 px de altura, texto em caixa alta
function selo(ctx, th, texto, xDir, y) {
  font(ctx, 700, 22, th.mono);
  const sw = spacedWidth(ctx, texto, 2) + 32;
  ctx.save();
  if (th.chamfer) shapePath(ctx, xDir - sw, y, sw, 32, { chamfer: 8 }); else roundPath(ctx, xDir - sw, y, sw, 32, 16);
  ctx.fillStyle = th.selo; ctx.fill(); ctx.restore();
  ctx.fillStyle = th.seloTexto; spaced(ctx, texto, xDir - sw + 16, y + 24, 2);
  return sw;
}

// Preço: começa em 90 px (antes 118) e só reduz até 72 px se não couber
function preco(ctx, th, txt, maxW, peso) {
  let size = PRECO_PX; font(ctx, peso, size, th.display);
  while (ctx.measureText(txt).width > maxW && size > 72) { size -= 2; font(ctx, peso, size, th.display); }
  return size;
}

// ── Valor NEXTCARD: PIX em destaque + 1 condição + "demais condições" + validade
function medeValorNextcard(ctx, model, th, modo) {
  const X = MARGEM, IW = CWID - 2 * PAD;
  const c = (model.condImagem || [])[0];
  let partes = null, det = [];
  if (c) { partes = partesCondicao(c); font(ctx, 400, 30, th.body); det = clampLines(ctx, wrap(ctx, partes.det, IW), 2, IW); }
  const notas = [];
  if (model.condExtras > 0) notas.push(modo === 'pdf' ? 'Demais condições na página 2' : 'Demais condições no PDF');
  if (c && c.mediante) notas.push('* mediante aprovação financeira');
  else if (c && model.notaCredito) notas.push(model.notaCredito);
  font(ctx, 400, 30, th.body);
  const notaLs = notas.length ? clampLines(ctx, wrap(ctx, notas.join(' · '), IW), 2, IW) : [];
  const h = PAD + 32 + 8 + 88 + (c ? 8 + LH + det.length * LH : 0) + (notaLs.length ? 8 + notaLs.length * LH : 0) + GAP_LISTA + LH + PAD;
  return {
    h,
    draw(y) {
      panel(ctx, X, y, CWID, h, th, { fillTop: th.valorTop, fillBottom: th.valorBottom });
      let cy = y + PAD;
      rotulo(ctx, th, 'INVESTIMENTO À VISTA NO PIX', X + PAD, cy + 24);
      if (model.frete === 'CIF') selo(ctx, th, 'FRETE INCLUSO', X + CWID - PAD, cy);
      cy += 32 + 8;
      const txt = fmtBRL(model.calc.valorFinal);
      preco(ctx, th, txt, IW, 700);
      ctx.save(); if (th.precoGlow) { ctx.shadowColor = th.precoGlow; ctx.shadowBlur = 32; } ctx.fillStyle = th.preco[0];
      ctx.fillText(txt, X + PAD, cy + 72); ctx.restore();
      cy += 88;
      if (c) {
        cy += 8;
        font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted; ctx.fillText('ou ', X + PAD, cy + 30);
        let cx = X + PAD + ctx.measureText('ou ').width;
        font(ctx, 700, 34, th.display); ctx.fillStyle = th.text;
        const tv = fmtBRL(c.total); ctx.fillText(tv, cx, cy + 30); cx += ctx.measureText(tv).width + 8;
        font(ctx, 600, 30, th.body); ctx.fillStyle = th.text;
        ctx.fillText(fit(ctx, partes.forma, X + CWID - PAD - cx), cx, cy + 30);
        cy += LH;
        font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted;
        det.forEach((l) => { ctx.fillText(l, X + PAD, cy + 30); cy += LH; });
      }
      if (notaLs.length) {
        cy += 8;
        font(ctx, 400, 30, th.body); ctx.fillStyle = th.dim;
        notaLs.forEach((l) => { ctx.fillText(l, X + PAD, cy + 30); cy += LH; });
      }
      cy += GAP_LISTA;
      ctx.fillStyle = th.line; ctx.fillRect(X + PAD, cy - 8, IW, 2);
      validadeLinha(ctx, model, th, X + PAD, cy + 30, IW);
    },
  };
}

// ── Hero Teloos: plano + até 8 recursos (7 + "e mais N") + até 6 adicionais
// ── Plano Teloos compacto: nome do plano + duas colunas (recursos do plano | adicionais contratados).
// "linhas" limita os itens por coluna; o que não cabe vira "e mais N recursos" / "+ N adicionais no PDF".
function medePlanoTeloos(ctx, model, th, linhas, sym) {
  const X = MARGEM, IW = CWID - 2 * PAD, p = model.planoCfg;
  const recursos = p ? p.recursos : [];
  const adic = model.calc.linhas.filter((l) => l.kind === 'adicional');
  const duas = adic.length > 0;
  const colW = (IW - PAD) / 2;
  font(ctx, 500, 30, th.body);
  const linhasDe = (t, larg) => clampLines(ctx, wrap(ctx, t, larg), 2, larg);
  // recursos: com adicionais, uma coluna de até "linhas" itens; sem adicionais, duas colunas (até 2 × linhas)
  const capRec = duas ? linhas : 2 * linhas;
  // o que não cabe vira "e mais N recursos", na linha do nome do plano (as colunas ficam só com recursos)
  const rec = recursos.slice(0, capRec);
  const maisRec = recursos.length - rec.length;
  // adicionais: os primeiros pelo nome; o total vai no rótulo da coluna (a lista completa está no PDF)
  const ad = adic.slice(0, linhas);
  const itemH = (n) => n * LH + 8;
  const colunas = duas ? [rec, ad.map((l) => ({ l }))] : [rec.slice(0, Math.ceil(rec.length / 2)), rec.slice(Math.ceil(rec.length / 2))];
  const alturaCol = (col) => col.reduce((acc, it) => acc + (typeof it === 'string' ? itemH(linhasDe(it, colW - 48).length)
    : itemH(linhasDe(`${it.l.qtd}× ${it.l.nome}`, colW).length)), 0);
  const colH = Math.max(...colunas.map(alturaCol), 0);
  const cab = duas ? 32 + 8 : 0;
  const h = PAD + 72 + GAP_TITULO + cab + colH - 8 + PAD;
  return {
    h,
    draw(y) {
      panel(ctx, X, y, CWID, h, th, { fillTop: th.heroTop, fillBottom: th.heroBottom });
      const IX = X + PAD;
      let cy = y + PAD;
      if (sym) { ctx.save(); if (!th.claro) { ctx.shadowColor = 'rgba(69,102,233,0.9)'; ctx.shadowBlur = 24; } ctx.drawImage(sym, IX, cy + 8, 56 * sym.width / sym.height, 56); ctx.restore(); }
      const tx = IX + 128;
      rotulo(ctx, th, 'PLANO CONTRATADO', tx, cy + 22);
      let mw = 0;
      if (maisRec) { font(ctx, 600, 30, th.body); const t = `e mais ${maisRec} recursos`; mw = ctx.measureText(t).width + GAP_TITULO; ctx.fillStyle = th.laranja; ctx.textAlign = 'right'; ctx.fillText(t, X + CWID - PAD, cy + 66); ctx.textAlign = 'left'; }
      const nome = p ? p.nomeCaps : 'PLANO TELOOS';
      const nn = fitFont(ctx, nome, X + CWID - PAD - tx - mw, 800, 40, 32, th.display); ctx.fillStyle = th.text;
      ctx.fillText(nn, tx, cy + 66);
      cy += 72 + GAP_TITULO / 2;
      ctx.fillStyle = th.line; ctx.fillRect(IX, cy - 1, IW, 2);
      cy += GAP_TITULO / 2;
      if (duas) {
        rotulo(ctx, th, 'RECURSOS DO PLANO', IX, cy + 24);
        rotulo(ctx, th, adic.length > ad.length ? `${adic.length} ADICIONAIS CONTRATADOS` : 'ADICIONAIS CONTRATADOS', IX + colW + PAD, cy + 24, th.hi);
        cy += 32 + 8;
      }
      colunas.forEach((col, k) => {
        const cx = IX + k * (colW + PAD);
        let iy = cy;
        col.forEach((it) => {
          if (typeof it === 'string') {
            check(ctx, cx, iy + 4, 32, th);
            font(ctx, 500, 30, th.body); ctx.fillStyle = th.text;
            const ls = linhasDe(it, colW - 48);
            ls.forEach((l, j) => ctx.fillText(l, cx + 48, iy + 30 + j * LH));
            iy += itemH(ls.length);
          } else {
            font(ctx, 700, 30, th.mono); const q = `${it.l.qtd}× `; const qw = ctx.measureText(q).width;
            font(ctx, 500, 30, th.body);
            const ls = linhasDe(`${q}${it.l.nome}`, colW);
            ls.forEach((l, j) => {
              if (j === 0) { font(ctx, 700, 30, th.mono); ctx.fillStyle = th.tone; ctx.fillText(q, cx, iy + 30); font(ctx, 500, 30, th.body); ctx.fillStyle = th.text; ctx.fillText(l.slice(q.length), cx + qw, iy + 30); }
              else { ctx.fillStyle = th.text; ctx.fillText(l, cx, iy + 30 + j * LH); }
            });
            iy += itemH(ls.length);
          }
        });
      });
    },
  };
}

// o rótulo fica no espaço livre acima da janela do navegador (à esquerda do selo "+23 pedidos")
function telasBloco(ctx, th, model, x, y, w, h) {
  desenhaTelas(ctx, 'capa', x, y, w, h, { cliente: model.cliente, escuro: !th.claro });
  const lw = rotulo(ctx, th, 'TELAS ILUSTRATIVAS DO SISTEMA', x, y + 24);
  bloco(ctx, 'rótulo das telas', x, y, lw, 32, 'rotulo');
}
// alvo = ilustração inteira na largura útil (952 × 560); mínimo = gráficos inteiros (o resto esmaece)
const TELAS_ALVO = TELAS_DIM.capa[1], TELAS_MAX = TELAS_DIM.capa[1], TELAS_MIN = TELAS_VIS_MIN * CWID / TELAS_DIM.capa[0];

// ── Valor Teloos: mensalidade + periodicidade/economia + implantação + validade
function medeValorTeloos(ctx, model, th, modo) {
  const X = MARGEM, IW = CWID - 2 * PAD;
  const r = model.calc;
  const dest = model.destaque;
  const outras = r.periodicidades.filter((p) => p !== dest).slice(0, 2);
  const temImpl = r.unicos.length > 0;
  const econ = dest && dest.fator < 1 ? Math.round((1 - dest.fator) * 100) : 0;
  const temLinha2 = !!(dest && (econ || dest.meses > 1));
  const h = PAD + 32 + 8 + 88 + (temLinha2 ? LH : 0) + outras.length * LH + (temImpl ? GAP_LISTA + LH + (model.implLimite ? 8 + 32 : 0) : 0) + GAP_LISTA + LH + PAD;
  return {
    h,
    draw(y) {
      panel(ctx, X, y, CWID, h, th, { fillTop: th.valorTop, fillBottom: th.valorBottom });
      let cy = y + PAD;
      const label = dest ? (dest.avista ? `PLANO ANUAL À VISTA · ${dest.forma.toUpperCase()}` : dest.meses === 1 ? `MENSALIDADE · ${dest.forma.toUpperCase()}` : `PLANO ${dest.nome.toUpperCase()} · ${dest.forma.toUpperCase()}`) : 'MENSALIDADE';
      const cup = model.cupom || 0;
      const sw = cup ? selo(ctx, th, `CUPOM ${cup}%`, X + CWID - PAD, cy) : 0;
      font(ctx, 700, 22, th.mono);
      rotulo(ctx, th, fit(ctx, label, IW - (sw ? sw + GAP_LISTA : 0)), X + PAD, cy + 24);
      cy += 32 + 8;
      const big = dest ? (dest.avista ? dest.total : dest.porMes) : r.mensal;
      const suf = dest && dest.avista ? '' : '/mês';
      const txt = fmtBRL(big);
      preco(ctx, th, txt, IW - 128, 800);
      const tw = ctx.measureText(txt).width;
      const gt = ctx.createLinearGradient(X, 0, X + tw, 0);
      gt.addColorStop(0, th.preco[0]); gt.addColorStop(0.65, th.preco[1] || th.preco[0]); gt.addColorStop(1, th.preco[2] || th.preco[0]);
      ctx.save(); if (th.precoGlow) { ctx.shadowColor = th.precoGlow; ctx.shadowBlur = 32; } ctx.fillStyle = gt; ctx.fillText(txt, X + PAD, cy + 72); ctx.restore();
      if (suf) { font(ctx, 600, 40, th.display); ctx.fillStyle = th.precoSufixo; ctx.fillText(suf, X + PAD + tw + 8, cy + 72); }
      cy += 88;
      if (temLinha2) {
        const partes = [];
        if (dest.avista) partes.push(`Pagamento único de 12 meses (${dest.forma})`);
        else if (dest.meses > 1) partes.push(`${dest.meses}x de ${fmtBRL(dest.porMes)} (${dest.forma})`);
        font(ctx, 500, 30, th.body); ctx.fillStyle = th.text;
        ctx.fillText(fit(ctx, partes.join(''), IW - 256), X + PAD, cy + 30);
        if (econ) { font(ctx, 700, 30, th.body); ctx.fillStyle = th.laranja; ctx.textAlign = 'right'; ctx.fillText(`economia de ${econ}%`, X + CWID - PAD, cy + 30); ctx.textAlign = 'left'; }
        cy += LH;
      }
      outras.forEach((p) => {
        font(ctx, 400, 30, th.body); ctx.fillStyle = th.muted; ctx.fillText('ou ', X + PAD, cy + 30);
        const ow = ctx.measureText('ou ').width;
        font(ctx, 500, 30, th.body); ctx.fillStyle = th.text;
        ctx.fillText(fit(ctx, p.curto, IW - ow), X + PAD + ow, cy + 30);
        cy += LH;
      });
      if (temImpl) {
        cy += GAP_LISTA;
        ctx.fillStyle = th.line; ctx.fillRect(X + PAD, cy - 8, IW, 2);
        rotulo(ctx, th, 'IMPLANTAÇÃO E TREINAMENTO', X + PAD, cy + 28);
        font(ctx, 700, 34, th.display); ctx.fillStyle = th.text; ctx.textAlign = 'right';
        ctx.fillText(r.implantacao === 0 ? 'inclusa' : `${fmtBRL(r.implantacao)} à vista`, X + CWID - PAD, cy + 30); ctx.textAlign = 'left';
        cy += LH;
        if (model.implLimite) {
          cy += 8;
          font(ctx, 700, 22, th.mono);
          const lt = `CONDIÇÃO VÁLIDA ATÉ ${model.implLimite}`;
          selo(ctx, th, lt, X + PAD + spacedWidth(ctx, lt, 2) + 32, cy);
          cy += 32;
        }
      }
      cy += GAP_LISTA;
      ctx.fillStyle = th.line; ctx.fillRect(X + PAD, cy - 8, IW, 2);
      validadeLinha(ctx, model, th, X + PAD, cy + 30, IW);
    },
  };
}

// ───────────── PDF: capa (a peça em modo PDF) + páginas de detalhamento ─────────────
export async function renderPaginasPDF(model, cfg, scale = 1, opts = {}) {
  const det = await renderDetalhe(model, cfg, scale, { ...opts, primeiraPagina: 2 }); // a capa é a página 1
  const capa = await renderPeca(model, cfg, scale, { ...opts, modo: 'pdf', pagina: { n: 1, total: det.length + 1 } });
  return [capa, ...det];
}

// ───────────── Páginas de detalhamento ─────────────
// Ritmo fixo: 48 entre seções, 24 do título ao conteúdo, 16 entre itens de lista, entrelinha constante de 32 (texto de 24 px)
const DET_TXT = 24, DET_LH = 32;
export async function renderDetalhe(model, cfg, scale = 1, opts = {}) {
  await ensureFonts();
  const th = paleta(model.brand, model.tema);
  const [logo, casesImg] = await Promise.all([loadImage(IMG[th.logo]), model.incluirCases ? loadImage(model.casesSrc) : null]);
  const pages = [];
  let ctx, cv, y;
  const X = MARGEM, CW = CWID;
  const RODAPE = H - 8 - PAD - 32; // topo da linha do rodapé (texto de 22 px)
  const LIMITE = RODAPE - GAP_TITULO - GAP_SECAO; // o conteúdo termina 48 px antes da régua do rodapé
  let secao = null;
  const fechaSecao = () => { if (secao) { bloco(ctx, secao.nome, X, secao.y, CW, y - secao.y); secao = null; } };
  const newPage = () => {
    const aberta = secao && secao.nome;
    fechaSecao();
    if (ctx) ctx.canvas.__blocos = ctx.__blocos;
    cv = document.createElement('canvas'); cv.width = W * scale; cv.height = H * scale;
    ctx = cv.getContext('2d'); ctx.scale(scale, scale); ctx.__blocos = [];
    ctx.fillStyle = th.bg; ctx.fillRect(0, 0, W, H);
    const g = ctx.createRadialGradient(W, 0, 0, W, 0, 700);
    g.addColorStop(0, th.brilho); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // cabeçalho: logo; "DETALHAMENTO" e número à direita; régua; título; cliente
    const top = GAP_SECAO;
    faixaCabecalho(ctx, th, top + 48 + GAP_TITULO);
    if (logo) ctx.drawImage(logo, X, top, 48 * logo.width / logo.height, 48);
    font(ctx, 700, 20, th.mono); ctx.fillStyle = th.bandaTone || th.tone;
    spaced(ctx, 'DETALHAMENTO DA PROPOSTA', W - X, top + 20, 2.5, 'right');
    font(ctx, 600, 20, th.mono); ctx.fillStyle = th.bandaMuted || th.muted;
    spaced(ctx, `${model.numero ? 'Nº ' + model.numero + ' · ' : ''}${model.dataEmissao}`, W - X, top + 48, 1, 'right');
    let hy = top + 48 + GAP_TITULO;
    ctx.fillStyle = th.banda ? th.accent : th.line; ctx.fillRect(X, hy - 1, CW, 2);
    // título e cliente só na primeira página do detalhamento (nas seguintes: logo, número e régua)
    if (!pages.length) {
      hy += GAP_TITULO;
      font(ctx, 700, 40, th.display); ctx.fillStyle = th.text;
      ctx.fillText(clampLines(ctx, [model.titulo], 1, CW)[0], X, hy + 38);
      hy += 48 + 8;
      font(ctx, 400, DET_TXT, th.body); ctx.fillStyle = th.muted;
      ctx.fillText(clampLines(ctx, [`${model.cliente}${model.contato ? ' · A/C ' + model.contato : ''}`], 1, CW)[0], X, hy + 24);
      hy += DET_LH;
    }
    bloco(ctx, 'cabeçalho', X, top, CW, hy - top);
    y = hy;
    pages.push(cv);
    if (aberta) { y += GAP_SECAO; secao = { nome: aberta.replace(/( \(continuação\))?$/, ' (continuação)'), y }; }
  };
  const ensure = (need) => { if (y + need > LIMITE) newPage(); };
  // título de seção (rótulo 20 px + fio) e início da caixa da seção
  const section = (t, minConteudo = 3 * DET_LH) => {
    fechaSecao();
    if (t === opts.quebraAntes || y + GAP_SECAO + 24 + GAP_TITULO + minConteudo > LIMITE) newPage();
    y += GAP_SECAO;
    secao = { nome: t, y };
    font(ctx, 700, 20, th.mono); ctx.fillStyle = th.tone;
    const tw = spaced(ctx, t.toUpperCase(), X, y + 20, 3);
    ctx.fillStyle = th.line; ctx.fillRect(X + tw + GAP_LISTA, y + 12, CW - tw - GAP_LISTA, 2);
    y += 24 + GAP_TITULO;
  };
  const para = (t, o = {}) => {
    font(ctx, o.weight || 400, o.size || DET_TXT, th.body);
    for (const l of wrap(ctx, t, CW)) { ensure(DET_LH); font(ctx, o.weight || 400, o.size || DET_TXT, th.body); ctx.fillStyle = o.color || th.text; ctx.fillText(l, X, y + 24); y += DET_LH; }
  };
  const bullets = (arr) => {
    arr.forEach((t, i) => {
      font(ctx, 400, DET_TXT, th.body);
      const lines = wrap(ctx, t, CW - PAD);
      const antes = pages.length;
      ensure((i ? GAP_LISTA : 0) + lines.length * DET_LH);
      if (i && pages.length === antes) y += GAP_LISTA; // 16 entre itens (não no topo de uma página nova)
      font(ctx, 400, DET_TXT, th.body); // página nova = canvas novo: reaplica a fonte
      ctx.fillStyle = th.bullet;
      if (th.chamfer) ctx.fillRect(X, y + 12, 8, 8); else { ctx.beginPath(); ctx.arc(X + 4, y + 16, 4, 0, Math.PI * 2); ctx.fill(); }
      ctx.fillStyle = th.text;
      lines.forEach((l, k) => ctx.fillText(l, X + PAD, y + 24 + k * DET_LH));
      y += lines.length * DET_LH;
    });
  };

  // lista curta em 2 colunas quando todos os itens cabem em uma linha na meia largura

  // ── Infraestrutura do cliente, compacta: itens numerados em duas colunas (leitura de cima para baixo, coluna
  // por coluna), texto de 22 px; linha "- Rótulo: texto" vira subitem com o rótulo em destaque
  const INF_TXT = 22, INF_LH = 30;
  const infraestrutura = (linhas) => {
    const itens = [];
    for (const l of linhas.map((t) => String(t).trim()).filter(Boolean)) {
      if (/^[-–•]\s*/.test(l) && itens.length) itens[itens.length - 1].subs.push(l.replace(/^[-–•]\s*/, ''));
      else itens.push({ texto: l, subs: [] });
    }
    if (!itens.length) return;
    const colW = (CW - PAD) / 2, num = 32, tx = num + GAP_LISTA, larg = colW - tx;
    const medir = (it) => {
      font(ctx, 400, INF_TXT, th.body);
      const ls = wrap(ctx, it.texto, larg);
      const subs = it.subs.map((sub) => {
        const m = /^([^:]{2,40}):\s*(.+)$/.exec(sub);
        const txt = m ? m[2].charAt(0).toLocaleUpperCase('pt-BR') + m[2].slice(1) : sub; // depois do rótulo, começa com maiúscula
        font(ctx, 400, INF_TXT, th.body); return { rot: m ? m[1] : null, ls: wrap(ctx, txt, larg - GAP_LISTA) };
      });
      const h = Math.max(num, ls.length * INF_LH) + subs.reduce((a, sb) => a + 8 + (sb.rot ? 24 : 0) + sb.ls.length * INF_LH, 0);
      return { ...it, ls, subsM: subs, h };
    };
    const ms = itens.map(medir);
    // ponto de divisão que equilibra as duas colunas
    const alt = (a) => a.reduce((acc, m, i) => acc + m.h + (i ? GAP_LISTA : 0), 0);
    let corte = Math.ceil(ms.length / 2), melhor = Infinity;
    for (let k = 1; k < ms.length; k++) { const hmax = Math.max(alt(ms.slice(0, k)), alt(ms.slice(k))); if (hmax < melhor) { melhor = hmax; corte = k; } }
    const cols = ms.length > 1 ? [ms.slice(0, corte), ms.slice(corte)] : [ms];
    const corpo = Math.max(...cols.map(alt));
    section('Infraestrutura · responsabilidade do cliente', DET_LH + GAP_LISTA + corpo);
    font(ctx, 400, DET_TXT, th.body); ctx.fillStyle = th.muted;
    ctx.fillText('O cliente deverá disponibilizar e garantir:', X, y + 24);
    y += DET_LH + GAP_LISTA;
    let n = 0;
    cols.forEach((col, k) => {
      const cx = X + k * (colW + PAD);
      let iy = y;
      col.forEach((m, i) => {
        if (i) iy += GAP_LISTA;
        n += 1;
        // número em quadrado da marca
        ctx.save();
        if (th.chamfer) shapePath(ctx, cx, iy, num, num, { chamfer: 8 }); else roundPath(ctx, cx, iy, num, num, 10);
        ctx.fillStyle = th.accent; ctx.fill(); ctx.restore();
        font(ctx, 700, 18, th.mono); ctx.fillStyle = '#FFFFFF'; ctx.textAlign = 'center'; ctx.fillText(String(n), cx + num / 2, iy + 23); ctx.textAlign = 'left';
        font(ctx, m.subs.length ? 600 : 400, INF_TXT, th.body); ctx.fillStyle = th.text;
        m.ls.forEach((l, j) => ctx.fillText(l, cx + tx, iy + 22 + j * INF_LH));
        let sy = iy + Math.max(num, m.ls.length * INF_LH);
        m.subsM.forEach((sb) => {
          sy += 8;
          ctx.fillStyle = th.accent; ctx.fillRect(cx + tx, sy + 4, 3, (sb.rot ? 24 : 0) + sb.ls.length * INF_LH - 8);
          if (sb.rot) { font(ctx, 700, 18, th.mono); ctx.fillStyle = th.tone; spaced(ctx, sb.rot.toUpperCase(), cx + tx + GAP_LISTA, sy + 18, 2); sy += 24; }
          font(ctx, 400, INF_TXT, th.body); ctx.fillStyle = th.text;
          sb.ls.forEach((l) => { ctx.fillText(l, cx + tx + GAP_LISTA, sy + 22); sy += INF_LH; });
        });
        iy += m.h;
      });
    });
    y += corpo;
  };
  // ── Integração das catracas: 1º parágrafo corrido; 2º em destaque (quadro com ícone)
  const integracao = (pars) => {
    const [p1, ...resto] = pars.map((t) => String(t).trim()).filter(Boolean);
    if (!p1) return;
    const dest = resto.join(' ');
    font(ctx, 400, INF_TXT, th.body);
    const l1 = wrap(ctx, p1, CW);
    const ic = 40, dl = dest ? wrap(ctx, dest, CW - 2 * PAD + 8 - ic - GAP_LISTA) : [];
    const caixaH = dest ? Math.max(ic, dl.length * INF_LH) + 2 * 20 : 0;
    section('Integração das catracas', l1.length * INF_LH + (dest ? GAP_LISTA + caixaH : 0));
    font(ctx, 400, INF_TXT, th.body); ctx.fillStyle = th.text;
    l1.forEach((l) => { ctx.fillText(l, X, y + 22); y += INF_LH; });
    if (dest) {
      y += GAP_LISTA;
      ctx.save(); shapePath(ctx, X, y, CW, caixaH, th.chamfer ? { chamfer: 14 } : { radius: 18 }); ctx.fillStyle = th.totalFill; ctx.fill(); ctx.restore();
      ctx.fillStyle = th.accent; ctx.fillRect(X, y, 4, caixaH);
      icone(ctx, th, 'plug', X + PAD - 8, y + (caixaH - ic) / 2, ic);
      font(ctx, 600, INF_TXT, th.body); ctx.fillStyle = th.text;
      const ty = y + (caixaH - dl.length * INF_LH) / 2;
      dl.forEach((l, j) => ctx.fillText(l, X + PAD - 8 + ic + GAP_LISTA, ty + 22 + j * INF_LH));
      y += caixaH;
    }
  };
  // ── O que está incluso: ícone por assunto + texto, em duas colunas
  const inclusosComIcones = (arr) => {
    const colW = (CW - PAD) / 2, ic = 40, tx = ic + GAP_LISTA, larg = colW - tx;
    font(ctx, 400, DET_TXT, th.body);
    const ms = arr.map((t) => { font(ctx, 400, DET_TXT, th.body); const ls = clampLines(ctx, wrap(ctx, t, larg), 2, larg); return { t, ls, h: Math.max(ic, ls.length * DET_LH) }; });
    const linhasG = [];
    for (let i = 0; i < ms.length; i += 2) linhasG.push([ms[i], ms[i + 1]].filter(Boolean));
    const corpo = linhasG.reduce((a, l, i) => a + Math.max(...l.map((m) => m.h)) + (i ? GAP_LISTA : 0), 0);
    section('O que está incluso', Math.min(corpo, 3 * (ic + GAP_LISTA)));
    linhasG.forEach((par, i) => {
      const rh = Math.max(...par.map((m) => m.h));
      const antes = pages.length;
      ensure((i ? GAP_LISTA : 0) + rh);
      if (i && pages.length === antes) y += GAP_LISTA;
      par.forEach((m, k) => {
        const cx = X + k * (colW + PAD);
        icone(ctx, th, iconeDe(m.t), cx, y, ic);
        font(ctx, 400, DET_TXT, th.body); ctx.fillStyle = th.text;
        const ty = y + (m.h - m.ls.length * DET_LH) / 2; // texto centralizado na altura do ícone
        m.ls.forEach((l, j) => ctx.fillText(l, cx + tx, ty + 24 + j * DET_LH));
      });
      y += rh;
    });
  };

  newPage();
  // ── Itens: colunas numéricas medidas pelo maior valor; a descrição fica com o resto da largura
  const linhas = model.calc.linhas;
  const sufixo = (l) => ((l.kind === 'plano' || l.kind === 'adicional') ? '/mês' : '');
  const txtUnit = (l) => (l.unit === 0 ? 'incluso' : fmtBRL(l.unit) + sufixo(l));
  const txtTot = (l) => (l.total === 0 ? 'incluso' : fmtBRL(l.total) + sufixo(l));
  font(ctx, 700, 22, th.body);
  const wT = Math.max(...linhas.map((l) => ctx.measureText(txtTot(l)).width), 64);
  font(ctx, 400, 22, th.body);
  const wU = Math.max(...linhas.map((l) => ctx.measureText(txtUnit(l)).width), 128);
  const wQ = Math.max(...linhas.map((l) => ctx.measureText(String(l.qtd)).width), 56);
  const colT = X + CW - GAP_LISTA, colU = colT - wT - GAP_TITULO, colQ = colU - wU - GAP_TITULO;
  const descW = colQ - wQ - GAP_TITULO - (X + GAP_LISTA);
  section('Itens da proposta');
  const header = () => {
    ctx.save(); shapePath(ctx, X, y, CW, 48, { ...th, chamfer: th.chamfer ? 8 : 0, radius: 16 }); ctx.fillStyle = th.surface; ctx.fill(); ctx.restore();
    font(ctx, 700, 16, th.mono); ctx.fillStyle = th.muted;
    spaced(ctx, 'DESCRIÇÃO', X + GAP_LISTA, y + 30, 2);
    spaced(ctx, 'QTDE', colQ, y + 30, 2, 'right');
    spaced(ctx, 'VALOR UNIT.', colU, y + 30, 2, 'right');
    spaced(ctx, 'TOTAL', colT, y + 30, 2, 'right');
    y += 48;
  };
  header();
  for (const l of linhas) {
    font(ctx, 600, DET_TXT, th.body);
    const nl = wrap(ctx, l.nome, descW);
    font(ctx, 400, 20, th.body);
    const sl = l.spec ? wrap(ctx, l.spec, descW) : [];
    const cod = l.codigo && l.codigo !== l.nome ? l.codigo : '';
    const rowH = GAP_LISTA + nl.length * DET_LH + sl.length * 24 + (cod ? 24 : 0) + GAP_LISTA;
    if (y + rowH > LIMITE) { newPage(); section('Itens da proposta (continuação)'); header(); }
    let yy = y + GAP_LISTA;
    font(ctx, 600, DET_TXT, th.body); ctx.fillStyle = th.text;
    nl.forEach((t) => { ctx.fillText(t, X + GAP_LISTA, yy + 24); yy += DET_LH; });
    font(ctx, 400, 20, th.body); ctx.fillStyle = th.muted;
    sl.forEach((t) => { ctx.fillText(t, X + GAP_LISTA, yy + 18); yy += 24; });
    if (cod) { font(ctx, 600, 16, th.mono); ctx.fillStyle = th.dim; spaced(ctx, cod, X + GAP_LISTA, yy + 18, 1); }
    ctx.textAlign = 'right';
    font(ctx, 400, 22, th.body); ctx.fillStyle = th.text;
    ctx.fillText(String(l.qtd), colQ, y + GAP_LISTA + 24);
    ctx.fillText(txtUnit(l), colU, y + GAP_LISTA + 24);
    font(ctx, 700, 22, th.body); ctx.fillStyle = l.total === 0 ? th.hi : th.text;
    ctx.fillText(txtTot(l), colT, y + GAP_LISTA + 24);
    ctx.textAlign = 'left';
    y += rowH;
    ctx.fillStyle = th.line; ctx.fillRect(X, y - 1, CW, 1);
  }
  ensure(8 + 64);
  y += 8;
  ctx.save(); shapePath(ctx, X, y, CW, 64, { ...th, chamfer: th.chamfer ? 8 : 0, radius: 16 });
  ctx.fillStyle = th.totalFill; ctx.fill(); ctx.restore();
  font(ctx, 700, 18, th.mono); ctx.fillStyle = th.muted;
  spaced(ctx, model.brand === 'teloos' ? 'MENSALIDADE TOTAL' : 'VALOR TOTAL À VISTA (PIX)', X + GAP_LISTA, y + 40, 2);
  font(ctx, 700, 30, th.display); ctx.fillStyle = th.text; ctx.textAlign = 'right';
  ctx.fillText(fmtBRL(model.calc.valorFinal) + (model.brand === 'teloos' ? '/mês' : ''), colT, y + 44); ctx.textAlign = 'left';
  y += 64;

  // ── Condições
  section('Condições comerciais');
  if (model.brand === 'teloos') {
    const r = model.calc;
    bullets([...r.periodicidades.map((p) => p.texto), ...(r.unicos.length ? [`Implantação e treinamento: ${r.implantacao === 0 ? 'inclusos' : fmtBRL(r.implantacao) + ' à vista'}`] : [])]);
  } else {
    const cs = model.calc.condicoes.filter((c) => c.disponivel);
    const txts = cs.map((c) => (c.tipo === 'avista' ? `Para pagamento à vista (PIX): ${fmtBRL(c.total)}` : `Ou ${c.texto}`));
    bullets(txts.length ? txts : [`Valor total: ${fmtBRL(model.calc.valorFinal)}`]);
    y += GAP_LISTA;
    para('Condições sujeitas à análise de crédito.', { size: 20, color: th.muted });
  }
  // ── Prazos, garantia e suporte
  const P = model.brand === 'teloos' ? cfg.teloos.prazos : (() => {
    const f = familias(model.calc.linhas);
    const arr = [];
    for (const k of ['totem', 'catraca', 'comanda']) if (f.has(k)) arr.push(...(cfg.nextcard.prazos[k] || []));
    arr.push(model.freteTxt);
    arr.push(...cfg.nextcard.prazos.geral);
    return arr;
  })();
  section(model.brand === 'teloos' ? 'Contratação e suporte' : 'Prazos, garantia e suporte');
  bullets([`Validade da proposta: ${model.validadeLabel}, até ${model.validade}`, ...(model.implLimite ? [`Condição especial de implantação válida até ${model.implLimite}`] : []), ...P]);
  if (model.brand === 'teloos' && model.planoCfg) {
    section(`Recursos do ${model.planoCfg.nomeCaps}`);
    bullets(model.planoCfg.recursos);
  }
  // Teloos: telas do sistema (PDV e cardápio digital), como ilustração
  if (model.brand === 'teloos') {
    const TH = Math.round(CW * TELAS_DIM.detalhe[1] / TELAS_DIM.detalhe[0]); // proporção fixa das telas
    section('Telas do sistema', TH + GAP_LISTA + DET_LH);
    desenhaTelas(ctx, 'detalhe', X, y, CW, TH, { cliente: model.cliente, escuro: !th.claro });
    y += TH + GAP_LISTA;
    para('Frente de caixa (PDV) e cardápio digital. Imagens ilustrativas.', { color: th.muted });
  }
  if (model.brand === 'nextcard' && familias(model.calc.linhas).has('catraca')) {
    infraestrutura(cfg.nextcard.infraCatraca || []);
    integracao(cfg.nextcard.integracaoCatraca || []);
  }
  if (model.inclusosTodos && model.inclusosTodos.length) inclusosComIcones(model.inclusosTodos);
  if (model.observacoes && model.observacoes.trim()) {
    section('Observações');
    model.observacoes.split(/\n+/).forEach((p, i) => { if (i) y += GAP_LISTA; para(p); });
  }
  fechaSecao();
  // ── Frase de fechamento (centralizada)
  // encerramento (30 px, destaque) + frase da marca (24 px), centralizadas
  const frases = [
    [cfg[model.brand].fraseEncerramento, 700, 30, 40, th.text],
    [cfg[model.brand].fraseFinal, 600, DET_TXT, DET_LH, th.frase],
  ].filter(([t]) => t && String(t).trim()).map(([t, w, sz, lh, cor]) => { font(ctx, w, sz, th.display); return { ls: wrapEquilibrado(ctx, String(t).trim(), CW), w, sz, lh, cor }; });
  if (frases.length) {
    const fh = frases.reduce((a, f, i) => a + f.ls.length * f.lh + (i ? 8 : 0), 0);
    if (opts.quebraAntes === 'frase' || y + GAP_SECAO + fh > LIMITE) newPage();
    y += GAP_SECAO;
    const fy = y;
    ctx.textAlign = 'center';
    frases.forEach((f, i) => { if (i) y += 8; font(ctx, f.w, f.sz, th.display); ctx.fillStyle = f.cor; f.ls.forEach((l) => { ctx.fillText(l, W / 2, y + f.lh - (f.lh - f.sz) / 2 - 4); y += f.lh; }); });
    ctx.textAlign = 'left';
    bloco(ctx, 'frase', X, fy, CW, y - fy);
  }
  // ── Última página: cases de sucesso + bloco do consultor (único lugar do PDF com os dados do consultor)
  const E = model.E;
  const site = String(E.site || '').replace(/^https?:\/\//, '').replace(/^www\./, '');
  const alturaConsultor = GAP_SECAO + PAD + 32 + 8 + 48 + PAD;
  if (casesImg) {
    // imagem na largura útil, encaixe proporcional (os logos nunca são cortados)
    const ih = Math.round((CW - 2 * GAP_LISTA) * casesImg.height / casesImg.width);
    // cases e consultor ficam juntos: o bloco do consultor nunca vai sozinho para uma página
    fechaSecao();
    if (y + GAP_SECAO + 24 + GAP_TITULO + ih + 2 * GAP_LISTA + alturaConsultor > LIMITE) newPage();
    section('Cases de sucesso', ih + 2 * GAP_LISTA);
    ctx.save();
    if (th.chamfer) shapePath(ctx, X, y, CW, ih + 2 * GAP_LISTA, { chamfer: 16 }); else roundPath(ctx, X, y, CW, ih + 2 * GAP_LISTA, 24);
    ctx.fillStyle = '#FFFFFF'; ctx.fill();
    if (th.claro) { ctx.strokeStyle = th.line; ctx.lineWidth = 2; ctx.stroke(); }
    ctx.restore();
    drawContain(ctx, casesImg, X + GAP_LISTA, y + GAP_LISTA, CW - 2 * GAP_LISTA, ih);
    y += ih + 2 * GAP_LISTA;
    fechaSecao();
  }
  {
    const resp = model.resp;
    const nome = resp ? resp.nome : E.nome;
    const contatos = [
      (resp && resp.telefone) || E.whatsapp ? ['WHATSAPP', (resp && resp.telefone) || E.whatsapp] : null,
      (resp && resp.email) || E.email ? ['E-MAIL', (resp && resp.email) || E.email] : null,
      site ? ['SITE', site] : null,
    ].filter(Boolean);
    // duas colunas: rótulo + nome à esquerda; WhatsApp, e-mail e site empilhados à direita
    const miolo = Math.max(32 + 8 + 48, contatos.length * DET_LH);
    const alturaBloco = PAD + miolo + PAD;
    if (y + GAP_SECAO + alturaBloco > LIMITE) newPage();
    y += GAP_SECAO;
    panel(ctx, X, y, CW, alturaBloco, th, { fillTop: th.valorTop, fillBottom: th.valorBottom });
    font(ctx, 700, 20, th.mono); ctx.fillStyle = th.tone;
    spaced(ctx, resp ? 'SEU CONSULTOR' : 'ATENDIMENTO', X + PAD, y + PAD + 24, 3);
    const cx = X + 384; // coluna dos contatos: nome à esquerda, contatos com espaço para e-mails longos
    font(ctx, 700, 36, th.display); ctx.fillStyle = th.text;
    ctx.fillText(fit(ctx, nome, cx - X - 2 * PAD), X + PAD, y + PAD + 32 + 8 + 36);
    let cy = y + PAD + (miolo - contatos.length * DET_LH) / 2;
    contatos.forEach(([k, v]) => {
      font(ctx, 700, 18, th.mono); ctx.fillStyle = th.muted; spaced(ctx, k, cx, cy + 24, 2);
      font(ctx, 400, DET_TXT, th.body); ctx.fillStyle = th.text; ctx.fillText(fit(ctx, v, X + CW - PAD - cx - 128), cx + 128, cy + 24);
      cy += DET_LH;
    });
    bloco(ctx, 'consultor', X, y, CW, alturaBloco);
    y += alturaBloco;
  }
  ctx.canvas.__blocos = ctx.__blocos;
  // ── Equilíbrio: última página com menos de 55% da altura → leva seções inteiras da penúltima para ela.
  // Escolhe o ponto de quebra que deixa a página menos cheia o mais cheia possível; só vale se o número de páginas não mudar.
  if (!opts.quebraAntes && pages.length >= 2) {
    const conteudo = (p) => (p.__blocos || []).filter((b) => b.tipo === 'secao' && b.nome !== 'cabeçalho');
    const fim = (bs) => Math.max(...bs.map((b) => b.y + b.h));
    const ult = conteudo(pages[pages.length - 1]), pen = conteudo(pages[pages.length - 2]);
    if (ult.length && pen.length > 1 && fim(ult) < H * 0.55 && !/\(continuação\)$/.test(ult[0].nome)) {
      const fimUlt = fim(ult), fimPen = fim(pen);
      let melhor = null, nota = Math.min(fimPen, fimUlt);
      for (let k = pen.length - 1; k >= 1; k--) {
        const novoUlt = fimUlt + (fimPen - pen[k].y) + GAP_SECAO, novoPen = pen[k - 1].y + pen[k - 1].h;
        if (novoUlt > LIMITE || /\(continuação\)$/.test(pen[k].nome)) break;
        if (Math.min(novoPen, novoUlt) > nota) { nota = Math.min(novoPen, novoUlt); melhor = pen[k].nome; }
      }
      if (melhor) {
        const equilibrado = await renderDetalhe(model, cfg, scale, { ...opts, quebraAntes: melhor });
        if (equilibrado.length === pages.length) return equilibrado;
      }
    }
  }
  // ── Rodapé de cada página: só o site, a validade e a paginação (n/N do documento inteiro, contando a capa)
  const ini = opts.primeiraPagina || 1, total = pages.length + ini - 1;
  pages.forEach((pcv, i) => {
    const c = pcv.getContext('2d');
    c.save(); c.setTransform(scale, 0, 0, scale, 0, 0);
    c.fillStyle = th.line; c.fillRect(X, RODAPE - GAP_TITULO, CW, 2);
    font(c, 400, 22, th.body); c.fillStyle = th.muted;
    c.fillText(site, X, RODAPE + 24);
    c.textAlign = 'right';
    c.fillText(`Válida até ${model.validade}  ·  ${ini + i}/${total}`, W - X, RODAPE + 24);
    c.textAlign = 'left';
    const g = c.createLinearGradient(0, 0, W, 0);
    g.addColorStop(0, th.barra[0]); g.addColorStop(0.5, th.barra[1]); g.addColorStop(1, th.barra[2]);
    c.fillStyle = g; c.fillRect(0, H - 8, W, 8);
    c.restore();
    (pcv.__blocos || (pcv.__blocos = [])).push({ nome: 'rodapé', tipo: 'ancora', x: X, y: RODAPE - GAP_TITULO, w: CW, h: GAP_TITULO + 32 });
    if (gradeLigada(opts)) { c.save(); c.setTransform(scale, 0, 0, scale, 0, 0); desenhaGrade(c, pcv.__blocos); c.restore(); }
  });
  return pages;
}

// ───────────── Exportação ─────────────
export function canvasToBlob(cv, type = 'image/png', q = 0.92) {
  return new Promise((res) => cv.toBlob((b) => res(b), type, q));
}
export function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
export async function copyCanvas(cv) {
  const blob = await canvasToBlob(cv, 'image/png');
  if (!navigator.clipboard || typeof window.ClipboardItem === 'undefined') throw new Error('sem suporte');
  await navigator.clipboard.write([new window.ClipboardItem({ 'image/png': blob })]);
}
export async function exportPDF(canvases, name) {
  downloadBlob(await pdfBlob(canvases), name);
}
export async function pdfBlob(canvases) {
  const { jsPDF } = await import('jspdf');
  const pdf = new jsPDF({ orientation: 'portrait', unit: 'px', format: [W, H], hotfixes: ['px_scaling'], compress: true });
  canvases.forEach((cv, i) => {
    if (i > 0) pdf.addPage([W, H], 'portrait');
    pdf.addImage(cv.toDataURL('image/jpeg', 0.9), 'JPEG', 0, 0, W, H, undefined, 'FAST');
  });
  return pdf.output('blob');
}
