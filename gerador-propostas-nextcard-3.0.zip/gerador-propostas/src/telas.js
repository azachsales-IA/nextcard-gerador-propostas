// Telas ilustrativas do sistema Teloos (gestão, PDV, app de mesas e cardápio digital), desenhadas em canvas.
// É uma ilustração: os números são de exemplo e os textos pequenos fazem parte da imagem, como o texto
// na tela de um totem numa foto. Por isso o canvas sai marcado com __ilustracao (fora da regra de texto mínimo).
// Cores da interface do Teloos: azul-marinho da barra lateral, azul de ação, laranja da marca.

const FAM = 'Inter';
const T = {
  navy: '#12265E', navy2: '#0D1D4B', azul: '#3D63E0', azulTxt: '#2F55D4', azulClaro: '#E7ECFD',
  topo1: '#1B4A9C', topo2: '#2F6FC4', laranja: '#FF7A1A', fundo: '#F4F6FB', card: '#FFFFFF',
  tinta: '#14224F', tinta2: '#5D6788', tinta3: '#8C95B0', linha: '#E3E7F0', menu: '#B9C3E2', menuPonto: '#4C5D94',
  agua: '#14B8A6', aguaClara: '#8FE5D8', indigo: '#5B6CF0',
  verde: '#1E9E5A', verdeFundo: '#E2F6EA', vermelho: '#D92D3A', vermelhoFundo: '#FDE8EA', ambar: '#B7791F', ambarFundo: '#FFF4D6',
};

const fnt = (c, peso, tam) => { c.font = `${peso} ${tam}px ${FAM}`; };
function txt(c, t, x, y, peso, tam, cor, align = 'left') { fnt(c, peso, tam); c.fillStyle = cor; c.textAlign = align; c.fillText(t, x, y); c.textAlign = 'left'; }
function cabe(c, t, max) { if (c.measureText(t).width <= max) return t; let s = t; while (s.length > 1 && c.measureText(s + '…').width > max) s = s.slice(0, -1); return s + '…'; }
function rr(c, x, y, w, h, r) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
}
function caixa(c, x, y, w, h, r, fill, sombra) {
  c.save();
  if (sombra) { c.shadowColor = sombra[0]; c.shadowBlur = sombra[1]; c.shadowOffsetY = sombra[2]; }
  rr(c, x, y, w, h, r); c.fillStyle = fill; c.fill(); c.restore();
}
const cartao = (c, x, y, w, h) => caixa(c, x, y, w, h, 10, T.card, ['rgba(20,40,100,0.10)', 12, 3]);
// coluna com ponta de dados arredondada e base reta
function coluna(c, x, base, w, h, cor, r = 3) {
  if (h <= 0) return;
  r = Math.min(r, w / 2, h);
  c.beginPath(); c.moveTo(x, base); c.lineTo(x, base - h + r); c.arcTo(x, base - h, x + r, base - h, r); c.lineTo(x + w - r, base - h); c.arcTo(x + w, base - h, x + w, base - h + r, r); c.lineTo(x + w, base); c.closePath();
  c.fillStyle = cor; c.fill();
}
function ponto(c, x, y, r, cor) { c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fillStyle = cor; c.fill(); }
function estrela(c, x, y, r, cor) {
  c.beginPath();
  for (let i = 0; i < 8; i++) { const a = (i * Math.PI) / 4 - Math.PI / 2, rr2 = i % 2 ? r * 0.38 : r; c.lineTo(x + Math.cos(a) * rr2, y + Math.sin(a) * rr2); }
  c.closePath(); c.fillStyle = cor; c.fill();
}
const iniciais = (nome) => String(nome || 'Restaurante').split(/\s+/).filter((p) => p.length > 2 || /^[A-Z]/.test(p)).slice(0, 2).map((p) => p[0]).join('').toUpperCase() || 'RT';

// ícones de comida simples (miniaturas dos produtos)
function comida(c, tipo, x, y, s) {
  c.save();
  const g = c.createLinearGradient(x, y, x, y + s);
  const cores = { chopp: ['#FFD27A', '#F59E0B'], carne: ['#FDBA8C', '#EA580C'], pizza: ['#FED7AA', '#F97316'], burger: ['#FDE68A', '#D97706'], salada: ['#BBF7D0', '#16A34A'], doce: ['#FBCFE8', '#DB2777'], refri: ['#FECACA', '#DC2626'], cafe: ['#E7D3C0', '#92400E'] }[tipo] || ['#E0E7FF', '#6366F1'];
  g.addColorStop(0, cores[0]); g.addColorStop(1, cores[1]);
  rr(c, x, y, s, s, s * 0.22); c.fillStyle = g; c.fill();
  c.fillStyle = 'rgba(255,255,255,0.92)';
  const cx = x + s / 2, cy = y + s / 2;
  if (tipo === 'chopp' || tipo === 'refri' || tipo === 'cafe') { rr(c, cx - s * 0.16, cy - s * 0.2, s * 0.32, s * 0.42, s * 0.06); c.fill(); if (tipo === 'chopp') { c.beginPath(); c.arc(cx, cy - s * 0.22, s * 0.17, Math.PI, 0); c.fill(); } }
  else if (tipo === 'pizza') { c.beginPath(); c.arc(cx, cy, s * 0.27, 0, Math.PI * 2); c.fill(); c.fillStyle = cores[1]; [[-0.1, -0.08], [0.1, 0.02], [-0.04, 0.12]].forEach(([dx, dy]) => { c.beginPath(); c.arc(cx + dx * s, cy + dy * s, s * 0.05, 0, Math.PI * 2); c.fill(); }); }
  else if (tipo === 'burger') { rr(c, cx - s * 0.26, cy - s * 0.2, s * 0.52, s * 0.14, s * 0.07); c.fill(); rr(c, cx - s * 0.28, cy - s * 0.03, s * 0.56, s * 0.08, s * 0.04); c.fill(); rr(c, cx - s * 0.26, cy + s * 0.08, s * 0.52, s * 0.12, s * 0.06); c.fill(); }
  else { c.beginPath(); c.ellipse(cx, cy, s * 0.28, s * 0.18, -0.3, 0, Math.PI * 2); c.fill(); }
  c.restore();
}

// ───────── Painel de gestão (janela de navegador) ─────────
function dashboard(c, x0, y0, W0, H0, cliente) {
  caixa(c, x0, y0, W0, H0, 18, '#FFFFFF', ['rgba(6,16,60,0.35)', 36, 14]);
  c.save(); rr(c, x0, y0, W0, H0, 18); c.clip();
  // barra do navegador
  c.fillStyle = '#F2F4F9'; c.fillRect(x0, y0, W0, 44);
  ['#FF5F57', '#FEBC2E', '#28C840'].forEach((cor, i) => ponto(c, x0 + 24 + i * 20, y0 + 22, 6, cor));
  caixa(c, x0 + 96, y0 + 9, Math.min(380, W0 * 0.42), 26, 13, '#FFFFFF');
  c.strokeStyle = T.linha; c.lineWidth = 1; rr(c, x0 + 96.5, y0 + 9.5, Math.min(380, W0 * 0.42) - 1, 25, 12.5); c.stroke();
  txt(c, 'app.teloos.com.br/dashboard', x0 + 114, y0 + 27, 400, 12.5, T.tinta3);
  // barra superior azul
  const tg = c.createLinearGradient(x0, 0, x0 + W0, 0); tg.addColorStop(0, T.topo1); tg.addColorStop(1, T.topo2);
  c.fillStyle = tg; c.fillRect(x0, y0 + 44, W0, 36);
  fnt(c, 700, 12); txt(c, cabe(c, String(cliente || 'Restaurante').toUpperCase(), W0 * 0.5), x0 + 20, y0 + 67, 700, 12, '#FFFFFF');
  ponto(c, x0 + W0 - 118, y0 + 62, 11, T.laranja); txt(c, iniciais(cliente), x0 + W0 - 118, y0 + 66, 700, 9.5, '#FFFFFF', 'center');
  txt(c, 'GERÊNCIA', x0 + W0 - 100, y0 + 66, 600, 11, '#FFFFFF');
  // barra lateral
  const SB = 188, sy = y0 + 80, sh = H0 - 80;
  const sg = c.createLinearGradient(0, sy, 0, sy + sh); sg.addColorStop(0, T.navy); sg.addColorStop(1, T.navy2);
  c.fillStyle = sg; c.fillRect(x0, sy, SB, sh);
  ponto(c, x0 + 32, sy + 30, 15, T.laranja); txt(c, iniciais(cliente), x0 + 32, sy + 35, 700, 11, '#FFFFFF', 'center');
  txt(c, 'GERÊNCIA', x0 + 56, sy + 35, 700, 13, '#FFFFFF');
  caixa(c, x0 + 16, sy + 58, SB - 32, 28, 6, 'rgba(255,255,255,0.07)');
  txt(c, 'Pesquisar…', x0 + 28, sy + 76, 400, 11.5, '#8E9AC2');
  const itens = ['Dashboards', 'Cadastros', 'Financeiro', 'Estoque', 'Vendas', 'Delivery', 'Relatórios', 'Suporte'];
  itens.forEach((t, i) => {
    const iy = sy + 104 + i * 34;
    if (iy + 30 > sy + sh - 34) return;
    if (i === 0) { caixa(c, x0 + 12, iy, SB - 24, 30, 8, T.azul); ponto(c, x0 + 28, iy + 15, 3.5, '#FFFFFF'); txt(c, t, x0 + 42, iy + 20, 600, 12.5, '#FFFFFF'); return; }
    ponto(c, x0 + 28, iy + 15, 3, T.menuPonto); txt(c, t, x0 + 42, iy + 20, 500, 12.5, T.menu);
    if (t === 'Suporte') { ponto(c, x0 + SB - 32, iy + 15, 8, '#EF3B4A'); txt(c, '2', x0 + SB - 32, iy + 19, 700, 10, '#FFFFFF', 'center'); }
  });
  c.fillStyle = 'rgba(255,255,255,0.08)'; c.fillRect(x0, sy + sh - 34, SB, 1);
  txt(c, 'Avalie o sistema', x0 + 16, sy + sh - 13, 400, 10.5, '#6D7AA8');
  // área de conteúdo
  const cx0 = x0 + SB, cw = W0 - SB, P = 18;
  c.fillStyle = T.fundo; c.fillRect(cx0, sy, cw, sh);
  caixa(c, cx0 + P, sy + 12, 74, 24, 8, '#FFFFFF'); c.strokeStyle = '#C9D3F0'; c.lineWidth = 1; rr(c, cx0 + P + 0.5, sy + 12.5, 73, 23, 7.5); c.stroke();
  ponto(c, cx0 + P + 14, sy + 24, 3.5, T.azul); txt(c, 'Início', cx0 + P + 24, sy + 28, 600, 11.5, T.azulTxt); txt(c, '×', cx0 + P + 62, sy + 28, 500, 11.5, T.tinta3);
  txt(c, 'Visão de Vendas', cx0 + P, sy + 66, 700, 18, T.tinta);
  const ia = 'Analisar ontem (IA)'; fnt(c, 600, 11.5); const iaw = c.measureText(ia).width + 40;
  caixa(c, cx0 + cw - P - iaw, sy + 46, iaw, 26, 13, T.azulClaro); estrela(c, cx0 + cw - P - iaw + 16, sy + 59, 5.5, T.azul); txt(c, ia, cx0 + cw - P - iaw + 26, sy + 63, 600, 11.5, T.azulTxt);
  // indicadores
  const ky = sy + 80, kh = 68, kw = (cw - 2 * P - 30) / 4;
  const kpis = [['Vendas hoje', 'R$ 3.482,90', '142 pedidos', null], ['Vendas ontem', 'R$ 5.917,40', '231 pedidos', null], ['Últimos 7 dias', 'R$ 38.245,10', null, '+12,4%'], ['Mês', 'R$ 146.380,70', null, '+8,3%']];
  kpis.forEach(([t, v, sub, delta], i) => {
    const kx = cx0 + P + i * (kw + 10);
    cartao(c, kx, ky, kw, kh);
    txt(c, t, kx + 12, ky + 20, 500, 10.5, T.tinta3);
    fnt(c, 700, 16); txt(c, cabe(c, v, kw - 20), kx + 12, ky + 42, 700, 16, T.azulTxt);
    if (sub) txt(c, sub, kx + 12, ky + 58, 400, 10, '#A7AEC6');
    if (delta) { fnt(c, 700, 10); const dw = c.measureText(delta).width + 14; caixa(c, kx + 12, ky + 48, dw, 16, 5, T.verdeFundo); txt(c, delta, kx + 19, ky + 60, 700, 10, T.verde); }
  });
  // gráficos
  const gy = ky + kh + 12, gh = 132, gw = (cw - 2 * P - 10) / 2;
  const g1 = cx0 + P, g2 = g1 + gw + 10;
  cartao(c, g1, gy, gw, gh); cartao(c, g2, gy, gw, gh);
  txt(c, 'Vendas diárias · 30 dias', g1 + 12, gy + 20, 600, 11, T.tinta2);
  txt(c, 'Mensal · 12 meses', g2 + 12, gy + 20, 600, 11, T.tinta2);
  // diária: 30 colunas, pico no fim de semana, o dia de maior venda em destaque
  const dias = Array.from({ length: 30 }, (_, i) => [0.42, 0.46, 0.52, 0.6, 0.86, 1, 0.78][i % 7] * (0.86 + 0.14 * Math.sin(i * 1.7)) * (0.9 + i / 300));
  const maxD = Math.max(...dias), base1 = gy + gh - 26, alt1 = gh - 58;
  const passo1 = (gw - 24) / 30, bw1 = Math.max(3, Math.min(10, passo1 - 3));
  c.fillStyle = T.linha; c.fillRect(g1 + 12, base1, gw - 24, 1);
  dias.forEach((v, i) => coluna(c, g1 + 12 + i * passo1 + (passo1 - bw1) / 2, base1, bw1, (v / maxD) * alt1, v === maxD ? T.agua : T.aguaClara, 2));
  ['01/09', '15/09', '30/09'].forEach((t, i) => txt(c, t, g1 + 12 + [0, 0.5, 1][i] * (gw - 24), base1 + 16, 400, 9.5, '#A3ABC2', ['left', 'center', 'right'][i]));
  // mensal: salão + delivery empilhados, 2 px de respiro entre os segmentos
  const salao = [52, 48, 55, 58, 60, 57, 63, 66, 70, 72, 75, 78], deliv = [18, 20, 22, 21, 24, 26, 27, 29, 31, 33, 35, 38];
  const maxM = Math.max(...salao.map((s, i) => s + deliv[i])), base2 = gy + gh - 26, alt2 = gh - 64;
  const passo2 = (gw - 24) / 12, bw2 = Math.min(18, passo2 - 6);
  c.fillStyle = T.linha; c.fillRect(g2 + 12, base2, gw - 24, 1);
  salao.forEach((s, i) => {
    const bx = g2 + 12 + i * passo2 + (passo2 - bw2) / 2, hs = (s / maxM) * alt2, hd = (deliv[i] / maxM) * alt2;
    coluna(c, bx, base2, bw2, hs, T.agua, 0);
    coluna(c, bx, base2 - hs - 2, bw2, hd - 2, T.indigo, 3);
  });
  ['Out', 'Jan', 'Abr', 'Jul', 'Set'].forEach((t, i) => txt(c, t, g2 + 12 + passo2 * [0, 3, 6, 9, 11][i] + passo2 / 2, base2 + 16, 400, 9.5, '#A3ABC2', 'center'));
  // legenda (duas séries)
  fnt(c, 500, 10); const lx = g2 + gw - 12 - c.measureText('Delivery').width - 70 - c.measureText('Salão').width;
  ponto(c, lx, gy + 16, 4, T.agua); txt(c, 'Salão', lx + 9, gy + 20, 500, 10, T.tinta2);
  const lx2 = lx + 9 + c.measureText('Salão').width + 14; fnt(c, 500, 10);
  ponto(c, lx2, gy + 16, 4, T.indigo); txt(c, 'Delivery', lx2 + 9, gy + 20, 500, 10, T.tinta2);
  // linha de baixo: mais vendidos, ranking de grupos, visão geral
  const by = gy + gh + 12, bh = H0 - (by - y0) - 14, bw = (cw - 2 * P - 20) / 3;
  const b1 = cx0 + P, b2 = b1 + bw + 10, b3 = b2 + bw + 10;
  [b1, b2, b3].forEach((bx) => cartao(c, bx, by, bw, bh));
  txt(c, 'Mais vendidos', b1 + 12, by + 20, 700, 11, T.tinta);
  [['chopp', 'Chopp 500 ml', '498 un.'], ['carne', 'Picanha na chapa', '312 un.'], ['pizza', 'Pizza calabresa', '254 un.']].forEach(([tipo, n, q], i) => {
    const iy = by + 30 + i * 26; if (iy + 22 > by + bh) return;
    comida(c, tipo, b1 + 12, iy, 22);
    fnt(c, 600, 10.5); txt(c, cabe(c, n, bw - 110), b1 + 42, iy + 15, 600, 10.5, T.tinta);
    txt(c, q, b1 + bw - 12, iy + 15, 500, 10, T.tinta3, 'right');
  });
  txt(c, 'Ranking de grupos', b2 + 12, by + 20, 700, 11, T.tinta);
  [['Bebidas', 270], ['Pratos', 186], ['Pizzas', 128], ['Sobremesas', 64]].forEach(([n, v], i) => {
    const iy = by + 36 + i * 19; if (iy + 12 > by + bh) return;
    txt(c, n, b2 + 12, iy, 500, 10, T.tinta2); txt(c, String(v), b2 + bw - 12, iy, 500, 10, T.tinta3, 'right');
    caixa(c, b2 + 12, iy + 4, bw - 24, 5, 2.5, '#E8ECF7'); caixa(c, b2 + 12, iy + 4, (bw - 24) * (v / 270), 5, 2.5, T.azul);
  });
  txt(c, 'Visão geral', b3 + 12, by + 20, 700, 11, T.tinta);
  [['Pedidos delivery', '87', '#FFC21A', '#4A3300'], ['Itens lançados', '1.366', '#1DB954', '#FFFFFF'], ['Pessoas atendidas', '562', '#FF5A5F', '#FFFFFF'], ['Ticket médio', 'R$ 64,20', '#19B5D8', '#FFFFFF']].forEach(([n, v, cor, tc], i) => {
    const iy = by + 36 + i * 19; if (iy + 12 > by + bh) return;
    fnt(c, 500, 10); txt(c, cabe(c, n, bw - 96), b3 + 12, iy, 500, 10, T.tinta2);
    fnt(c, 700, 9.5); const vw = c.measureText(v).width + 12;
    caixa(c, b3 + bw - 12 - vw, iy - 10, vw, 14, 4, cor); txt(c, v, b3 + bw - 12 - vw / 2, iy + 1, 700, 9.5, tc, 'center');
  });
  c.restore();
}

// ───────── Celular com o app de mesas (garçom) ─────────
function celular(c, x, y, w, h, tela) {
  caixa(c, x, y, w, h, w * 0.16, '#0E1426', ['rgba(6,16,60,0.45)', 28, 12]);
  const m = w * 0.05, sx = x + m, sy = y + m, sw = w - 2 * m, sh = h - 2 * m;
  c.save(); rr(c, sx, sy, sw, sh, w * 0.12); c.clip();
  c.fillStyle = '#FFFFFF'; c.fillRect(sx, sy, sw, sh);
  tela(c, sx, sy, sw, sh);
  c.restore();
  caixa(c, x + w / 2 - w * 0.14, y + m + 4, w * 0.28, 8, 4, '#0E1426');
}
function telaMesas(c, x, y, w, h) {
  const tg = c.createLinearGradient(x, y, x + w, y); tg.addColorStop(0, T.azul); tg.addColorStop(1, T.topo2);
  c.fillStyle = tg; c.fillRect(x, y, w, 58);
  txt(c, 'Mesas', x + 12, y + 38, 700, 14, '#FFFFFF'); txt(c, 'Salão principal', x + 12, y + 52, 400, 9.5, 'rgba(255,255,255,0.8)');
  const est = { l: ['#E2F6EA', T.verde], o: ['#FDE8EA', T.vermelho], c: ['#FFF4D6', T.ambar] };
  const mapa = 'olloclolooclolo';
  const cols = 3, g = 6, tw = (w - 24 - (cols - 1) * g) / cols, th = 36;
  for (let i = 0; i < 15; i++) {
    const r = Math.floor(i / cols), k = i % cols, tx = x + 12 + k * (tw + g), ty = y + 70 + r * (th + g);
    if (ty + th > y + h - 44) break;
    const [bg, fg] = est[mapa[i]];
    caixa(c, tx, ty, tw, th, 7, bg);
    txt(c, String(i + 1).padStart(2, '0'), tx + tw / 2, ty + 17, 700, 11, fg, 'center');
    txt(c, { l: 'livre', o: 'ocupada', c: 'conta' }[mapa[i]], tx + tw / 2, ty + 29, 500, 8, fg, 'center');
  }
  caixa(c, x + 12, y + h - 38, w - 24, 28, 9, T.laranja);
  txt(c, 'Lançar pedido', x + w / 2, y + h - 20, 700, 11, '#FFFFFF', 'center');
}
function telaCardapio(c, x, y, w, h, cliente) {
  c.fillStyle = T.fundo; c.fillRect(x, y, w, h);
  const tg = c.createLinearGradient(x, y, x + w, y); tg.addColorStop(0, T.navy); tg.addColorStop(1, T.azul);
  c.fillStyle = tg; c.fillRect(x, y, w, 64);
  txt(c, 'Cardápio digital', x + 14, y + 38, 700, 14, '#FFFFFF');
  fnt(c, 400, 9.5); txt(c, cabe(c, String(cliente || ''), w - 28), x + 14, y + 53, 400, 9.5, 'rgba(255,255,255,0.8)');
  let cx = x + 14;
  ['Pratos', 'Bebidas', 'Doces'].forEach((t, i) => { fnt(c, 600, 10); const tw = c.measureText(t).width + 18; caixa(c, cx, y + 74, tw, 22, 11, i ? '#FFFFFF' : T.azul); txt(c, t, cx + 9, y + 89, 600, 10, i ? T.tinta2 : '#FFFFFF'); cx += tw + 6; });
  [['burger', 'Burger', 'R$ 38,90'], ['salada', 'Salada', 'R$ 32,50'], ['pizza', 'Pizza', 'R$ 54,00'], ['doce', 'Petit gâteau', 'R$ 24,90']].forEach(([tipo, n, p], i) => {
    const iy = y + 108 + i * 62; if (iy + 54 > y + h - 50) return;
    cartao(c, x + 10, iy, w - 20, 54);
    comida(c, tipo, x + 18, iy + 10, 34);
    fnt(c, 600, 10.5); txt(c, cabe(c, n, w - 96), x + 60, iy + 24, 600, 10.5, T.tinta);
    txt(c, p, x + 60, iy + 41, 700, 10.5, T.azulTxt);
    ponto(c, x + w - 26, iy + 27, 10, T.laranja); txt(c, '+', x + w - 26, iy + 32, 700, 13, '#FFFFFF', 'center');
  });
  caixa(c, x + 10, y + h - 44, w - 20, 32, 10, T.navy);
  txt(c, 'Ver pedido', x + 22, y + h - 23, 600, 10.5, '#FFFFFF'); txt(c, 'R$ 125,40', x + w - 22, y + h - 23, 700, 10.5, '#FFFFFF', 'right');
}

// ───────── PDV (frente de caixa) ─────────
function pdv(c, x0, y0, W0, H0) {
  caixa(c, x0, y0, W0, H0, 16, '#FFFFFF', ['rgba(6,16,60,0.30)', 30, 12]);
  c.save(); rr(c, x0, y0, W0, H0, 16); c.clip();
  c.fillStyle = '#F2F4F9'; c.fillRect(x0, y0, W0, 40);
  ['#FF5F57', '#FEBC2E', '#28C840'].forEach((cor, i) => ponto(c, x0 + 22 + i * 18, y0 + 20, 5.5, cor));
  txt(c, 'Teloos PDV · Caixa 01', x0 + W0 / 2, y0 + 25, 600, 12, T.tinta2, 'center');
  const tg = c.createLinearGradient(x0, 0, x0 + W0, 0); tg.addColorStop(0, T.topo1); tg.addColorStop(1, T.topo2);
  c.fillStyle = tg; c.fillRect(x0, y0 + 40, W0, 44);
  caixa(c, x0 + 16, y0 + 50, W0 * 0.42, 24, 12, 'rgba(255,255,255,0.16)');
  txt(c, 'Buscar produto ou código', x0 + 30, y0 + 66, 400, 11, 'rgba(255,255,255,0.85)');
  caixa(c, x0 + W0 - 200, y0 + 50, 84, 24, 12, T.laranja); txt(c, 'Mesa 12', x0 + W0 - 158, y0 + 66, 700, 11, '#FFFFFF', 'center');
  txt(c, 'Consumidor', x0 + W0 - 20, y0 + 66, 600, 11, '#FFFFFF', 'right');
  const top = y0 + 84, alt = H0 - 84;
  // categorias
  c.fillStyle = T.navy; c.fillRect(x0, top, 124, alt);
  ['Lanches', 'Pratos', 'Pizzas', 'Bebidas', 'Doces', 'Combos'].forEach((t, i) => {
    const iy = top + 14 + i * 40; if (iy + 32 > top + alt) return;
    if (i === 3) caixa(c, x0 + 10, iy, 104, 32, 8, T.azul);
    txt(c, t, x0 + 24, iy + 21, i === 3 ? 700 : 500, 11.5, i === 3 ? '#FFFFFF' : T.menu);
  });
  // produtos
  const px0 = x0 + 124, cartW = Math.max(190, W0 * 0.3), pw = W0 - 124 - cartW;
  c.fillStyle = T.fundo; c.fillRect(px0, top, pw, alt);
  const prods = [['chopp', 'Chopp 500 ml', 'R$ 14,90'], ['refri', 'Refrigerante', 'R$ 7,50'], ['cafe', 'Café espresso', 'R$ 6,00'], ['chopp', 'Chopp 1 L', 'R$ 26,90'], ['refri', 'Suco natural', 'R$ 11,00'], ['cafe', 'Cappuccino', 'R$ 9,50'], ['chopp', 'Caipirinha', 'R$ 22,00'], ['refri', 'Água com gás', 'R$ 5,50'], ['doce', 'Milk-shake', 'R$ 18,90']];
  const cols = 3, g = 10, tw = (pw - 28 - (cols - 1) * g) / cols, th = Math.min(104, (alt - 28 - 2 * g) / 3);
  prods.forEach(([tipo, n, p], i) => {
    const r = Math.floor(i / cols), k = i % cols, tx = px0 + 14 + k * (tw + g), ty = top + 14 + r * (th + g);
    if (ty + th > top + alt - 6) return;
    cartao(c, tx, ty, tw, th);
    const ic = Math.min(48, th - 52);
    comida(c, tipo, tx + tw / 2 - ic / 2, ty + 8, ic);
    fnt(c, 600, 10.5); txt(c, cabe(c, n, tw - 16), tx + tw / 2, ty + th - 26, 600, 10.5, T.tinta, 'center');
    txt(c, p, tx + tw / 2, ty + th - 10, 700, 10.5, T.azulTxt, 'center');
  });
  // pedido
  const kx = px0 + pw;
  c.fillStyle = '#FFFFFF'; c.fillRect(kx, top, cartW, alt); c.fillStyle = T.linha; c.fillRect(kx, top, 1, alt);
  txt(c, 'Pedido · Mesa 12', kx + 16, top + 26, 700, 12.5, T.tinta);
  const linhas = [['2×', 'Chopp 500 ml', 'R$ 29,80'], ['1×', 'Picanha na chapa', 'R$ 89,90'], ['1×', 'Pizza calabresa', 'R$ 54,00'], ['2×', 'Refrigerante', 'R$ 15,00']];
  linhas.forEach(([q, n, v], i) => {
    const iy = top + 52 + i * 26;
    txt(c, q, kx + 16, iy, 700, 10.5, T.azulTxt); fnt(c, 500, 10.5); txt(c, cabe(c, n, cartW - 120), kx + 40, iy, 500, 10.5, T.tinta2); txt(c, v, kx + cartW - 16, iy, 600, 10.5, T.tinta, 'right');
  });
  const ry = top + 52 + linhas.length * 26 + 4;
  c.fillStyle = T.linha; c.fillRect(kx + 16, ry, cartW - 32, 1);
  txt(c, 'Serviço (10%)', kx + 16, ry + 20, 400, 10.5, T.tinta3); txt(c, 'R$ 18,87', kx + cartW - 16, ry + 20, 500, 10.5, T.tinta2, 'right');
  txt(c, 'Total', kx + 16, ry + 46, 700, 13, T.tinta); txt(c, 'R$ 207,57', kx + cartW - 16, ry + 46, 800, 15, T.azulTxt, 'right');
  const by = top + alt - 52;
  caixa(c, kx + 16, by, (cartW - 40) / 2, 34, 9, T.verde); txt(c, 'Pagar', kx + 16 + (cartW - 40) / 4, by + 22, 700, 11.5, '#FFFFFF', 'center');
  caixa(c, kx + 24 + (cartW - 40) / 2, by, (cartW - 40) / 2, 34, 9, T.azul); txt(c, 'Cozinha', kx + 24 + (cartW - 40) * 0.75, by + 22, 700, 11.5, '#FFFFFF', 'center');
  c.restore();
}

// selo flutuante "+23 pedidos realizados hoje"
function selo(c, x, y, w, h) {
  caixa(c, x, y, w, h, 16, '#FFFFFF', ['rgba(6,16,60,0.28)', 24, 8]);
  ponto(c, x + 32, y + h / 2, 15, T.verdeFundo); ponto(c, x + 32, y + h / 2, 6, '#22C55E');
  txt(c, '+23 pedidos', x + 58, y + h / 2 - 2, 800, 16, T.tinta);
  txt(c, 'realizados hoje', x + 58, y + h / 2 + 15, 500, 11.5, T.tinta3);
}

// brilho azul elíptico atrás das telas (tema escuro): some antes da borda, sem desenhar um retângulo
function brilho(c, DW, base, forca) {
  c.save(); c.translate(DW / 2, base / 2); c.scale(DW / base, 1);
  const gl = c.createRadialGradient(0, 0, 0, 0, 0, base / 2);
  gl.addColorStop(0, `rgba(69,102,233,${forca})`); gl.addColorStop(0.6, `rgba(69,102,233,${forca * 0.35})`); gl.addColorStop(1, 'rgba(69,102,233,0)');
  c.fillStyle = gl; c.beginPath(); c.arc(0, 0, base / 2, 0, Math.PI * 2); c.fill(); c.restore();
}

// Composição. variante 'capa': gestão + selo + celular com as mesas (imagem e capa do PDF).
// variante 'detalhe': PDV + celular com o cardápio digital (seção do PDF).
// Proporção fixa (nunca estica): a ilustração ocupa a largura toda; se faltar altura, o painel é recortado
// embaixo com esmaecimento (como um print que continua) e o celular e o selo ficam inteiros.
export const TELAS_DIM = { capa: [952, 560], detalhe: [952, 460] };
// fim dos gráficos do painel (unidades do desenho): abaixo disso o painel pode ser recortado
const JANELA_Y = 42; // topo da janela do navegador (acima fica o rótulo das telas)
const FIM_GRAFICOS = JANELA_Y + 80 + 160 + 132;
// menor altura (em unidades do desenho) em que o painel ainda mostra os gráficos inteiros
export const TELAS_VIS_MIN = FIM_GRAFICOS + 34;
export function desenhaTelas(ctx, variante, x, y, w, h, { cliente, escuro } = {}) {
  const k = (ctx.getTransform && ctx.getTransform().a) || 1;
  const [DW, DH] = TELAS_DIM[variante] || TELAS_DIM.capa;
  const s = w / DW;
  const vis = Math.min(DH, h / s); // altura visível, em unidades do desenho
  const dy = (h - vis * s) / 2;     // sobra de altura: centraliza
  const B = 48; // sangria: as sombras se apagam fora da caixa, sem corte reto na borda
  const off = document.createElement('canvas');
  off.__ilustracao = true; // textos da ilustração ficam fora da regra de texto mínimo
  off.width = Math.max(1, Math.round((DW + 2 * B) * s * k)); off.height = Math.max(1, Math.round((vis + 2 * B) * s * k));
  const c = off.getContext('2d');
  c.scale(k * s, k * s); c.translate(B, B);
  const esmaece = () => {
    if (vis >= DH - 1) return;
    // recorte com esmaecimento: o painel some suavemente nos últimos 120 do espaço visível
    c.save(); c.globalCompositeOperation = 'destination-out';
    // o esmaecimento começa depois dos gráficos (a linha de baixo do painel é que some)
    const ini = variante === 'detalhe' ? vis - 100 : Math.max(Math.min(FIM_GRAFICOS + 8, vis - 24), vis - 120);
    const g = c.createLinearGradient(0, ini, 0, vis + 1);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,1)');
    c.fillStyle = g; c.fillRect(-B, ini, DW + 2 * B, vis - ini + B + 2); c.restore();
  };
  if (variante === 'detalhe') {
    const fw = 196;
    if (escuro) brilho(c, DW, vis, 0.35);
    pdv(c, 8, 16, DW - fw - 8, DH - 40);
    esmaece();
    const PH = DH - 14, e = Math.min(1, (vis - 12) / PH); // celular em escala uniforme
    c.save(); c.translate(DW - 6 - fw * e, vis - 6 - PH * e); c.scale(e, e);
    celular(c, 0, 0, fw, PH, (cc, sx, sy, sw, sh) => telaCardapio(cc, sx, sy, sw, sh, cliente));
    c.restore();
  } else {
    const winW = DW - 96, fw = 150;
    if (escuro) brilho(c, DW, vis, 0.45);
    dashboard(c, 8, JANELA_Y, winW - 8, 506, cliente);
    esmaece();
    selo(c, winW - 168, JANELA_Y - 28, 216, 62);
    const PH = 300, e = Math.min(1, (vis - 110) / PH); // celular em escala uniforme, sempre inteiro
    c.save(); c.translate(DW - 4 - fw * e, vis - 14 - PH * e); c.scale(e, e);
    celular(c, 0, 0, fw, PH, telaMesas);
    c.restore();
  }
  ctx.drawImage(off, x - B * s, y + dy - B * s, (DW + 2 * B) * s, (vis + 2 * B) * s);
}
