// Cliente da API corporativa. A fonte oficial de dados é o servidor; o navegador guarda só preferências e cache.
// NX_MODE=local (definido no build) mantém o modo antigo, sem servidor, apenas para o harness e testes visuais.
export const REMOTO = process.env.NX_MODE !== 'local';

// Contexto da sessão, lido pelos componentes sem repassar props por toda a árvore
export const ctx = { user: null, alcadaPct: 0, kommo: false, configVersion: null, aprovacoesPendentes: 0 };
export const tem = (...roles) => !!ctx.user && roles.some((r) => (ctx.user.roles || []).includes(r));

export class ApiError extends Error {
  constructor(status, body) { super((body && body.mensagem) || 'Falha de comunicação com o servidor'); this.status = status; this.code = body && body.erro; this.body = body || {}; }
}
let aoExpirar = null;
export const onSessaoExpirada = (fn) => { aoExpirar = fn; };

async function call(method, path, body, { raw, tipo } = {}) {
  const headers = { 'x-nx': '1' };
  if (body !== undefined) headers['Content-Type'] = raw ? (tipo || 'application/octet-stream') : 'application/json';
  let res;
  try { res = await fetch(path, { method, headers, credentials: 'same-origin', body: body === undefined ? undefined : raw ? body : JSON.stringify(body) }); }
  catch (e) { throw new ApiError(0, { erro: 'rede', mensagem: 'Sem conexão com o servidor' }); }
  const ct = res.headers.get('content-type') || '';
  if (!ct.includes('json')) {
    if (res.ok) return res.blob();
    throw new ApiError(res.status, { erro: 'servidor', mensagem: res.status === 404 ? 'Servidor da aplicação não encontrado' : `Servidor respondeu ${res.status}` });
  }
  const j = await res.json();
  if (!res.ok) {
    if (res.status === 401 && j.erro === 'sessao' && aoExpirar) aoExpirar();
    throw new ApiError(res.status, j);
  }
  return j;
}
const get = (p) => call('GET', p), post = (p, b) => call('POST', p, b ?? {}), put = (p, b, o) => call('PUT', p, b, o), patch = (p, b) => call('PATCH', p, b), del = (p) => call('DELETE', p);

export async function carregarSessao() {
  const me = await get('/api/me');
  Object.assign(ctx, { user: me.user, alcadaPct: me.alcadaPct, kommo: me.kommo, configVersion: me.configVersion, aprovacoesPendentes: me.aprovacoesPendentes });
  return me;
}
export const login = (email, senha) => post('/api/login', { email, senha });
export async function logout() { try { await post('/api/logout'); } finally { ctx.user = null; } }
export const trocarSenha = (atual, nova) => post('/api/me/senha', { atual, nova });
export const salvarPerfil = (d) => patch('/api/me', d);

// Configuração
export const getConfig = () => get('/api/config');
const cacheVersoes = new Map();
export async function getConfigVersao(v) {
  if (!cacheVersoes.has(v)) cacheVersoes.set(v, (await get('/api/config/versions/' + v)).data); // versão publicada é imutável: pode ficar em cache
  return cacheVersoes.get(v);
}
export const listConfigVersoes = () => get('/api/config/versions');
export const putConfig = (baseVersion, data, nota) => put('/api/config', { baseVersion, data, nota });
// campos que não pertencem à configuração oficial (vivem em tabelas próprias ou são derivados da sessão)
export function configLimpa(c) { const { responsaveis, proximoNumero, version, ...resto } = c || {}; return resto; }

export const getFotos = () => get('/api/fotos');
export const putFoto = (id, data) => put('/api/fotos/' + encodeURIComponent(id), { data });
export const delFoto = (id) => del('/api/fotos/' + encodeURIComponent(id));

// Usuários, alçadas, aprovações, numeração
export const listUsers = () => get('/api/users');
export const criarUser = (d) => post('/api/users', d);
export const alterarUser = (id, d) => patch('/api/users/' + id, d);
export const listAlcadas = () => get('/api/alcadas');
export const concederAlcada = (d) => post('/api/alcadas', d);
export const revogarAlcada = (id) => post(`/api/alcadas/${id}/revogar`);
export const listAprovacoes = () => get('/api/aprovacoes');
export const decidirAprovacao = (id, aprovar, resposta) => post(`/api/aprovacoes/${id}/decidir`, { aprovar, resposta });
export const getSequencia = () => get('/api/sequencia');
export const putSequencia = (proximo) => put('/api/sequencia', { proximo });
export const getAudit = () => get('/api/audit');
export const getDashboard = () => get('/api/dashboard');
export const enviarImportacao = (payload, origem) => post('/api/importacoes', { payload, origem });
export const listImportacoes = () => get('/api/importacoes');
export const statusImportacao = (id, status) => post(`/api/importacoes/${id}/status`, { status });
export const importarPropostas = (propostas) => post('/api/propostas-importar', { propostas });

// Propostas
export const listPropostas = () => get('/api/propostas');
export const analisar = (data) => post('/api/analise', { data });
export const emitir = (id, data) => post(`/api/propostas/${id}/emitir`, { data });
export const pedirAprovacao = (id, data, justificativa) => post(`/api/propostas/${id}/aprovacao`, { data, justificativa });
export const excluirProposta = (id) => del('/api/propostas/' + id);
export const situacao = (id, d) => patch(`/api/propostas/${id}/situacao`, d);
export const listVersoes = (id) => get(`/api/propostas/${id}/versoes`);
export const getVersao = (id, v) => get(`/api/propostas/${id}/versoes/${v}`);
export const putPdf = (id, v, blob) => put(`/api/propostas/${id}/versoes/${v}/pdf`, blob, { raw: true, tipo: 'application/pdf' });
export const getPdf = (id, v) => get(`/api/propostas/${id}/versoes/${v}/pdf`);
export const anexarKommo = (id, v, leadId, leadNome) => post(`/api/propostas/${id}/versoes/${v}/kommo`, { leadId, leadNome });
export const buscarLeads = (q) => get('/api/kommo/leads?q=' + encodeURIComponent(q));
export const detalheLead = (id) => get('/api/kommo/leads/' + id);

// Salvamento de rascunhos: uma fila por proposta, sempre com a versão mais recente e controle de revisão.
const fila = new Map(); // id → { rev, enviando, pendente, ouvintes }
export function registrarRev(id, rev) { const f = fila.get(id) || {}; fila.set(id, { ...f, rev }); }
export function salvarRascunho(prop, aoMudar) {
  const { _srv, tocada, ...data } = prop;
  const f = fila.get(prop.id) || {};
  f.pendente = data; f.aoMudar = aoMudar || f.aoMudar;
  fila.set(prop.id, f);
  if (!f.enviando) drenar(prop.id);
}
async function drenar(id) {
  const f = fila.get(id);
  if (!f || !f.pendente) return;
  const data = f.pendente; f.pendente = null; f.enviando = true;
  f.aoMudar && f.aoMudar('salvando');
  try {
    let r;
    try { r = await put('/api/propostas/' + id, { data, rev: f.rev }); }
    catch (e) {
      if (e.status === 409 && e.code === 'conflito') r = await put('/api/propostas/' + id, { data, rev: e.body.rev }); // mesma pessoa em duas abas: vale a última edição
      else throw e;
    }
    f.rev = r.rev; f.enviando = false;
    if (f.pendente) return drenar(id);
    f.aoMudar && f.aoMudar('salvo');
  } catch (e) {
    f.enviando = false;
    if (!f.pendente) f.pendente = data; // tenta de novo na próxima alteração ou em repetir()
    f.aoMudar && f.aoMudar('erro', e);
  }
}
export const repetirRascunho = (id) => drenar(id);
export const temPendencia = () => [...fila.values()].some((f) => f.enviando || f.pendente);
