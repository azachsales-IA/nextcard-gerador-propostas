// Criação e manipulação de propostas (sem React).
import { uid, novoId } from './store.js';
import { totemPreco, totemCodigo, totemResumo, familias, fmtDataCompacta, isNil, comandaFaixa } from './core.js';

export const TIPOS_SOLUCAO = {
  totem: { brand: 'nextcard', nome: 'Totem de autoatendimento' },
  catraca: { brand: 'nextcard', nome: 'Catracas + comandas' },
  comanda: { brand: 'nextcard', nome: 'Comandas eletrônicas' },
  livre: { brand: 'nextcard', nome: 'Projeto sob medida' },
  teloos: { brand: 'teloos', nome: 'Sistema Teloos' },
};

export function novaProposta(brand, cfg, tipo, perfil) {
  const now = new Date().toISOString();
  const E = cfg[brand].empresa;
  const p = {
    id: novoId(),
    empresa: brand,
    tipoSolucao: tipo || (brand === 'teloos' ? 'teloos' : 'livre'),
    modalidade: cfg[brand].modalidades[0].id,
    etapa: 'rascunho',
    criadaEm: now,
    atualizadaEm: now,
    emitidaEm: null,
    numero: null,
    versao: 0,
    cliente: { empresa: '', contato: '', telefone: '', email: '', cidade: '', tipo: 'PJ', segmento: '', logo: null },
    nome: '',
    responsavel: perfil?.nome || '',
    validadeOpcao: E.validadePadrao || '7c',
    itens: [],
    pagamento: {
      condicoes: brand === 'nextcard' ? cfg.nextcard.condicoes.filter((c) => c.padrao).map((c) => c.id) : [],
      overrides: {},
      entradas: {},
      frete: 'FOB',
      periodicidades: brand === 'teloos' ? cfg.teloos.periodicidades.filter((c) => c.padrao).map((c) => c.id) : [],
      destaque: brand === 'teloos' ? 'mensal' : (cfg.nextcard.condicoes.filter((c) => c.padrao && c.tipo !== 'avista').slice(-1)[0]?.id || null),
    },
    teloos: { plano: null, cupom: 0, implantacao: 'padrao' },
    inclusos: [],
    inclusosAuto: true,
    observacoes: '',
    usarFoto: true,
    historico: [],
  };
  if (brand === 'teloos') {
    p.itens.push(linhaImplantacao(cfg.teloos.implantacao[0]));
  } else {
    const N = cfg.nextcard;
    const cat = (tipoC, modelo, variante) => N.catracas.find((c) => c.tipo === tipoC && c.modelo === modelo && c.variante === variante) || N.catracas.find((c) => c.tipo === tipoC);
    const cmd = (id) => N.comandas.find((c) => c.id === id) || N.comandas[0];
    if (tipo === 'totem') p.itens.push(linhaTotem({ modelo: 'NX24-V', ...N.totem.referencia }, cfg, p, 1));
    if (tipo === 'catraca') {
      p.itens.push(linhaCatraca(cat('Dispensadora', 'C120', 'Catraca acoplada'), 1));
      p.itens.push(linhaCatraca(cat('Receptora', 'R120', 'Catraca acoplada'), 1));
      p.itens.push(linhaComanda(cmd('CMD14x8-RFI'), 200));
      if (N.servicos[0]) p.itens.push(linhaServico(N.servicos[0]));
    }
    if (tipo === 'comanda') p.itens.push(linhaComanda(cmd('CMD14x8-RFI'), 100));
    p.pagamento.frete = freteSugerido(p);
  }
  p.inclusos = autoInclusos(p, cfg);
  return p;
}

export function fatorModalidade(prop, cfg) {
  const m = (cfg.nextcard.modalidades || []).find((x) => x.id === prop.modalidade);
  return m && !isNil(m.fatorTotem) ? m.fatorTotem : 1;
}

export function linhaTotem(sel, cfg, prop, qtd = 1) {
  const T = cfg.nextcard.totem;
  const r = totemResumo(T, sel);
  const cheio = totemPreco(T, sel);
  const f = fatorModalidade(prop, cfg);
  return {
    uid: uid(), kind: 'totem', refId: sel.modelo, qtd,
    nome: r.modelo.nome, spec: r.spec, codigo: totemCodigo(T, sel),
    tabela: Math.round(cheio * f), tabelaCheia: cheio, preco: null, piso: 'tabela', config: { ...sel },
  };
}
export const tipoCatraca = (t) => (t === 'Dispensadora e receptora' ? 'expedidora e receptora' : t === 'Dispensadora' ? 'expedidora' : 'receptora');
export function linhaCatraca(c, qtd = 1) {
  return { uid: uid(), kind: 'catraca', refId: c.id, qtd, nome: `Catraca ${tipoCatraca(c.tipo)} Tecnibra ${c.modelo}`, spec: [c.variante, c.compat ? 'comandas: ' + c.compat.charAt(0).toLowerCase() + c.compat.slice(1) : ''].filter(Boolean).join(' · '), codigo: c.codigo, tabela: c.cents, preco: null, piso: 'tabela' };
}
export function linhaComanda(c, qtd = 30) {
  const tech = { SIM: 'personalizada', ANT: 'antifurto', RFI: 'RFID', MIF: 'Mifare', REA: 'RFID + antifurto', MEA: 'Mifare + antifurto' }[c.tech] || '';
  return { uid: uid(), kind: 'comanda', refId: c.id, qtd, nome: `Comanda eletrônica ${c.tamanho} · ${tech}`, spec: `Personalizada · ABS + PVC · ${c.dimensao}`, codigo: c.codigoBase, tiers: c.tiers.map((t) => ({ ...t })), preco: null, piso: 'tabela' };
}
export function linhaServico(s, qtd = 1) {
  return { uid: uid(), kind: 'servico', refId: s.id, qtd, nome: s.nome, spec: s.spec || '', codigo: s.codigo, tabela: s.cents, preco: null, piso: 'zero' };
}
export function linhaAvulsa(nome, spec, cents, qtd = 1) {
  return { uid: uid(), kind: 'avulso', refId: null, qtd, nome: nome || 'Item avulso', spec: spec || '', codigo: '', tabela: cents ?? 0, preco: null, piso: 'zero' };
}
export function linhaFrete(cents) {
  return { uid: 'frete', kind: 'frete', refId: 'frete', qtd: 1, nome: 'Frete', spec: 'Entrega no endereço do cliente', codigo: '', tabela: cents ?? 0, preco: null, piso: 'zero' };
}
// Teloos
export function linhaPlano(pl, cupom) {
  const t = Math.round(pl.cents * (1 - (cupom || 0) / 100));
  return { uid: uid(), kind: 'plano', refId: pl.id, qtd: 1, nome: pl.nomeCaps, spec: pl.recursos.slice(0, 4).join(' · '), codigo: '', tabela: t, tabelaCheia: pl.cents, preco: null, piso: 'tabela' };
}
export function linhaAdicional(a, cupom, qtd = 1) {
  const t = Math.round((a.cents ?? 0) * (1 - (cupom || 0) / 100));
  return { uid: uid(), kind: 'adicional', refId: a.id, qtd, nome: a.nome, spec: 'Adicional mensal', codigo: '', tabela: t, tabelaCheia: a.cents ?? 0, preco: null, piso: 'zero' };
}
export function linhaImplantacao(imp) {
  return { uid: 'implantacao', kind: 'implantacao', refId: imp.id, qtd: 1, nome: 'Treinamento e implantação', spec: imp.id === 'padrao' ? 'Pagamento à vista' : imp.nome, codigo: '', tabela: imp.cents, preco: null, piso: 'zero' };
}

// Reaplica cupom do consultor nas linhas mensais (Teloos)
export function aplicaCupom(itens, cupom) {
  return itens.map((l) => {
    if (l.kind !== 'plano' && l.kind !== 'adicional') return l;
    const t = Math.round((l.tabelaCheia ?? l.tabela) * (1 - (cupom || 0) / 100));
    const preco = !isNil(l.preco) && l.piso === 'tabela' && l.preco < t ? null : l.preco;
    return { ...l, tabela: t, preco };
  });
}

// Reaplica fator de modalidade nas linhas de totem (NEXTCARD)
export function aplicaModalidade(prop, cfg) {
  const f = fatorModalidade(prop, cfg);
  return prop.itens.map((l) => {
    if (l.kind !== 'totem') return l;
    const cheio = l.tabelaCheia ?? l.tabela;
    const t = Math.round(cheio * f);
    const preco = !isNil(l.preco) && l.preco < t ? null : l.preco;
    return { ...l, tabela: t, preco };
  });
}

export function autoInclusos(prop, cfg) {
  if (prop.empresa === 'teloos') {
    const pl = cfg.teloos.planos.find((p) => p.id === prop.teloos?.plano);
    const r = pl ? pl.recursos : [];
    const pick = r.filter((x) => /implanta|suporte|integra/i.test(x));
    return [...new Set([...pick, ...(cfg.teloos.inclusosExtras || [])])].slice(0, 6);
  }
  const f = familias(prop.itens);
  const I = cfg.nextcard.inclusos;
  const out = [];
  const totens = prop.itens.filter((l) => l.kind === 'totem');
  if (f.has('servico') && (f.has('catraca') || f.has('totem'))) out.push(...(I.servico || []));
  if (totens.length) {
    const base = [...(I.totem || [])];
    const extras = [];
    if (totens.some((l) => l.config?.pinpad && l.config.pinpad !== 'none')) extras.push('Acompanha pinpad Gertec PPC 930');
    if (totens.some((l) => l.config?.impressora && l.config.impressora !== 'none')) extras.push('Acompanha impressora térmica Elgin i9');
    if (totens.some((l) => l.config?.adesivagem === 'sim')) extras.push('Adesivagem personalizada com a sua marca');
    out.push(base[0], base[1], ...extras, ...base.slice(2));
  }
  if (f.has('catraca')) out.push(...(I.catraca || []));
  if (f.has('comanda')) out.push(...(I.comanda || []));
  return [...new Set(out.filter(Boolean))].slice(0, 6);
}

export function freteSugerido(prop) {
  const f = familias(prop.itens);
  if (f.has('catraca')) return 'CIF';
  return 'FOB';
}

export function nomeSugerido(prop, cfg) {
  if (prop.empresa === 'teloos') {
    const pl = cfg.teloos.planos.find((p) => p.id === prop.teloos?.plano);
    return pl ? `Sistema ${pl.nome}` : 'Sistema de gestão Teloos';
  }
  const f = familias(prop.itens);
  const tot = prop.itens.filter((l) => l.kind === 'totem');
  const k = ['totem', 'catraca', 'comanda'].filter((x) => f.has(x));
  if (k.length > 1) return 'Projeto de automação NEXTCARD';
  if (k[0] === 'totem') return tot.length === 1 ? `${tot[0].qtd > 1 ? 'Totens' : 'Totem'} de autoatendimento ${tot[0].refId}` : 'Totens de autoatendimento Linha NX';
  if (k[0] === 'catraca') return 'Catracas de comandas Tecnibra';
  if (k[0] === 'comanda') return 'Comandas eletrônicas personalizadas';
  return 'Proposta comercial';
}

export function siglaDe(nome, cfg) {
  const r = (cfg.responsaveis || []).find((x) => x.nome === nome);
  if (r && r.sigla) return r.sigla.toUpperCase().slice(0, 3);
  return (nome || '').trim().charAt(0).toUpperCase();
}

export function emitir(prop, cfg) {
  const now = new Date();
  let numero = prop.numero;
  let proximo = cfg.proximoNumero;
  if (!numero) {
    numero = `${fmtDataCompacta(now)}/${proximo}${siglaDe(prop.responsavel, cfg)}`;
    proximo += 1;
  }
  return { numero, proximo, emitidaEm: prop.emitidaEm || now.toISOString() };
}

// Desconto efetivo sobre a tabela (só itens de catálogo; frete e itens livres ficam de fora).
// É a mesma conta que o servidor refaz na emissão; aqui serve para avisar o consultor antes.
export function descontoLocal(prop) {
  let base = 0, desconto = 0, avulso = false;
  for (const l of prop.itens || []) {
    if (l.kind === 'frete') continue;
    if (l.kind === 'avulso') { avulso = true; continue; }
    const q = isNil(l.qtd) ? 0 : l.qtd;
    let ref;
    if (l.kind === 'comanda') { const f = comandaFaixa(l.tiers, q); ref = f ? f.cents : 0; }
    else if (l.kind === 'plano' || l.kind === 'adicional') ref = l.tabelaCheia ?? l.tabela ?? 0;
    else ref = l.tabela ?? 0;
    const unit = isNil(l.preco) ? (l.kind === 'comanda' ? ref : l.tabela ?? 0) : l.preco;
    base += ref * q;
    if (unit < ref) desconto += (ref - unit) * q;
  }
  return { base, desconto, pct: base > 0 ? (desconto / base) * 100 : 0, avulso };
}
