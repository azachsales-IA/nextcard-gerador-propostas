import CAT from './catalog.json';
import { FOTOS_DRIVE_LISTA } from './fotos.js';

// Versão da configuração. Ao mudar, a configuração salva no navegador é substituída pela do código
// (propostas já emitidas mantêm os valores congelados nas próprias linhas).
export const CONFIG_VERSION = 'NX-2026.09-v2';

export const ETAPAS = [
  { id: 'rascunho', nome: 'Rascunho' },
  { id: 'enviada', nome: 'Enviada' },
  { id: 'negociacao', nome: 'Em negociação' },
  { id: 'ganho', nome: 'Ganho' },
  { id: 'perdido', nome: 'Perdido' },
];

export const SEGMENTOS = ['Restaurante', 'Bar / choperia', 'Posto / rede de postos', 'Lanchonete / fast food', 'Food court / praça de alimentação', 'Parque, lazer e eventos', 'Padaria / cafeteria', 'Hotel / clube', 'Franquia', 'Outro'];

// Biblioteca de fotos embutidas (id → descrição). Fotos enviadas em Configuração ficam no navegador.
// Primeiro as fotos oficiais do Drive (30/09); depois as anteriores, que continuam valendo para modelos sem foto nova.
const FOTOS_ANTERIORES = [
  { id: 'totem-pedestal-branco', nome: 'Totem pedestal · branco', familia: 'totem', formato: 'Pedestal' },
  { id: 'totem-pedestal-preto', nome: 'Totem pedestal · preto', familia: 'totem', formato: 'Pedestal' },
  { id: 'totem-bancada', nome: 'Totem bancada', familia: 'totem', formato: 'Bancada' },
  { id: 'totem-parede', nome: 'Totem parede', familia: 'totem', formato: 'Parede' },
  { id: 'catraca-expedidora-acoplada', nome: 'Expedidora com catraca acoplada', familia: 'catraca', tipo: 'Dispensadora' },
  { id: 'catraca-receptora-acoplada', nome: 'Receptora com catraca acoplada', familia: 'catraca', tipo: 'Receptora' },
  { id: 'catraca-expedidora-tecnew', nome: 'Expedidora de coluna + catraca', familia: 'catraca', tipo: 'Dispensadora' },
  { id: 'catraca-receptora-smart', nome: 'Receptora com urna + catraca Smart', familia: 'catraca', tipo: 'Receptora' },
];
export const FOTOS_PADRAO = [...FOTOS_DRIVE_LISTA, ...FOTOS_ANTERIORES.map((f) => ({ ...f, nome: `${f.nome} (foto anterior)` }))];

// Foto padrão por produto [VALIDAR COM OS FUNDADORES]: modelo com foto própria no Drive usa a dela;
// NX32-V, NX32-P, NX18,5-B e NX24-B usam a do modelo parecido; o resto continua com a foto anterior.
const FOTO_TOTEM = { 'NX24-V': 'totem-nx24v', 'NX32-V': 'totem-nx24v', 'NX24-P': 'totem-nx24p', 'NX32-P': 'totem-nx24p', 'NX21-B': 'totem-nx21b', 'NX24-B': 'totem-nx21b', 'NX15-B': 'totem-nx156b', 'NX18,5-B': 'totem-nx156b', 'NX18,5-H': 'totem-horizontal' };
const FOTO_CATRACA = { 'C120|Catraca acoplada': 'catraca-c120', 'C150|Catraca acoplada': 'catraca-c150', 'C180|Com catraca Smart': 'catraca-c180-smart', 'R120|Catraca acoplada': 'catraca-r120', 'R150|Catraca acoplada': 'catraca-r150', 'R100|Com catraca Smart': 'catraca-r100-smart', 'R200|Com catraca Smart': 'catraca-r200-smart' };
const FOTO_COMANDA = { '15x10': 'comanda-15x10', '14x8': 'comanda-14x8', '9x7x5': 'comanda-9x7', '9x7x3,5': 'comanda-9x7' };
function fotoCatracaAnterior(c) {
  if (c.variante === 'Catraca acoplada') return c.tipo === 'Receptora' ? 'catraca-receptora-acoplada' : c.tipo === 'Dispensadora' ? 'catraca-expedidora-acoplada' : null;
  if (c.tipo === 'Dispensadora' && c.variante === 'Com catraca Tecnew') return 'catraca-expedidora-tecnew';
  if (c.tipo === 'Receptora' && c.variante === 'Com catraca Smart') return 'catraca-receptora-smart';
  return null;
}
const fotoCatraca = (c) => FOTO_CATRACA[`${c.modelo}|${c.variante}`] || fotoCatracaAnterior(c);
// Mapeamento anterior (até 29/09): a migração troca só as fotos que ainda estão no padrão antigo
export const FOTOS_V1 = {
  totem: { 'NX24-V': 'totem-pedestal-branco', 'NX32-V': 'totem-pedestal-branco', 'NX18,5-B': 'totem-bancada', 'NX21-B': 'totem-bancada', 'NX24-B': 'totem-bancada', 'NX24-P': 'totem-parede', 'NX32-P': 'totem-parede' },
  catraca: fotoCatracaAnterior,
};
export const FOTOS_VERSAO = 2;
// Textos anteriores (até 04/10): a migração troca a infraestrutura só se ainda estiver no texto padrão antigo
export const INFRA_V1 = [
  'Local adequado para instalação, livre de dutos elétricos, hidráulicos ou outros itens que possam ser danificados',
  'Acabamentos, reparos em gesso e concreto, canaletas, furos e adaptações de layout',
  'Ponto de alimentação 110/220 V estabilizado e disjuntores dedicados aos equipamentos',
  'Ponto de rede habilitado próximo ao equipamento, estruturado e crimpado conforme o padrão da rede',
  'Servidor (PC) disponível para o software, se necessário, com rede até o equipamento, switch/hub em área protegida',
  'Pessoa habilitada para receber o treinamento e as instruções',
];
export const TEXTOS_VERSAO = 2;

export function defaultConfig() {
  return {
    version: CONFIG_VERSION,
    fotosVersao: FOTOS_VERSAO,
    textosVersao: TEXTOS_VERSAO,
    proximoNumero: 1218,
    responsaveis: [],
    nextcard: {
      empresa: {
        nome: 'NEXTCARD',
        descritor: 'Automação Comercial',
        whatsapp: '(41) 99550-7759',
        site: 'www.nextcard.com.br',
        email: '',
        validadePadrao: '7c',
      },
      arredondamento: '5',
      modalidades: [
        { id: 'direta', nome: 'Venda direta', descricao: 'Cliente final. Valor de tabela. Faturamento NEXTCARD.', fatorTotem: 1 },
        { id: 'revenda', nome: 'Revenda (parceiro)', descricao: 'Parceiro revendedor: 6% de desconto sobre a tabela de totens.', fatorTotem: 0.94 },
        { id: 'indicacao', nome: 'Indicação (parceiro)', descricao: 'Parceiro indica; cliente compra pelo valor de tabela.', fatorTotem: 1 },
      ],
      condicoes: [
        { id: 'pix', nome: 'À vista (PIX)', tipo: 'avista', fator: 1, parcelas: 0, entradaPadrao: 0, padrao: true },
        { id: 'bol28', nome: 'Entrada + saldo em 28 dias (boleto)', tipo: 'boleto', fator: 1.025, parcelas: 1, prazos: '28', entradaPadrao: 50, mediante: true, padrao: true },
        { id: 'bol2856', nome: 'Entrada + saldo em 28/56 dias (boleto)', tipo: 'boleto', fator: 1.051, parcelas: 2, prazos: '28/56', entradaPadrao: 50, mediante: true, padrao: true },
        { id: 'bol214263', nome: 'Boleto 21/42/63 dias', tipo: 'boleto', fator: null, parcelas: 3, prazos: '21/42/63', entradaPadrao: 0, mediante: true },
        { id: 'cc1', nome: 'Cartão de crédito 1x', tipo: 'cartao', fator: null, parcelas: 1, entradaPadrao: 0 },
        { id: 'cc3', nome: 'Cartão de crédito até 3x', tipo: 'cartao', fator: null, parcelas: 3, entradaPadrao: 0 },
        { id: 'cc6', nome: 'Cartão de crédito até 6x', tipo: 'cartao', fator: 1.077, parcelas: 6, entradaPadrao: 0, padrao: true },
        { id: 'cc12', nome: 'Cartão de crédito até 12x', tipo: 'cartao', fator: null, parcelas: 12, entradaPadrao: 0 },
      ],
      totem: { ...CAT.totem, modelos: CAT.totem.modelos.map((m) => ({ ...m, foto: FOTO_TOTEM[m.id] || null })) },
      catracas: CAT.catracas.map((c) => ({ ...c, foto: fotoCatraca(c) })),
      comandas: CAT.comandas.map((c) => ({ ...c, foto: FOTO_COMANDA[c.tamanho] || null })),
      servicos: [
        { id: 'SRV-INST', codigo: 'SRV-INST', nome: 'Deslocamento, instalação e treinamento', spec: 'Equipe NEXTCARD · integração, testes e treinamento prático', cents: 245000 },
      ],
      inclusos: {
        totem: ['Garantia on-site de 12 meses', 'Suporte técnico remoto via WhatsApp e e-mail', 'Fabricação própria 100% nacional', 'Estrutura em aço carbono com pintura eletrostática'],
        catraca: ['Garantia de 1 ano direto da fábrica', 'Suporte remoto gratuito por 90 dias', 'Equipamento robusto, sem contrato de manutenção', 'Documentação de integração com o seu software'],
        comanda: ['Comandas personalizadas com a sua marca', 'Fabricação própria NEXTCARD'],
        servico: ['Instalação, integração e treinamento pela equipe NEXTCARD'],
      },
      prazos: {
        totem: ['Embarque em até 20 dias úteis após a aprovação do pedido', 'Suporte técnico remoto: WhatsApp e e-mail, com SLA padrão de até 2 dias úteis', 'Garantia on-site: 12 meses'],
        catraca: ['Fornecimento das catracas em até 20 dias úteis após a aprovação da proposta', 'Instalação após a entrega, conforme agenda do cliente', 'Garantia: equipamento 1 ano direto da fábrica (balcão) e instalação 3 meses', 'Suporte remoto gratuito por 90 dias em horário comercial; suporte presencial sob agendamento (deslocamento e hora técnica a consultar)'],
        comanda: ['Produção iniciada após a aprovação da arte e a confirmação do pagamento'],
        geral: ['Liberação do pedido após a confirmação do pagamento de entrada ou aprovação financeira'],
      },
      prazoCurto: { totem: 'Embarque em até 20 dias úteis', catraca: 'Fornecimento em até 20 dias úteis', comanda: 'Produção após aprovação da arte', servico: 'Instalação conforme agenda' },
      // Infraestrutura (responsabilidade do cliente). Uma linha por item; linha que começa com "- " é subitem do anterior
      // e "Rótulo: texto" destaca o rótulo. Revisado em 05/10 (texto enviado pelo Gabriel).
      infraCatraca: [
        'Local adequado para instalação, livre de interferências elétricas, hidráulicas ou outros elementos que possam ser danificados.',
        'Infraestrutura elétrica e de rede:',
        '- Catraca de Entrada: alimentação estabilizada 110/220V, disjuntor dedicado e cabo com conector fêmea de 3 pinos.',
        '- Catraca de Saída: mesmos requisitos da entrada, mais ponto de rede com cabo e conector RJ45.',
        'Servidor ou computador e infraestrutura de rede para comunicação dos equipamentos.',
        'Adequações civis e acabamentos necessários à instalação, incluindo furos, canaletas e adaptações no espaço físico.',
        'Pessoa responsável para receber treinamento e orientações.',
      ],
      // Integração das catracas: 1º parágrafo = como funciona; 2º = destaque (software comunicador)
      integracaoCatraca: [
        'A integração será realizada pelo nosso time técnico junto ao software de PDV do cliente, ficando sob responsabilidade do cliente e/ou de seu fornecedor as adequações necessárias. Forneceremos o suporte e a documentação técnica para o processo.',
        'Caso o sistema de PDV do cliente não possua integração compatível, disponibilizamos software comunicador mediante contratação adicional. Consulte valores e condições.',
      ],
      rodape: { impostos: 'Sujeitas à análise de crédito' },
      fraseFinal: 'Um contrato comercial leva mais que a nossa assinatura, leva nossa palavra.',
      // frases pedidas pelo Hamilton (05/10): abertura na capa do PDF; encerramento no fim do detalhamento
      fraseAbertura: 'Escolher nossa solução e know-how é certeza da entrega de resultados reais para seu projeto.',
      fraseEncerramento: 'Nossos objetivos vão muito além do que um simples processo de venda!',
    },
    teloos: {
      empresa: {
        nome: 'Teloos',
        descritor: 'Sistemas Integrados',
        whatsapp: '',
        site: 'teloos.com.br',
        email: '',
        validadePadrao: '7c',
        tagline: 'transformando negócios food em receitas de grande sucesso!',
      },
      modalidades: [{ id: 'assinatura', nome: 'Assinatura do sistema', descricao: 'Plano mensal + implantação. Sem fidelidade.' }],
      planos: CAT.teloosPlanos,
      adicionais: CAT.teloosAdicionais,
      periodicidades: [
        { id: 'mensal', nome: 'Mensal', forma: 'boleto', fator: 1, meses: 1, padrao: true },
        { id: 'semestral', nome: 'Semestral', forma: 'parcelado', fator: 0.93, meses: 6 },
        { id: 'anualcartao', nome: 'Anual', forma: 'cartão de crédito', fator: 0.85, meses: 12, padrao: true },
        { id: 'anualpix', nome: 'Anual à vista', forma: 'PIX', fator: 0.8, meses: 12, avista: true, padrao: true },
      ],
      implantacao: [
        { id: 'padrao', nome: 'Treinamento e implantação', cents: 95000, validadeDias: null },
        { id: 'semanal', nome: 'Condição especial da semana', cents: 75000, validadeDias: 7 },
        { id: 'd1', nome: 'Pagamento até amanhã (D+1)', cents: 65000, validadeDias: 1 },
        { id: 'imediato', nome: 'Pagamento imediato', cents: 55000, validadeDias: 0 },
      ],
      cupons: [0, 5, 10],
      inclusosExtras: ['Sem fidelidade'],
      prazos: ['Sem fidelidade contratual', 'Implantação e treinamento pagos à vista', 'Suporte conforme o plano contratado'],
      rodape: { impostos: 'Mensalidade recorrente' },
      fraseFinal: 'Teloos — transformando negócios food em receitas de grande sucesso!',
    },
  };
}

// Pontos que dependem de confirmação dos fundadores. Aparecem em Política e Configuração.
export const PENDENCIAS = [
  { tema: 'Simulador de pagamentos', texto: 'Fatores de acréscimo por condição (boleto 28 e 28/56 dias ≈ 2,5% e 5,1%; cartão 6x ≈ 7,7%) foram deduzidos das propostas 1208H e 1217H. Cartão 1x, 3x, 12x e boleto 21/42/63 estão sem fator: cole o valor do simulador oficial até a confirmação.' },
  { tema: 'Prazos do boleto', texto: 'A política V2/2026 fala em 7/21 e 21/42/63 dias; as propostas enviadas usam 28 e 28/56 dias.' },
  { tema: 'Arredondamento', texto: 'As propostas enviadas arredondam valores com acréscimo para múltiplos de R$ 5. Regra aplicada por padrão até a confirmação.' },
  { tema: 'Validade', texto: 'Decidido em 29/09: 2, 3 ou 5 dias úteis ou 7 dias, escolhido em cada proposta. Dias úteis contam seg–sex e excluem feriados nacionais; confirmar se feriados estaduais e municipais também entram.' },
  { tema: 'Frete', texto: 'Decidido em 29/09: CIF (NEXTCARD) ou FOB (destinatário) em cada proposta. Confirmar se qualquer consultor pode escolher CIF.' },
  { tema: 'Totens', texto: 'A proposta 1208H (R$ 15.314,00) não corresponde a nenhuma configuração da tabela V7. Os preços da tabela de parceiros batem com a V7.' },
  { tema: 'Fotos', texto: 'Fotos oficiais do Drive (30/09) com fundo recortado. Foto própria: NX24-V, NX24-P, NX21-B, NX15,6-B (usada no NX15-B), totem horizontal (NX18,5-H), expedidoras C120, C150 e C180 + Smart, receptoras R120, R150, R100 + Smart e R200 + Smart, comandas 15 × 10, 14 × 8 e 9 × 7. Por aparência: NX32-V (foto do NX24-V), NX32-P (NX24-P), NX18,5-B (NX15,6-B), NX24-B (NX21-B) e comanda 9 × 7 × 3,5 (9 × 7). Sem foto nova (continuam com a anterior ou sem foto): C250, variantes Tecnew, R300, RD120 e variantes sem catraca. Topdata Fit e cartão comanda ficam na biblioteca, sem produto no catálogo.' },
  { tema: 'Revenda', texto: 'Desconto de 6% para revenda está na tabela de parceiros de totens. Confirmar se vale para catracas e comandas.' },
  { tema: 'Catracas', texto: 'A proposta 1217H usa preços diferentes da tabela Tecnibra V1/2026 (C120 receptora 13.480 × 13.450; C150 9.950 × 9.650; receptora C150 11.675 × 11.300). Confirmar tabela vigente, capacidade de comandas por modelo e pareamento receptora ↔ expedidora.' },
  { tema: 'Comandas', texto: 'Tabela V1/2025: confirmar se está vigente, lote mínimo (primeira faixa = 30 un.) e preço acima de 1.000 unidades.' },
  { tema: 'Serviços', texto: 'Deslocamento, instalação e treinamento (R$ 2.450,00 na proposta 1217H): valor fixo ou por região?' },
  { tema: 'Rodapé', texto: 'Texto sobre impostos (inclusos ou destacados) e prazo de produção de comandas.' },
  { tema: 'Teloos — preços', texto: 'A planilha Planos 2026 traz dois preços por plano: aba "PLANO FOOD TELOOS" (189 / 339 / 469 / 629 / 339) e aba "Planilha1" (189 / 364 / 614 / 564 / 624). O gerador usa a primeira.' },
  { tema: 'Teloos — periodicidade', texto: 'Semestral −7% (Autoatendimento mostra −10%); anual no cartão −15%; anual à vista −20% (a coluna diz −15%). Confirmar se o desconto vale também para os adicionais.' },
  { tema: 'Teloos — adicionais', texto: 'TEF Elgin está como "Ver tabela" (sem preço). TEF Destaxa diverge entre a aba de planos (125 / 180 / 35) e as observações (75 / 95 / 30).' },
  { tema: 'Teloos — cupom', texto: 'Cupom do consultor (5% e 10%, 2 de cada por mês, 1 por cliente): confirmar se incide só no plano ou também nos adicionais.' },
  { tema: 'Numeração', texto: 'Formato observado: DDMMAAAA/sequencial + sigla (ex.: 1217H). Sequência começa em 1218 e a sigla vem do consultor.' },
  { tema: 'Consultores', texto: 'Cadastrar nomes, siglas e contatos dos consultores em Configuração.' },
];
