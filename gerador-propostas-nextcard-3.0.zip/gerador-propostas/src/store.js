import { CONFIG_VERSION, defaultConfig, FOTOS_V1, FOTOS_VERSAO, INFRA_V1, TEXTOS_VERSAO } from './defaults.js';

const K = { config: 'nxp.config', props: 'nxp.propostas', photos: 'nxp.fotos', ui: 'nxp.ui', perfil: 'nxp.perfil' };
const mem = {};
let persistente = true;

function testStorage() {
  try {
    const k = '__nxp_test__';
    window.localStorage.setItem(k, '1');
    window.localStorage.removeItem(k);
    return true;
  } catch (e) {
    return false;
  }
}
persistente = typeof window !== 'undefined' && testStorage();

export const storageOk = () => persistente;

function read(key, fallback) {
  try {
    if (persistente) {
      const v = window.localStorage.getItem(key);
      return v === null ? fallback : JSON.parse(v);
    }
  } catch (e) { /* cai para memória */ }
  return key in mem ? mem[key] : fallback;
}

// Retorna { ok, quota } — quota=true quando o navegador recusou por falta de espaço
function write(key, value) {
  mem[key] = value;
  if (!persistente) return { ok: false, quota: false };
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
    return { ok: true };
  } catch (e) {
    const quota = e && (e.name === 'QuotaExceededError' || e.code === 22 || e.code === 1014);
    return { ok: false, quota };
  }
}

export function loadConfig() {
  const saved = read(K.config, null);
  if (!saved) return { config: defaultConfig(), aviso: null };
  if (saved.version !== CONFIG_VERSION) {
    const fresh = defaultConfig();
    // preserva cadastros locais que não fazem parte da política (consultores e numeração)
    fresh.responsaveis = saved.responsaveis || [];
    if (saved.proximoNumero && saved.proximoNumero > fresh.proximoNumero) fresh.proximoNumero = saved.proximoNumero;
    write(K.config, fresh);
    return { config: fresh, aviso: `Política atualizada para a versão ${CONFIG_VERSION}` };
  }
  const fresh = defaultConfig();
  const mFotos = migraFotos(saved, fresh), mTextos = migraTextos(saved, fresh);
  if (mFotos || mTextos) write(K.config, saved);
  return { config: saved, aviso: null };
}

// Fotos novas (30/09): troca só as fotos que ainda estão no padrão anterior; escolhas feitas em Configuração ficam
export function migraFotos(saved, fresh) {
  if ((saved.fotosVersao || 1) >= FOTOS_VERSAO || !saved.nextcard) return false;
  const N = saved.nextcard, F = fresh.nextcard;
  const novo = (lista, id) => (lista.find((x) => x.id === id) || {}).foto;
  for (const m of N.totem?.modelos || []) if ((m.foto || null) === (FOTOS_V1.totem[m.id] || null) && novo(F.totem.modelos, m.id) !== undefined) m.foto = novo(F.totem.modelos, m.id);
  for (const c of N.catracas || []) if ((c.foto || null) === FOTOS_V1.catraca(c) && novo(F.catracas, c.id) !== undefined) c.foto = novo(F.catracas, c.id);
  for (const c of N.comandas || []) if (c.foto === undefined && novo(F.comandas, c.id) !== undefined) c.foto = novo(F.comandas, c.id);
  saved.fotosVersao = FOTOS_VERSAO;
  return true;
}
// Textos novos (05/10): infraestrutura troca só se ainda estiver no texto padrão antigo; campos novos entram com o padrão
export function migraTextos(saved, fresh) {
  if ((saved.textosVersao || 1) >= TEXTOS_VERSAO || !saved.nextcard) return false;
  const N = saved.nextcard, F = fresh.nextcard;
  if (JSON.stringify(N.infraCatraca || []) === JSON.stringify(INFRA_V1)) N.infraCatraca = F.infraCatraca;
  for (const k of ['integracaoCatraca', 'fraseAbertura', 'fraseEncerramento']) if (N[k] === undefined) N[k] = F[k];
  saved.textosVersao = TEXTOS_VERSAO;
  return true;
}
export const saveConfig = (c) => write(K.config, c);

export const loadPropostas = () => read(K.props, []);
export const savePropostas = (p) => write(K.props, p);

export const loadFotos = () => read(K.photos, {});
export const saveFotos = (f) => write(K.photos, f);

export const loadUI = () => read(K.ui, {});
export const saveUI = (u) => write(K.ui, u);

// Perfil do consultor que usa este navegador (nome, sigla, WhatsApp, e-mail)
export const loadPerfil = () => read(K.perfil, null);
export const savePerfil = (p) => write(K.perfil, p);

// Identificador de proposta (UUID): o mesmo id vale no navegador e no banco
export function novoId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => { const r = (Math.random() * 16) | 0; return (c === 'x' ? r : (r & 3) | 8).toString(16); });
}

export function uid() {
  return Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
}

// Reduz imagem enviada pelo usuário (logo do cliente / foto de produto) para caber no armazenamento
export function fileToDataURL(file, maxSide = 900, type = 'image/webp', quality = 0.88) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onerror = reject;
    fr.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const s = Math.min(1, maxSide / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * s);
        c.height = Math.round(img.height * s);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        let out = c.toDataURL(type, quality);
        if (!out.startsWith('data:image/webp')) out = c.toDataURL('image/png');
        resolve(out);
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}
