// Servidor local: API + dist/index.html. Uso: DATABASE_URL=... node scripts/dev.mjs [porta]
import http from 'node:http';
import fs from 'node:fs';
import { handler } from '../server/app.js';
const porta = Number(process.argv[2] || process.env.PORT || 5173);
http.createServer((req, res) => {
  if (req.url.startsWith('/api/')) return handler(req, res);
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  fs.createReadStream(new URL('../dist/index.html', import.meta.url)).pipe(res);
}).listen(porta, () => console.log('http://localhost:' + porta));
