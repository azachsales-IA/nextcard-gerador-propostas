// Implantação: aplica migrações, publica a configuração inicial (se não houver) e cria o proprietário administrativo.
// Uso: DATABASE_URL=... OWNER_EMAIL=... OWNER_NOME=... OWNER_SENHA=... [OWNER_SIGLA=HF] [OWNER_APROVADOR=1] [SEQ_INICIAL=1276] node scripts/setup.mjs
// Nada é sobrescrito: se já existir configuração, proprietário ou sequência, o passo é ignorado.
import fs from 'node:fs';
import { q, migrate, closePool } from '../server/db.js';
import { hashSenha, senhaForte } from '../server/auth.js';
import { validarConfig } from '../server/policy.js';

await migrate();
console.log('migrações: ok');
const cv = await q('select count(*)::int as n from config_versions');
if (cv.rows[0].n === 0) {
  const data = JSON.parse(fs.readFileSync(new URL('../db/seed/config.json', import.meta.url), 'utf8'));
  const e = validarConfig(data);
  if (e.length) { console.error('seed inválido:', e); process.exit(1); }
  await q("insert into config_versions (version, data, nota) values (1, $1, 'Configuração inicial (tabelas V7/2026, Tecnibra V1/2026, comandas V1/2025, Teloos 2026) — validar antes do uso')", [data]);
  console.log('configuração inicial publicada como v1');
} else console.log('configuração existente preservada');

const own = await q("select count(*)::int as n from users where 'owner' = any(roles)");
if (own.rows[0].n === 0) {
  const { OWNER_EMAIL, OWNER_NOME, OWNER_SENHA, OWNER_SIGLA = '', OWNER_APROVADOR } = process.env;
  if (!OWNER_EMAIL || !OWNER_NOME || !senhaForte(OWNER_SENHA)) { console.error('Defina OWNER_EMAIL, OWNER_NOME e OWNER_SENHA (10+ caracteres, letras e números).'); process.exit(1); }
  const roles = OWNER_APROVADOR === '1' ? ['owner', 'aprovador'] : ['owner'];
  await q('insert into users (email, nome, sigla, roles, pass_hash) values ($1, $2, $3, $4, $5)', [OWNER_EMAIL.toLowerCase(), OWNER_NOME, OWNER_SIGLA.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 3), roles, hashSenha(OWNER_SENHA)]);
  console.log('proprietário criado:', OWNER_EMAIL, roles.join('+'));
} else console.log('proprietário existente preservado');

const sq = await q('select proximo from sequencia where id = 1');
if (!sq.rows[0]) {
  const n = Number(process.env.SEQ_INICIAL);
  if (Number.isInteger(n) && n > 0) { await q('insert into sequencia (id, proximo) values (1, $1)', [n]); console.log('numeração inicia em', n); }
  else console.log('ATENÇÃO: numeração não configurada (defina SEQ_INICIAL ou ajuste em Administração → Numeração). Emissão bloqueada até lá.');
} else console.log('numeração preservada: próximo =', sq.rows[0].proximo);
await closePool();
